#!/usr/bin/env bash
# tcm19 node: turns this server into an extra server for your main tcm19 panel.
#   bash install-node.sh            install / update the node agent (+ Xray) and print the join code
#   bash install-node.sh show       print the join code again
#   bash install-node.sh uninstall  remove the agent (Xray is left installed)
# Optional env: NODE_PORT=8443
set -euo pipefail
H=/opt/tcm19-node
say()  { printf '\n\033[1;36m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m[!] %s\033[0m\n' "$*"; }
die()  { printf '\033[1;31m[x] %s\033[0m\n' "$*"; exit 1; }
[ "$(id -u)" = 0 ] || die "Run as root"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"

join_code() {
  python3 - "$H" <<'PY'
import base64, hashlib, json, subprocess, sys
h = sys.argv[1]
sec = open(h + "/secret").read().strip()
port = open(h + "/port").read().strip()
der = subprocess.run(["openssl", "x509", "-in", h + "/cert.pem", "-outform", "der"], capture_output=True, check=True).stdout
fp = hashlib.sha256(der).hexdigest()
raw = json.dumps({"p": int(port), "s": sec, "f": fp}, separators=(",", ":")).encode()
print("tcmn1." + base64.urlsafe_b64encode(raw).decode().rstrip("="))
PY
}
show() {
  [ -f "$H/secret" ] || die "Node is not installed"
  IP="$(curl -fsS4 -m 6 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')"
  echo
  echo "  Server address : $IP"
  echo "  Join code      :"
  echo
  join_code
  echo
  echo "In the main panel: Servers -> Add server, paste the address and this join code."
}

case "${1:-install}" in
  show) show; exit 0 ;;
  uninstall)
    systemctl disable --now tcm19-node >/dev/null 2>&1 || true
    rm -f /etc/systemd/system/tcm19-node.service; systemctl daemon-reload
    rm -rf "$H"; echo "Node agent removed (Xray left installed)."; exit 0 ;;
esac

[ -f "$HERE/app/node_agent.py" ] || die "app/node_agent.py not found next to this script"
say "Installing packages"
export DEBIAN_FRONTEND=noninteractive
apt-get update -y >/dev/null 2>&1 || warn "apt update had errors"
apt-get install -y python3 openssl curl ca-certificates unzip >/dev/null 2>&1 || die "Could not install packages"

if ! command -v xray >/dev/null 2>&1 && [ ! -x /usr/local/bin/xray ]; then
  say "Installing Xray"
  bash -c "$(curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install || die "Xray install failed"
fi
systemctl enable xray >/dev/null 2>&1 || true

say "Installing the node agent"
mkdir -p "$H"; chmod 700 "$H"
install -m 755 "$HERE/app/node_agent.py" "$H/node_agent.py"
if [ ! -f "$H/secret" ]; then
  openssl rand -hex 24 > "$H/secret"; chmod 600 "$H/secret"
fi
if [ ! -f "$H/port" ]; then echo "${NODE_PORT:-8443}" > "$H/port"; fi
if [ ! -f "$H/cert.pem" ]; then
  openssl req -x509 -newkey ec -pkeyopt ec_paramgen_curve:prime256v1 -nodes -days 3650 -subj "/CN=tcm19-node" \
    -keyout "$H/key.pem" -out "$H/cert.pem" >/dev/null 2>&1 || die "Could not create the certificate"
  chmod 600 "$H/key.pem"
fi
PORT="$(cat "$H/port")"
cat > /etc/systemd/system/tcm19-node.service <<UNIT
[Unit]
Description=tcm19 node agent
After=network.target

[Service]
User=root
Environment=NODE_PORT=$PORT NODE_HOME=$H
ExecStart=/usr/bin/python3 $H/node_agent.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable tcm19-node >/dev/null 2>&1
systemctl restart tcm19-node
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "$PORT/tcp" >/dev/null 2>&1 && echo "ufw: opened $PORT/tcp"
fi
sleep 1
systemctl is-active --quiet tcm19-node || die "Agent did not start: journalctl -u tcm19-node"
say "Node is ready"
show
