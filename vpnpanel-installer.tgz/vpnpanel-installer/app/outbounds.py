"""Outbounds + routing rules.

Built-in outbounds: direct, block.  Managed ones (rows in the `outbounds` table):
  warp        Cloudflare WARP (WireGuard, account registered by the panel)
  tor         local Tor client (SOCKS on 127.0.0.1)
  psiphon     Psiphon through warp-plus --cfon (SOCKS on 127.0.0.1)
  socks/http/shadowsocks/wireguard   an upstream you already have

Everything here is pure (no FastAPI) except the service / WARP / test helpers at the bottom.
"""
import base64
import ipaddress
import json
import re
import secrets
import shutil
import subprocess
import threading
import time
import urllib.request
from pathlib import Path

from . import config, db

TAG_RE = re.compile(r"^[A-Za-z0-9_-]{2,32}$")
RESERVED_TAGS = {"direct", "block", "api"}
TYPES = ("warp", "tor", "psiphon", "socks", "http", "shadowsocks", "wireguard")
SINGLETON_TYPES = ("tor", "psiphon")          # one local instance each
SS_METHODS = ("chacha20-ietf-poly1305", "aes-256-gcm", "aes-128-gcm",
              "2022-blake3-aes-128-gcm", "2022-blake3-aes-256-gcm")
PSIPHON_COUNTRIES = ("AT BE BG BR CA CH CZ DE DK EE ES FI FR GB HR HU IE IN IT JP LV NL NO PL PT RO RS SE SG SK UA US").split()

LOCAL_PORT = {"tor": 19050, "psiphon": 18086}
TEST_BASE_PORT = 10100                         # direct = 10100, enabled outbounds follow
TEST_TAG_PREFIX = "tcm19test-"
MAX_OUTBOUNDS = 80
MAX_RULES = 200
WARP_DEFAULT_ENDPOINT = "162.159.192.1:2408"
WARP_PEER_KEY = "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="

RESERVED_PORTS = {10085, *range(TEST_BASE_PORT, TEST_BASE_PORT + 100), *LOCAL_PORT.values()}


class OutboundError(Exception):
    def __init__(self, msg: str, code: int = 400):
        super().__init__(msg)
        self.code = code


# ------------------------------------------------------------------ validation helpers
def _host(v, what="آدرس") -> str:
    v = str(v or "").strip()
    if not v:
        raise OutboundError(f"{what} را وارد کن")
    try:
        ipaddress.ip_address(v.strip("[]"))
        return v.strip("[]")
    except ValueError:
        pass
    if not re.fullmatch(r"[A-Za-z0-9]([A-Za-z0-9.-]{0,251}[A-Za-z0-9])?", v):
        raise OutboundError(f"{what} معتبر نیست")
    return v


def _port(v, what="پورت") -> int:
    try:
        p = int(v)
    except (TypeError, ValueError):
        raise OutboundError(f"{what} باید عدد باشد")
    if not 1 <= p <= 65535:
        raise OutboundError(f"{what} باید بین ۱ تا ۶۵۵۳۵ باشد")
    return p


def _b64key(v, what) -> str:
    v = str(v or "").strip()
    try:
        if len(base64.b64decode(v, validate=True)) != 32:
            raise ValueError
    except Exception:
        raise OutboundError(f"{what} معتبر نیست (باید کلید base64 با ۳۲ بایت باشد)")
    return v


def _addresses(v) -> list[str]:
    items = v if isinstance(v, list) else re.split(r"[,\s]+", str(v or ""))
    out = []
    for a in items:
        a = str(a).strip()
        if not a:
            continue
        try:
            ifc = ipaddress.ip_interface(a)
        except ValueError:
            raise OutboundError(f"آدرس WireGuard معتبر نیست: {a}")
        out.append(f"{ifc.ip}/{ifc.network.prefixlen if '/' in a else ifc.max_prefixlen}")
    if not out:
        raise OutboundError("آدرس داخلی WireGuard را وارد کن (مثلاً 172.16.0.2/32)")
    return out


def _reserved(v) -> list[int]:
    if v in (None, "", []):
        return []
    items = v if isinstance(v, list) else re.split(r"[,\s]+", str(v).strip())
    try:
        r = [int(x) for x in items if str(x) != ""]
    except ValueError:
        raise OutboundError("Reserved باید سه عدد بین ۰ تا ۲۵۵ باشد، مثل 12,34,56")
    if len(r) != 3 or any(not 0 <= x <= 255 for x in r):
        raise OutboundError("Reserved باید سه عدد بین ۰ تا ۲۵۵ باشد، مثل 12,34,56")
    return r


def _endpoint(v, default="") -> tuple[str, int]:
    v = str(v or default).strip()
    host, sep, port = v.rpartition(":")
    if not sep:
        raise OutboundError("Endpoint باید به شکل host:port باشد")
    return _host(host, "Endpoint"), _port(port, "پورت Endpoint")


# ------------------------------------------------------------------ outbound normalisation
def normalize_outbound(data: dict, others: list[dict], existing: dict | None = None) -> dict:
    tag, typ = data["tag"], data["type"]
    if typ not in TYPES:
        raise OutboundError("نوع اوتباند پشتیبانی نمی‌شود")
    if tag in RESERVED_TAGS or tag.startswith(TEST_TAG_PREFIX):
        raise OutboundError(f"تگ «{tag}» رزرو است؛ یک نام دیگر بگذار")
    me = (existing or {}).get("id")
    for o in others:
        if o["id"] == me:
            continue
        if o["tag"] == tag:
            raise OutboundError(f"تگ «{tag}» از قبل وجود دارد", 409)
        if typ in SINGLETON_TYPES and o["type"] == typ:
            raise OutboundError(f"فقط یک اوتباند {typ} می‌توانی داشته باشی (از همان برای همه‌ی قانون‌ها استفاده کن)", 409)
    if not existing and len(others) >= MAX_OUTBOUNDS:
        raise OutboundError("تعداد اوتباندها به سقف رسیده")
    if existing and existing["type"] != typ:
        raise OutboundError("نوع اوتباند بعد از ساخت قابل تغییر نیست؛ حذف و دوباره بساز")

    s = dict(data.get("settings") or {})
    old = (existing or {}).get("settings", {})
    clean: dict = {}

    if typ in ("socks", "http"):
        clean = {"address": _host(s.get("address")), "port": _port(s.get("port")),
                 "username": str(s.get("username") or "").strip(), "password": str(s.get("password") or "")}
        if bool(clean["username"]) != bool(clean["password"]):
            raise OutboundError("نام کاربری و رمز را هر دو پر کن یا هر دو را خالی بگذار")
    elif typ == "shadowsocks":
        method = s.get("method") or "chacha20-ietf-poly1305"
        if method not in SS_METHODS:
            raise OutboundError("متد Shadowsocks پشتیبانی نمی‌شود")
        if not s.get("password"):
            raise OutboundError("رمز Shadowsocks را وارد کن")
        clean = {"address": _host(s.get("address")), "port": _port(s.get("port")),
                 "method": method, "password": str(s["password"])}
    elif typ in ("wireguard", "warp"):
        if typ == "warp" and not s.get("private_key") and old.get("private_key"):
            s = {**old, **{k: v for k, v in s.items() if v not in (None, "")}}
        if typ == "warp" and not s.get("private_key"):
            raise OutboundError("حساب WARP ساخته نشده است")
        host, port = _endpoint(s.get("endpoint"), WARP_DEFAULT_ENDPOINT if typ == "warp" else "")
        clean = {
            "private_key": _b64key(s.get("private_key"), "کلید خصوصی"),
            "address": _addresses(s.get("address")),
            "peer_public_key": _b64key(s.get("peer_public_key") or (WARP_PEER_KEY if typ == "warp" else ""),
                                       "کلید عمومی سرور"),
            "endpoint": f"{host}:{port}" if ":" not in host else f"[{host}]:{port}",
            "reserved": _reserved(s.get("reserved")),
            "mtu": int(s.get("mtu") or 1280),
        }
        if not 1000 <= clean["mtu"] <= 1500:
            raise OutboundError("MTU باید بین ۱۰۰۰ تا ۱۵۰۰ باشد")
        if s.get("preshared_key"):
            clean["preshared_key"] = _b64key(s["preshared_key"], "Preshared key")
        if typ == "warp":
            for k in ("license", "account_id"):
                if s.get(k):
                    clean[k] = str(s[k]).strip()
            if clean.get("license") and not re.fullmatch(r"[A-Za-z0-9]{8}-[A-Za-z0-9]{8}-[A-Za-z0-9]{8}", clean["license"]):
                raise OutboundError("لایسنس WARP+ باید شبیه xxxxxxxx-xxxxxxxx-xxxxxxxx باشد")
    elif typ == "tor":
        cc = str(s.get("exit_country") or "").strip().lower()
        if cc and not re.fullmatch(r"[a-z]{2}", cc):
            raise OutboundError("کد کشور خروجی Tor باید دو حرف باشد، مثل de")
        clean = {"exit_country": cc}
    elif typ == "psiphon":
        cc = str(s.get("country") or "DE").strip().upper()
        if cc not in PSIPHON_COUNTRIES:
            raise OutboundError("کشور Psiphon پشتیبانی نمی‌شود")
        key = str(s.get("warp_key") or "").strip()
        if key and not re.fullmatch(r"[A-Za-z0-9-]{8,64}", key):
            raise OutboundError("کلید WARP+ معتبر نیست")
        clean = {"country": cc, **({"warp_key": key} if key else {})}

    return {"tag": tag, "remark": str(data.get("remark") or "")[:80], "type": typ, "settings": clean,
            "enabled": bool(data.get("enabled", True))}


# ------------------------------------------------------------------ rule normalisation
_DOMAIN_PREFIX = re.compile(r"^(geosite|domain|full|keyword|regexp):(.+)$")
_GEOIP = re.compile(r"^geoip:!?[a-z0-9_-]{1,32}$")
_PORT = re.compile(r"^\d{1,5}(-\d{1,5})?(,\d{1,5}(-\d{1,5})?)*$")
PROTOCOLS = ("http", "tls", "bittorrent", "quic")


def _tokens(v, what, limit=500) -> list[str]:
    items = v if isinstance(v, list) else re.split(r"[\n,]+", str(v or ""))
    out = []
    for t in items:
        t = str(t).strip()
        if not t:
            continue
        if len(t) > 200 or re.search(r"\s", t):
            raise OutboundError(f"مقدار نامعتبر در {what}: {t[:40]}")
        out.append(t)
    if len(out) > limit:
        raise OutboundError(f"تعداد مقدارها در {what} بیشتر از {limit} است")
    return list(dict.fromkeys(out))


def normalize_rule(data: dict, outbound_tags: set[str], inbound_tags: set[str]) -> dict:
    m = {}
    tags = _tokens(data.get("inbound_tags"), "اینباندها")
    bad = [t for t in tags if t not in inbound_tags]
    if bad:
        raise OutboundError(f"اینباند ناشناخته: {bad[0]}")
    if tags:
        m["inbound_tags"] = tags

    domains = _tokens(data.get("domain"), "دامنه‌ها")
    for d in domains:
        mt = _DOMAIN_PREFIX.match(d)
        if mt and mt.group(1) == "geosite" and not re.fullmatch(r"[A-Za-z0-9!@._-]+", mt.group(2)):
            raise OutboundError(f"نام geosite معتبر نیست: {d}")
        if mt and mt.group(1) == "regexp":
            try:
                re.compile(mt.group(2))
            except re.error:
                raise OutboundError(f"regexp معتبر نیست: {d}")
    if domains:
        m["domain"] = domains

    ips = _tokens(data.get("ip"), "آی‌پی‌ها")
    for i in ips:
        if i.startswith("geoip:"):
            if not _GEOIP.match(i):
                raise OutboundError(f"geoip معتبر نیست: {i}")
            continue
        try:
            ipaddress.ip_network(i, strict=False)
        except ValueError:
            raise OutboundError(f"آی‌پی یا CIDR معتبر نیست: {i}")
    if ips:
        m["ip"] = ips

    port = str(data.get("port") or "").replace(" ", "")
    if port:
        if not _PORT.match(port):
            raise OutboundError("پورت باید مثل 443 یا 80,443,8000-9000 باشد")
        for part in port.split(","):
            lo, _, hi = part.partition("-")
            if not (1 <= int(lo) <= 65535) or (hi and not (int(lo) <= int(hi) <= 65535)):
                raise OutboundError("بازه‌ی پورت معتبر نیست")
        m["port"] = port

    net = str(data.get("network") or "")
    if net not in ("", "tcp", "udp", "tcp,udp"):
        raise OutboundError("شبکه باید tcp یا udp باشد")
    if net:
        m["network"] = net

    protos = _tokens(data.get("protocol"), "پروتکل‌ها")
    if any(p not in PROTOCOLS for p in protos):
        raise OutboundError("پروتکل باید از http, tls, bittorrent, quic باشد")
    if protos:
        m["protocol"] = protos

    if not m:
        raise OutboundError("حداقل یک شرط برای قانون لازم است")
    target = str(data.get("outbound_tag") or "")
    if target not in outbound_tags:
        raise OutboundError("اوتباند مقصد وجود ندارد یا غیرفعال است")
    return {"remark": str(data.get("remark") or "")[:80], "enabled": bool(data.get("enabled", True)),
            "match": m, "outbound_tag": target}


# ------------------------------------------------------------------ rendering
def _local_socks(tag: str, port: int) -> dict:
    return {"tag": tag, "protocol": "socks",
            "settings": {"servers": [{"address": "127.0.0.1", "port": port}]}}


def xray_outbound(ob: dict) -> dict | None:
    t, s, tag = ob["type"], ob["settings"], ob["tag"]
    if t in ("tor", "psiphon"):
        return _local_socks(tag, LOCAL_PORT[t])
    if t in ("socks", "http"):
        srv = {"address": s["address"], "port": s["port"]}
        if s.get("username"):
            srv["users"] = [{"user": s["username"], "pass": s["password"]}]
        return {"tag": tag, "protocol": t, "settings": {"servers": [srv]}}
    if t == "shadowsocks":
        return {"tag": tag, "protocol": "shadowsocks", "settings": {"servers": [
            {"address": s["address"], "port": s["port"], "method": s["method"], "password": s["password"]}]}}
    if t in ("wireguard", "warp"):
        peer = {"publicKey": s["peer_public_key"], "allowedIPs": ["0.0.0.0/0", "::/0"], "endpoint": s["endpoint"]}
        if s.get("preshared_key"):
            peer["preSharedKey"] = s["preshared_key"]
        st = {"secretKey": s["private_key"], "address": s["address"], "peers": [peer], "mtu": s.get("mtu", 1280)}
        if s.get("reserved"):
            st["reserved"] = s["reserved"]
        return {"tag": tag, "protocol": "wireguard", "settings": st}
    return None


def singbox_outbound(ob: dict) -> tuple[str, dict] | None:
    """-> ('outbound'|'endpoint', dict)"""
    t, s, tag = ob["type"], ob["settings"], ob["tag"]
    if t in ("tor", "psiphon"):
        return "outbound", {"type": "socks", "tag": tag, "server": "127.0.0.1", "server_port": LOCAL_PORT[t], "version": "5"}
    if t == "socks":
        d = {"type": "socks", "tag": tag, "server": s["address"], "server_port": s["port"], "version": "5"}
    elif t == "http":
        d = {"type": "http", "tag": tag, "server": s["address"], "server_port": s["port"]}
    elif t == "shadowsocks":
        return "outbound", {"type": "shadowsocks", "tag": tag, "server": s["address"], "server_port": s["port"],
                            "method": s["method"], "password": s["password"]}
    elif t in ("wireguard", "warp"):
        host, _, port = s["endpoint"].rpartition(":")
        peer = {"address": host.strip("[]"), "port": int(port), "public_key": s["peer_public_key"],
                "allowed_ips": ["0.0.0.0/0", "::/0"]}
        if s.get("preshared_key"):
            peer["pre_shared_key"] = s["preshared_key"]
        if s.get("reserved"):
            peer["reserved"] = s["reserved"]
        return "endpoint", {"type": "wireguard", "tag": tag, "address": s["address"], "private_key": s["private_key"],
                            "mtu": s.get("mtu", 1280), "peers": [peer]}
    else:
        return None
    if s.get("username"):
        d["username"], d["password"] = s["username"], s["password"]
    return "outbound", d


def _final(rt: dict, available: set[str]) -> str:
    f = rt.get("final") or "direct"
    return f if f in available else "direct"


def test_ports(rt: dict) -> dict[str, int]:
    """direct -> 10100, enabled outbounds (by id) -> 10101..."""
    ports = {"direct": TEST_BASE_PORT}
    for i, ob in enumerate(sorted(rt["outbounds"], key=lambda o: o["id"]), 1):
        ports[ob["tag"]] = TEST_BASE_PORT + i
    return ports


def xray_routing(rt: dict) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    """-> (outbounds, test_inbounds, test_rules, user_rules). The final outbound is listed first (= Xray's default)."""
    rendered = {"direct": {"tag": "direct", "protocol": "freedom"}, "block": {"tag": "block", "protocol": "blackhole"}}
    for ob in rt["outbounds"]:
        d = xray_outbound(ob)
        if d:
            rendered[ob["tag"]] = d
    final = _final(rt, set(rendered))
    ordered = [rendered[final]] + [d for t, d in rendered.items() if t != final]

    test_inbounds, test_rules = [], []
    for tag, port in test_ports(rt).items():
        if tag not in rendered:
            continue
        itag = TEST_TAG_PREFIX + tag
        test_inbounds.append({"tag": itag, "listen": "127.0.0.1", "port": port, "protocol": "socks",
                              "settings": {"auth": "noauth", "udp": False}})
        test_rules.append({"type": "field", "inboundTag": [itag], "outboundTag": tag})

    engine = rt.get("inbound_engine", {})
    rules = []
    for r in rt["rules"]:
        m, target = r["match"], r["outbound_tag"]
        if target not in rendered:
            continue
        rule = {"type": "field", "outboundTag": target}
        if m.get("inbound_tags"):
            tags = [t for t in m["inbound_tags"] if engine.get(t) == "xray"]
            if not tags:
                continue
            rule["inboundTag"] = tags
        for src, dst in (("domain", "domain"), ("ip", "ip"), ("port", "port"), ("network", "network"), ("protocol", "protocol")):
            if m.get(src):
                rule[dst] = m[src]
        rules.append(rule)
    return ordered, test_inbounds, test_rules, rules


def _sb_domain(tokens: list[str]) -> dict:
    out: dict[str, list[str]] = {}
    for t in tokens:
        mt = _DOMAIN_PREFIX.match(t)
        kind, val = (mt.group(1), mt.group(2)) if mt else ("keyword", t)
        key = {"domain": "domain_suffix", "full": "domain", "keyword": "domain_keyword", "regexp": "domain_regex"}.get(kind)
        if key:                                   # geosite is not available in sing-box rule form
            out.setdefault(key, []).append(val)
    return out


def singbox_routing(rt: dict) -> tuple[list[dict], list[dict], list[dict], str]:
    """-> (outbounds, endpoints, user_rules, final_tag). Rules that cannot be expressed are skipped, never widened."""
    outs, eps, tags = [{"type": "direct", "tag": "direct"}], [], {"direct", "block"}
    for ob in rt["outbounds"]:
        r = singbox_outbound(ob)
        if not r:
            continue
        (outs if r[0] == "outbound" else eps).append(r[1])
        tags.add(ob["tag"])
    engine = rt.get("inbound_engine", {})
    rules = []
    for r in rt["rules"]:
        m, target = r["match"], r["outbound_tag"]
        if target not in tags:
            continue
        rule: dict = {}
        if m.get("inbound_tags"):
            t = [x for x in m["inbound_tags"] if engine.get(x) == "singbox"]
            if not t:
                continue
            rule["inbound"] = t
        if m.get("domain"):
            d = _sb_domain(m["domain"])
            if not d:
                continue
            rule.update(d)
        if m.get("ip"):
            cidrs = [i for i in m["ip"] if not i.startswith("geoip:")]
            if not cidrs:
                continue
            rule["ip_cidr"] = cidrs
        if m.get("port"):
            ports, ranges = [], []
            for part in m["port"].split(","):
                (ranges if "-" in part else ports).append(part.replace("-", ":") if "-" in part else int(part))
            if ports:
                rule["port"] = ports
            if ranges:
                rule["port_range"] = ranges
        if m.get("network"):
            rule["network"] = m["network"].split(",")
        if m.get("protocol"):
            rule["protocol"] = m["protocol"]
        if target == "block":
            rule["action"] = "reject"
        else:
            rule.update({"action": "route", "outbound": target})
        rules.append(rule)
    final = _final(rt, tags)
    if final == "block":
        rules.append({"action": "reject"})
        final = "direct"
    return outs, eps, rules, final


def load_routing() -> dict:
    inb = [i for i in db.list_inbounds() if i["enabled"]]
    return {
        "outbounds": [o for o in db.list_outbounds() if o["enabled"]],
        "rules": [r for r in db.list_rules() if r["enabled"]],
        "final": db.get_settings().get("routing_final", "direct") or "direct",
        "inbound_engine": {i["tag"]: i["engine"] for i in inb},
    }


# ------------------------------------------------------------------ presets
PRESETS = {
    "ads": {"title": "بلاک تبلیغات", "target": "block",
            "rules": [{"remark": "تبلیغات", "domain": ["geosite:category-ads-all"]}]},
    "porn": {"title": "بلاک سایت‌های مستهجن", "target": "block",
             "rules": [{"remark": "مستهجن", "domain": ["geosite:category-porn"]}]},
    "ir-block": {"title": "بلاک سایت‌ها و آی‌پی‌های ایران", "target": "block",
                 "rules": [{"remark": "دامنه‌های ایران", "domain": ["geosite:category-ir"]},
                           {"remark": "آی‌پی‌های ایران", "ip": ["geoip:ir"]}]},
    "ir-direct": {"title": "سایت‌ها و آی‌پی‌های ایران مستقیم", "target": "direct",
                  "rules": [{"remark": "دامنه‌های ایران", "domain": ["geosite:category-ir"]},
                            {"remark": "آی‌پی‌های ایران", "ip": ["geoip:ir"]}]},
    "ai": {"title": "ChatGPT و Claude از اوتباند انتخابی", "target": None,
           "rules": [{"remark": "AI", "domain": ["geosite:openai", "domain:chatgpt.com", "domain:anthropic.com",
                                                  "domain:claude.ai"]}]},
    "streaming": {"title": "Netflix / Disney / Spotify از اوتباند انتخابی", "target": None,
                  "rules": [{"remark": "استریم", "domain": ["geosite:netflix", "geosite:disney", "geosite:spotify"]}]},
}


# ------------------------------------------------------------------ WARP registration (needs internet access)
def warp_register(license_key: str = "", timeout: int = 20) -> dict:
    from . import system
    kp = system.wg_keypair()
    body = {"key": kp["public"], "install_id": "", "fcm_token": "",
            "tos": time.strftime("%Y-%m-%dT%H:%M:%S.000Z", time.gmtime()), "model": "PC",
            "serial_number": secrets.token_hex(8), "locale": "en_US"}
    hdr = {"User-Agent": "okhttp/3.12.1", "CF-Client-Version": "a-6.3-1922", "Content-Type": "application/json"}

    def call(method, path, payload, token=None):
        h = dict(hdr)
        if token:
            h["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request("https://api.cloudflareclient.com/v0a2158" + path,
                                     data=json.dumps(payload).encode(), headers=h, method=method)
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.load(r)

    try:
        reg = call("POST", "/reg", body)
        cfg = reg["config"]
        addrs = cfg["interface"]["addresses"]
        peer_key = cfg["peers"][0]["public_key"]
        reserved = list(base64.b64decode(cfg["client_id"]))[:3]
        out = {"private_key": kp["private"], "peer_public_key": peer_key, "endpoint": WARP_DEFAULT_ENDPOINT,
               "address": [f"{addrs['v4']}/32"] + ([f"{addrs['v6']}/128"] if addrs.get("v6") else []),
               "reserved": reserved, "mtu": 1280, "account_id": reg.get("id", "")}
    except Exception as e:
        raise OutboundError(f"ساخت حساب WARP ناموفق بود (سرور به api.cloudflareclient.com دسترسی ندارد؟): {e}", 502)
    if license_key:
        try:
            call("PUT", f"/reg/{reg['id']}/account", {"license": license_key}, reg.get("token"))
            out["license"] = license_key
        except Exception as e:
            raise OutboundError(f"حساب ساخته شد ولی لایسنس WARP+ پذیرفته نشد: {e}", 502)
    return out


# ------------------------------------------------------------------ local services (Tor, Psiphon)
SERVICES = {
    "tor": {"unit": "tcm19-tor", "title": "Tor"},
    "psiphon": {"unit": "tcm19-psiphon", "title": "Psiphon", "bin": "/usr/local/bin/warp-plus"},
}
_jobs: dict[str, dict] = {}
_job_lock = threading.Lock()


def _run(cmd, timeout=60, env=None) -> tuple[int, str]:
    import os
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                           env={**os.environ, **(env or {})})
        return p.returncode, (p.stdout + p.stderr).strip()
    except FileNotFoundError:
        return 127, f"command not found: {cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def _unit_path(name: str) -> Path:
    return Path("/etc/systemd/system") / f"{SERVICES[name]['unit']}.service"


def installed(name: str) -> bool:
    if name == "tor":
        return shutil.which("tor") is not None
    return Path(SERVICES["psiphon"]["bin"]).exists()


def is_active(name: str) -> bool:
    return _run(["systemctl", "is-active", SERVICES[name]["unit"]], 10)[1].strip() == "active"


def service_status(name: str) -> dict:
    job = _jobs.get(name, {})
    return {"installed": installed(name), "active": is_active(name) if installed(name) else False,
            "installing": bool(job.get("running")), "install_ok": job.get("ok"),
            "log": (job.get("log") or [])[-12:]}


def _flag_supported(binary: str, flag: str) -> bool:
    return flag in _run([binary, "-h"], 8)[1]


def service_files(name: str, s: dict) -> dict[str, str]:
    if name == "tor":
        torrc = ["SocksPort 127.0.0.1:%d" % LOCAL_PORT["tor"], "DataDirectory /var/lib/tcm19-tor",
                 "ClientOnly 1", "AvoidDiskWrites 1", "Log notice stderr"]
        if s.get("exit_country"):
            torrc += ["ExitNodes {%s}" % s["exit_country"], "StrictNodes 1"]
        unit = ("[Unit]\nDescription=tcm19 Tor client\nAfter=network-online.target\nWants=network-online.target\n\n"
                "[Service]\nUser=debian-tor\nExecStart=/usr/bin/tor -f /etc/tcm19/tor/torrc\n"
                "Restart=always\nRestartSec=5\n\n[Install]\nWantedBy=multi-user.target\n")
        return {"/etc/tcm19/tor/torrc": "\n".join(torrc) + "\n", str(_unit_path("tor")): unit}
    binary = SERVICES["psiphon"]["bin"]
    args = f"-b 127.0.0.1:{LOCAL_PORT['psiphon']} --cfon --country {s.get('country', 'DE')}"
    if _flag_supported(binary, "cache-dir"):
        args += " --cache-dir /var/lib/tcm19-psiphon"
    if s.get("warp_key"):
        args += f" -k {s['warp_key']}"
    unit = ("[Unit]\nDescription=tcm19 Psiphon (warp-plus --cfon)\nAfter=network-online.target\nWants=network-online.target\n\n"
            "[Service]\nDynamicUser=yes\nStateDirectory=tcm19-psiphon\nWorkingDirectory=/var/lib/tcm19-psiphon\n"
            f"Environment=HOME=/var/lib/tcm19-psiphon\nExecStart={binary} {args}\n"
            "Restart=always\nRestartSec=5\n\n[Install]\nWantedBy=multi-user.target\n")
    return {str(_unit_path("psiphon")): unit}


def _apply_one(name: str, ob: dict | None) -> str:
    unit = _unit_path(name)
    if ob is None:
        if unit.exists() and is_active(name):
            _run(["systemctl", "disable", "--now", SERVICES[name]["unit"]], 30)
            return "stopped"
        return "off"
    if not installed(name):
        return "not installed"
    changed = False
    for path, content in service_files(name, ob["settings"]).items():
        p = Path(path)
        if not p.exists() or p.read_text() != content:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(content)
            changed = True
    if name == "tor":
        d = Path("/var/lib/tcm19-tor")
        d.mkdir(parents=True, exist_ok=True)
        try:
            shutil.chown(d, "debian-tor", "debian-tor")
            d.chmod(0o700)
            shutil.chown("/etc/tcm19/tor/torrc", group="debian-tor")
            Path("/etc/tcm19/tor/torrc").chmod(0o640)
        except (LookupError, PermissionError, OSError):
            pass
    if changed:
        _run(["systemctl", "daemon-reload"], 20)
    if changed or not is_active(name):
        code, out = _run(["systemctl", "enable", "--now", SERVICES[name]["unit"]], 30)
        if code == 0 and changed:
            _run(["systemctl", "restart", SERVICES[name]["unit"]], 30)
        return "started" if code == 0 else f"start failed: {out[-200:]}"
    return "running"


def apply_services(obs: list[dict] | None = None) -> dict:
    if config.DRY_RUN:
        return {"services": "dry-run"}
    obs = db.list_outbounds() if obs is None else obs
    res = {}
    for name in SERVICES:
        ob = next((o for o in obs if o["type"] == name and o["enabled"]), None)
        try:
            res[name] = _apply_one(name, ob)
        except Exception as e:
            res[name] = f"error: {e}"
    return res


def _job_log(name: str, line: str):
    _jobs[name]["log"].append(line)


def _download_psiphon(url: str) -> None:
    import io
    import platform
    import tarfile
    import zipfile
    arch = {"x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64", "arm64": "arm64"}.get(platform.machine().lower())
    if not arch:
        raise RuntimeError(f"معماری {platform.machine()} پشتیبانی نمی‌شود")
    if not url:
        _job_log("psiphon", "پیدا کردن آخرین نسخه‌ی warp-plus در GitHub…")
        req = urllib.request.Request("https://api.github.com/repos/bepass-org/warp-plus/releases/latest",
                                     headers={"User-Agent": "tcm19-panel", "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(req, timeout=30) as r:
            rel = json.load(r)
        names = {"amd64": ("amd64", "x86_64", "x64"), "arm64": ("arm64", "aarch64")}[arch]
        for a in rel.get("assets", []):
            n = a["name"].lower()
            if "linux" in n and any(k in n for k in names) and n.endswith((".zip", ".tar.gz", ".tgz")):
                url = a["browser_download_url"]
                break
        if not url:
            raise RuntimeError("فایل لینوکس warp-plus در آخرین نسخه پیدا نشد؛ آدرس مستقیم فایل را خودت بده")
    _job_log("psiphon", f"دانلود {url.rsplit('/', 1)[-1]}…")
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "tcm19-panel"}), timeout=120) as r:
        blob = r.read(80 * 1024 * 1024)
    data = None
    if url.lower().endswith(".zip"):
        z = zipfile.ZipFile(io.BytesIO(blob))
        for n in z.namelist():
            base = n.rsplit("/", 1)[-1].lower()
            if base.startswith("warp") and "." not in base and not n.endswith("/"):
                data = z.read(n)
                break
    elif url.lower().endswith((".tar.gz", ".tgz")):
        t = tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz")
        for m in t.getmembers():
            base = m.name.rsplit("/", 1)[-1].lower()
            if m.isfile() and base.startswith("warp") and "." not in base:
                data = t.extractfile(m).read()
                break
    else:
        data = blob                                # a bare binary
    if not data or data[:4] != b"\x7fELF":
        raise RuntimeError("فایل اجرایی warp-plus داخل بسته پیدا نشد")
    dst = Path(SERVICES["psiphon"]["bin"])
    tmp = dst.with_suffix(".new")
    tmp.write_bytes(data)
    tmp.chmod(0o755)
    tmp.replace(dst)
    code, out = _run([str(dst), "-h"], 10)
    if "cfon" not in out:
        dst.unlink(missing_ok=True)
        raise RuntimeError("این فایل warp-plus گزینه‌ی --cfon (Psiphon) ندارد")


def _do_install(name: str, url: str):
    try:
        if name == "tor":
            _job_log(name, "apt-get update…")
            _run(["apt-get", "update"], 300, {"DEBIAN_FRONTEND": "noninteractive"})
            _job_log(name, "نصب بسته‌ی tor…")
            code, out = _run(["apt-get", "install", "-y", "tor"], 600, {"DEBIAN_FRONTEND": "noninteractive"})
            if code != 0:
                raise RuntimeError("apt-get install tor ناموفق بود: " + out[-300:])
            _run(["systemctl", "disable", "--now", "tor@default"], 30)   # keep only our own instance
        else:
            _download_psiphon(url)
        _job_log(name, "راه‌اندازی سرویس…")
        res = _apply_one(name, next((o for o in db.list_outbounds() if o["type"] == name and o["enabled"]), None))
        _job_log(name, f"سرویس: {res}")
        _jobs[name]["ok"] = True
    except Exception as e:
        _job_log(name, f"خطا: {e}")
        _jobs[name]["ok"] = False
    finally:
        _jobs[name]["running"] = False


def install_service(name: str, url: str = "") -> None:
    if name not in SERVICES:
        raise OutboundError("سرویس ناشناخته", 404)
    if url and not url.startswith("https://"):
        raise OutboundError("آدرس دانلود باید https باشد")
    with _job_lock:
        if _jobs.get(name, {}).get("running"):
            raise OutboundError("نصب در حال انجام است", 409)
        _jobs[name] = {"running": True, "ok": None, "log": []}
    threading.Thread(target=_do_install, args=(name, url), daemon=True).start()


# ------------------------------------------------------------------ connectivity test (through the real outbound)
def test_outbound(port: int) -> dict:
    code, out = _run(["curl", "-s", "-m", "25", "-w", "\n__T=%{time_total}", "--socks5-hostname",
                      f"127.0.0.1:{port}", "https://www.cloudflare.com/cdn-cgi/trace"], 30)
    if code != 0 or "ip=" not in out:
        hint = "Tor چند دقیقه برای اولین اتصال زمان می‌خواهد" if code == 28 else ""
        return {"ok": False, "error": f"اتصال برقرار نشد (کد {code}). {hint}".strip()}
    kv = dict(l.split("=", 1) for l in out.splitlines() if "=" in l)
    return {"ok": True, "ip": kv.get("ip", ""), "country": kv.get("loc", ""), "warp": kv.get("warp", "off"),
            "ms": int(float(kv.get("__T", "0")) * 1000)}
