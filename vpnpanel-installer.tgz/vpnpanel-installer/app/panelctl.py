"""Command-line helper: python3 -m app.panelctl <command>   (run from the panel directory, as root)."""
import argparse
import getpass
import sys
from pathlib import Path

from . import certstore as cs


def _restart_panel():
    r = cs.sh(["systemctl", "restart", cs.PANEL_SERVICE], 60)
    print("panel restarted" if r.returncode == 0 else f"restart failed: {r.stderr.strip()}")


def main(argv=None):
    ap = argparse.ArgumentParser(prog="panelctl")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("issue-cloudflare", "issue-http"):
        p = sub.add_parser(name)
        p.add_argument("domain")
        p.add_argument("--email", default="")
        p.add_argument("--extra", nargs="*", default=[])
        if name == "issue-cloudflare":
            p.add_argument("--no-wildcard", action="store_true")
            p.add_argument("--token", default="", help="Cloudflare API token (or prompt)")
    p = sub.add_parser("import")
    p.add_argument("domain"); p.add_argument("cert_file"); p.add_argument("key_file")
    p = sub.add_parser("set-panel"); p.add_argument("domain"); p.add_argument("--no-restart", action="store_true")
    sub.add_parser("unlock")
    sub.add_parser("status")
    sub.add_parser("install-hook")
    sub.add_parser("migrate")
    sub.add_parser("deploy-lineage")
    a = ap.parse_args(argv)
    try:
        if a.cmd == "issue-cloudflare":
            tok = a.token or cs.cf_token()
            if not tok:
                tok = getpass.getpass("Cloudflare API token: ").strip()
            cs.cf_save_token(tok)
            ok = cs.issue(a.domain, "cloudflare", not a.no_wildcard, a.extra, a.email, lambda s: print(s, end=""))
            return 0 if ok else 1
        if a.cmd == "issue-http":
            ok = cs.issue(a.domain, "http", False, a.extra, a.email, lambda s: print(s, end=""))
            return 0 if ok else 1
        if a.cmd == "import":
            e = cs.import_pem(a.domain, Path(a.cert_file).read_text(), Path(a.key_file).read_text())
            print("imported:", e["cert"])
            return 0
        if a.cmd == "set-panel":
            info = cs.set_panel(a.domain)
            print("panel domain set:", a.domain, "| names:", ", ".join(info["names"]))
            if not a.no_restart:
                _restart_panel()
            return 0
        if a.cmd == "unlock":
            cs.clear_panel()
            print("panel HTTPS / domain lock disabled (panel will answer on plain HTTP and by IP again)")
            _restart_panel()
            return 0
        if a.cmd == "status":
            cs.ensure_migrated()
            d = cs.load()
            print("panel domain:", d["panel"].get("domain") or "(none)")
            for n, e in d["domains"].items():
                i = cs.cert_info(e["cert"])
                print(f"- {n} [{e.get('source')}] {'%s days left' % i.get('days_left') if i['ok'] else i['error']}")
            return 0
        if a.cmd == "install-hook":
            cs.install_hook()
            print("hook installed:", cs.HOOK_FILE)
            return 0
        if a.cmd == "migrate":
            cs.ensure_migrated()
            return 0
        if a.cmd == "deploy-lineage":
            import os
            n = cs.deploy_lineage(os.environ.get("RENEWED_LINEAGE", ""))
            print(f"deployed {n} domain(s)")
            return 0
    except cs.CertError as e:
        print("ERROR:", e, file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
