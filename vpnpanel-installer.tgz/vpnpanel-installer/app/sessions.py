"""Login sessions: tokens last 30 days; they die when the admin password changes or when "log out everyone" is used."""
from . import db


def epoch() -> str:
    with db.tx() as c:
        r = c.execute("SELECT value FROM settings WHERE key='session_epoch'").fetchone()
        return r["value"] if r else "0"


def kick_all() -> str:
    n = str(int(epoch()) + 1)
    with db.tx() as c:
        c.execute("INSERT INTO settings(key,value) VALUES('session_epoch',?) "
                  "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (n,))
    return n
