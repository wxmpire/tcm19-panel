"""ASGI wrapper that exposes only /sub/* of the panel (used by the vpnpanel-sub service)."""
from app.main import app as _main


async def app(scope, receive, send):
    t = scope["type"]
    if t == "lifespan":
        while True:
            m = await receive()
            if m["type"] == "lifespan.startup":
                await send({"type": "lifespan.startup.complete"})
            elif m["type"] == "lifespan.shutdown":
                await send({"type": "lifespan.shutdown.complete"})
                return
    if t == "http" and scope["path"].startswith("/sub/"):
        await _main(scope, receive, send)
        return
    if t == "http":
        await send({"type": "http.response.start", "status": 404, "headers": [(b"content-type", b"text/plain")]})
        await send({"type": "http.response.body", "body": b"not found"})
        return
    if t == "websocket":
        await send({"type": "websocket.close", "code": 1008})
