"""Public subscription page: what a person sees when they open their subscription link in a web browser.

VPN apps keep getting the normal base64 subscription from the same URL (see main.py: wants_page).
Everything is inline (no /static files), because the sub-only listener serves /sub/* and nothing else.
"""
import json
import re
from pathlib import Path

_QR_JS = (Path(__file__).with_name("qr.js").read_text(encoding="utf-8")
          if Path(__file__).with_name("qr.js").exists() else "window.makeQR=function(){return null};")

# Apps that fetch subscriptions send their own User-Agent; browsers send Mozilla/5.0 + Accept: text/html.
_CLIENT_UA = re.compile(
    r"(v2ray|v2box|hiddify|clash|mihomo|sing-?box|nekobox|nekoray|streisand|shadowrocket|quantumult|surge|loon|stash|"
    r"happ|karing|foxray|flclash|husi|exclave|matsuri|hysteria|xray|wireguard|okhttp|curl|wget|python|go-http|"
    r"incy|rocket|sfa|sfi|sfm|tuic|meta)", re.I)


def wants_page(headers, query) -> bool:
    if query.get("raw") is not None or query.get("client") is not None:
        return False
    if query.get("page") is not None:
        return True
    accept, ua = headers.get("accept", ""), headers.get("user-agent", "")
    return "text/html" in accept and ua.startswith("Mozilla") and not _CLIENT_UA.search(ua)


def _js_json(obj) -> str:
    # safe inside <script type="application/json">
    return (json.dumps(obj, ensure_ascii=False)
            .replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


def render(user: dict, settings: dict, sub_url: str, links: list[str], clash_conf: str | None,
           wg_conf: str | None) -> str:
    data = {
        "title": settings.get("profile_title") or "VPN",
        "support": settings.get("support_url") or "",
        "username": user["username"],
        "status": user["status"],
        "used": int(user.get("used") or 0),
        "limit": int(user.get("data_limit") or 0),
        "expire": int(user.get("expire_at") or 0),
        "sub": sub_url,
        "clash_url": sub_url + "/clash" if clash_conf else "",
        "wg_url": sub_url + "/wg" if wg_conf else "",
        "links": links,
        "clash": clash_conf or "",
        "wg": wg_conf or "",
    }
    repl = {"/*__QR__*/": _QR_JS.replace("</script", "<\\/script"), "__DATA__": _js_json(data),
            "__TITLE__": _html_escape(data["title"] + " · " + user["username"])}
    # single pass: text inserted by one placeholder is never scanned for the others
    return re.sub(r"/\*__QR__\*/|__DATA__|__TITLE__", lambda m: repl[m.group(0)], _TEMPLATE)


def _html_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


_TEMPLATE = r"""<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="color-scheme" content="light dark">
<title>__TITLE__</title>
<style>
:root{--bg:#f4f6fb;--card:#fff;--tx:#12161f;--mut:#667085;--line:#e4e8f0;--pri:#2f6bff;--pri2:#1f4fd1;--ok:#12a150;--warn:#d9822b;--bad:#d92d3a;--soft:#eef3ff}
@media (prefers-color-scheme:dark){:root{--bg:#0d1118;--card:#161c26;--tx:#e8ecf3;--mut:#93a0b5;--line:#252e3c;--pri:#5b8cff;--pri2:#7aa2ff;--ok:#3ccf7a;--warn:#f0a458;--bad:#ff6b76;--soft:#1b2640}}
*{box-sizing:border-box}html,body{margin:0}
body{background:var(--bg);color:var(--tx);font:15px/1.7 Vazirmatn,Tahoma,"Segoe UI",system-ui,sans-serif;padding:max(16px,env(safe-area-inset-top)) 14px max(24px,env(safe-area-inset-bottom))}
.wrap{max-width:560px;margin:0 auto}
.card{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:18px;margin-bottom:14px}
h1{font-size:18px;margin:0}h2{font-size:15px;margin:0 0 10px}
.top{display:flex;align-items:center;justify-content:space-between;gap:10px}
.who{display:flex;flex-direction:column}.who small{color:var(--mut)}
.pill{padding:3px 12px;border-radius:99px;font-size:12.5px;font-weight:700;background:var(--soft);color:var(--pri)}
.pill.active{background:color-mix(in srgb,var(--ok) 15%,transparent);color:var(--ok)}
.pill.expired,.pill.limited{background:color-mix(in srgb,var(--bad) 15%,transparent);color:var(--bad)}
.pill.disabled{background:color-mix(in srgb,var(--mut) 18%,transparent);color:var(--mut)}
.bar{height:12px;border-radius:99px;background:var(--line);overflow:hidden;margin:14px 0 8px}
.bar i{display:block;height:100%;width:0;border-radius:99px;background:linear-gradient(90deg,var(--pri),var(--pri2));transition:width .6s}
.bar i.warn{background:var(--warn)}.bar i.bad{background:var(--bad)}
.kv{display:flex;justify-content:space-between;gap:10px;padding:7px 0;border-top:1px dashed var(--line)}
.kv:first-of-type{border-top:0}.kv span:first-child{color:var(--mut)}.num{font-variant-numeric:tabular-nums;direction:ltr;unicode-bidi:plaintext}
.btn{appearance:none;border:0;border-radius:12px;padding:10px 14px;font:inherit;font-weight:700;cursor:pointer;background:var(--pri);color:#fff;text-decoration:none;display:inline-block}
.btn.sec{background:var(--soft);color:var(--pri)}.btn.sm{padding:6px 11px;font-size:13px;border-radius:10px}
.btn:active{transform:scale(.97)}.row{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}
.url{direction:ltr;text-align:left;background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:10px 12px;font:12.5px/1.5 ui-monospace,Menlo,Consolas,monospace;word-break:break-all;user-select:all}
.qrbox{background:#fff;border-radius:14px;padding:10px;margin-top:10px;max-width:230px}.qrbox svg{display:block;width:100%;height:auto}
.node{border-top:1px dashed var(--line);padding:12px 0}.node:first-child{border-top:0;padding-top:0}
.node b{display:block;word-break:break-word}.node small{color:var(--mut);direction:ltr;display:inline-block}
pre{direction:ltr;text-align:left;background:var(--bg);border:1px solid var(--line);border-radius:12px;padding:10px;font-size:12px;max-height:200px;overflow:auto;margin:8px 0 0}
.note{color:var(--mut);font-size:13px}.msg{padding:12px 14px;border-radius:12px;background:color-mix(in srgb,var(--bad) 12%,transparent);color:var(--bad);margin-bottom:14px}
.apps{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:8px}
.toast{position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#12161f;color:#fff;padding:9px 18px;border-radius:99px;font-size:13px;opacity:0;pointer-events:none;transition:opacity .2s}.toast.on{opacity:1}
footer{text-align:center;color:var(--mut);font-size:12px;margin-top:8px}
</style>
</head>
<body>
<div class="wrap" id="app"></div>
<div class="toast" id="toast"></div>
<script type="application/json" id="d">__DATA__</script>
<script>
/*__QR__*/
</script>
<script>
(function(){
const D=JSON.parse(document.getElementById('d').textContent);
const $=s=>document.querySelector(s);
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const ST={active:'فعال',expired:'منقضی',limited:'اتمام حجم',disabled:'غیرفعال'};
function bytes(n){n=+n||0;if(!n)return '0 B';const u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<4){n/=1024;i++}return (i>1?n.toFixed(2):Math.round(n))+' '+u[i]}
function fdate(t){return t?new Date(t*1000).toLocaleDateString('fa-IR-u-nu-latn',{year:'numeric',month:'long',day:'numeric'}):'نامحدود'}
let tt;function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>t.classList.remove('on'),1800)}
function legacy(t){const a=document.createElement('textarea');a.value=t;a.setAttribute('readonly','');a.style.cssText='position:fixed;top:0;left:0;opacity:0;font-size:16px';document.body.appendChild(a);a.focus();a.select();let ok=false;try{ok=document.execCommand('copy')}catch(e){}a.remove();return ok}
async function copy(t){let ok=false;if(navigator.clipboard&&window.isSecureContext){try{await navigator.clipboard.writeText(t);ok=true}catch(e){}}if(!ok)ok=legacy(t);if(ok)toast('کپی شد');else prompt('کپی کنید:',t)}
function qr(btn,text){const n=btn.parentElement.nextElementSibling;if(n&&n.classList.contains('qrbox')){n.remove();return}
  const s=window.makeQR(text);btn.parentElement.insertAdjacentHTML('afterend',s?'<div class="qrbox">'+s+'</div>':'<div class="note qrbox" style="background:none">متن برای QR خیلی بلند است</div>')}
function remark(l){try{const i=l.lastIndexOf('#');if(i>-1)return decodeURIComponent(l.slice(i+1))}catch(e){}
  if(l.startsWith('vmess://')){try{return JSON.parse(atob(l.slice(8))).ps||'vmess'}catch(e){}}return l.split('://')[0]}
function proto(l){return (l.split('://')[0]||'').toUpperCase()}
const left=D.limit?Math.max(0,D.limit-D.used):0,pct=D.limit?Math.min(100,D.used/D.limit*100):0;
const days=D.expire?Math.ceil((D.expire-Date.now()/1000)/86400):null;
const bad=D.status!=='active';
const enc=encodeURIComponent;
let h=`<div class="card"><div class="top"><div class="who"><h1>${esc(D.title)}</h1><small>${esc(D.username)}</small></div><span class="pill ${esc(D.status)}">${esc(ST[D.status]||D.status)}</span></div>`;
if(bad)h+=`<div class="msg" style="margin:14px 0 0">${D.status==='expired'?'اشتراک شما منقضی شده است. برای تمدید با پشتیبانی تماس بگیرید.':D.status==='limited'?'حجم اشتراک شما تمام شده است. برای تمدید با پشتیبانی تماس بگیرید.':'این اشتراک غیرفعال است.'}</div>`;
h+=`<div class="bar"><i class="${pct>=90?'bad':pct>=70?'warn':''}" id="bf"></i></div>
<div class="kv"><span>مصرف‌شده</span><span class="num">${bytes(D.used)}</span></div>
<div class="kv"><span>حجم کل</span><span class="num">${D.limit?bytes(D.limit):'نامحدود'}</span></div>
${D.limit?`<div class="kv"><span>باقی‌مانده</span><span class="num">${bytes(left)}</span></div>`:''}
<div class="kv"><span>تاریخ انقضا</span><span>${fdate(D.expire)}${days!==null?(days>0?` · ${days} روز مانده`:' · منقضی'):''}</span></div>`;
if(D.support)h+=`<div class="row"><a class="btn sec sm" href="${esc(D.support)}" target="_blank" rel="noopener">پشتیبانی</a></div>`;
h+=`</div>`;
if(!bad){
 h+=`<div class="card"><h2>لینک اشتراک</h2><div class="url">${esc(D.sub)}</div>
  <div class="row"><button class="btn sm" data-copy="sub">کپی لینک</button><button class="btn sec sm" data-qr="sub">QR</button></div>
  <h2 style="margin-top:16px">افزودن مستقیم به برنامه</h2>
  <div class="apps">
   <a class="btn sec sm" href="hiddify://import/${esc(D.sub)}#${enc(D.title)}">Hiddify</a>
   <a class="btn sec sm" href="v2rayng://install-sub?url=${enc(D.sub)}&name=${enc(D.title)}">v2rayNG</a>
   <a class="btn sec sm" href="sing-box://import-remote-profile?url=${enc(D.sub)}#${enc(D.title)}">sing-box</a>
   ${D.clash_url?`<a class="btn sec sm" href="clash://install-config?url=${enc(D.clash_url)}&name=${enc(D.title)}">Clash / Mihomo</a>`:''}
  </div><p class="note">اگر برنامه باز نشد، لینک اشتراک را کپی کنید و داخل برنامه (Add subscription) بچسبانید.</p></div>`;
 if(D.links.length){h+=`<div class="card"><h2>کانفیگ‌ها (${D.links.length})</h2>`+D.links.map((l,i)=>`<div class="node"><b>${esc(remark(l))}</b><small>${esc(proto(l))}</small><div class="row"><button class="btn sec sm" data-copy="l${i}">کپی</button><button class="btn sec sm" data-qr="l${i}">QR</button></div></div>`).join('')+`</div>`}
 if(D.clash)h+=`<div class="card"><h2>Clash / Mihomo</h2><p class="note" style="margin:0">برای Mieru، Sudoku، ShadowQUIC و TrustTunnel. نیاز به کلاینت مبتنی بر Mihomo (Clash Verge Rev، FlClash، Mihomo Party).</p><div class="url" style="margin-top:8px">${esc(D.clash_url)}</div><div class="row"><button class="btn sm" data-copy="cu">کپی لینک Clash</button><button class="btn sec sm" data-copy="cc">کپی کانفیگ</button></div></div>`;
 if(D.wg)h+=`<div class="card"><h2>WireGuard</h2><div class="row" style="margin-top:0"><button class="btn sm" data-copy="wg">کپی کانفیگ</button><button class="btn sec sm" data-qr="wg">QR</button><a class="btn sec sm" href="${esc(D.wg_url)}" download>دانلود .conf</a></div></div>`;
}
h+=`<footer>این صفحه اختصاصی شماست؛ لینک را با کسی به اشتراک نگذارید.</footer>`;
$('#app').innerHTML=h;
requestAnimationFrame(()=>{const b=$('#bf');if(b)b.style.width=(D.limit?pct:0)+'%'});
const val=k=>k==='sub'?D.sub:k==='cu'?D.clash_url:k==='cc'?D.clash:k==='wg'?D.wg:D.links[+k.slice(1)];
document.querySelectorAll('[data-copy]').forEach(b=>b.onclick=()=>copy(val(b.dataset.copy)));
document.querySelectorAll('[data-qr]').forEach(b=>b.onclick=()=>qr(b,val(b.dataset.qr)));
})();
</script>
</body>
</html>
"""
