"""Public subscription page: what a person sees when they open their subscription link in a web browser.

VPN apps keep getting the normal base64 subscription from the same URL (see main.py: wants_page).
Everything is inline (no /static files), because the sub-only listener serves /sub/* and nothing else.
"""
import json
import re
from pathlib import Path

_QR_JS = (Path(__file__).with_name("qr.js").read_text(encoding="utf-8")
          if Path(__file__).with_name("qr.js").exists() else "window.makeQR=function(){return null};")

# Apps that fetch subscriptions send their own User-Agent; browsers send Mozilla/5.0 + Accept: text/html.
_CLIENT_UA = re.compile(
    r"(v2ray|v2box|hiddify|clash|mihomo|sing-?box|nekobox|nekoray|streisand|shadowrocket|quantumult|surge|loon|stash|"
    r"happ|karing|foxray|flclash|husi|exclave|matsuri|hysteria|xray|wireguard|okhttp|curl|wget|python|go-http|"
    r"incy|rocket|sfa|sfi|sfm|tuic|meta)", re.I)


def wants_page(headers, query) -> bool:
    if query.get("raw") is not None or query.get("client") is not None:
        return False
    if query.get("page") is not None:
        return True
    accept, ua = headers.get("accept", ""), headers.get("user-agent", "")
    return "text/html" in accept and ua.startswith("Mozilla") and not _CLIENT_UA.search(ua)


def _js_json(obj) -> str:
    # safe inside <script type="application/json">
    return (json.dumps(obj, ensure_ascii=False)
            .replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


def render(user: dict, settings: dict, sub_url: str, links: list[str], clash_conf: str | None,
           wg_conf: str | None, proxies: list[dict] | None = None) -> str:
    logo = (settings.get("sub_logo") or "").strip()
    data = {
        "title": settings.get("profile_title") or "VPN",
        "support": settings.get("support_url") or "",
        "notice": (settings.get("sub_notice") or "").strip(),
        "logo": logo if logo.startswith("https://") else "",
        "username": user["username"],
        "status": user["status"],
        "used": int(user.get("used") or 0),
        "up": int(user.get("up_bytes") or 0),
        "down": int(user.get("down_bytes") or 0),
        "proxies": proxies or [],
        "limit": int(user.get("data_limit") or 0),
        "expire": int(user.get("expire_at") or 0),
        "created": int(user.get("created_at") or 0),
        "reset": user.get("reset_strategy") or "none",
        "sub": sub_url,
        "clash_url": sub_url + "/clash" if clash_conf else "",
        "wg_url": sub_url + "/wg" if wg_conf else "",
        "links": links,
        "clash": clash_conf or "",
        "wg": wg_conf or "",
    }
    repl = {"/*__QR__*/": _QR_JS.replace("</script", "<\\/script"), "__DATA__": _js_json(data),
            "__TITLE__": _html_escape(data["title"] + " · " + user["username"])}
    # single pass: text inserted by one placeholder is never scanned for the others
    return re.sub(r"/\*__QR__\*/|__DATA__|__TITLE__", lambda m: repl[m.group(0)], _TEMPLATE)


def _html_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


_TEMPLATE = r"""<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="color-scheme" content="dark">
<title>__TITLE__</title>
<style>
:root{--bg:#0A0712;--sf:#120D1E;--sf2:#1A1329;--tx:#F3EEFF;--mut:#9A8FB5;--line:#2A2040;--line2:#3A2D58;--pri:#8B5CF6;--vio2:#A78BFA;--vio3:#C4B5FD;--pri-t:#fff;--pri-s:rgba(139,92,246,.16);--teal:#38BDF8;--ok:#34D399;--warn:#F5B84B;--bad:#FF6B7A;--grad:linear-gradient(120deg,#8B5CF6,#6D7BFA 62%,#4FB6F0);--shadow:none;color-scheme:dark}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{margin:0}
html{background:var(--bg)}body{background:radial-gradient(700px 380px at 50% 0%,rgba(139,92,246,.26),transparent 70%) no-repeat,var(--bg);color:var(--tx);font:15px/1.75 Vazirmatn,"IRANSans",Tahoma,"Segoe UI",system-ui,sans-serif;padding:max(14px,env(safe-area-inset-top)) 14px max(28px,env(safe-area-inset-bottom))}
.wrap{max-width:600px;margin:0 auto}
:focus-visible{outline:3px solid var(--pri);outline-offset:2px;border-radius:10px}
button{font:inherit;color:inherit}
/* top bar */
.bar{display:flex;align-items:center;gap:10px;padding:4px 2px 14px}
.logo{width:38px;height:38px;border-radius:11px;object-fit:cover;background:var(--sf2)}
.mark{width:40px;height:40px;border-radius:12px;background:linear-gradient(145deg,var(--vio2),#5B34C8);color:#fff;display:grid;place-items:center;font-weight:800;font-size:18px}
.bar h1{font-size:18px;line-height:1.3;margin:0;flex:1;min-width:0}.bar h1 small{display:block;font-weight:400;color:var(--mut);font-size:13px}
.ibtn{width:40px;height:40px;border-radius:12px;border:1px solid var(--line);background:var(--sf);cursor:pointer;display:grid;place-items:center}
.ibtn svg{width:19px;height:19px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.sheet{background:var(--sf);border:1px solid var(--line);border-radius:22px;box-shadow:var(--shadow);overflow:hidden}
.sec{padding:20px 18px;border-top:1px solid var(--line)}.sec:first-child{border-top:0}
.sec>h2{font-size:16px;margin:0 0 4px}.sec>.sub{color:var(--mut);font-size:13.5px;margin:0 0 14px}
/* notice */
.notice{display:flex;gap:10px;background:var(--pri-s);color:var(--tx);border-radius:14px;padding:12px 14px;margin-bottom:12px;font-size:14px}
.notice svg{flex:none;width:20px;height:20px;stroke:var(--pri);fill:none;stroke-width:2;margin-top:3px}
.warnbox{border-radius:14px;padding:11px 14px;margin:0 0 14px;font-size:14px;background:color-mix(in srgb,var(--warn) 14%,transparent)}
.warnbox.bad{background:color-mix(in srgb,var(--bad) 13%,transparent)}
/* hero */
.hero{display:grid;justify-items:center;gap:12px;padding-top:22px}
.rings{display:grid;grid-template-columns:1fr 1fr;gap:12px;width:100%}.rg{display:grid;justify-items:center;gap:8px;align-content:start}
.rg .rl{font-weight:700;font-size:14px}.rg .rs{color:var(--mut);font-size:12.5px;text-align:center;line-height:1.5;min-height:2.4em}
.ring{position:relative;width:min(38vw,168px);aspect-ratio:1}
.ring svg{width:100%;height:100%;transform:rotate(-90deg)}
.ring circle{fill:none;stroke-linecap:round}
.trk{stroke:var(--sf2)}
.ring .c{position:absolute;inset:0;display:grid;place-content:center;text-align:center;gap:0}
.big{font-size:30px;font-weight:800;line-height:1.1;letter-spacing:-.5px;direction:ltr;font-variant-numeric:tabular-nums}
.big small{font-size:14px;font-weight:700;margin-inline-start:3px;color:var(--mut)}
.cap{color:var(--mut);font-size:12.5px;line-height:1.4;max-width:90px;margin:2px auto 0}
.pill{display:inline-flex;align-items:center;gap:6px;padding:3px 13px;border-radius:99px;font-size:13px;font-weight:700;background:color-mix(in srgb,var(--ok) 15%,transparent);color:var(--ok)}
.pill::before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor}
.pill.expired,.pill.limited{background:color-mix(in srgb,var(--bad) 14%,transparent);color:var(--bad)}
.pill.disabled{background:var(--sf2);color:var(--mut)}
.legend{display:flex;gap:18px;color:var(--mut);font-size:13px;margin-top:6px}.legend i{display:inline-block;width:10px;height:10px;border-radius:3px;margin-inline-end:6px;vertical-align:-1px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:1px;background:var(--line);margin:14px -18px -20px;border-top:1px solid var(--line);justify-self:stretch;width:calc(100% + 36px)}
.grid>div{background:var(--sf);padding:13px 18px}.grid>div:last-child:nth-child(odd){grid-column:1/-1}.grid span{display:block;color:var(--mut);font-size:12.5px}.grid b{font-size:15px;display:block}
.num{direction:ltr;unicode-bidi:plaintext;display:inline-block}
/* buttons */
.btn{appearance:none;border:0;border-radius:13px;padding:10px 16px;font-weight:700;cursor:pointer;background:var(--grad);color:#fff;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:42px}
.btn.sec{background:var(--sf2);color:var(--tx);border:1px solid var(--line)}.btn.sm{padding:6px 13px;min-height:36px;font-size:13.5px;border-radius:11px}
.btn:active{transform:scale(.97)}.row{display:flex;flex-wrap:wrap;gap:8px}
.url{direction:ltr;text-align:left;background:var(--sf2);border:1px solid var(--line);border-radius:13px;padding:11px 13px;font:12.5px/1.55 ui-monospace,Menlo,Consolas,monospace;word-break:break-all;margin-bottom:10px;user-select:all}
/* platform picker */
.plat{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.pbtn{border:1.5px solid var(--line);background:var(--sf2);border-radius:16px;padding:14px 10px;cursor:pointer;display:grid;justify-items:center;gap:6px;font-weight:700}
.pbtn svg{width:30px;height:30px;stroke:var(--tx);fill:none;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}
.pbtn small{font-weight:400;color:var(--mut);font-size:12.5px}
.pbtn[aria-expanded=true]{border-color:var(--pri);background:var(--pri-s)}
.pbtn[aria-expanded=true] svg{stroke:var(--vio3)}
.apps{display:none;margin-top:14px}.apps.open{display:block}
.steps{display:flex;gap:6px;color:var(--mut);font-size:12.5px;margin:0 0 10px}.steps b{color:var(--tx)}
.app{display:grid;grid-template-columns:46px 1fr;gap:4px 12px;padding:13px 0;border-top:1px dashed var(--line)}
.app:first-of-type{border-top:0}
.ico{width:46px;height:46px;border-radius:13px;display:grid;place-items:center;font-weight:800;font-size:19px;color:#fff;grid-row:span 2}
.app h3{margin:0;font-size:15px;display:flex;gap:7px;align-items:center;flex-wrap:wrap}
.tag{font-size:11.5px;font-weight:700;padding:0 8px;border-radius:99px;background:var(--sf2);color:var(--mut);border:1px solid var(--line);line-height:1.7}
.tag.rec{background:var(--pri-s);color:var(--vio3);border-color:transparent}
.app p{margin:0;color:var(--mut);font-size:13px;line-height:1.6}
.app .row{grid-column:2;margin-top:6px}
.sep{margin:14px 0 4px;font-size:13px;color:var(--mut);font-weight:700}
/* configs */
.tools{display:flex;gap:8px;margin-bottom:10px}
.tools input{flex:1;min-width:0;border:1px solid var(--line);background:var(--sf2);color:var(--tx);border-radius:12px;padding:9px 13px;font:inherit}
.chips{display:flex;gap:7px;overflow-x:auto;padding-bottom:8px;margin-bottom:4px;scrollbar-width:none}.chips::-webkit-scrollbar{display:none}
.chip{flex:none;border:1px solid var(--line);background:var(--sf2);border-radius:99px;padding:3px 13px;font-size:13px;cursor:pointer}
.chip[aria-pressed=true]{background:var(--grad);color:#fff;border-color:transparent}
.node{display:flex;align-items:center;gap:10px;padding:11px 0;border-top:1px dashed var(--line)}
.node:first-child{border-top:0}.node .nm{flex:1;min-width:0}.node b{display:block;font-size:14.5px;word-break:break-word;line-height:1.5}
.node small{color:var(--mut);direction:ltr;display:inline-block;font-size:12px}
.empty{color:var(--mut);text-align:center;padding:14px 0;font-size:14px}
details{border-top:1px dashed var(--line);padding:11px 0}details:first-of-type{border-top:0}
summary{cursor:pointer;font-weight:700;list-style:none;display:flex;justify-content:space-between}summary::after{content:"+";color:var(--mut);font-weight:400;font-size:20px;line-height:1}
details[open] summary::after{content:"–"}
pre{direction:ltr;text-align:left;background:var(--sf2);border:1px solid var(--line);border-radius:12px;padding:10px;font-size:12px;max-height:180px;overflow:auto;margin:10px 0}
.note{color:var(--mut);font-size:13px;margin:6px 0 10px}
footer{text-align:center;color:var(--mut);font-size:12.5px;margin-top:16px;display:grid;gap:8px;justify-items:center}
/* modal + toast */
.ov{position:fixed;inset:0;background:rgba(5,10,20,.55);display:none;align-items:flex-end;justify-content:center;z-index:20}
.ov.on{display:flex}.md{background:var(--sf);width:min(100%,460px);border-radius:24px 24px 0 0;padding:20px 20px max(24px,env(safe-area-inset-bottom));text-align:center}
@media (min-width:640px){.ov{align-items:center}.md{border-radius:24px}}
.qrw{background:#fff;border-radius:16px;padding:12px;width:min(72vw,260px);margin:12px auto}.qrw svg{display:block;width:100%;height:auto}
.toast{position:fixed;left:50%;bottom:max(24px,env(safe-area-inset-bottom));transform:translateX(-50%) translateY(12px);background:var(--tx);color:var(--bg);padding:9px 20px;border-radius:99px;font-size:13.5px;font-weight:700;opacity:0;pointer-events:none;transition:opacity .2s,transform .2s;z-index:30}
.toast.on{opacity:1;transform:translateX(-50%)}

.lg{display:inline-flex;direction:ltr;background:var(--sf);border:1px solid var(--line);border-radius:99px;padding:3px;margin:0 0 12px;gap:2px}
.lg button{border:0;background:transparent;border-radius:99px;padding:5px 15px;font-weight:700;font-size:13.5px;cursor:pointer;color:var(--mut)}
.lg button[aria-pressed=true]{background:var(--grad);color:#fff}
.tile{display:flex;gap:11px;align-items:center}
.tile i{flex:none;width:34px;height:34px;border-radius:10px;display:grid;place-items:center;background:var(--pri-s)}
.tile i svg{width:17px;height:17px;stroke:var(--vio2);fill:none;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
.tile.dn i{background:color-mix(in srgb,var(--teal) 16%,transparent)}.tile.dn i svg{stroke:var(--teal)}
.tile div{min-width:0}
.qrin{background:#fff;border-radius:16px;padding:12px;width:min(62vw,220px);margin:14px auto 4px}.qrin svg{display:block;width:100%;height:auto}
.qcap{text-align:center;color:var(--mut);font-size:13px;margin:0}
.kvr{display:flex;justify-content:space-between;align-items:center;gap:10px;padding:8px 0;border-top:1px dashed var(--line)}
.kvr:first-of-type{border-top:0}.kvr span{color:var(--mut);font-size:13px}.kvr b{direction:ltr;font-size:13.5px;word-break:break-all;text-align:left}
.pxn{font-weight:700;margin:12px 0 2px;font-size:14px}.pxn:first-of-type{margin-top:6px}
.more{width:100%;margin-top:6px}
@media (prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
</style>
</head>
<body>
<div class="wrap" id="app"></div>
<div class="ov" id="ov" role="dialog" aria-modal="true" aria-label="QR"><div class="md"><b id="mt"></b><div class="qrw" id="qrw"></div><div class="row" style="justify-content:center"><button class="btn sm" id="mcopy">کپی</button><button class="btn sec sm" id="mclose">بستن</button></div></div></div>
<div class="toast" id="toast" role="status"></div>
<script type="application/json" id="d">__DATA__</script>
<script>
/*__QR__*/
</script>
<script>
(function(){
const D=JSON.parse(document.getElementById('d').textContent);
const $=(s,r)=>(r||document).querySelector(s),$$=(s,r)=>[...(r||document).querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const enc=encodeURIComponent;

/* ---------- languages ---------- */
const LANGS={fa:{n:'فارسی',dir:'rtl',loc:'fa-IR-u-nu-latn'},en:{n:'EN',dir:'ltr',loc:'en-GB'},ru:{n:'Русский',dir:'ltr',loc:'ru-RU'}};
const T={
fa:{active:'فعال',expired:'منقضی شده',limited:'حجم تمام شده',disabled:'غیرفعال',left:'حجم باقی‌مانده',unl:'نامحدود',unlcap:'حجم نامحدود',
 dataL:'حجم',timeL:'زمان',used:'مصرف‌شده',total:'حجم کل',up:'آپلود',down:'دانلود',ends:'پایان اشتراک',timeleft:'زمان باقی‌مانده',started:'تاریخ شروع',reset:'ریست حجم',
 daily:'هر روز',weekly:'هر هفته',monthly:'هر ماه',days:'{n} روز',over:'تمام شده',daysCap:'روز مانده',usedOf:'{a} از {b} مصرف شده',usedOnly:'{x} مصرف شده',endsOn:'تا {d}',noExp:'بدون تاریخ انقضا',
 wExp:'اشتراک شما منقضی شده است. برای تمدید با پشتیبانی تماس بگیرید.',wLim:'حجم اشتراک شما تمام شده است. برای تمدید یا افزایش حجم با پشتیبانی تماس بگیرید.',wDis:'این اشتراک غیرفعال است. برای اطلاعات بیشتر با پشتیبانی تماس بگیرید.',
 wLow:'فقط {x} از حجم شما مانده است.',wDays:'فقط {n} روز تا پایان اشتراک مانده است.',wToday:'اشتراک شما امروز تمام می‌شود.',
 conn:'اتصال به سرویس',connS:'دستگاه خود را انتخاب کنید تا برنامه‌های مناسب آن را ببینید.',napps:'{n} برنامه',
 s1:'نصب برنامه',s2:'افزودن اشتراک',s3:'اتصال',appNote:'اگر دکمه‌ی «افزودن اشتراک» برنامه را باز نکرد، برنامه را باز کنید و لینک اشتراک (پایین همین صفحه) را در آن بچسبانید.',
 free:'رایگان',oss:'متن‌باز',paid:'پولی',mihomo:'هسته Mihomo',rec:'پیشنهادی',addSub:'افزودن اشتراک',addClash:'افزودن Clash',apk:'دانلود APK',
 linkH:'لینک اشتراک',linkS:'یک بار اضافه کنید؛ برنامه‌ها سرورها را خودکار به‌روز می‌کنند.',copyLink:'کپی لینک',scan:'اسکن کنید یا کپی کنید',
 srv:'سرورها',srvS:'برای اتصال تکی، هر کانفیگ را جدا کپی یا با QR اسکن کنید.',search:'جستجوی نام سرور',copyAll:'کپی همه',all:'همه',none:'موردی پیدا نشد.',more:'نمایش بیشتر ({n})',
 moreH:'گزینه‌های بیشتر',copy:'کپی',qr:'QR',copied:'کپی شد',copyPrompt:'کپی کنید:',qrLong:'متن برای QR خیلی بلند است؛ از دکمه‌ی کپی استفاده کنید.',close:'بستن',
 clashNote:'برای پروتکل‌های Mieru، Sudoku، ShadowQUIC و TrustTunnel. برنامه باید هسته‌ی Mihomo داشته باشد (مثل FlClash یا Karing)؛ بعضی پروتکل‌ها به نسخه‌ی جدید هسته نیاز دارند.',
 clashCopy:'کپی لینک Clash',cfgCopy:'کپی کانفیگ',wgDl:'دانلود .conf',
 tg:'پروکسی تلگرام',tgNote:'پروکسی SOCKS5 برای تلگرام. دکمه‌ی زیر را بزنید و در تلگرام «Connect Proxy» را تایید کنید.',tgAdd:'افزودن به تلگرام',
 px:'پروکسی SOCKS / HTTP',pxNote:'برای برنامه‌هایی که پروکسی دستی می‌خواهند. ورود با نام‌کاربری و رمز شماست.',srvr:'سرور',port:'پورت',user:'نام‌کاربری',pass:'رمز',cpS5:'کپی SOCKS5',cpHttp:'کپی HTTP',
 helpH:'کمک می‌خواهید؟',helpS:'برای تمدید، افزایش حجم یا مشکل در اتصال به پشتیبانی پیام بدهید.',helpB:'ارتباط با پشتیبانی',
 refresh:'به‌روزرسانی اطلاعات',priv:'این صفحه اختصاصی شماست؛ لینک آن را با کسی به اشتراک نگذارید.',theme:'تغییر تم'},
en:{active:'Active',expired:'Expired',limited:'Data used up',disabled:'Disabled',left:'Data left',unl:'Unlimited',unlcap:'Unlimited data',
 dataL:'Data',timeL:'Time',used:'Used',total:'Total',up:'Upload',down:'Download',ends:'Expires',timeleft:'Time left',started:'Started',reset:'Data reset',
 daily:'Every day',weekly:'Every week',monthly:'Every month',days:'{n} days',over:'Over',daysCap:'days left',usedOf:'{a} of {b} used',usedOnly:'{x} used',endsOn:'Until {d}',noExp:'No expiry date',
 wExp:'Your subscription has expired. Contact support to renew.',wLim:'Your data is used up. Contact support to renew or add data.',wDis:'This subscription is disabled. Contact support for details.',
 wLow:'Only {x} of data left.',wDays:'Only {n} days left on your subscription.',wToday:'Your subscription ends today.',
 conn:'Connect',connS:'Pick your device to see the apps that work on it.',napps:'{n} apps',
 s1:'Install the app',s2:'Add subscription',s3:'Connect',appNote:'If “Add subscription” does not open the app, open the app yourself and paste your subscription link (further down this page).',
 free:'Free',oss:'Open source',paid:'Paid',mihomo:'Mihomo core',rec:'Recommended',addSub:'Add subscription',addClash:'Add Clash',apk:'Download APK',
 linkH:'Your subscription link',linkS:'Add this once. Your apps refresh their servers automatically.',copyLink:'Copy link',scan:'Scan or copy',
 srv:'Servers',srvS:'Copy a single server or scan its QR code to connect with it alone.',search:'Search servers',copyAll:'Copy all',all:'All',none:'Nothing found.',more:'Show more ({n})',
 moreH:'More options',copy:'Copy',qr:'QR',copied:'Copied',copyPrompt:'Copy:',qrLong:'The text is too long for a QR code. Use the copy button.',close:'Close',
 clashNote:'For Mieru, Sudoku, ShadowQUIC and TrustTunnel. Needs an app with the Mihomo core (such as FlClash or Karing); some protocols need a recent core.',
 clashCopy:'Copy Clash link',cfgCopy:'Copy config',wgDl:'Download .conf',
 tg:'Telegram proxy',tgNote:'A SOCKS5 proxy for Telegram. Tap the button and confirm “Connect Proxy” in Telegram.',tgAdd:'Add to Telegram',
 px:'SOCKS / HTTP proxy',pxNote:'For apps that ask for a manual proxy. You sign in with your username and password.',srvr:'Server',port:'Port',user:'Username',pass:'Password',cpS5:'Copy SOCKS5',cpHttp:'Copy HTTP',
 helpH:'Need help?',helpS:'Message support to renew, add data or fix a connection problem.',helpB:'Contact support',
 refresh:'Refresh',priv:'This page is yours alone; do not share its link.',theme:'Switch theme'},
ru:{active:'Активна',expired:'Истекла',limited:'Трафик исчерпан',disabled:'Отключена',left:'Осталось трафика',unl:'Безлимит',unlcap:'Безлимитный трафик',
 dataL:'Трафик',timeL:'Время',used:'Использовано',total:'Всего',up:'Отдача',down:'Загрузка',ends:'Действует до',timeleft:'Осталось времени',started:'Начало',reset:'Сброс трафика',
 daily:'Каждый день',weekly:'Каждую неделю',monthly:'Каждый месяц',days:'{n} дн.',over:'Истекло',daysCap:'дн. осталось',usedOf:'{a} из {b} использовано',usedOnly:'Использовано {x}',endsOn:'До {d}',noExp:'Без срока действия',
 wExp:'Подписка истекла. Для продления обратитесь в поддержку.',wLim:'Трафик исчерпан. Для продления или добавления трафика обратитесь в поддержку.',wDis:'Подписка отключена. Подробности — в поддержке.',
 wLow:'Осталось всего {x} трафика.',wDays:'До конца подписки осталось {n} дн.',wToday:'Подписка заканчивается сегодня.',
 conn:'Подключение',connS:'Выберите устройство, чтобы увидеть подходящие приложения.',napps:'Приложений: {n}',
 s1:'Установите приложение',s2:'Добавьте подписку',s3:'Подключитесь',appNote:'Если кнопка «Добавить подписку» не открыла приложение, откройте его сами и вставьте ссылку подписки (ниже на этой странице).',
 free:'Бесплатно',oss:'Открытый код',paid:'Платно',mihomo:'Ядро Mihomo',rec:'Рекомендуем',addSub:'Добавить подписку',addClash:'Добавить Clash',apk:'Скачать APK',
 linkH:'Ссылка подписки',linkS:'Добавьте один раз. Приложения сами обновляют серверы.',copyLink:'Скопировать ссылку',scan:'Сканируйте или копируйте',
 srv:'Серверы',srvS:'Скопируйте один сервер или отсканируйте его QR-код, чтобы подключиться только к нему.',search:'Поиск серверов',copyAll:'Копировать все',all:'Все',none:'Ничего не найдено.',more:'Показать ещё ({n})',
 moreH:'Дополнительно',copy:'Копировать',qr:'QR',copied:'Скопировано',copyPrompt:'Скопируйте:',qrLong:'Текст слишком длинный для QR-кода. Используйте кнопку копирования.',close:'Закрыть',
 clashNote:'Для Mieru, Sudoku, ShadowQUIC и TrustTunnel. Нужно приложение с ядром Mihomo (например FlClash или Karing); некоторым протоколам нужно свежее ядро.',
 clashCopy:'Копировать ссылку Clash',cfgCopy:'Копировать конфиг',wgDl:'Скачать .conf',
 tg:'Прокси для Telegram',tgNote:'SOCKS5-прокси для Telegram. Нажмите кнопку и подтвердите «Connect Proxy» в Telegram.',tgAdd:'Добавить в Telegram',
 px:'Прокси SOCKS / HTTP',pxNote:'Для приложений, которым нужен ручной прокси. Вход по вашему логину и паролю.',srvr:'Сервер',port:'Порт',user:'Логин',pass:'Пароль',cpS5:'Копировать SOCKS5',cpHttp:'Копировать HTTP',
 helpH:'Нужна помощь?',helpS:'Напишите в поддержку, чтобы продлить подписку, добавить трафик или решить проблему с подключением.',helpB:'Связаться с поддержкой',
 refresh:'Обновить',priv:'Эта страница только для вас; не делитесь ссылкой.',theme:'Сменить тему'}
};
let lang='fa';
try{const q=new URLSearchParams(location.search).get('lang'),sv=localStorage.getItem('lg');lang=LANGS[q]?q:LANGS[sv]?sv:'fa'}catch(e){}
const t=(k,v)=>{let s=(T[lang][k]!=null?T[lang][k]:(T.fa[k]!=null?T.fa[k]:k));if(v)for(const x in v)s=s.replace('{'+x+'}',v[x]);return s};

/* ---------- helpers ---------- */
function sz(n){n=+n||0;const u=['B','KB','MB','GB','TB'];let i=0;while(n>=1024&&i<4){n/=1024;i++}return {v:i>=3?n.toFixed(n>=100?0:2):Math.round(n),u:u[i]}}
const szt=n=>{const x=sz(n);return x.v+' '+x.u};
const szi=n=>'\u2066'+szt(n)+'\u2069';
const fdate=ts=>ts?new Date(ts*1000).toLocaleDateString(LANGS[lang].loc,{year:'numeric',month:'long',day:'numeric'}):t('unl');
let tt;function toast(m){const e=$('#toast');e.textContent=m;e.classList.add('on');clearTimeout(tt);tt=setTimeout(()=>e.classList.remove('on'),1700)}
function legacy(x){const a=document.createElement('textarea');a.value=x;a.setAttribute('readonly','');a.style.cssText='position:fixed;top:0;left:0;opacity:0;font-size:16px';document.body.appendChild(a);a.focus();a.select();let ok=false;try{ok=document.execCommand('copy')}catch(e){}a.remove();return ok}
async function copy(x){let ok=false;if(navigator.clipboard&&window.isSecureContext){try{await navigator.clipboard.writeText(x);ok=true}catch(e){}}if(!ok)ok=legacy(x);if(ok)toast(t('copied'));else prompt(t('copyPrompt'),x)}
function openQR(title,text){const s=window.makeQR(text);$('#mt').textContent=title;$('#qrw').innerHTML=s||'<div style="color:#333;font-size:13px;padding:20px">'+esc(t('qrLong'))+'</div>';$('#mcopy').textContent=t('copy');$('#mclose').textContent=t('close');$('#mcopy').onclick=()=>copy(text);$('#ov').classList.add('on');$('#mclose').focus()}
$('#mclose').onclick=()=>$('#ov').classList.remove('on');$('#ov').onclick=e=>{if(e.target.id==='ov')$('#ov').classList.remove('on')};document.addEventListener('keydown',e=>{if(e.key==='Escape')$('#ov').classList.remove('on')});
function remark(l){try{const i=l.lastIndexOf('#');if(i>-1)return decodeURIComponent(l.slice(i+1))}catch(e){}
  if(l.startsWith('vmess://')){try{return JSON.parse(atob(l.slice(8))).ps||'vmess'}catch(e){}}return l.split('://')[0]}
const proto=l=>(l.split('://')[0]||'').toLowerCase();
const PN={vless:'VLESS',vmess:'VMess',trojan:'Trojan',ss:'Shadowsocks',hysteria2:'Hysteria2',hy2:'Hysteria2',tuic:'TUIC',anytls:'AnyTLS',wireguard:'WireGuard',socks:'SOCKS',http:'HTTP'};
const pname=p=>PN[p]||p.toUpperCase();
const hostU=h=>h.includes(':')&&!h.startsWith('[')?'['+h+']':h;

/* ---------- apps ---------- */
const sub=D.sub,name=D.title,cl=D.clash_url;
const AS=id=>'https://apps.apple.com/app/id'+id,GP=id=>'https://play.google.com/store/apps/details?id='+id,GH=r=>'https://github.com/'+r+'/releases/latest';
const DS={
 streisand:{fa:'رایگان و ساده؛ برای شروع سریع مناسب است.',en:'Free and simple; a quick way to get started.',ru:'Бесплатное и простое; быстрый старт.'},
 v2box:{fa:'رایگان؛ پروتکل‌های زیاد و تست پینگ سرورها.',en:'Free; many protocols and server ping tests.',ru:'Бесплатное; много протоколов и проверка пинга.'},
 hiddify:{fa:'رایگان و متن‌باز؛ لینک اشتراک و Clash را می‌خواند.',en:'Free and open source; reads subscription and Clash links.',ru:'Бесплатное, с открытым кодом; читает подписки и Clash.'},
 happ:{fa:'رایگان؛ رابط ساده با نمایش پینگ سرورها.',en:'Free; simple interface that shows server ping.',ru:'Бесплатное; простой интерфейс с показом пинга.'},
 v2raytun:{fa:'رایگان؛ ظاهر مرتب با تنظیمات DNS و مسیریابی.',en:'Free; tidy design with DNS and routing settings.',ru:'Бесплатное; аккуратный вид, настройки DNS и маршрутов.'},
 karing:{fa:'رایگان؛ لینک اشتراک و کانفیگ Clash را می‌خواند.',en:'Free; reads subscription links and Clash configs.',ru:'Бесплатное; читает подписки и конфиги Clash.'},
 shadowrocket:{fa:'پولی (حدود ۳ دلار)؛ قدیمی و پرامکانات.',en:'Paid (about $3); long-standing and full-featured.',ru:'Платное (около 3 $); проверенное и функциональное.'},
 onexray:{fa:'کلاینت Xray؛ لینک را باید دستی اضافه کنید.',en:'An Xray client; add the link by hand.',ru:'Клиент Xray; ссылку нужно добавить вручную.'},
 v2rayng:{fa:'محبوب‌ترین کلاینت اندروید؛ سبک و بدون تبلیغ.',en:'The most popular Android client; light and ad-free.',ru:'Самый популярный клиент для Android; лёгкий, без рекламы.'},
 flclash:{fa:'هسته Mihomo؛ فقط برای کانفیگ Clash (Mieru، Sudoku و ...).',en:'Mihomo core; for Clash configs only (Mieru, Sudoku, …).',ru:'Ядро Mihomo; только для конфигов Clash (Mieru, Sudoku и др.).'}
};
const IOS=[
 {k:'streisand',n:'Streisand',c:'#7c3aed',tag:['free'],rec:1,i:[['App Store',AS('6450534064')]],add:'streisand://import/'+sub},
 {k:'v2box',n:'V2Box',c:'#0ea5e9',tag:['free'],i:[['App Store',AS('6446814690')]],add:'v2box://install-sub?url='+enc(sub)+'&name='+enc(name)},
 {k:'hiddify',n:'Hiddify',c:'#2563eb',tag:['free','oss'],rec:1,i:[['App Store',AS('6596777532')]],add:'hiddify://import/'+sub+'#'+enc(name),clash:cl&&'hiddify://import/'+cl+'#'+enc(name)},
 {k:'happ',n:'Happ',c:'#16a34a',tag:['free'],i:[['App Store',AS('6504287215')]],add:'happ://add/'+sub},
 {k:'v2raytun',n:'v2RayTun',c:'#f97316',tag:['free'],i:[['App Store',AS('6476628951')]],add:'v2raytun://import/'+sub},
 {k:'karing',n:'Karing',c:'#db2777',tag:['free','mihomo'],i:[['App Store',AS('6472431552')]],add:'karing://install-config?url='+enc(sub)+'&name='+enc(name),clash:cl&&'karing://install-config?url='+enc(cl)+'&name='+enc(name)},
 {k:'shadowrocket',n:'Shadowrocket',c:'#475569',tag:['paid'],i:[['App Store',AS('932747118')]],add:'shadowrocket://add/'+sub},
 {k:'onexray',n:'OneXray',c:'#0f766e',tag:['free'],i:[['App Store',AS('6745748773')]],add:''}
];
const AND=[
 {k:'hiddify',n:'Hiddify',c:'#2563eb',tag:['free','oss'],rec:1,i:[['Google Play',GP('app.hiddify.com')],['apk',GH('hiddify/hiddify-app')]],add:'hiddify://import/'+sub+'#'+enc(name),clash:cl&&'hiddify://import/'+cl+'#'+enc(name)},
 {k:'v2rayng',n:'v2rayNG',c:'#1d4ed8',tag:['free','oss'],rec:1,i:[['Google Play',GP('com.v2ray.ang')],['apk',GH('2dust/v2rayNG')]],add:'v2rayng://install-sub?url='+enc(sub)+'&name='+enc(name)},
 {k:'happ',n:'Happ',c:'#16a34a',tag:['free'],i:[['Google Play',GP('com.happproxy')]],add:'happ://add/'+sub},
 {k:'v2raytun',n:'v2RayTun',c:'#f97316',tag:['free'],i:[['Google Play',GP('com.v2raytun.android')]],add:'v2raytun://import/'+sub},
 {k:'karing',n:'Karing',c:'#db2777',tag:['free','mihomo'],i:[['Google Play',GP('com.nebula.karing')],['apk',GH('KaringX/karing')]],add:'karing://install-config?url='+enc(sub)+'&name='+enc(name),clash:cl&&'karing://install-config?url='+enc(cl)+'&name='+enc(name)},
 {k:'flclash',n:'FlClash',c:'#0891b2',tag:['free','oss','mihomo'],i:[['apk',GH('chen08209/FlClash')]],add:'',clash:cl&&'flclash://install-config?url='+enc(cl),clashOnly:1}
];
const vis=l=>l.filter(a=>!(a.clashOnly&&!cl));
function appRow(a){
  const tags=a.tag.map(x=>`<span class="tag">${esc(t(x))}</span>`).join('');
  const inst=a.i.map(x=>`<a class="btn sec sm" href="${esc(x[1])}" target="_blank" rel="noopener noreferrer">${esc(x[0]==='apk'?t('apk'):x[0])}</a>`).join('');
  let add='';if(a.add)add+=`<a class="btn sm" href="${esc(a.add)}">${esc(t('addSub'))}</a>`;if(a.clash)add+=`<a class="btn sm" href="${esc(a.clash)}">${esc(t('addClash'))}</a>`;
  return `<div class="app"><div class="ico" style="background:${a.c}">${esc(a.n[0])}</div><div><h3>${esc(a.n)}${a.rec?`<span class="tag rec">${esc(t('rec'))}</span>`:''}${tags}</h3><p>${esc(DS[a.k][lang])}</p></div><div class="row">${inst}${add}</div></div>`}
const appList=l=>`<p class="steps"><span><b>1</b> ${esc(t('s1'))}</span> › <span><b>2</b> ${esc(t('s2'))}</span> › <span><b>3</b> ${esc(t('s3'))}</span></p>`+vis(l).map(appRow).join('')+`<p class="note">${esc(t('appNote'))}</p>`;

/* ---------- gauge numbers ---------- */
const now=Date.now()/1000,bad=D.status!=='active';
const unl=!D.limit,left=unl?0:Math.max(0,D.limit-D.used),pct=unl?0:Math.min(100,D.used/D.limit*100);
const days=D.expire?Math.ceil((D.expire-now)/86400):null;
let tpct=0;if(D.expire){const span=D.expire-(D.created&&D.created<D.expire?D.created:D.expire-30*86400);tpct=Math.max(0,Math.min(100,(D.expire-now)/span*100))}
const STOP={ok:['#C4B5FD','#7C3AED'],teal:['#7DD3FC','#38BDF8'],warn:['#F8D28A','#F59E0B'],bad:['#FF9AA5','#FF5468'],mut:['#4A3F66','#4A3F66']};
const dataK=bad?'mut':pct>=90?'bad':pct>=70?'warn':'ok';
const dayK=bad?'mut':(days!==null&&days<=3)?'warn':'teal';
const leftPct=unl?100:100-pct, timePct=D.expire?tpct:100;
const I={moon:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',info:'<circle cx="12" cy="12" r="9"/><path d="M12 8h.01M11 12h1v4h1"/>',phone:'<rect x="6" y="2.5" width="12" height="19" rx="3"/><path d="M10.5 18.5h3"/>',droid:'<path d="M5 17V9a7 7 0 0 1 14 0v8a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2z"/><path d="M9 10h.01M15 10h.01M8 3.5 6.5 2M16 3.5 17.5 2"/>',refresh:'<path d="M20 11a8 8 0 1 0-2.3 5.7M20 4v7h-7"/>',upl:'<path d="M12 19V5M6 11l6-6 6 6"/>',dwn:'<path d="M12 5v14M6 13l6 6 6-6"/>'};
const svg=(p,x)=>`<svg viewBox="0 0 24 24" aria-hidden="true"${x||''}>${p}</svg>`;

/* ---------- state ---------- */
const ua=navigator.userAgent||'';
let plat=/iPhone|iPad|iPod/.test(ua)||(/Macintosh/.test(ua)&&navigator.maxTouchPoints>1)?'ios':/Android/.test(ua)?'and':'';
let flt='',term='',shown=20,first=true;
const val=k=>k==='sub'?D.sub:k==='cu'?D.clash_url:k==='cc'?D.clash:k==='wg'?D.wg:k[0]==='p'?pv(k):D.links[+k.slice(1)];
function pv(k){const m=k.match(/^p(\w)(\d+)$/),p=D.proxies[+m[2]];if(!p)return '';const a=enc(p.user)+':'+enc(p.pass)+'@'+hostU(p.host)+':'+p.port;return m[1]==='s'?'socks5://'+a:m[1]==='h'?'http://'+a:p[m[1]==='u'?'user':m[1]==='w'?'pass':'host']}

function view(){
 const L=LANGS[lang];document.documentElement.lang=lang;document.documentElement.dir=L.dir;
 const lg=D.logo?`<img class="logo" src="${esc(D.logo)}" alt="" referrerpolicy="no-referrer" onerror="this.outerHTML='<div class=mark>${esc((D.title[0]||'V').toUpperCase())}</div>'">`:`<div class="mark">${esc((D.title[0]||'V').toUpperCase())}</div>`;
 let h=`<div class="bar">${lg}<h1>${esc(D.title)}<small>${esc(D.username)}</small></h1></div>
 <div class="lg" role="group" aria-label="Language">${Object.keys(LANGS).map(k=>`<button data-l="${k}" aria-pressed="${k===lang}">${LANGS[k].n}</button>`).join('')}</div>`;
 if(D.notice)h+=`<div class="notice">${svg(I.info)}<div>${esc(D.notice).replace(/\n/g,'<br>')}</div></div>`;
 const R=84,C=2*Math.PI*R;
 const ringSVG=(id,pc,k)=>`<svg viewBox="0 0 200 200" aria-hidden="true"><defs><linearGradient id="g${id}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${STOP[k][0]}"/><stop offset="1" stop-color="${STOP[k][1]}"/></linearGradient></defs><circle class="trk" cx="100" cy="100" r="${R}" stroke-width="15"/><circle id="r${id}" cx="100" cy="100" r="${R}" stroke-width="15" stroke="url(#g${id})" stroke-dasharray="${C}" stroke-dashoffset="${first?C:C*(1-pc/100)}"/></svg>`;
 const dCen=unl?`<div class="big">∞</div><div class="cap">${esc(t('unlcap'))}</div>`:`<div class="big">${sz(left).v}<small>${sz(left).u}</small></div><div class="cap">${esc(t('left'))}</div>`;
 const tCen=D.expire?`<div class="big">${Math.max(0,days)}</div><div class="cap">${esc(days>0?t('daysCap'):t('over'))}</div>`:`<div class="big">∞</div><div class="cap">${esc(t('unl'))}</div>`;
 const dSub=unl?t('usedOnly',{x:szi(D.used)}):t('usedOf',{a:szi(D.used),b:szi(D.limit)});
 const tSub=D.expire?t('endsOn',{d:fdate(D.expire)}):t('noExp');
 const rings=`<div class="rings"><div class="rg"><div class="ring">${ringSVG('D',leftPct,dataK)}<div class="c">${dCen}</div></div><div class="rl">${esc(t('dataL'))}</div><div class="rs">${esc(dSub)}</div></div>
 <div class="rg"><div class="ring">${ringSVG('T',timePct,dayK)}<div class="c">${tCen}</div></div><div class="rl">${esc(t('timeL'))}</div><div class="rs">${esc(tSub)}</div></div></div>`;
 h+=`<div class="sheet"><div class="sec hero">${rings}<span class="pill ${esc(D.status)}">${esc(t(D.status))}</span>`;
 if(bad)h+=`<div class="warnbox bad" style="width:100%;margin:12px 0 0">${esc(t(D.status==='expired'?'wExp':D.status==='limited'?'wLim':'wDis'))}</div>`;
 else if(!unl&&pct>=90)h+=`<div class="warnbox bad" style="width:100%;margin:12px 0 0">${esc(t('wLow',{x:szi(left)}))}</div>`;
 else if(days!==null&&days<=3)h+=`<div class="warnbox" style="width:100%;margin:12px 0 0">${esc(days>0?t('wDays',{n:days}):t('wToday'))}</div>`;
 const tl=(c,ic,lab,v)=>`<div><div class="tile ${c}"><i>${svg(ic)}</i><div><span>${esc(lab)}</span><b class="num">${esc(v)}</b></div></div></div>`;
 h+=`<div class="grid"><div><span>${esc(t('used'))}</span><b class="num">${esc(szt(D.used))}</b></div><div><span>${esc(t('total'))}</span><b class="num">${unl?esc(t('unl')):esc(szt(D.limit))}</b></div>`;
 if(D.up+D.down>0)h+=tl('up',I.upl,t('up'),szt(D.up))+tl('dn dn',I.dwn,t('down'),szt(D.down));
 h+=`<div><span>${esc(t('ends'))}</span><b>${esc(fdate(D.expire))}</b></div>${D.created?`<div><span>${esc(t('started'))}</span><b>${esc(fdate(D.created))}</b></div>`:''}${t(D.reset)!==D.reset&&D.reset!=='none'?`<div><span>${esc(t('reset'))}</span><b>${esc(t(D.reset))}</b></div>`:''}</div></div>`;
 if(!bad){
  h+=`<div class="sec"><h2>${esc(t('conn'))}</h2><p class="sub">${esc(t('connS'))}</p><div class="plat">
   <button class="pbtn" data-p="ios" aria-expanded="${plat==='ios'}" aria-controls="p-ios">${svg(I.phone)}iPhone / iPad<small>${esc(t('napps',{n:vis(IOS).length}))}</small></button>
   <button class="pbtn" data-p="and" aria-expanded="${plat==='and'}" aria-controls="p-and">${svg(I.droid)}Android<small>${esc(t('napps',{n:vis(AND).length}))}</small></button></div>
   <div class="apps${plat==='ios'?' open':''}" id="p-ios">${appList(IOS)}</div><div class="apps${plat==='and'?' open':''}" id="p-and">${appList(AND)}</div></div>`;
  const q=window.makeQR(D.sub);
  h+=`<div class="sec"><h2>${esc(t('linkH'))}</h2><p class="sub">${esc(t('linkS'))}</p><div class="url">${esc(D.sub)}</div>
   <div class="row"><button class="btn" data-copy="sub">${esc(t('copyLink'))}</button></div>${q?`<div class="qrin">${q}</div><p class="qcap">${esc(t('scan'))}</p>`:''}</div>`;
  if(D.links.length){const ps=[...new Set(D.links.map(proto))];
   h+=`<div class="sec"><h2>${esc(t('srv'))} (${D.links.length})</h2><p class="sub">${esc(t('srvS'))}</p>
   <div class="tools"><input id="q" type="search" value="${esc(term)}" placeholder="${esc(t('search'))}" aria-label="${esc(t('search'))}"><button class="btn sec sm" id="ca">${esc(t('copyAll'))}</button></div>
   ${ps.length>1?`<div class="chips">${[''].concat(ps).map(p=>`<button class="chip" data-f="${esc(p)}" aria-pressed="${p===flt}">${p?esc(pname(p)):esc(t('all'))}</button>`).join('')}</div>`:''}<div id="nl"></div></div>`}
  if(D.clash||D.wg||D.proxies.length){h+=`<div class="sec"><h2>${esc(t('moreH'))}</h2>`;
   if(D.proxies.length){
    h+=`<details><summary>${esc(t('tg'))}</summary><p class="note">${esc(t('tgNote'))}</p>${D.proxies.map(p=>`<a class="btn sm more" href="https://t.me/socks?server=${enc(p.host)}&port=${p.port}&user=${enc(p.user)}&pass=${enc(p.pass)}" target="_blank" rel="noopener noreferrer">${esc(t('tgAdd'))}${D.proxies.length>1?' · '+esc(p.name):''}</a>`).join('')}</details>`;
    h+=`<details><summary>${esc(t('px'))}</summary><p class="note">${esc(t('pxNote'))}</p>${D.proxies.map((p,i)=>`<div class="pxn">${esc(p.name)}</div>
     <div class="kvr"><span>${esc(t('srvr'))}</span><b>${esc(p.host)}</b></div><div class="kvr"><span>${esc(t('port'))}</span><b>${p.port}</b></div><div class="kvr"><span>${esc(t('user'))}</span><b>${esc(p.user)}</b></div><div class="kvr"><span>${esc(t('pass'))}</span><b>${esc(p.pass)}</b></div>
     <div class="row" style="margin-top:8px"><button class="btn sm" data-copy="ps${i}">${esc(t('cpS5'))}</button><button class="btn sec sm" data-copy="ph${i}">${esc(t('cpHttp'))}</button></div>`).join('')}</details>`}
   if(D.clash)h+=`<details><summary>Clash / Mihomo</summary><p class="note">${esc(t('clashNote'))}</p><div class="url">${esc(D.clash_url)}</div><div class="row"><button class="btn sm" data-copy="cu">${esc(t('clashCopy'))}</button><button class="btn sec sm" data-copy="cc">${esc(t('cfgCopy'))}</button></div></details>`;
   if(D.wg)h+=`<details><summary>WireGuard</summary><pre>${esc(D.wg)}</pre><div class="row"><button class="btn sm" data-copy="wg">${esc(t('cfgCopy'))}</button><button class="btn sec sm" data-qr="wg">QR</button><a class="btn sec sm" href="${esc(D.wg_url)}" download>${esc(t('wgDl'))}</a></div></details>`;
   h+=`</div>`}
 }
 if(D.support)h+=`<div class="sec"><h2>${esc(t('helpH'))}</h2><p class="sub">${esc(t('helpS'))}</p><a class="btn" href="${esc(D.support)}" target="_blank" rel="noopener noreferrer">${esc(t('helpB'))}</a></div>`;
 h+=`</div><footer><button class="btn sec sm" id="rf">${svg(I.refresh,' style="width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:2"')}${esc(t('refresh'))}</button><span>${esc(t('priv'))}</span></footer>`;
 $('#app').innerHTML=h;
 drawNodes();bind();
 if(first){first=false;requestAnimationFrame(()=>requestAnimationFrame(()=>{const a=$('#rD'),b=$('#rT');if(!a)return;const tr='stroke-dashoffset 1s cubic-bezier(.2,.7,.2,1)';a.style.transition=b.style.transition=tr;a.style.strokeDashoffset=C*(1-leftPct/100);b.style.strokeDashoffset=C*(1-timePct/100)}))}
}
function drawNodes(){const box=$('#nl');if(!box)return;
 const rows=D.links.map((l,i)=>({l,i})).filter(({l})=>(!flt||proto(l)===flt)&&(!term||remark(l).toLowerCase().includes(term)));
 const part=rows.slice(0,shown);
 box.innerHTML=(part.length?part.map(({l,i})=>`<div class="node"><div class="nm"><b>${esc(remark(l))}</b><small>${esc(pname(proto(l)))}</small></div><button class="btn sm" data-copy="l${i}">${esc(t('copy'))}</button><button class="btn sec sm" data-qr="l${i}">QR</button></div>`).join(''):`<div class="empty">${esc(t('none'))}</div>`)+
  (rows.length>shown?`<button class="btn sec more" id="sm">${esc(t('more',{n:rows.length-shown}))}</button>`:'');
 const sm=$('#sm');if(sm)sm.onclick=()=>{shown+=20;drawNodes()}}
const root=document.documentElement;
function bind(){
 $$('.lg button').forEach(b=>b.onclick=()=>{lang=b.dataset.l;try{localStorage.setItem('lg',lang)}catch(e){}view()});
 $('#rf').onclick=()=>location.reload();
 $$('.pbtn').forEach(b=>b.onclick=()=>{const open=b.getAttribute('aria-expanded')==='true';$$('.pbtn').forEach(x=>{x.setAttribute('aria-expanded','false');$('#p-'+x.dataset.p).classList.remove('open')});
  plat=open?'':b.dataset.p;if(!open){b.setAttribute('aria-expanded','true');const el=$('#p-'+b.dataset.p);el.classList.add('open');setTimeout(()=>el.scrollIntoView({behavior:'smooth',block:'nearest'}),50)}});
 const qi=$('#q');if(qi)qi.oninput=()=>{term=qi.value.trim().toLowerCase();shown=20;drawNodes()};
 $$('.chip').forEach(c=>c.onclick=()=>{flt=c.dataset.f;shown=20;$$('.chip').forEach(x=>x.setAttribute('aria-pressed',x===c?'true':'false'));drawNodes()});
 const ca=$('#ca');if(ca)ca.onclick=()=>copy(D.links.join('\n'));
}
document.addEventListener('click',e=>{const c=e.target.closest('[data-copy]');if(c){copy(val(c.dataset.copy));return}
 const q=e.target.closest('[data-qr]');if(q){const k=q.dataset.qr;openQR(k==='wg'?'WireGuard':remark(D.links[+k.slice(1)]),val(k))}});
view();
})();
</script>
</body>
</html>
"""
