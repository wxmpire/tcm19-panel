"""Tunnel health checks (why is it not working?) and benchmark (which one is fastest?)."""
import json
import re
import socket
import statistics
import time

from . import config, system, tunnels
from . import tunnel_tools as tt

LOG_HINTS = [
    (r"address already in use|bind: .*in use|EADDRINUSE", "پورت قبلاً توسط برنامه‌ی دیگری استفاده شده. پورت دیگری انتخاب کن یا برنامه‌ی قبلی را ببند: ss -lntup | grep :PORT"),
    (r"connection refused|ECONNREFUSED", "اتصال رد شد: سرور مقابل اجرا نیست، پورتش اشتباه است یا فایروال آن بسته است."),
    (r"i/o timeout|timed? ?out|deadline exceeded|no route to host|unreachable", "تایم‌اوت: مسیر شبکه تا سرور مقابل بسته است (فایروال دیتاسنتر، فیلتر آی‌پی یا پورت اشتباه). آی‌پی را از یک سرور دیگر هم تست کن."),
    (r"auth|token|unauthori[sz]ed|invalid password|forbidden|401|403", "احراز هویت ناموفق: توکن دو طرف باید یکی باشد. تنظیمات سرور مقابل را از «راهنمای اتصال» دوباره کپی کن."),
    (r"permission denied|operation not permitted", "دسترسی کافی نیست (پورت زیر ۱۰۲۴، یا کرنل/کانتینر اجازه‌ی ساخت تونل نمی‌دهد). روی VPSهای OpenVZ/LXC تونل‌های GRE/IPIP/WireGuard معمولاً کار نمی‌کنند."),
    (r"no such file|not found|exec format|cannot execute", "فایل اجرایی یا تنظیمات پیدا نشد / با معماری سازگار نیست. برنامه را از دکمه‌ی «نصب» دوباره نصب کن."),
    (r"handshake|certificate|tls|x509", "خطای TLS/Handshake: ساعت دو سرور را بررسی کن (timedatectl) و مطمئن شو ترنسپورت دو طرف یکی است."),
    (r"unknown (variable|field|key)|parse|invalid (config|toml)|syntax|unmarshal", "فایل تنظیمات توسط برنامه قبول نشد. نسخه‌ی برنامه را با «نصب» به‌روز کن (فرمت تنظیمات در نسخه‌های قدیمی فرق دارد)."),
    (r"RTNETLINK|Cannot find device|Operation not supported|Protocol not supported", "کرنل این نوع تونل را پشتیبانی نمی‌کند (ماژول gre/ipip/vxlan/wireguard). این سرور احتمالاً مجازی‌سازی OpenVZ/LXC دارد."),
]


def _ok(n, d, ok=True):
    return {"n": n, "ok": ok, "d": d}


def _tcp_ms(host: str, port: int, timeout: float = 3.0):
    t0 = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return (time.perf_counter() - t0) * 1000
    except OSError:
        return None


def _listening() -> set[tuple[int, str]]:
    """{(port, 'tcp'|'udp')} of sockets listening on this server."""
    from .system import run
    code, out = run(["ss", "-H", "-ltnu"], 10)
    res = set()
    if code != 0:
        return res
    for line in out.splitlines():
        p = line.split()
        if len(p) >= 5:
            m = re.search(r":(\d+)$", p[4])
            if m:
                res.add((int(m.group(1)), "tcp" if p[0].startswith("tcp") else "udp"))
    return res


def _ufw_blocks(port: int) -> bool:
    from .system import have, run
    if not have("ufw"):
        return False
    code, out = run(["ufw", "status"], 8)
    if "Status: active" not in out:
        return False
    return not re.search(rf"(^|\s){port}(/|\s)", out)


def _health_inbound(t: dict, listening: set) -> dict:
    """Plain port-forward / via-outbound tunnels (Xray dokodemo-door)."""
    s = t["settings"]
    base = {"id": t["id"], "name": t["name"], "kind": t["kind"], "line": f":{t['port']} ← {s['target_host']}:{s['target_port']}", "log": []}
    if not t["enabled"]:
        return {**base, "level": "off", "checks": [_ok("وضعیت", "تونل خاموش است", None)], "hints": ["تونل را روشن کن."]}
    state = system.service_state(config.XRAY_SERVICE)
    checks = [_ok("Xray", state, state in ("active", "dry-run"))]
    hints = [] if state in ("active", "dry-run") else ["Xray بالا نیست: صفحه‌ی «موتورها» را ببین یا journalctl -u xray -n 30"]
    if not config.DRY_RUN:
        ok = (t["port"], "tcp") in listening
        checks.append(_ok(f"گوش‌دادن روی پورت {t['port']}", "باز است" if ok else "باز نیست", ok))
        if not ok:
            hints.append("پورت باز نشده؛ بعد از ذخیره چند ثانیه صبر کن یا در «موتورها» ری‌استارت Xray را بزن.")
        if _ufw_blocks(t["port"]):
            checks.append(_ok(f"فایروال ufw برای {t['port']}", "پورت در ufw اجازه ندارد", False))
            hints.append(f"ufw allow {t['port']}")
        try:
            ms = _tcp_ms(s["target_host"], int(s["target_port"]))
        except (TypeError, ValueError):
            ms = None
        checks.append(_ok(f"اتصال به مقصد {s['target_host']}:{s['target_port']}", f"{ms:.0f} ms" if ms is not None else "وصل نشد", ms is not None))
        if ms is None:
            hints.append("مقصد از این سرور در دسترس نیست؛ آدرس/پورت یا فایروال سرور مقصد را بررسی کن.")
    bad = [c for c in checks if c["ok"] is False]
    if not bad and not hints:
        hints.append("همه‌چیز سالم به نظر می‌رسد.")
    return {**base, "level": "ok" if not bad else "bad", "checks": checks, "hints": hints}


def health_one(t: dict, listening: set, enabled_only: bool = True) -> dict:
    from .system import run
    if t.get("inbound"):
        return _health_inbound(t, listening)
    info = tunnels.diag_info(t)
    checks, hints = [], []
    unit = tunnels.unit_name(t) if t["kind"] != "reverse" else config.XRAY_SERVICE
    if not t["enabled"]:
        return {"id": t["id"], "name": t["name"], "kind": t["kind"], "level": "off", "checks": [_ok("وضعیت", "تونل خاموش است", None)], "hints": ["تونل را روشن کن."], "log": []}
    miss = tt.missing_bins(t) if t["kind"] in tt.KINDS else []
    if t["kind"] in tt.KINDS:
        checks.append(_ok("برنامه‌ی لازم", "نصب است" if not miss else "نصب نیست: " + ", ".join(miss), not miss))
        if miss:
            hints.append("در «مدیریت تونل‌ها» دکمه‌ی «نصب برنامه‌ها» را بزن، بعد تونل را یک بار ذخیره کن.")
    state = tunnels.status(t)
    active = state in ("active", "dry-run")
    checks.append(_ok("سرویس", f"{unit}: {state}", active))
    if not active and not miss:
        hints.append(f"سرویس بالا نیست. اول لاگ پایین را بخوان، بعد: systemctl restart {unit}")
    if config.DRY_RUN:
        return {"id": t["id"], "name": t["name"], "kind": t["kind"], "level": "bad" if miss else "ok", "checks": checks, "hints": hints, "log": []}
    for port, proto in info["listen"]:
        ok = (port, proto) in listening
        checks.append(_ok(f"گوش‌دادن روی پورت {port}/{proto}", "باز است" if ok else "کسی روی این پورت گوش نمی‌دهد", ok))
        if not ok and active and t["kind"] not in tt.ONESHOT:
            hints.append(f"پورت {port} باز نشده با اینکه سرویس فعال است؛ معمولاً یعنی برنامه بعد از اجرا خطا داده. لاگ را ببین.")
        if ok and _ufw_blocks(port):
            checks.append(_ok(f"فایروال ufw برای {port}", "پورت در ufw اجازه ندارد", False))
            hints.append(f"ufw فعال است و پورت {port} در آن نیست: ufw allow {port}")
    if info["peer"]:
        h, p = info["peer"]
        ms = _tcp_ms(h, p)
        checks.append(_ok(f"اتصال TCP به {h}:{p}", f"{ms:.0f} ms" if ms is not None else "وصل نشد", ms is not None))
        if ms is None:
            hints.append(f"از این سرور به {h}:{p} نمی‌شود وصل شد: سرور مقابل خاموش است، سرویسش بالا نیست، یا پورت در فایروال سرور مقابل/پنل هاستینگ بسته است.")
    if t["kind"] in ("gre", "ipip", "vxlan", "wg"):
        ir = t["settings"]["inner_remote"]
        code, out = run(["ping", "-c", "2", "-W", "2", ir], 10)
        checks.append(_ok(f"پینگ آی‌پی داخلی {ir}", "جواب می‌دهد" if code == 0 else "جواب نداد", code == 0))
        if code != 0:
            hints.append("آی‌پی داخلی جواب نمی‌دهد: سرور مقابل را طبق «راهنمای اتصال» نصب کن؛ فایروال باید پروتکل/پورت تونل را بین دو سرور باز بگذارد.")
        if t["kind"] == "wg":
            code, out = run(["wg", "show", f"ptun{t['id']}", "latest-handshakes"], 8)
            hs = [int(x.split()[-1]) for x in out.splitlines() if x.split() and x.split()[-1].isdigit()]
            ok = bool(hs) and max(hs) > 0 and time.time() - max(hs) < 300
            checks.append(_ok("Handshake WireGuard", "تازه است" if ok else "هنوز handshake نشده", ok))
            if not ok:
                hints.append("Handshake انجام نشده: کلیدها را از راهنما دوباره کپی کن و مطمئن شو پورت UDP باز است و Endpoint درست است.")
    if t["kind"] in ("dnat",) or (t["kind"] in tt.ONESHOT and t["settings"].get("expose_port")):
        code, out = run(["sysctl", "-n", "net.ipv4.ip_forward"], 5)
        checks.append(_ok("IP forwarding", "فعال" if out.strip() == "1" else "غیرفعال", out.strip() == "1"))
        if out.strip() != "1":
            hints.append("sysctl -w net.ipv4.ip_forward=1")
    code, out = run(["journalctl", "-u", unit, "-n", "14", "--no-pager", "-o", "cat"], 10)
    log = [l[-300:] for l in out.splitlines()[-14:]] if code == 0 else []
    text = "\n".join(log)
    for pat, hint in LOG_HINTS:
        if re.search(pat, text, re.I) and hint not in hints:
            hints.append(hint)
    bad = [c for c in checks if c["ok"] is False]
    level = "ok" if not bad else "bad" if (not active or any("سرویس" in c["n"] or "برنامه" in c["n"] for c in bad)) else "warn"
    if level == "ok" and not hints:
        hints.append("همه‌چیز سالم به نظر می‌رسد. اگر کاربر هنوز وصل نمی‌شود، مشکل از فایروال پنل هاستینگ یا تنظیم برنامه‌ی کاربر است.")
    return {"id": t["id"], "name": t["name"], "kind": t["kind"], "line": info["line"], "level": level, "checks": checks, "hints": hints, "log": log}


def health_all(rows: list[dict]) -> list[dict]:
    listening = _listening() if not config.DRY_RUN else set()
    return [health_one(t, listening) for t in rows]


def _ping(host: str, n: int):
    from .system import run
    code, out = run(["ping", "-c", str(n), "-W", "2", "-i", "0.3", host], 12 + n)
    m = re.search(r"(\d+(?:\.\d+)?)% packet loss", out)
    r = re.search(r"= ([\d.]+)/([\d.]+)/([\d.]+)/([\d.]+)", out)
    if not m:
        return None
    return {"loss": float(m.group(1)), "avg": float(r.group(2)) if r else None, "jitter": float(r.group(4)) if r else None}


def _iperf(host: str, port: int, secs: int = 5):
    from .system import have, run
    if not have("iperf3"):
        return {"error": "iperf3 نصب نیست (apt install -y iperf3)"}
    code, out = run(["iperf3", "-c", host, "-p", str(port), "-t", str(secs), "-J"], secs + 15)
    try:
        d = json.loads(out)
        if "error" in d:
            return {"error": str(d["error"])[:120]}
        return {"mbps": round(d["end"]["sum_received"]["bits_per_second"] / 1e6, 1)}
    except Exception:
        return {"error": (out or "iperf3 failed")[-120:]}


def benchmark_one(t: dict, samples: int = 8, speed: bool = False) -> dict:
    info = tunnels.diag_info(t)
    res = {"id": t["id"], "name": t["name"], "kind": t["kind"], "line": info["line"], "latency": None, "jitter": None, "loss": None,
           "mbps": None, "notes": []}
    if config.DRY_RUN:
        res["notes"].append("dry-run")
        return res
    xs: list[float] = []
    if info["peer"]:
        h, p = info["peer"]
        for _ in range(samples):
            ms = _tcp_ms(h, p, 2.5)
            if ms is not None:
                xs.append(ms)
            time.sleep(0.05)
        res["loss"] = round(100 * (samples - len(xs)) / samples, 1)
        if xs:
            res["latency"] = round(statistics.median(xs), 1)
            res["jitter"] = round(statistics.pstdev(xs), 1) if len(xs) > 1 else 0.0
        res["notes"].append(f"تأخیر = اتصال TCP تا {h}:{p}")
    elif info["icmp"]:
        r = _ping(info["icmp"], samples)
        if r:
            res.update(latency=r["avg"], jitter=r["jitter"], loss=r["loss"])
            res["notes"].append(f"تأخیر = پینگ تا {info['icmp']}")
    else:
        res["notes"].append("این سرور مقصدی برای اندازه‌گیری ندارد (سرور مقابل خودش وصل می‌شود). آدرس سرور مقابل را در تنظیمات تونل بگذار.")
    if speed:
        if info["entry"]:
            h, p = info["entry"]
            r = _iperf(h, p)
            if "mbps" in r:
                res["mbps"] = r["mbps"]
                res["notes"].append("سرعت با iperf3 از طریق ورودی تونل")
            else:
                res["notes"].append(r["error"])
        else:
            res["notes"].append("برای این نوع تونل ورودی محلی برای تست سرعت وجود ندارد.")
    return res


def benchmark(rows: list[dict], samples: int, speed_ids: set[int]) -> dict:
    out = [benchmark_one(t, samples, t["id"] in speed_ids) for t in rows if t["enabled"]]
    lat = [r for r in out if r["latency"] is not None and (r["loss"] or 0) < 100]
    spd = [r for r in out if r["mbps"] is not None]
    best_lat = min(lat, key=lambda r: (r["latency"], r["loss"] or 0))["id"] if lat else None
    best_spd = max(spd, key=lambda r: r["mbps"])["id"] if spd else None
    # overall: when speed was measured rank by speed per ms, otherwise by latency
    best = None
    if spd:
        best = max(spd, key=lambda r: r["mbps"] / max(r["latency"] or 50, 1))["id"]
    elif best_lat is not None:
        best = best_lat
    return {"results": out, "best_latency": best_lat, "best_speed": best_spd, "best": best}


def preflight(kind: str, body: dict, existing, inbounds, rows, settings) -> dict:
    """Read-only check of a tunnel that is NOT saved: validation, program, ports, remote reachability."""
    checks = []
    try:
        data = tunnels.normalize({**body, "kind": kind}, existing, inbounds, rows, settings)
    except tunnels.TunnelError as e:
        return {"ok": False, "checks": [_ok("اعتبارسنجی تنظیمات", str(e), False)]}
    checks.append(_ok("اعتبارسنجی تنظیمات", "درست است"))
    t = {"id": existing["id"] if existing else 0, "name": data["name"], "kind": kind, "port": data["port"], "settings": data["settings"], "enabled": True}
    if kind in tt.KINDS:
        miss = tt.missing_bins(t)
        checks.append(_ok("برنامه‌ی لازم روی این سرور", "نصب است" if not miss else "نصب نیست: " + ", ".join(miss) + " (در «نصب برنامه‌ها» نصب کن)", not miss))
    if not config.DRY_RUN:
        info = tunnels.diag_info(t)
        if not existing:
            from .inbound_rules import _bind_free
            for port, proto in info["listen"]:
                if proto == "tcp":
                    free = _bind_free(port, {"tcp"})
                    checks.append(_ok(f"پورت {port} آزاد است", "آزاد" if free else "در حال استفاده توسط برنامه‌ی دیگر", free))
        if info["peer"]:
            h, p = info["peer"]
            ms = _tcp_ms(h, p)
            checks.append(_ok(f"دسترسی به {h}:{p}", f"{ms:.0f} ms" if ms is not None else "وصل نشد (اگر سرور مقابل هنوز راه‌اندازی نشده، طبیعی است)", ms is not None))
    return {"ok": all(c["ok"] is not False for c in checks), "checks": checks}
