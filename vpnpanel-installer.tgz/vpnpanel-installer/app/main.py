import asyncio
import base64
import json
import logging
import os
import re
import secrets
import sqlite3
import tempfile
from pathlib import Path
import threading
import time
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, PlainTextResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import version as _ver
from . import config, db, mihomo_config, subpage, monitor, protocols, security, system, cloudflare, inbound_rules, subport, serverips, outbounds, tunnels, tunnel_tools, tunnel_diag, tunnel_traffic, sessions, ovpn, apikeys, backup, tgbot, activity, online, health, geo, nodes, nordvpn
import subprocess
import shutil

log = logging.getLogger("panel")
GB = 1024 ** 3
USERNAME_RE = r"^[A-Za-z0-9_.-]{3,32}$"
TAG_RE = r"^[A-Za-z0-9_-]{2,32}$"
RESERVED_PORTS = {10085}


# ------------------------------------------------------------------ startup
def bootstrap_admin():
    if db.admin_count():
        return
    user = os.environ.get("PANEL_ADMIN_USER", "admin")
    pw = os.environ.get("PANEL_ADMIN_PASS") or secrets.token_urlsafe(12)
    db.create_admin(user, security.hash_password(pw))
    config.INITIAL_ADMIN_FILE.write_text(f"username: {user}\npassword: {pw}\n")
    os.chmod(config.INITIAL_ADMIN_FILE, 0o600)
    log.warning("Created admin '%s'. Credentials saved to %s", user, config.INITIAL_ADMIN_FILE)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logging.basicConfig(level=logging.INFO)
    db.init()
    try:
        inbound_rules.migrate(db)
    except Exception:
        log.exception("inbound migration failed")
    bootstrap_admin()
    asyncio.create_task(asyncio.to_thread(monitor.apply_now))
    task = asyncio.create_task(monitor.run_forever())
    yield
    task.cancel()


app = FastAPI(title="tcm19", version=_ver.VERSION, lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
if config.STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=config.STATIC_DIR), name="static")


@app.middleware("http")
async def _security_headers(request: Request, call_next):
    resp = await call_next(request)
    h = resp.headers
    h.setdefault("X-Content-Type-Options", "nosniff")
    h.setdefault("X-Frame-Options", "DENY")
    h.setdefault("Referrer-Policy", "no-referrer")
    h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    if request.url.path.startswith("/api/"):
        h.setdefault("Cache-Control", "no-store")
    return resp


@app.middleware("http")
async def _activity_mw(request: Request, call_next):
    resp = await call_next(request)
    try:
        p = request.url.path
        if request.method in ("POST", "PUT", "DELETE") and p.startswith("/api/") and resp.status_code < 400 \
                and not p.startswith(("/api/auth", "/api/tg/", "/api/tgbot/test")):
            st = request.state
            actor = getattr(st, "actor", None)
            if actor:
                ip = request.client.host if request.client else ""
                await asyncio.to_thread(activity.log, actor, getattr(st, "src", "panel"),
                                        activity.describe(request.method, p), getattr(st, "detail", ""), ip)
    except Exception:
        log.exception("activity log failed")
    return resp


# ------------------------------------------------------------------ auth
_fails: dict[str, list[float]] = {}


def _pv(password_hash: str) -> str:
    return security.pw_version(password_hash + "|" + sessions.epoch())


_API_BLOCKED = ("/api/me", "/api/api-keys", "/api/backup", "/api/auth", "/api/tgbot")


def admin_required(request: Request, authorization: str | None = Header(default=None),
                   x_api_key: str | None = Header(default=None)) -> str:
    tok = x_api_key or (authorization[7:] if authorization and authorization.lower().startswith("bearer ") else "")
    if not tok:
        raise HTTPException(401, "unauthorized")
    if tok.startswith(apikeys.PREFIX):  # API key (for bots / scripts)
        k = apikeys.verify(tok)
        if not k:
            raise HTTPException(401, "invalid api key")
        request.state.actor, request.state.src = f"api:{k['name']}", "api"
        if request.url.path.startswith(_API_BLOCKED):
            raise HTTPException(403, "این مسیر با کلید API در دسترس نیست")
        if k["scope"] == "read" and request.method not in ("GET", "HEAD"):
            raise HTTPException(403, "این کلید فقط خواندنی است")
        return db.first_admin()
    sub = security.read_token(tok)
    row = db.get_admin(sub) if sub else None
    if not row or not security.read_token(tok, _pv(row["password_hash"])):
        raise HTTPException(401, "unauthorized")
    request.state.actor, request.state.src = sub, "panel"
    request.state.scope = None
    if row.get("role") == "reseller":
        if not row["enabled"]:
            raise HTTPException(403, "حساب شما غیرفعال شده است")
        if not _reseller_path_ok(request.url.path, request.method):
            raise HTTPException(403, "این بخش برای ادمین فروشنده در دسترس نیست")
        request.state.scope = row
    return sub


_RS_OK = re.compile(r"^/api/(users(/\d+(/(reset-usage|revoke-sub|links|usage))?)?|me|me/password|online|online/\d+/kick|inbounds)$")


def _reseller_path_ok(path: str, method: str) -> bool:
    if not _RS_OK.match(path):
        return False
    if path == "/api/inbounds":
        return method == "GET"
    return True


def _scope(request: Request):
    return getattr(request.state, "scope", None)


def _owner_only(request: Request, admin: str = Depends(admin_required)) -> str:
    if _scope(request):
        raise HTTPException(403, "forbidden")
    return admin


def _owner_jwt(request: Request, admin: str = Depends(_owner_only)) -> str:
    if request.state.src != "panel":
        raise HTTPException(403, "forbidden")
    return admin


class LoginIn(BaseModel):
    username: str
    password: str


@app.post("/api/auth/login")
def login(body: LoginIn, request: Request):
    ip = request.client.host if request.client else "?"
    now = time.time()
    if len(_fails) > 5000:  # bound memory
        for k in [k for k, v in _fails.items() if not v or now - v[-1] > 600]:
            _fails.pop(k, None)
    keys = (ip, "u:" + body.username[:64].lower())
    for k in keys:
        _fails[k] = [t for t in _fails.get(k, []) if now - t < 600]
    if len(_fails[keys[0]]) >= 8 or len(_fails[keys[1]]) >= 20:
        raise HTTPException(429, "too many attempts, try again later")
    admin = db.get_admin(body.username)
    ok = security.verify_password(body.password, admin["password_hash"]) if admin else False
    if not ok:
        for k in keys:
            _fails[k].append(now)
        activity.log(body.username[:40], "login", "ورود ناموفق", "", ip)
        time.sleep(0.4)
        raise HTTPException(401, "invalid credentials")
    activity.log(admin["username"], "login", "ورود موفق", "", ip)
    _fails.pop(keys[0], None)
    return {"token": security.make_token(admin["username"], pv=_pv(admin["password_hash"])),
            "username": admin["username"]}


class PasswordIn(BaseModel):
    old_password: str
    new_password: str = Field(min_length=8, max_length=128)


@app.post("/api/me/password")
def change_password(body: PasswordIn, admin: str = Depends(admin_required)):
    row = db.get_admin(admin)
    if not security.verify_password(body.old_password, row["password_hash"]):
        raise HTTPException(400, "old password is wrong")
    new_hash = security.hash_password(body.new_password)
    db.set_admin_password(admin, new_hash)
    return {"ok": True, "token": security.make_token(admin, pv=_pv(new_hash))}


@app.post("/api/me/logout-all")
def logout_all(admin: str = Depends(admin_required)):
    sessions.kick_all()
    return {"ok": True}


class KeyIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    scope: Literal["read", "full"] = "read"


def _jwt_only(request: Request, admin: str = Depends(admin_required)) -> str:
    if (request.headers.get("x-api-key") or request.headers.get("authorization", "")[7:]).startswith(apikeys.PREFIX):
        raise HTTPException(403, "forbidden")
    return admin


@app.get("/api/api-keys")
def list_api_keys(_: str = Depends(_jwt_only)):
    return apikeys.list_keys()


@app.post("/api/api-keys")
def create_api_key(body: KeyIn, _: str = Depends(_jwt_only)):
    return apikeys.create(body.name.strip(), body.scope)


@app.put("/api/api-keys/{kid}")
def toggle_api_key(kid: int, body: dict, _: str = Depends(_jwt_only)):
    apikeys.set_enabled(kid, bool(body.get("enabled")))
    return {"ok": True}


@app.delete("/api/api-keys/{kid}")
def delete_api_key(kid: int, _: str = Depends(_jwt_only)):
    apikeys.delete(kid)
    return {"ok": True}


@app.get("/api/version")
def version_info():
    return {"version": _ver.VERSION}


@app.get("/api/me")
def me(request: Request, admin: str = Depends(admin_required)):
    sc = _scope(request)
    if not sc:
        return {"username": admin, "role": "owner"}
    return {"username": admin, "role": "reseller", "max_users": sc["max_users"], "max_gb": sc["max_gb"],
            **db.owner_stats(admin)}


# ------------------------------------------------------------------ reseller admins
class ResellerIn(BaseModel):
    username: str = Field(pattern=r"^[A-Za-z0-9_.-]{3,32}$")
    password: str = Field(min_length=8, max_length=128)
    max_users: int = Field(default=0, ge=0, le=100000)
    max_gb: int = Field(default=0, ge=0, le=10000000)
    inbound_ids: list[int] = []
    note: str = Field(default="", max_length=200)
    blocks: list[Literal["torrent", "ads", "adult", "quic"]] = []


class ResellerUpdate(BaseModel):
    password: str | None = Field(default=None, min_length=8, max_length=128)
    max_users: int | None = Field(default=None, ge=0, le=100000)
    max_gb: int | None = Field(default=None, ge=0, le=10000000)
    inbound_ids: list[int] | None = None
    enabled: bool | None = None
    note: str | None = Field(default=None, max_length=200)
    blocks: list[Literal["torrent", "ads", "adult", "quic"]] | None = None


@app.get("/api/admins")
def list_admins(_: str = Depends(_owner_jwt)):
    return db.list_resellers()


@app.post("/api/admins")
def create_admin(body: ResellerIn, request: Request, _: str = Depends(_owner_jwt)):
    if db.get_admin(body.username):
        raise HTTPException(409, "این نام کاربری قبلاً وجود دارد")
    request.state.detail = body.username
    db.create_reseller(body.username, security.hash_password(body.password), body.max_users, body.max_gb,
                       body.inbound_ids, body.note, ",".join(body.blocks))
    return {"ok": True}


@app.put("/api/admins/{username}")
def update_admin(username: str, body: ResellerUpdate, request: Request, _: str = Depends(_owner_jwt)):
    row = db.get_admin(username)
    if not row or row["role"] != "reseller":
        raise HTTPException(404, "not found")
    f = body.model_dump(exclude_none=True)
    if "blocks" in f:
        f["blocks"] = ",".join(f["blocks"])
    if "password" in f:
        f["password_hash"] = security.hash_password(f.pop("password"))  # also logs that reseller out (token pv changes)
    request.state.detail = username + (" · " + ", ".join(k for k in f if k != "password_hash") if f else "")
    db.update_reseller(username, f)
    if "blocks" in f:
        apply_in_background()
    return {"ok": True}


@app.delete("/api/admins/{username}")
def delete_admin(username: str, request: Request, _: str = Depends(_owner_jwt)):
    request.state.detail = username
    if not db.delete_reseller(username):
        raise HTTPException(404, "not found")
    return {"ok": True}


# ------------------------------------------------------------------ nodes (extra servers)
class NodeIn(BaseModel):
    name: str = Field(min_length=1, max_length=40)
    address: str = Field(min_length=3, max_length=253, pattern=r"^[A-Za-z0-9.\-:\[\]]+$")
    join: str = Field(min_length=10, max_length=2000)


class NodeUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=40)
    address: str | None = Field(default=None, min_length=3, max_length=253, pattern=r"^[A-Za-z0-9.\-:\[\]]+$")
    join: str | None = Field(default=None, max_length=2000)
    enabled: bool | None = None
    inbound_ids: list[int] | None = None
    wg: bool | None = None


def _node_out(n: dict) -> dict:
    return {k: n[k] for k in ("id", "name", "address", "port", "enabled", "inbound_ids", "last_ok", "last_error", "xray", "wg", "created_at")}


@app.get("/api/nodes")
def list_nodes(_: str = Depends(_owner_jwt)):
    ibs = db.list_inbounds()
    return {"items": [_node_out(n) for n in nodes.list_nodes()],
            "eligible": [{"id": i["id"], "name": i.get("remark") or i["tag"], "protocol": i["protocol"], "port": i["port"]}
                         for i in ibs if nodes.eligible(i)]}


@app.post("/api/nodes")
def create_node(body: NodeIn, request: Request, _: str = Depends(_owner_jwt)):
    request.state.detail = body.name
    try:
        nid = nodes.add_node(body.name.strip(), body.address.strip(), body.join)
    except nodes.NodeError as e:
        raise HTTPException(400, str(e))
    apply_in_background()
    return _node_out(nodes.get_node(nid))


@app.put("/api/nodes/{nid}")
def update_node(nid: int, body: NodeUpdate, request: Request, _: str = Depends(_owner_jwt)):
    n = nodes.get_node(nid)
    if not n:
        raise HTTPException(404, "not found")
    request.state.detail = n["name"]
    try:
        nodes.update_node(nid, body.model_dump(exclude_none=True))
    except nodes.NodeError as e:
        raise HTTPException(400, str(e))
    apply_in_background()
    return _node_out(nodes.get_node(nid))


@app.delete("/api/nodes/{nid}")
def delete_node(nid: int, request: Request, _: str = Depends(_owner_jwt)):
    n = nodes.get_node(nid)
    if not n or not nodes.delete_node(nid):
        raise HTTPException(404, "not found")
    request.state.detail = n["name"]
    return {"ok": True}


@app.post("/api/nodes/{nid}/check")
def check_node(nid: int, _: str = Depends(_owner_jwt)):
    n = nodes.get_node(nid)
    if not n:
        raise HTTPException(404, "not found")
    return nodes.check(n)


@app.post("/api/nodes/{nid}/sync")
def sync_node(nid: int, request: Request, _: str = Depends(_owner_jwt)):
    n = nodes.get_node(nid)
    if not n:
        raise HTTPException(404, "not found")
    request.state.detail = n["name"]
    nodes._applied.pop(nid, None)
    users = [u for u in db.all_users() if u["status"] == "active"]
    return {"result": nodes.apply_one(n, db.get_settings(), db.list_inbounds(), users)}


# ------------------------------------------------------------------ helpers
def base_url(request: Request, settings: dict) -> str:
    root = (settings.get("sub_base_url") or "").rstrip("/") or str(request.base_url).rstrip("/")
    port = (settings.get("sub_port") or "").strip()
    if port.isdigit():  # separate subscription port: keep scheme + host, swap the port
        from urllib.parse import urlsplit
        u = urlsplit(root)
        host = u.hostname or ""
        if ":" in host:
            host = f"[{host}]"
        return f"{u.scheme}://{host}:{port}"
    return root


def user_out(u: dict, settings: dict, request: Request) -> dict:
    out = {k: u[k] for k in ("id", "username", "status", "data_limit", "used", "expire_at", "reset_strategy",
                              "note", "wg_enabled", "ovpn_enabled", "wg_ip", "max_ips", "speed_mbps", "last_seen", "inbound_ids", "created_at", "last_reset", "country_exits", "owner")}
    out["blocks"] = u.get("blocks_own", [])
    out["blocks_eff"] = u.get("blocks_eff", [])
    out["sub_url"] = f"{base_url(request, settings)}/sub/{u['sub_token']}"
    return out


def apply_in_background():
    # endpoints are sync (threadpool) so there is no running loop here; use a plain thread
    threading.Thread(target=monitor.apply_now, daemon=True).start()


def _ovpn_fields(u: dict, settings: dict) -> dict:
    if settings.get("ovpn_enabled") != "1":
        raise HTTPException(400, "OpenVPN در تنظیمات فعال نیست")
    try:
        return {"ovpn_enabled": True} if u["ovpn_cert"] else ovpn.issue_client(u)
    except Exception as e:
        raise HTTPException(500, f"ساخت گواهی OpenVPN ناموفق بود: {e}")


def setup_wg_for_user(settings: dict) -> dict:
    if settings.get("wg_enabled") != "1":
        raise HTTPException(400, "WireGuard is disabled in settings")
    system.ensure_wg_server_keys(settings)
    kp = system.wg_keypair()
    return {"wg_enabled": True, "wg_private": kp["private"], "wg_public": kp["public"],
            "wg_psk": system.wg_psk(), "wg_ip": system.allocate_wg_ip(settings)}


# ------------------------------------------------------------------ users
class UserCreate(BaseModel):
    username: str = Field(pattern=USERNAME_RE)
    data_limit_gb: float = Field(default=0, ge=0)
    expire_days: int | None = Field(default=None, ge=0)
    expire_at: int = 0
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] = "none"
    note: str = ""
    inbound_ids: list[int] | None = None
    wg_enabled: bool = False
    ovpn_enabled: bool = False
    country_exits: bool = False
    max_ips: int = Field(default=0, ge=0, le=100)
    speed_mbps: int = Field(default=0, ge=0, le=10000)
    blocks: list[Literal["torrent", "ads", "adult", "quic"]] = []


class UserUpdate(BaseModel):
    status: Literal["active", "disabled"] | None = None
    data_limit_gb: float | None = Field(default=None, ge=0)
    expire_at: int | None = None
    expire_days: int | None = Field(default=None, ge=0)
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] | None = None
    note: str | None = None
    inbound_ids: list[int] | None = None
    wg_enabled: bool | None = None
    ovpn_enabled: bool | None = None
    max_ips: int | None = Field(default=None, ge=0, le=100)
    speed_mbps: int | None = Field(default=None, ge=0, le=10000)
    country_exits: bool | None = None
    blocks: list[Literal["torrent", "ads", "adult", "quic"]] | None = None


def _create_user(body: UserCreate, settings: dict) -> int:
    data = body.model_dump()
    data["data_limit"] = int(body.data_limit_gb * GB)
    if body.expire_days:
        data["expire_at"] = db.now() + body.expire_days * 86400
    if body.inbound_ids is None:
        data["inbound_ids"] = [i["id"] for i in db.list_inbounds() if i["enabled"]]
    if body.wg_enabled:
        data.update(setup_wg_for_user(settings))
    data.pop("ovpn_enabled", None)
    try:
        uid = db.create_user(data)
        if body.ovpn_enabled:
            db.update_user(uid, _ovpn_fields(db.get_user(uid), settings))
        if body.max_ips or body.speed_mbps:
            db.update_user(uid, {"max_ips": body.max_ips, "speed_mbps": body.speed_mbps})
        if body.blocks:
            db.update_user(uid, {"blocks": ",".join(body.blocks)})
        return uid
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"username '{body.username}' already exists")


@app.get("/api/users")
def list_users(request: Request, search: str = "", status: str = "", page: int = 1, per_page: int = 50,
               _: str = Depends(admin_required)):
    per_page = min(max(per_page, 1), 200)
    sc = _scope(request)
    users, total = db.list_users(search, status, per_page, (max(page, 1) - 1) * per_page,
                                 owner=sc["username"] if sc else None)
    settings = db.get_settings()
    return {"total": total, "items": [user_out(u, settings, request) for u in users]}


@app.post("/api/users")
def create_user(body: UserCreate, request: Request, _: str = Depends(admin_required)):
    settings = db.get_settings()
    request.state.detail = body.username
    sc = _scope(request)
    if sc:
        body = _reseller_check_create(sc, body)
    uid = _create_user(body, settings)
    if sc:
        db.update_user(uid, {"owner": sc["username"]})
    apply_in_background()
    return user_out(db.get_user(uid), settings, request)


class BulkCreate(BaseModel):
    prefix: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,24}$")
    count: int = Field(ge=1, le=200)
    data_limit_gb: float = Field(default=0, ge=0)
    expire_days: int | None = Field(default=None, ge=0)
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] = "none"
    inbound_ids: list[int] | None = None
    country_exits: bool = False


@app.post("/api/users/bulk")
def bulk_create(body: BulkCreate, request: Request, _: str = Depends(_owner_only)):
    settings = db.get_settings()
    created = []
    for _i in range(body.count):
        name = f"{body.prefix}-{secrets.token_hex(3)}"
        uid = _create_user(UserCreate(username=name, data_limit_gb=body.data_limit_gb, expire_days=body.expire_days,
                                      reset_strategy=body.reset_strategy, inbound_ids=body.inbound_ids,
                                      country_exits=body.country_exits), settings)
        created.append(user_out(db.get_user(uid), settings, request))
    apply_in_background()
    return {"created": created}


def _get_user_or_404(user_id: int, request: Request | None = None) -> dict:
    u = db.get_user(user_id)
    sc = _scope(request) if request is not None else None
    if not u or (sc and u.get("owner") != sc["username"]):
        raise HTTPException(404, "user not found")
    return u


def _reseller_inbounds(sc: dict, wanted: list[int] | None) -> list[int]:
    ok = {i["id"] for i in db.list_inbounds() if i["enabled"]}
    if sc["inbound_ids"]:
        ok &= set(sc["inbound_ids"])
    return sorted(ok if wanted is None else ok & set(wanted))


def _reseller_check_create(sc: dict, body: "UserCreate") -> "UserCreate":
    st = db.owner_stats(sc["username"])
    if sc["max_users"] and st["users"] >= sc["max_users"]:
        raise HTTPException(403, f"سقف تعداد کاربر شما ({sc['max_users']}) پر شده است")
    _reseller_check_gb(sc, st, body.data_limit_gb * GB, 0)
    body.inbound_ids = _reseller_inbounds(sc, body.inbound_ids)
    return body


def _reseller_check_gb(sc: dict, st: dict, new_limit: int, old_limit: int):
    if not sc["max_gb"]:
        return
    if new_limit <= 0:
        raise HTTPException(403, "با سهمیه‌ی حجمی، ساخت کاربر نامحدود مجاز نیست")
    if st["gb_allocated"] - old_limit + new_limit > sc["max_gb"] * GB:
        left = max(0, sc["max_gb"] * GB - (st["gb_allocated"] - old_limit))
        raise HTTPException(403, f"سهمیه‌ی حجم کافی نیست (باقی‌مانده: {left / GB:.1f} گیگ)")


@app.get("/api/users/{user_id}")
def get_user(user_id: int, request: Request, _: str = Depends(admin_required)):
    return user_out(_get_user_or_404(user_id, request), db.get_settings(), request)


@app.put("/api/users/{user_id}")
def update_user(user_id: int, body: UserUpdate, request: Request, _: str = Depends(admin_required)):
    u = _get_user_or_404(user_id, request)
    settings = db.get_settings()
    sc = _scope(request)
    if sc:
        if body.data_limit_gb is not None:
            _reseller_check_gb(sc, db.owner_stats(sc["username"]), int(body.data_limit_gb * GB), u["data_limit"])
        if body.inbound_ids is not None:
            body.inbound_ids = _reseller_inbounds(sc, body.inbound_ids)
    fields: dict = {}
    if body.status is not None:
        fields["status"] = body.status
    if body.data_limit_gb is not None:
        fields["data_limit"] = int(body.data_limit_gb * GB)
    if body.expire_days:
        fields["expire_at"] = max(db.now(), u["expire_at"]) + body.expire_days * 86400
    elif body.expire_at is not None:
        fields["expire_at"] = body.expire_at
    for k in ("reset_strategy", "note"):
        if getattr(body, k) is not None:
            fields[k] = getattr(body, k)
    if body.country_exits is not None:
        fields["country_exits"] = body.country_exits
    if body.wg_enabled is True and not u["wg_enabled"]:
        fields.update(setup_wg_for_user(settings) if not u["wg_private"] else {"wg_enabled": True})
    elif body.wg_enabled is False:
        fields["wg_enabled"] = False
    if body.max_ips is not None:
        fields["max_ips"] = body.max_ips
    if body.speed_mbps is not None:
        fields["speed_mbps"] = body.speed_mbps
    if body.blocks is not None:
        fields["blocks"] = ",".join(body.blocks)
    request.state.detail = u["username"] + (" · " + ", ".join(fields) if fields else "")
    if body.ovpn_enabled is True and not u["ovpn_enabled"]:
        fields.update(_ovpn_fields(u, settings))
    elif body.ovpn_enabled is False:
        fields["ovpn_enabled"] = False
    db.update_user(user_id, fields, body.inbound_ids)
    apply_in_background()
    return user_out(db.get_user(user_id), settings, request)


@app.delete("/api/users/{user_id}")
def delete_user(user_id: int, request: Request, _: str = Depends(admin_required)):
    request.state.detail = _get_user_or_404(user_id, request)["username"]
    db.delete_user(user_id)
    apply_in_background()
    return {"ok": True}


@app.post("/api/users/{user_id}/reset-usage")
def reset_usage(user_id: int, request: Request, _: str = Depends(admin_required)):
    u = _get_user_or_404(user_id, request)
    fields = {"used": 0, "up_bytes": 0, "down_bytes": 0, "last_reset": db.now()}
    if u["status"] == "limited":
        fields["status"] = "active"
    db.update_user(user_id, fields)
    apply_in_background()
    return {"ok": True}


@app.post("/api/users/{user_id}/revoke-sub")
def revoke_sub(user_id: int, request: Request, _: str = Depends(admin_required)):
    _get_user_or_404(user_id, request)
    db.update_user(user_id, {"sub_token": secrets.token_urlsafe(18)})
    return user_out(db.get_user(user_id), db.get_settings(), request)


@app.get("/api/users/{user_id}/links")
def user_links(user_id: int, request: Request, _: str = Depends(admin_required)):
    u, settings = _get_user_or_404(user_id, request), db.get_settings()
    inbounds = db.list_inbounds()
    allowed = set(u.get("inbound_ids", []))
    proxies = []

    for ib in inbounds:
        proto = ib["protocol"]
        if proto not in ("socks", "http", "mixed"):
            continue
        if not ib["enabled"] or ib["id"] not in allowed:
            continue

        ib_settings = ib.get("settings") or {}
        address = (
            ib_settings.get("address")
            or settings.get("server_address")
            or ""
        )

        label = ib.get("remark") or ib["tag"]
        protocol_name = {"socks": "SOCKS5", "http": "HTTP Proxy"}.get(proto, "SOCKS5 / HTTP (Mixed)")

        copy_text = (
            f"{protocol_name}\n"
            f"Server: {address}\n"
            f"Port: {ib['port']}\n"
            f"Username: {u['username']}\n"
            f"Password: {u['password']}"
        )

        proxies.append({
            "protocol": proto,
            "protocol_name": protocol_name,
            "tag": ib["tag"],
            "remark": label,
            "address": address,
            "port": ib["port"],
            "username": u["username"],
            "password": u["password"],
            "copy_text": copy_text,
        })

    return {
        "links": protocols.user_links(u, inbounds, settings),
        "proxies": proxies,
        "wireguard": protocols.wireguard_client_config(u, settings),
        "openvpn": ovpn.client_config(u, settings),
        "clash": mihomo_config.client_config(u, inbounds, settings) if u["status"] == "active" else None,
        "configs": [{"title": f"ShadowTLS · {ib.get('remark') or ib['tag']} (sing-box)",
                     "text": protocols.shadowtls_singbox_client(ib, u, settings)}
                    for ib in inbounds if ib["protocol"] == "shadowtls" and ib["enabled"] and ib["id"] in allowed],
    }


# ------------------------------------------------------------------ inbounds
class InboundIn(BaseModel):
    tag: str = Field(pattern=TAG_RE)
    remark: str = ""
    protocol: Literal["vless", "vmess", "trojan", "shadowsocks", "socks", "http",
                      "hysteria2", "hysteria", "tuic", "anytls", "naive", "mixed", "shadowtls", "tunnel",
                      "mieru", "sudoku", "shadowquic", "trusttunnel"]
    port: int | None = Field(default=None, ge=1, le=65535)  # empty = random
    network: Literal["tcp", "ws", "grpc", "httpupgrade", "xhttp", "kcp", "udp"] = "tcp"
    security: Literal["none", "tls", "reality"] = "none"
    settings: dict = {}
    enabled: bool = True


def normalize_inbound(data: dict, settings: dict, exclude_id: int | None = None) -> dict:
    existing = db.get_inbound(exclude_id) if exclude_id else None
    try:
        return inbound_rules.normalize(data, settings, db.list_inbounds() + tunnels.claims(db.list_tunnels()), existing=existing)
    except inbound_rules.RuleError as e:
        raise HTTPException(e.code, str(e))


@app.get("/api/inbounds")
def list_inbounds(request: Request, _: str = Depends(admin_required)):
    sc = _scope(request)
    if not sc:
        return db.list_inbounds()
    ok = set(_reseller_inbounds(sc, None))
    return [{"id": i["id"], "tag": i["tag"], "remark": i.get("remark", ""), "protocol": i["protocol"], "port": i["port"],
             "enabled": True}
            for i in db.list_inbounds() if i["id"] in ok]


@app.post("/api/inbounds")
def create_inbound(body: InboundIn, _: str = Depends(admin_required)):
    data = normalize_inbound(body.model_dump(), db.get_settings())
    try:
        iid = db.create_inbound(data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"tag '{data['tag']}' already exists")
    apply_in_background()
    return db.get_inbound(iid)


@app.put("/api/inbounds/{inbound_id}")
def update_inbound(inbound_id: int, body: InboundIn, _: str = Depends(admin_required)):
    if not db.get_inbound(inbound_id):
        raise HTTPException(404, "inbound not found")
    data = normalize_inbound(body.model_dump(), db.get_settings(), exclude_id=inbound_id)
    try:
        db.update_inbound(inbound_id, data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"tag '{data['tag']}' already exists")
    apply_in_background()
    return db.get_inbound(inbound_id)


@app.delete("/api/inbounds/{inbound_id}")
def delete_inbound(inbound_id: int, _: str = Depends(admin_required)):
    if not db.get_inbound(inbound_id):
        raise HTTPException(404, "inbound not found")
    db.delete_inbound(inbound_id)
    apply_in_background()
    return {"ok": True}


@app.post("/api/tools/reality-keys")
def reality_keys(_: str = Depends(admin_required)):
    try:
        return {**system.reality_keypair(), "short_id": system.short_id()}
    except RuntimeError as e:
        raise HTTPException(500, str(e))



# ------------------------------------------------------------------ outbounds + routing
class OutboundIn(BaseModel):
    tag: str = Field(pattern=TAG_RE)
    remark: str = ""
    type: Literal["warp", "tor", "psiphon", "socks", "http", "shadowsocks", "wireguard"]
    settings: dict = {}
    enabled: bool = True


class RuleIn(BaseModel):
    remark: str = ""
    enabled: bool = True
    inbound_tags: list[str] = []
    domain: list[str] = []
    ip: list[str] = []
    port: str = ""
    network: str = ""
    protocol: list[str] = []
    outbound_tag: str


class FinalIn(BaseModel):
    outbound_tag: str


class PresetIn(BaseModel):
    outbound_tag: str = ""


class InstallIn(BaseModel):
    url: str = ""


def _oerr(e: outbounds.OutboundError) -> HTTPException:
    return HTTPException(e.code, str(e))


def _apply_checked(undo):
    """Apply now. If Xray / sing-box reject the new config, run undo() and report why (the old config stays live)."""
    res = monitor.apply_now()
    errs = [f"{k}: {v}" for k, v in res.items()
            if isinstance(v, str) and ("validation failed" in v or v.startswith("restart failed"))]
    if errs:
        try:
            undo()
        finally:
            monitor.apply_now()
        raise HTTPException(400, "تنظیم اعمال نشد و به حالت قبل برگشت: " + " | ".join(e[:500] for e in errs))
    return res


def _enabled_tags() -> set[str]:
    return {"direct", "block"} | {o["tag"] for o in db.list_outbounds() if o["enabled"]}


def _usage(tag: str) -> list[str]:
    users = [f"قانون «{r['remark'] or r['id']}»" for r in db.list_rules() if r["outbound_tag"] == tag]
    if db.get_settings().get("routing_final") == tag:
        users.append("اوتباند پیش‌فرض")
    n = outbounds.text_rules_using(tag)
    if n:
        users.append(f"{n} قانون متنی")
    return users


@app.get("/api/outbounds")
def list_outbounds_api(_: str = Depends(admin_required)):
    rules = db.list_rules()
    final = db.get_settings().get("routing_final", "direct") or "direct"
    out = [{"id": 0, "tag": "direct", "remark": "مستقیم", "type": "direct", "builtin": True, "enabled": True,
            "settings": {}, "rules_using": sum(r["outbound_tag"] == "direct" for r in rules), "is_final": final == "direct"},
           {"id": -1, "tag": "block", "remark": "بلاک", "type": "block", "builtin": True, "enabled": True,
            "settings": {}, "rules_using": sum(r["outbound_tag"] == "block" for r in rules), "is_final": final == "block"}]
    for o in db.list_outbounds():
        out.append({**o, "builtin": False, "rules_using": sum(r["outbound_tag"] == o["tag"] for r in rules),
                    "is_final": final == o["tag"],
                    "status": outbounds.service_status(o["type"]) if o["type"] in outbounds.SERVICES else None})
    return {"outbounds": out, "final": final,
            "inbounds": [{"tag": i["tag"], "engine": i["engine"], "remark": i["remark"]} for i in db.list_inbounds()]}


@app.post("/api/outbounds")
def create_outbound_api(body: OutboundIn, _: str = Depends(admin_required)):
    data = body.model_dump()
    try:
        if data["type"] == "warp" and not data["settings"].get("private_key"):
            reg = outbounds.warp_register(str(data["settings"].get("license") or "").strip())
            data["settings"] = {**data["settings"], **reg}
        norm = outbounds.normalize_outbound(data, db.list_outbounds())
    except outbounds.OutboundError as e:
        raise _oerr(e)
    try:
        oid = db.create_outbound(norm)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"تگ '{norm['tag']}' از قبل وجود دارد")
    _apply_checked(lambda: db.delete_outbound(oid))
    return db.get_outbound(oid)


@app.put("/api/outbounds/{outbound_id}")
def update_outbound_api(outbound_id: int, body: OutboundIn, _: str = Depends(admin_required)):
    old = db.get_outbound(outbound_id)
    if not old:
        raise HTTPException(404, "اوتباند پیدا نشد")
    data = body.model_dump()
    if data["tag"] != old["tag"]:
        raise HTTPException(400, "تگ بعد از ساخت قابل تغییر نیست (قانون‌ها با تگ به آن وصل‌اند)")
    if not data["enabled"] and _usage(old["tag"]):
        raise HTTPException(409, "این اوتباند استفاده می‌شود و نمی‌شود غیرفعالش کرد: " + "، ".join(_usage(old["tag"])))
    try:
        if data["type"] == "warp" and data["settings"].get("reregister"):
            reg = outbounds.warp_register(str(data["settings"].get("license") or old["settings"].get("license") or "").strip())
            data["settings"] = {**{k: v for k, v in data["settings"].items() if k != "reregister"}, **reg}
        norm = outbounds.normalize_outbound(data, db.list_outbounds(), existing=old)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    db.update_outbound(outbound_id, norm)
    _apply_checked(lambda: db.update_outbound(outbound_id, old))
    return db.get_outbound(outbound_id)


@app.delete("/api/outbounds/{outbound_id}")
def delete_outbound_api(outbound_id: int, _: str = Depends(admin_required)):
    old = db.get_outbound(outbound_id)
    if not old:
        raise HTTPException(404, "اوتباند پیدا نشد")
    used = _usage(old["tag"])
    if used:
        raise HTTPException(409, "این اوتباند استفاده می‌شود؛ اول این‌ها را تغییر بده یا حذف کن: " + "، ".join(used))
    db.delete_outbound(outbound_id)
    apply_in_background()
    return {"ok": True}


@app.get("/api/nordvpn/countries")
def nord_countries(_: str = Depends(_owner_only)):
    try:
        return nordvpn.countries()
    except nordvpn.NordError as e:
        raise HTTPException(502, str(e))


class NordIn(BaseModel):
    token: str = Field(min_length=10, max_length=300)
    country_ids: list[int] = Field(default_factory=list, max_length=12)   # empty = the single best server
    remark: str = Field(default="", max_length=80)


@app.post("/api/nordvpn/outbound")
def nord_create(body: NordIn, request: Request, _: str = Depends(_owner_only)):
    try:
        key = nordvpn.check_token(body.token)   # one NordLynx key works for every Nord server
    except nordvpn.NordError as e:
        raise HTTPException(502, str(e))
    created, errors = [], []
    for cid in (body.country_ids or [None]):
        try:
            srv = nordvpn.pick_server(cid)
            existing = {o["tag"] for o in db.list_outbounds()}
            base = f"nord-{srv['cc'] or 'xx'}"
            tag, n = base, 1
            while tag in existing:
                n += 1
                tag = f"{base}-{n}"
            remark = body.remark.strip() if len(body.country_ids) <= 1 and body.remark.strip() else f"NordVPN {srv['country']} ({srv['hostname']})"
            norm = outbounds.normalize_outbound({"tag": tag, "remark": remark, "type": "wireguard",
                                                 "settings": nordvpn.settings_for(key, srv), "enabled": True}, db.list_outbounds())
            oid = db.create_outbound(norm)
            created.append({"id": oid, "tag": tag, "country": srv["country"], "hostname": srv["hostname"], "load": srv["load"]})
        except (nordvpn.NordError, outbounds.OutboundError) as e:
            errors.append({"country_id": cid, "error": str(e)})
    request.state.detail = ", ".join(c["tag"] for c in created) or "—"
    if created:
        apply_in_background()
    elif errors:
        raise HTTPException(502, errors[0]["error"])
    return {"created": created, "errors": errors}


@app.post("/api/outbounds/test/{ref}")
def test_outbound_api(ref: str, _: str = Depends(admin_required)):
    rt = outbounds.load_routing()
    ports = outbounds.test_ports(rt)
    if ref == "0":
        tag = "direct"
    elif ref.isdigit():
        ob = db.get_outbound(int(ref))
        tag = ob["tag"] if ob else ""
    else:
        tag = ref
    if tag == "block":
        raise HTTPException(400, "اوتباند بلاک اتصال ندارد که تست شود")
    if tag not in ports:
        raise HTTPException(400, "اوتباند فعال نیست یا هنوز اعمال نشده؛ چند ثانیه بعد دوباره امتحان کن")
    if system.service_state(config.XRAY_SERVICE) != "active" and not config.DRY_RUN:
        raise HTTPException(400, "Xray روشن نیست؛ تست از مسیر Xray انجام می‌شود")
    return outbounds.test_outbound(ports[tag])


@app.get("/api/outbounds/services")
def outbound_services(_: str = Depends(admin_required)):
    return {n: outbounds.service_status(n) for n in outbounds.SERVICES}


@app.post("/api/outbounds/services/{name}/install")
def install_outbound_service(name: str, body: InstallIn, _: str = Depends(admin_required)):
    try:
        outbounds.install_service(name, body.url.strip())
    except outbounds.OutboundError as e:
        raise _oerr(e)
    return {"ok": True}


@app.get("/api/routing")
def get_routing(_: str = Depends(admin_required)):
    st = db.get_settings()
    return {"final": st.get("routing_final", "direct") or "direct",
            "toggles": outbounds.toggle_state(st), "text": st.get("routing_text", ""),
            "rules": db.list_rules(),
            "outbound_tags": sorted(_enabled_tags()),
            "presets": [{"key": k, "title": v["title"], "target": v["target"], "count": len(v["rules"])}
                        for k, v in outbounds.PRESETS.items()]}


@app.put("/api/routing/final")
def put_routing_final(body: FinalIn, _: str = Depends(admin_required)):
    if body.outbound_tag not in _enabled_tags():
        raise HTTPException(400, "اوتباند وجود ندارد یا غیرفعال است")
    old = db.get_settings().get("routing_final", "direct")
    db.set_settings({"routing_final": body.outbound_tag})
    _apply_checked(lambda: db.set_settings({"routing_final": old}))
    return {"final": body.outbound_tag}


def _norm_rule(data: dict) -> dict:
    try:
        return outbounds.normalize_rule(data, _enabled_tags(), {i["tag"] for i in db.list_inbounds()})
    except outbounds.OutboundError as e:
        raise _oerr(e)


@app.post("/api/routing/rules")
def create_rule_api(body: RuleIn, _: str = Depends(admin_required)):
    if len(db.list_rules()) >= outbounds.MAX_RULES:
        raise HTTPException(400, "تعداد قانون‌ها به سقف رسیده")
    rid = db.create_rule(_norm_rule(body.model_dump()))
    _apply_checked(lambda: db.delete_rule(rid))
    return db.get_rule(rid)


@app.put("/api/routing/rules/{rule_id}")
def update_rule_api(rule_id: int, body: RuleIn, _: str = Depends(admin_required)):
    old = db.get_rule(rule_id)
    if not old:
        raise HTTPException(404, "قانون پیدا نشد")
    db.update_rule(rule_id, _norm_rule(body.model_dump()))
    _apply_checked(lambda: db.update_rule(rule_id, old))
    return db.get_rule(rule_id)


@app.delete("/api/routing/rules/{rule_id}")
def delete_rule_api(rule_id: int, _: str = Depends(admin_required)):
    if not db.get_rule(rule_id):
        raise HTTPException(404, "قانون پیدا نشد")
    db.delete_rule(rule_id)
    apply_in_background()
    return {"ok": True}


class MoveIn(BaseModel):
    direction: Literal["up", "down"]


@app.post("/api/routing/rules/{rule_id}/move")
def move_rule_api(rule_id: int, body: MoveIn, _: str = Depends(admin_required)):
    if not db.move_rule(rule_id, body.direction):
        raise HTTPException(400, "قانون بیشتر از این جابه‌جا نمی‌شود")
    apply_in_background()
    return {"ok": True}


@app.post("/api/routing/presets/{key}")
def add_preset(key: str, body: PresetIn, _: str = Depends(admin_required)):
    pre = outbounds.PRESETS.get(key)
    if not pre:
        raise HTTPException(404, "قالب پیدا نشد")
    target = pre["target"] or body.outbound_tag
    if not target:
        raise HTTPException(400, "اوتباند مقصد را انتخاب کن")
    if len(db.list_rules()) + len(pre["rules"]) > outbounds.MAX_RULES:
        raise HTTPException(400, "تعداد قانون‌ها به سقف رسیده")
    norm = [_norm_rule({**r, "outbound_tag": target}) for r in pre["rules"]]
    ids = [db.create_rule(n) for n in norm]
    _apply_checked(lambda: [db.delete_rule(i) for i in ids])
    return {"added": len(ids)}


class QuickIn(BaseModel):
    toggles: dict[str, bool] = {}
    text: str = Field(default="", max_length=20000)


@app.put("/api/routing/quick")
def put_routing_quick(body: QuickIn, _: str = Depends(admin_required)):
    bad = [k for k in body.toggles if k not in outbounds.TOGGLES and k != "torrent"]
    if bad:
        raise HTTPException(400, f"سوئیچ ناشناخته: {bad[0]}")
    obs = [o for o in db.list_outbounds() if o["enabled"]]
    try:
        outbounds.parse_text_rules(body.text, _enabled_tags(), outbounds._type_tags(obs), strict=True)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    st = db.get_settings()
    old = {k: st.get(k, "") for k in ("routing_toggles", "routing_text", "block_bittorrent")}
    cur = outbounds.toggle_state(st)
    cur.update(body.toggles)
    db.set_settings({"routing_toggles": json.dumps({k: cur[k] for k in outbounds.TOGGLES}),
                     "routing_text": body.text.strip("\n"),
                     "block_bittorrent": "1" if cur["torrent"] else "0"})
    _apply_checked(lambda: db.set_settings(old))
    st = db.get_settings()
    return {"toggles": outbounds.toggle_state(st), "text": st.get("routing_text", "")}


# ------------------------------------------------------------------ Tor / Psiphon exits + WARP card
TOR_COUNTRIES = ("AE AR AT AU BE BG BR CA CH CL CO CZ DE DK EE ES FI FR GB GR HK HR HU ID IE IL IN IS IT JP KR LT LU "
                 "LV MD MX MY NL NO NZ PL PT RO RS RU SE SG SI SK TH TR TW UA US ZA").split()


def _exit_item(o: dict) -> dict:
    if outbounds.is_nord_exit(o):      # pure WireGuard outbound: no local service, no port
        s = o["settings"]
        return {"id": o["id"], "tag": o["tag"], "service": "nord", "country": outbounds.ob_cc(o).upper(),
                "port": 0, "enabled": o["enabled"], "installed": True, "active": True, "custom_port": False,
                "hostname": s.get("hostname", "")}
    stt = outbounds.instance_status(o)
    return {"id": o["id"], "tag": o["tag"], "service": o["type"], "country": outbounds.ob_cc(o).upper(),
            "port": outbounds.ob_port(o), "enabled": o["enabled"],
            "installed": stt["installed"], "active": stt["active"],
            "custom_port": bool(o["settings"].get("port"))}


@app.get("/api/exits")
def get_exits(_: str = Depends(admin_required)):
    obs = db.list_outbounds()
    generic = {}
    for svc in ("tor", "psiphon"):
        o = next((x for x in obs if x["type"] == svc and not x["settings"].get("per_country")), None)
        generic[svc] = _exit_item(o) if o else None
    return {"generic": generic,
            "countries": [_exit_item(o) for o in obs
                          if (o["type"] in ("tor", "psiphon") and o["settings"].get("per_country")) or outbounds.is_nord_exit(o)],
            "nord": {"has_key": bool(nordvpn.saved_key(obs))},
            "services": {n: outbounds.service_status(n) for n in outbounds.SERVICES},
            "country_codes": {"tor": TOR_COUNTRIES, "psiphon": outbounds.PSIPHON_COUNTRIES},
            "default_ports": {"tor": outbounds.LOCAL_PORT["tor"], "psiphon": outbounds.LOCAL_PORT["psiphon"]}}


class GenericExitIn(BaseModel):
    enabled: bool
    port: int = Field(default=0, ge=0, le=65535)


@app.put("/api/exits/generic/{service}")
def put_generic_exit(service: Literal["tor", "psiphon"], body: GenericExitIn, _: str = Depends(admin_required)):
    obs = db.list_outbounds()
    old = next((o for o in obs if o["type"] == service and not o["settings"].get("per_country")), None)
    try:
        if old is None:
            if not body.enabled:
                return {"ok": True}
            norm = outbounds.normalize_outbound(
                {"tag": service, "remark": service.capitalize(), "type": service, "enabled": True,
                 "settings": {"port": body.port}}, obs)
            oid = db.create_outbound(norm)
            _apply_checked(lambda: db.delete_outbound(oid))
            return {"ok": True}
        if not body.enabled and old["enabled"] and _usage(old["tag"]):
            raise HTTPException(409, "این خروجی استفاده می‌شود و نمی‌شود خاموشش کرد: " + "، ".join(_usage(old["tag"])))
        norm = outbounds.normalize_outbound({**old, "enabled": body.enabled,
                                             "settings": {**old["settings"], "port": body.port}}, obs, existing=old)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    db.update_outbound(old["id"], norm)
    _apply_checked(lambda: db.update_outbound(old["id"], old))
    return {"ok": True}


class CountryExitIn(BaseModel):
    service: Literal["tor", "psiphon", "nord"]
    country: str = Field(pattern=r"^[A-Za-z]{2}$")
    token: str = Field(default="", max_length=300)     # NordVPN only, and only when no Nord outbound exists yet


def _create_nord_exit(body: CountryExitIn):
    cc = body.country.lower()
    obs = db.list_outbounds()
    try:
        key = nordvpn.saved_key(obs)
        if not key:
            if not body.token.strip():
                raise HTTPException(400, "توکن NordVPN را وارد کن (فقط بار اول لازم است)")
            key = nordvpn.check_token(body.token)
        c = nordvpn.country_by_code(cc)
        srv = nordvpn.pick_server(c["id"])
    except nordvpn.NordError as e:
        raise HTTPException(502, str(e))
    tag, n = f"nord-{cc}", 1
    taken = {o["tag"] for o in obs}
    while tag in taken:
        n += 1
        tag = f"nord-{cc}-{n}"
    st = {**nordvpn.settings_for(key, srv), "nord": True, "per_country": True, "country": cc.upper(),
          "hostname": srv["hostname"], "country_name": srv["country"]}
    data = {"tag": tag, "remark": f"NordVPN {srv['country'] or cc.upper()}", "type": "wireguard", "enabled": True, "settings": st}
    try:
        norm = outbounds.normalize_outbound(data, obs)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    try:
        oid = db.create_outbound(norm)
    except sqlite3.IntegrityError:
        raise HTTPException(409, "این خروجی از قبل وجود دارد")
    _apply_checked(lambda: db.delete_outbound(oid))
    return _exit_item(db.get_outbound(oid))


@app.post("/api/exits/{outbound_id}/nord-server")
def nord_other_server(outbound_id: int, _: str = Depends(admin_required)):
    """Pick a fresh NordVPN server for an existing per-country exit (use it when the current one is down)."""
    old = db.get_outbound(outbound_id)
    if not old or not outbounds.is_nord_exit(old):
        raise HTTPException(404, "خروجی NordVPN پیدا نشد")
    try:
        srv = nordvpn.pick_server(nordvpn.country_by_code(outbounds.ob_cc(old))["id"])
    except nordvpn.NordError as e:
        raise HTTPException(502, str(e))
    st = {**old["settings"], **nordvpn.settings_for(old["settings"]["private_key"], srv), "hostname": srv["hostname"]}
    try:
        norm = outbounds.normalize_outbound({**old, "settings": st}, db.list_outbounds(), existing=old)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    db.update_outbound(outbound_id, norm)
    _apply_checked(lambda: db.update_outbound(outbound_id, old))
    return _exit_item(db.get_outbound(outbound_id))


@app.post("/api/exits")
def create_country_exit(body: CountryExitIn, _: str = Depends(admin_required)):
    if body.service == "nord":
        return _create_nord_exit(body)
    cc = body.country.lower()
    if body.service == "psiphon" and cc.upper() not in outbounds.PSIPHON_COUNTRIES:
        raise HTTPException(400, "Psiphon این کشور را ندارد")
    key = "exit_country" if body.service == "tor" else "country"
    data = {"tag": f"{body.service}-{cc}", "remark": f"{body.service.capitalize()} {cc.upper()}", "type": body.service,
            "enabled": True, "settings": {"per_country": True, key: cc if body.service == "tor" else cc.upper()}}
    try:
        norm = outbounds.normalize_outbound(data, db.list_outbounds())
    except outbounds.OutboundError as e:
        raise _oerr(e)
    try:
        oid = db.create_outbound(norm)
    except sqlite3.IntegrityError:
        raise HTTPException(409, "این خروجی از قبل وجود دارد")
    _apply_checked(lambda: db.delete_outbound(oid))
    return _exit_item(db.get_outbound(oid))


@app.post("/api/exits/repair")
def repair_exits(_: str = Depends(admin_required)):
    res = {}
    if outbounds.installed("tor") and any(o["type"] == "tor" and o["settings"].get("per_country")
                                           for o in db.list_outbounds()):
        res["geoip"] = outbounds.ensure_geoip()
    res.update(outbounds.apply_services())
    return {"result": res}


def _warp_ob():
    return next((o for o in db.list_outbounds() if o["type"] == "warp"), None)


def _warp_state() -> dict:
    o, st = _warp_ob(), db.get_settings()
    s = o["settings"] if o else {}
    ep = s.get("endpoint", "")
    return {"registered": bool(o), "id": o["id"] if o else 0, "tag": o["tag"] if o else "",
            "account_id": s.get("account_id", ""), "plus": bool(s.get("license")),
            "enabled": bool(o and o["enabled"]), "mode": s.get("mode", "warp"),
            "endpoint": "" if ep == outbounds.WARP_DEFAULT_ENDPOINT else ep,
            "udp": st.get("warp_udp", "1") == "1", "clean": st.get("warp_clean", "1") == "1",
            "clean_endpoint": st.get("warp_clean_endpoint", ""), "binary": outbounds.installed("wow"),
            "usage": _usage(o["tag"]) if o else []}


@app.get("/api/warp")
def get_warp(_: str = Depends(admin_required)):
    return _warp_state()


class WarpRegIn(BaseModel):
    license: str = ""


@app.post("/api/warp/register")
def warp_register_api(body: WarpRegIn, _: str = Depends(admin_required)):
    o, obs = _warp_ob(), db.list_outbounds()
    try:
        reg = outbounds.warp_register(body.license.strip())
        if o:
            if o["settings"].get("endpoint") not in ("", outbounds.WARP_DEFAULT_ENDPOINT):
                reg.pop("endpoint", None)                         # keep the endpoint the user typed
            norm = outbounds.normalize_outbound({**o, "settings": {**o["settings"], **reg}}, obs, existing=o)
            db.update_outbound(o["id"], norm)
            _apply_checked(lambda: db.update_outbound(o["id"], o))
        else:
            tag = "warp" if all(x["tag"] != "warp" for x in obs) else "warp-cf"
            norm = outbounds.normalize_outbound({"tag": tag, "remark": "Cloudflare WARP", "type": "warp",
                                                 "enabled": True, "settings": reg}, obs)
            oid = db.create_outbound(norm)
            _apply_checked(lambda: db.delete_outbound(oid))
    except outbounds.OutboundError as e:
        raise _oerr(e)
    return _warp_state()


class WarpIn(BaseModel):
    enabled: bool = True
    udp: bool = True
    clean: bool = True
    mode: Literal["warp", "wow"] = "warp"
    endpoint: str = ""


@app.put("/api/warp")
def put_warp(body: WarpIn, _: str = Depends(admin_required)):
    o = _warp_ob()
    if not o:
        raise HTTPException(400, "اول حساب WARP را بساز")
    if not body.enabled and o["enabled"] and _usage(o["tag"]):
        raise HTTPException(409, "WARP استفاده می‌شود و نمی‌شود خاموشش کرد: " + "، ".join(_usage(o["tag"])))
    if body.mode == "wow" and not config.DRY_RUN and not outbounds.installed("wow"):
        raise HTTPException(400, "حالت WoW به warp-plus نیاز دارد؛ اول دکمه‌ی نصب را بزن")
    settings = {**o["settings"], "mode": body.mode, "endpoint": body.endpoint.strip() or outbounds.WARP_DEFAULT_ENDPOINT}
    try:
        norm = outbounds.normalize_outbound({**o, "enabled": body.enabled, "settings": settings},
                                            db.list_outbounds(), existing=o)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    st = db.get_settings()
    old_st = {k: st.get(k, "") for k in ("warp_udp", "warp_clean")}
    db.update_outbound(o["id"], norm)
    db.set_settings({"warp_udp": "1" if body.udp else "0", "warp_clean": "1" if body.clean else "0"})

    def undo():
        db.update_outbound(o["id"], o)
        db.set_settings(old_st)
    _apply_checked(undo)
    return _warp_state()


@app.post("/api/warp/next-endpoint")
def warp_next_endpoint(_: str = Depends(admin_required)):
    old = db.get_settings().get("warp_clean_endpoint", "")
    outbounds.clean_endpoint(rotate=True)
    _apply_checked(lambda: db.set_settings({"warp_clean_endpoint": old}))
    return _warp_state()


# ------------------------------------------------------------------ settings / system
HIDDEN_SETTINGS = {"wg_server_private"} | {k for k in db.DEFAULT_SETTINGS if k.startswith("tg_")}


@app.get("/api/settings")
def get_settings(_: str = Depends(admin_required)):
    return {k: v for k, v in db.get_settings().items() if k not in HIDDEN_SETTINGS}


@app.put("/api/settings")
def put_settings(body: dict, _: str = Depends(admin_required)):
    body = {k: v for k, v in body.items() if k in db.DEFAULT_SETTINGS and k not in HIDDEN_SETTINGS
            and k not in ("wg_server_public", "sub_port", "server_ips", "routing_final", "routing_toggles",
                                                  "routing_text", "warp_udp", "warp_clean", "warp_clean_endpoint")}
    if "geo_action" in body and body["geo_action"] not in ("off", "notify", "disable"):
        raise HTTPException(400, "geo_action must be off, notify or disable")
    for k in ("health_cpu", "health_mem", "health_disk"):
        if k in body and not (str(body[k]).isdigit() and 10 <= int(body[k]) <= 100):
            raise HTTPException(400, f"{k} باید بین ۱۰ تا ۱۰۰ باشد")
    if "ip_limit_action" in body and body["ip_limit_action"] not in ("notify", "disable"):
        raise HTTPException(400, "ip_limit_action must be notify or disable")
    if "ovpn_proto" in body and body["ovpn_proto"] not in ("udp", "tcp"):
        raise HTTPException(400, "ovpn_proto must be udp or tcp")
    if "ovpn_subnet" in body:
        try:
            import ipaddress as _ip
            _ip.ip_network(body["ovpn_subnet"], strict=False)
        except ValueError:
            raise HTTPException(400, "ovpn_subnet نامعتبر است")
    for k in ("wg_port", "monitor_interval", "wg_mtu", "update_interval", "ovpn_port", "backup_keep"):
        if k in body and not str(body[k]).isdigit():
            raise HTTPException(400, f"{k} must be a number")
    if "sub_logo" in body:
        body["sub_logo"] = str(body["sub_logo"]).strip()
        if body["sub_logo"] and not body["sub_logo"].startswith("https://"):
            raise HTTPException(400, "آدرس لوگو باید با https:// شروع شود")
        if len(body["sub_logo"]) > 500:
            raise HTTPException(400, "آدرس لوگو خیلی بلند است")
    if "sub_accent" in body:
        body["sub_accent"] = str(body["sub_accent"]).strip()
        if body["sub_accent"] and not re.fullmatch(r"#[0-9a-fA-F]{6}", body["sub_accent"]):
            raise HTTPException(400, "رنگ باید مثل #8B5CF6 باشد")
    if "sub_notice" in body:
        body["sub_notice"] = str(body["sub_notice"]).strip()[:500]
    db.set_settings({k: ("1" if v is True else "0" if v is False else v) for k, v in body.items()})
    apply_in_background()
    return get_settings(_)


class SubPortIn(BaseModel):
    port: int = Field(default=0, ge=0, le=65535)


@app.get("/api/subport")
def get_subport(_: str = Depends(admin_required)):
    return subport.current()


@app.put("/api/subport")
def put_subport(body: SubPortIn, _: str = Depends(admin_required)):
    try:
        return subport.set_port(body.port)
    except subport.SubPortError as e:
        raise HTTPException(400, str(e))


class IpIn(BaseModel):
    ip: str


def _ip_call(fn, *a):
    try:
        return fn(*a)
    except serverips.IpError as e:
        raise HTTPException(400, str(e))


@app.get("/api/server-ips")
def server_ips(_: str = Depends(admin_required)):
    return serverips.listing()


@app.post("/api/server-ips")
def server_ips_add(body: IpIn, _: str = Depends(admin_required)):
    return _ip_call(serverips.add, body.ip)


@app.put("/api/server-ips/default")
def server_ips_default(body: IpIn, _: str = Depends(admin_required)):
    r = _ip_call(serverips.make_default, body.ip)
    apply_in_background()
    return r


@app.delete("/api/server-ips/{ip}")
def server_ips_delete(ip: str, _: str = Depends(admin_required)):
    return _ip_call(serverips.remove, ip)


# ------------------------------------------------------------------ tunnels (reverse / ssh / dnat; port-forward lives in inbounds)
class TunnelIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    kind: str = Field(min_length=2, max_length=20)
    port: int | None = Field(default=None, ge=0, le=65535)
    settings: dict = Field(default_factory=dict)
    enabled: bool = True


def _tunnel_out(t: dict, host: str) -> dict:
    out = {**t, "status": tunnels.status(t), "info": {}}
    out["traffic"] = tunnel_traffic.totals().get(t["id"], {"rx": 0, "tx": 0})
    if t["kind"] == "reverse":
        out["info"]["bridge_json"] = json.dumps(tunnels.bridge_config(t, host), indent=2)
    if t["kind"] in tunnel_tools.KINDS:
        ti = tunnel_tools.info(t)
        out["info"]["line"] = ti["line"]
        out["info"]["guide"] = tunnel_tools.guide(t, host)
        out["info"]["missing"] = tunnel_tools.missing_bins(t)
        out["info"]["script"] = tunnel_tools.remote_script(t, host)
    return out


def _tunnel_host(request: Request, host: str, settings: dict) -> str:
    return (host or settings.get("server_address") or request.url.hostname or "SERVER_IP").strip()


def _tunnel_call(fn, *a):
    try:
        return fn(*a)
    except tunnels.TunnelError as e:
        raise HTTPException(e.code, str(e))


@app.get("/api/tunnels")
def tunnels_list(request: Request, host: str = "", _: str = Depends(admin_required)):
    settings = db.get_settings()
    h = _tunnel_host(request, host, settings)
    return [_tunnel_out(t, h) for t in db.list_tunnels()]


@app.post("/api/tunnels/preflight")
def tunnels_preflight(body: TunnelIn, tid: int = 0, _: str = Depends(admin_required)):
    cur = db.get_tunnel(tid) if tid else None
    return tunnel_diag.preflight(cur["kind"] if cur else body.kind, body.model_dump(), cur, db.list_inbounds(), db.list_tunnels(), db.get_settings())


@app.post("/api/tunnels")
def tunnels_create(body: TunnelIn, request: Request, _: str = Depends(admin_required)):
    settings = db.get_settings()
    data = _tunnel_call(tunnels.normalize, body.model_dump(), None, db.list_inbounds(), db.list_tunnels(), settings)
    tid = db.create_tunnel(data)
    apply_in_background()
    return _tunnel_out(db.get_tunnel(tid), _tunnel_host(request, "", settings))


@app.put("/api/tunnels/{tid}")
def tunnels_update(tid: int, body: TunnelIn, request: Request, _: str = Depends(admin_required)):
    cur = db.get_tunnel(tid)
    if not cur:
        raise HTTPException(404, "tunnel not found")
    settings = db.get_settings()
    data = _tunnel_call(tunnels.normalize, {**body.model_dump(), "kind": cur["kind"]}, cur,
                        db.list_inbounds(), db.list_tunnels(), settings)
    db.update_tunnel(tid, data)
    apply_in_background()
    return _tunnel_out(db.get_tunnel(tid), _tunnel_host(request, "", settings))


@app.delete("/api/tunnels/{tid}")
def tunnels_delete(tid: int, _: str = Depends(admin_required)):
    cur = db.get_tunnel(tid)
    if not cur:
        raise HTTPException(404, "tunnel not found")
    db.delete_tunnel(tid)
    tunnel_traffic.reset(tid)
    tunnels.cleanup(cur)
    apply_in_background()
    return {"ok": True}


class RolePick(BaseModel):
    ids: list[int] = Field(default_factory=list, max_length=40)
    samples: int = Field(default=8, ge=3, le=20)
    speed_ids: list[int] = Field(default_factory=list, max_length=10)


@app.get("/api/tunnel-tools")
def tunnel_tools_list(_: str = Depends(admin_required)):
    return {"tools": tunnel_tools.tool_status(), "meta": tunnel_tools.public_meta()}


@app.post("/api/tunnel-tools/{tool}/install")
def tunnel_tools_install(tool: str, _: str = Depends(admin_required)):
    if tool not in tunnel_tools.TOOLS:
        raise HTTPException(404, "tool not found")
    try:
        msg = tunnel_tools.install_tool(tool)
    except RuntimeError as e:
        raise HTTPException(500, str(e))
    apply_in_background()
    return {"ok": True, "message": msg}


@app.get("/api/tunnel-guide/{kind}")
def tunnel_guide_preview(kind: str, request: Request, role: str = "", host: str = "", _: str = Depends(admin_required)):
    if kind not in tunnel_tools.KINDS:
        raise HTTPException(404, "kind not found")
    h = _tunnel_host(request, host, db.get_settings())
    ex = tunnel_tools.example(kind, h, role)
    return {"steps": tunnel_tools.guide(ex, h)}


@app.get("/api/tunnel-diag/health")
def tunnel_health(_: str = Depends(admin_required)):
    rows = list(db.list_tunnels())
    for i in db.list_inbounds():          # plain port-forward tunnels live in inbounds
        if i["protocol"] == "tunnel":
            st = i["settings"] or {}
            rows.append({"id": -i["id"], "name": i.get("remark") or i["tag"], "kind": "forward" if not st.get("via") else "via",
                         "port": i["port"], "settings": {"target_host": st.get("target_host", ""), "target_port": st.get("target_port", 0), "network": st.get("network_mode", "tcp")},
                         "enabled": bool(i["enabled"]), "inbound": True})
    return tunnel_diag.health_all(rows)


@app.post("/api/tunnel-diag/benchmark")
def tunnel_benchmark(body: RolePick, _: str = Depends(admin_required)):
    rows = [t for t in db.list_tunnels() if not body.ids or t["id"] in body.ids]
    return tunnel_diag.benchmark(rows, body.samples, set(body.speed_ids))


@app.post("/api/tunnels/{tid}/traffic-reset")
def tunnels_traffic_reset(tid: int, _: str = Depends(admin_required)):
    tunnel_traffic.reset(tid)
    return {"ok": True}


@app.post("/api/tunnels/{tid}/restart")
def tunnels_restart(tid: int, _: str = Depends(admin_required)):
    t = db.get_tunnel(tid)
    if not t:
        raise HTTPException(404, "tunnel not found")
    if t["kind"] == "reverse":
        return {"ok": True, "result": system.run(["systemctl", "restart", config.XRAY_SERVICE], 30)[1]}
    code, out = system.run(["systemctl", "restart", tunnels.unit_name(t)], 30)
    return {"ok": code == 0, "result": out[-300:]}


@app.get("/api/dashboard")
def dashboard(_: str = Depends(admin_required)):
    return {**db.stats(), "system": system.system_info(), "history": db.usage_history(14)}


@app.post("/api/system/apply")
def apply(_: str = Depends(admin_required)):
    return monitor.apply_now()


@app.get("/api/online")
def online_list(request: Request, _: str = Depends(admin_required)):
    items = online.snapshot()
    sc = _scope(request)
    if sc:
        mine = {u["id"] for u in db.list_users("", "", 100000, 0, owner=sc["username"])[0]}
        items = [i for i in items if i["id"] in mine]
    return {"items": items, "window": online.WINDOW}


@app.post("/api/online/{uid}/kick")
def online_kick(uid: int, request: Request, _: str = Depends(admin_required)):
    _get_user_or_404(uid, request)
    request.state.detail = (db.get_user(uid) or {}).get("username", str(uid))
    return online.kick(uid)


@app.get("/api/users/{user_id}/usage")
def user_usage(user_id: int, request: Request, days: int = 30, _: str = Depends(admin_required)):
    _get_user_or_404(user_id, request)
    return db.usage_user(user_id, days)


@app.get("/api/usage/total")
def usage_total(days: int = 30, _: str = Depends(admin_required)):
    return db.usage_total(days)


@app.get("/api/usage/top")
def usage_top(days: int = 7, limit: int = 10, _: str = Depends(admin_required)):
    return db.usage_top(days, min(max(limit, 1), 50))


@app.get("/api/health")
def health_info(_: str = Depends(_owner_only)):
    cur = health.sample()
    cur["cpu"] = health._cpu_pct() if cur["cpu"] == 0 else cur["cpu"]
    s = db.get_settings()
    return {"now": cur, "history": health.history(180),
            "limits": {k: int(s.get(f"health_{k}", "90") or 90) for k in ("cpu", "mem", "disk")},
            "down": [{"id": i["id"], "name": i.get("remark") or i["tag"], "port": i["port"]}
                     for i in health.inbound_down(db.list_inbounds())],
            "geo_db": bool(geo.load())}


@app.get("/api/activity")
def activity_list(search: str = "", actor: str = "", action: str = "", page: int = 1, per_page: int = 50, after_id: int = 0,
                  _: str = Depends(admin_required)):
    per_page = min(max(per_page, 1), 200)
    items, total, actors = activity.list_items(search, actor, per_page, (max(page, 1) - 1) * per_page, after_id, action)
    return {"items": items, "total": total, "actors": actors}


@app.delete("/api/activity")
def activity_clear(request: Request, _: str = Depends(_jwt_only)):
    activity.clear()
    request.state.detail = "پاک شد"
    return {"ok": True}


@app.get("/api/backups")
def backups_list(_: str = Depends(admin_required)):
    s = db.get_settings()
    return {"items": backup.list_backups(), "auto": s.get("backup_auto") == "1", "keep": int(s.get("backup_keep", "7") or 7),
            "contents": backup.contents()}


@app.post("/api/backups")
def backups_create(_: str = Depends(admin_required)):
    p = backup.create("manual")
    return {"name": p.name, "size": p.stat().st_size}


@app.get("/api/backups/{name}/download")
def backups_download(name: str, _: str = Depends(admin_required)):
    try:
        p = backup.path_of(name)
    except (ValueError, FileNotFoundError):
        raise HTTPException(404, "not found")
    return FileResponse(p, filename=p.name, media_type="application/gzip")


@app.delete("/api/backups/{name}")
def backups_delete(name: str, _: str = Depends(admin_required)):
    try:
        backup.delete(name)
    except (ValueError, FileNotFoundError):
        raise HTTPException(404, "not found")
    return {"ok": True}


@app.post("/api/backups/{name}/restore")
def backups_restore_saved(name: str, _: str = Depends(admin_required)):
    try:
        res = backup.restore(backup.path_of(name))
    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(400, str(e))
    apply_in_background()
    return res


@app.post("/api/backups/restore-upload")
async def backups_restore_upload(request: Request, _: str = Depends(admin_required)):
    data = await request.body()
    if not data or len(data) > backup.MAX_UPLOAD:
        raise HTTPException(400, "فایل خالی یا بیش‌ازحد بزرگ است")
    with tempfile.NamedTemporaryFile(suffix=".tgz", delete=False) as f:
        f.write(data)
        tmp = f.name
    try:
        res = await asyncio.to_thread(backup.restore, Path(tmp))
    except ValueError as e:
        raise HTTPException(400, str(e))
    finally:
        os.unlink(tmp)
    apply_in_background()
    return res


@app.get("/api/backup/full")
def backup_full(_: str = Depends(admin_required)):
    p = backup.create("manual")
    return FileResponse(p, filename=p.name, media_type="application/gzip")


@app.get("/api/backup")
def backup_db_download(_: str = Depends(admin_required)):
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    tmp.close()
    src, dst = db.conn(), sqlite3.connect(tmp.name)
    src.backup(dst)
    dst.close()
    src.close()
    return FileResponse(tmp.name, filename=f"panel-backup-{time.strftime('%Y%m%d-%H%M')}.db",
                        media_type="application/octet-stream")


# ------------------------------------------------------------------ subscription (public, token-protected)
def _sub_headers(u: dict, settings: dict) -> dict:
    title = base64.b64encode(settings.get("profile_title", "VPN").encode()).decode()
    h = {
        "Subscription-Userinfo": f"upload=0; download={u['used']}; total={u['data_limit']}; expire={u['expire_at']}",
        "Profile-Title": f"base64:{title}",
        "Profile-Update-Interval": settings.get("update_interval", "12"),
        "Cache-Control": "no-store",
        "Vary": "Accept, User-Agent",
    }
    if settings.get("support_url"):
        h["Support-Url"] = settings["support_url"]
    return h


def _sub_page(request: Request, u: dict, settings: dict, token: str) -> Response:
    inbounds = nodes.sub_inbounds()
    active = u["status"] == "active"
    links = protocols.user_links(u, inbounds, settings) if active else []
    clash = mihomo_config.client_config(u, inbounds, settings) if active else None
    wg = protocols.wireguard_client_config(u, settings) if active else None
    proxies = []
    if active:  # SOCKS5 / HTTP (mixed) inbounds this user may use: they log in with the panel username + password
        allowed = set(u.get("inbound_ids", []))
        for ib in inbounds:
            if ib["enabled"] and ib["protocol"] == "mixed" and ib["id"] in allowed:
                proxies.append({"name": ib.get("remark") or ib["tag"], "host": protocols._host(ib, settings),
                                "port": ib["port"], "user": u["username"], "pass": u["password"]})
    html = subpage.render(u, settings, f"{base_url(request, settings)}/sub/{token}", links, clash, wg, proxies,
                          ovpn.client_config(u, settings) if active else None, db.usage_user(u["id"], 14),
                          [{"name": n["name"], "url": f"{base_url(request, settings)}/sub/{token}/wg/{n['id']}"} for n in nodes.wg_nodes()]
                          if wg else None)
    return Response(html, media_type="text/html; charset=utf-8", headers={
        "Cache-Control": "no-store", "Vary": "Accept, User-Agent", "X-Robots-Tag": "noindex, nofollow, noarchive",
        "Referrer-Policy": "no-referrer"})


@app.get("/sub/{token}")
def subscription(token: str, request: Request):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    settings = db.get_settings()
    if subpage.wants_page(request.headers, request.query_params):  # a person in a browser, not a VPN app
        return _sub_page(request, u, settings, token)
    links = protocols.user_links(u, nodes.sub_inbounds(), settings) if u["status"] == "active" else []
    body = base64.b64encode("\n".join(links).encode()).decode()
    return Response(body, media_type="text/plain; charset=utf-8", headers=_sub_headers(u, settings))


@app.get("/sub/{token}/page")
def subscription_page(token: str, request: Request):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    return _sub_page(request, u, db.get_settings(), token)


@app.get("/sub/{token}/raw")
def subscription_raw(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    settings = db.get_settings()
    links = protocols.user_links(u, nodes.sub_inbounds(), settings) if u["status"] == "active" else []
    return PlainTextResponse("\n".join(links), headers=_sub_headers(u, settings))


@app.get("/sub/{token}/clash")
def subscription_clash(token: str):
    u = db.get_user_by_token(token)
    settings = db.get_settings()
    conf = mihomo_config.client_config(u, nodes.sub_inbounds(), settings) if u and u["status"] == "active" else None
    if not conf:
        raise HTTPException(404, "not found")
    return PlainTextResponse(conf, headers=_sub_headers(u, settings))


def _profile_response(text: str, filename: str, media_type: str):
    """File download for VPN profiles. A non-text media type stops phone browsers from adding .txt."""
    import re as _re
    from urllib.parse import quote as _q
    safe = _re.sub(r'[^A-Za-z0-9._-]', "_", filename) or "profile"
    cd = f"attachment; filename=\"{safe}\"; filename*=UTF-8''{_q(filename)}"
    return Response(text.encode(), media_type=media_type,
                    headers={"Content-Disposition": cd, "X-Content-Type-Options": "nosniff"})


@app.get("/sub/{token}/wg")
def subscription_wg(token: str):
    u = db.get_user_by_token(token)
    settings = db.get_settings()
    conf = protocols.wireguard_client_config(u, settings) if u and u["status"] == "active" else None
    if not conf:
        raise HTTPException(404, "not found")
    return _profile_response(conf, f'{u["username"]}.conf', "application/x-wireguard-profile")


@app.get("/sub/{token}/wg/{nid}")
def subscription_wg_node(token: str, nid: int):
    u = db.get_user_by_token(token)
    settings = db.get_settings()
    n = next((x for x in nodes.wg_nodes() if x["id"] == nid), None)
    conf = protocols.wireguard_client_config(u, settings, n["address"]) if u and n and u["status"] == "active" else None
    if not conf:
        raise HTTPException(404, "not found")
    return _profile_response(conf, f'{u["username"]}-{n["name"]}.conf', "application/x-wireguard-profile")


@app.get("/sub/{token}/ovpn")
def subscription_ovpn(token: str):
    u = db.get_user_by_token(token)
    conf = ovpn.client_config(u, db.get_settings()) if u and u["status"] == "active" else None
    if not conf:
        raise HTTPException(404, "not found")
    return _profile_response(conf, f'{u["username"]}.ovpn', "application/x-openvpn-profile")


@app.get("/sub/{token}/info")
def subscription_info(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    return {"username": u["username"], "status": u["status"], "used": u["used"], "data_limit": u["data_limit"],
            "expire_at": u["expire_at"]}


# ------------------------------------------------------------------ UI
# ------------------------------------------------------------------ Telegram bot (settings + Mini App + speed test)
class TgTokenIn(BaseModel):
    token: str
    owner_id: int | None = None


class TgCfgIn(BaseModel):
    enabled: bool | None = None
    alerts: bool | None = None
    backup: bool | None = None
    backup_hours: int | None = Field(default=None, ge=1, le=720)


class TgAdminIn(BaseModel):
    id: int
    name: str = ""


def _tg_info() -> dict:
    s = db.get_settings()
    url, https = tgbot.public_url()
    return {"token_set": bool(s.get("tg_token")), "username": s.get("tg_username", ""), "enabled": s.get("tg_enabled") == "1",
            "service": tgbot.service_state(), "admins": tgbot.admins(), "alerts": s.get("tg_alerts", "1") == "1",
            "backup": s.get("tg_backup") == "1", "backup_hours": int(s.get("tg_backup_hours", "24") or 24),
            "miniapp_url": url + "/miniapp", "https": https}


@app.get("/api/tgbot")
def tg_get(_: str = Depends(_jwt_only)):
    return _tg_info()


@app.post("/api/tgbot/token")
def tg_token(body: TgTokenIn, _: str = Depends(_jwt_only)):
    try:
        tgbot.setup(body.token, body.owner_id)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return _tg_info()


@app.put("/api/tgbot")
def tg_put(body: TgCfgIn, _: str = Depends(_jwt_only)):
    vals = {}
    if body.alerts is not None:
        vals["tg_alerts"] = "1" if body.alerts else "0"
    if body.backup is not None:
        vals["tg_backup"] = "1" if body.backup else "0"
    if body.backup_hours is not None:
        vals["tg_backup_hours"] = str(body.backup_hours)
    if vals:
        db.set_settings(vals)
    if body.enabled is True and db.get_settings().get("tg_token"):
        db.set_settings({"tg_enabled": "1"})
        tgbot.install_service()
        subprocess.run(["systemctl", "enable", "--now", tgbot.SERVICE], capture_output=True, timeout=30)
    elif body.enabled is False:
        tgbot.stop_service()
    return _tg_info()


@app.delete("/api/tgbot")
def tg_remove(_: str = Depends(_jwt_only)):
    tgbot.stop_service(clear_token=True)
    return _tg_info()


@app.post("/api/tgbot/admins")
def tg_add_admin(body: TgAdminIn, _: str = Depends(_jwt_only)):
    tgbot.add_admin(body.id, body.name.strip())
    return _tg_info()


@app.delete("/api/tgbot/admins/{aid}")
def tg_del_admin(aid: int, _: str = Depends(_jwt_only)):
    tgbot.save_admins([a for a in tgbot.admins() if int(a["id"]) != aid])
    return _tg_info()


@app.post("/api/tgbot/pair")
def tg_pair(_: str = Depends(_jwt_only)):
    return {"code": tgbot.new_pair_code(), "minutes": 10, "username": db.get_settings().get("tg_username", "")}


@app.post("/api/tgbot/test")
def tg_test(_: str = Depends(_jwt_only)):
    s = db.get_settings()
    if not s.get("tg_token") or not tgbot.admins():
        raise HTTPException(400, "اول توکن و حداقل یک ادمین تنظیم کن")
    tg = tgbot.TG(s["tg_token"])
    sent = sum(1 for a in tgbot.admins() if tg.send(a["id"], "✅ پیام تست از پنل tcm19").get("ok"))
    return {"sent": sent}


class MiniIn(BaseModel):
    initData: str


@app.post("/api/tg/miniapp-auth")
def tg_miniapp_auth(body: MiniIn, request: Request):
    ip = request.client.host if request.client else "?"
    now = time.time()
    _fails[ip] = [t for t in _fails.get(ip, []) if now - t < 600]
    if len(_fails[ip]) >= 20:
        raise HTTPException(429, "too many attempts")
    s = db.get_settings()
    uid = tgbot.verify_webapp(body.initData, s.get("tg_token", "")) if s.get("tg_token") else None
    if uid is None or not any(int(a["id"]) == uid for a in tgbot.admins()):
        _fails[ip].append(now)
        raise HTTPException(403, "دسترسی ندارید")
    name = db.first_admin()
    row = db.get_admin(name)
    return {"token": security.make_token(name, ttl=12 * 3600, pv=_pv(row["password_hash"]))}


@app.get("/miniapp", include_in_schema=False)
def miniapp_page():
    return FileResponse(config.STATIC_DIR / "miniapp.html")


def _speed_ok(t: str):
    if security.read_token(t or "") != "speed":
        raise HTTPException(403, "لینک منقضی شده؛ از ربات لینک جدید بگیر")


@app.get("/speed", include_in_schema=False)
def speed_page(t: str = ""):
    _speed_ok(t)
    return FileResponse(config.STATIC_DIR / "speed.html", headers={"Cache-Control": "no-store"})


@app.get("/speed/ping", include_in_schema=False)
def speed_ping(t: str = ""):
    _speed_ok(t)
    return Response("ok", headers={"Cache-Control": "no-store"})


@app.get("/speed/down", include_in_schema=False)
def speed_down(t: str = "", mb: int = 25):
    _speed_ok(t)
    chunk = os.urandom(262144)
    total = min(max(mb, 1), 200) * 1024 * 1024

    def gen():
        sent = 0
        while sent < total:
            yield chunk
            sent += len(chunk)
    return StreamingResponse(gen(), media_type="application/octet-stream",
                             headers={"Content-Length": str(total), "Cache-Control": "no-store"})


@app.post("/speed/up", include_in_schema=False)
async def speed_up(request: Request, t: str = ""):
    _speed_ok(t)
    n = 0
    async for c in request.stream():
        n += len(c)
        if n > 100 * 1024 * 1024:
            raise HTTPException(413, "too large")
    return {"bytes": n}


@app.get("/", include_in_schema=False)
def index():
    html = (config.STATIC_DIR / "index.html").read_text(encoding="utf-8").replace("__APP_VERSION__", _ver.VERSION)
    return Response(html, media_type="text/html; charset=utf-8", headers={"Cache-Control": "no-cache"})


# UNIPANEL_ENGINE_CONTROL_V1
_ENGINE_SERVICES = {
    "xray": os.environ.get("XRAY_SERVICE", "xray"),
    "singbox": os.environ.get(
        "SINGBOX_SERVICE",
        os.environ.get("SINGBOX_SERVIC", "sing-box")
    ),
    "mihomo": os.environ.get("MIHOMO_SERVICE", "mihomo"),
    "wireguard": f"wg-quick@{config.WG_IFACE}",
    "openvpn": ovpn.SERVICE,
}

_ENGINE_BINARIES = {
    "xray": "xray",
    "singbox": "sing-box",
    "mihomo": config.MIHOMO_BIN,
    "wireguard": "wg",
    "openvpn": "openvpn",
}

_ENGINE_CONFIGS = {
    "xray": os.environ.get(
        "XRAY_CONFIG", "/usr/local/etc/xray/config.json"
    ),
    "singbox": os.environ.get(
        "SINGBOX_CONFIG", "/etc/sing-box/config.json"
    ),
    "mihomo": str(config.MIHOMO_CONFIG),
    "wireguard": str(config.WG_CONFIG),
    "openvpn": str(ovpn.CONF),
}


def _engine_command(args, timeout=12):
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return {
            "returncode": result.returncode,
            "stdout": (result.stdout or "").strip()[:3000],
            "stderr": (result.stderr or "").strip()[:3000],
        }
    except subprocess.TimeoutExpired:
        return {
            "returncode": 124,
            "stdout": "",
            "stderr": "Command timed out",
        }
    except Exception as exc:
        return {
            "returncode": 1,
            "stdout": "",
            "stderr": str(exc)[:1000],
        }


def _engine_status(name):
    service = _ENGINE_SERVICES[name]
    binary = _ENGINE_BINARIES[name]
    config_file = _ENGINE_CONFIGS[name]

    active = _engine_command(
        ["systemctl", "is-active", service]
    )
    enabled = _engine_command(
        ["systemctl", "is-enabled", service]
    )
    version = _engine_command(
        [binary, "-v"] if name == "mihomo"
        else [binary, "--version"] if name in ("wireguard", "openvpn")
        else [binary, "version"],
        timeout=8,
    )

    return {
        "name": name,
        "installed": bool(shutil.which(binary) or os.path.isfile(binary)),
        "service": service,
        "active": active["stdout"] == "active",
        "state": active["stdout"] or "unknown",
        "enabled": enabled["stdout"] == "enabled",
        "startup": enabled["stdout"] or "unknown",
        "version": (
            (version["stdout"] or version["stderr"]).splitlines()[0]
            if (version["stdout"] or version["stderr"])
            else "unknown"
        ),
        "config_exists": os.path.isfile(config_file),
        "config_path": config_file,
    }


# ---- install / update / remove / on-off for every engine (needs the panel login) ----
_ENGJOB_UNIT = "tcm19-engjob"
_ENGJOB_FILE = config.DATA_DIR / "engjob.json"
_ENGJOB_LOG = config.DATA_DIR / "engjob.log"
_ENGINE_SETTING = {"wireguard": "wg_enabled", "openvpn": "ovpn_enabled"}


def _engjob_running() -> bool:
    return _engine_command(["systemctl", "is-active", _ENGJOB_UNIT], 5)["stdout"] in ("active", "activating")


@app.get("/api/engines/job")
def engine_job(_: str = Depends(_owner_jwt)):
    try:
        meta = json.loads(_ENGJOB_FILE.read_text())
    except (OSError, ValueError):
        return {"running": False}
    try:
        log = _ENGJOB_LOG.read_text(errors="replace")[-3000:]
    except OSError:
        log = ""
    return {"running": _engjob_running(), "engine": meta.get("engine"), "action": meta.get("action"), "log": log}


@app.post("/api/engines/{engine}/manage/{action}")
def engine_manage(engine: str, action: str, request: Request, _: str = Depends(_owner_jwt)):
    if engine not in _ENGINE_SERVICES:
        raise HTTPException(404, "Unsupported engine")
    if action not in ("install", "update", "remove", "start", "stop"):
        raise HTTPException(400, "Unsupported action")
    request.state.detail = f"{engine} {action}"
    key = _ENGINE_SETTING.get(engine)
    if action in ("start", "stop"):
        if not key:
            raise HTTPException(400, "use the normal start/stop for this engine")
        if action == "start" and not _engine_status(engine)["installed"]:
            raise HTTPException(400, "ابتدا نصب کنید")
        db.set_settings({key: "1" if action == "start" else "0"})
        if action == "stop":
            _engine_command(["systemctl", "disable", "--now", _ENGINE_SERVICES[engine]], 40)
        else:
            apply_in_background()
        return {"success": True}
    if _engjob_running():
        raise HTTPException(409, "یک عملیات دیگر در حال اجراست")
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    _ENGJOB_FILE.write_text(json.dumps({"engine": engine, "action": action, "ts": int(time.time())}))
    _ENGJOB_LOG.write_text("")
    # a separate systemd unit: install/remove restart the panel, which must not kill the job itself
    cmd = f"TCM_YES=1 /usr/local/bin/tcm19 engine {engine} {action} >> {_ENGJOB_LOG} 2>&1"
    res = _engine_command(["systemd-run", f"--unit={_ENGJOB_UNIT}", "--collect", "bash", "-c", cmd], 15)
    if res["returncode"] != 0:
        raise HTTPException(500, res["stderr"] or "could not start the job")
    return {"success": True, "job": True}


@app.get("/api/engines")
def engine_status_api():
    return {
        "success": True,
        "engines": {
            name: _engine_status(name)
            for name in _ENGINE_SERVICES
        },
    }


@app.post("/api/engines/{engine}/{action}")
@app.post("/api/engines/{engine}/{action}")
# UNIPANEL_ENGINE_AUTH_V1
def engine_action_api(engine: str, action: str):
    if engine not in _ENGINE_SERVICES:
        return {
            "success": False,
            "error": "Unsupported engine",
        }

    if action not in ("start", "stop", "restart", "enable", "disable"):
        return {
            "success": False,
            "error": "Unsupported action",
        }

    service = _ENGINE_SERVICES[engine]

    result = _engine_command(
        ["systemctl", action, service],
        timeout=25,
    )

    if result["returncode"] != 0:
        return {
            "success": False,
            "engine": engine,
            "action": action,
            "error": result["stderr"] or result["stdout"] or "systemctl failed",
            "status": _engine_status(engine),
        }

    return {
        "success": True,
        "engine": engine,
        "action": action,
        "message": "Operation completed",
        "status": _engine_status(engine),
    }

# END UNIPANEL_ENGINE_CONTROL_V1


# CLOUDFLARE_SSL_V1
cloudflare.register(app, admin_required)
