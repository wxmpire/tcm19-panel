import asyncio
import base64
import logging
import os
import re
import secrets
import sqlite3
import tempfile
import threading
import time
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config, db, monitor, protocols, security, system, cloudflare, inbound_rules, subport, serverips
import subprocess
import shutil

log = logging.getLogger("panel")
GB = 1024 ** 3
USERNAME_RE = r"^[A-Za-z0-9_.-]{3,32}$"
TAG_RE = r"^[A-Za-z0-9_-]{2,32}$"
RESERVED_PORTS = {10085}


# ------------------------------------------------------------------ startup
def bootstrap_admin():
    if db.admin_count():
        return
    user = os.environ.get("PANEL_ADMIN_USER", "admin")
    pw = os.environ.get("PANEL_ADMIN_PASS") or secrets.token_urlsafe(12)
    db.create_admin(user, security.hash_password(pw))
    config.INITIAL_ADMIN_FILE.write_text(f"username: {user}\npassword: {pw}\n")
    os.chmod(config.INITIAL_ADMIN_FILE, 0o600)
    log.warning("Created admin '%s'. Credentials saved to %s", user, config.INITIAL_ADMIN_FILE)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logging.basicConfig(level=logging.INFO)
    db.init()
    try:
        inbound_rules.migrate(db)
    except Exception:
        log.exception("inbound migration failed")
    bootstrap_admin()
    asyncio.create_task(asyncio.to_thread(monitor.apply_now))
    task = asyncio.create_task(monitor.run_forever())
    yield
    task.cancel()


app = FastAPI(title="VPN Panel", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
if config.STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=config.STATIC_DIR), name="static")


# ------------------------------------------------------------------ auth
_fails: dict[str, list[float]] = {}


def admin_required(authorization: str | None = Header(default=None)) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "unauthorized")
    sub = security.read_token(authorization[7:])
    if not sub or not db.get_admin(sub):
        raise HTTPException(401, "unauthorized")
    return sub


class LoginIn(BaseModel):
    username: str
    password: str


@app.post("/api/auth/login")
def login(body: LoginIn, request: Request):
    ip = request.client.host if request.client else "?"
    recent = [t for t in _fails.get(ip, []) if time.time() - t < 600]
    if len(recent) >= 8:
        raise HTTPException(429, "too many attempts, try again later")
    admin = db.get_admin(body.username)
    if not admin or not security.verify_password(body.password, admin["password_hash"]):
        _fails[ip] = recent + [time.time()]
        raise HTTPException(401, "invalid credentials")
    _fails.pop(ip, None)
    return {"token": security.make_token(admin["username"]), "username": admin["username"]}


class PasswordIn(BaseModel):
    old_password: str
    new_password: str = Field(min_length=8)


@app.post("/api/me/password")
def change_password(body: PasswordIn, admin: str = Depends(admin_required)):
    row = db.get_admin(admin)
    if not security.verify_password(body.old_password, row["password_hash"]):
        raise HTTPException(400, "old password is wrong")
    db.set_admin_password(admin, security.hash_password(body.new_password))
    return {"ok": True}


@app.get("/api/me")
def me(admin: str = Depends(admin_required)):
    return {"username": admin}


# ------------------------------------------------------------------ helpers
def base_url(request: Request, settings: dict) -> str:
    root = (settings.get("sub_base_url") or "").rstrip("/") or str(request.base_url).rstrip("/")
    port = (settings.get("sub_port") or "").strip()
    if port.isdigit():  # separate subscription port: keep scheme + host, swap the port
        from urllib.parse import urlsplit
        u = urlsplit(root)
        host = u.hostname or ""
        if ":" in host:
            host = f"[{host}]"
        return f"{u.scheme}://{host}:{port}"
    return root


def user_out(u: dict, settings: dict, request: Request) -> dict:
    out = {k: u[k] for k in ("id", "username", "status", "data_limit", "used", "expire_at", "reset_strategy",
                              "note", "wg_enabled", "wg_ip", "inbound_ids", "created_at", "last_reset")}
    out["sub_url"] = f"{base_url(request, settings)}/sub/{u['sub_token']}"
    return out


def apply_in_background():
    # endpoints are sync (threadpool) so there is no running loop here; use a plain thread
    threading.Thread(target=monitor.apply_now, daemon=True).start()


def setup_wg_for_user(settings: dict) -> dict:
    if settings.get("wg_enabled") != "1":
        raise HTTPException(400, "WireGuard is disabled in settings")
    system.ensure_wg_server_keys(settings)
    kp = system.wg_keypair()
    return {"wg_enabled": True, "wg_private": kp["private"], "wg_public": kp["public"],
            "wg_psk": system.wg_psk(), "wg_ip": system.allocate_wg_ip(settings)}


# ------------------------------------------------------------------ users
class UserCreate(BaseModel):
    username: str = Field(pattern=USERNAME_RE)
    data_limit_gb: float = Field(default=0, ge=0)
    expire_days: int | None = Field(default=None, ge=0)
    expire_at: int = 0
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] = "none"
    note: str = ""
    inbound_ids: list[int] | None = None
    wg_enabled: bool = False


class UserUpdate(BaseModel):
    status: Literal["active", "disabled"] | None = None
    data_limit_gb: float | None = Field(default=None, ge=0)
    expire_at: int | None = None
    expire_days: int | None = Field(default=None, ge=0)
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] | None = None
    note: str | None = None
    inbound_ids: list[int] | None = None
    wg_enabled: bool | None = None


def _create_user(body: UserCreate, settings: dict) -> int:
    data = body.model_dump()
    data["data_limit"] = int(body.data_limit_gb * GB)
    if body.expire_days:
        data["expire_at"] = db.now() + body.expire_days * 86400
    if body.inbound_ids is None:
        data["inbound_ids"] = [i["id"] for i in db.list_inbounds() if i["enabled"]]
    if body.wg_enabled:
        data.update(setup_wg_for_user(settings))
    try:
        return db.create_user(data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"username '{body.username}' already exists")


@app.get("/api/users")
def list_users(request: Request, search: str = "", status: str = "", page: int = 1, per_page: int = 50,
               _: str = Depends(admin_required)):
    per_page = min(max(per_page, 1), 200)
    users, total = db.list_users(search, status, per_page, (max(page, 1) - 1) * per_page)
    settings = db.get_settings()
    return {"total": total, "items": [user_out(u, settings, request) for u in users]}


@app.post("/api/users")
def create_user(body: UserCreate, request: Request, _: str = Depends(admin_required)):
    settings = db.get_settings()
    uid = _create_user(body, settings)
    apply_in_background()
    return user_out(db.get_user(uid), settings, request)


class BulkCreate(BaseModel):
    prefix: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,24}$")
    count: int = Field(ge=1, le=200)
    data_limit_gb: float = Field(default=0, ge=0)
    expire_days: int | None = Field(default=None, ge=0)
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] = "none"
    inbound_ids: list[int] | None = None


@app.post("/api/users/bulk")
def bulk_create(body: BulkCreate, request: Request, _: str = Depends(admin_required)):
    settings = db.get_settings()
    created = []
    for _i in range(body.count):
        name = f"{body.prefix}-{secrets.token_hex(3)}"
        uid = _create_user(UserCreate(username=name, data_limit_gb=body.data_limit_gb, expire_days=body.expire_days,
                                      reset_strategy=body.reset_strategy, inbound_ids=body.inbound_ids), settings)
        created.append(user_out(db.get_user(uid), settings, request))
    apply_in_background()
    return {"created": created}


def _get_user_or_404(user_id: int) -> dict:
    u = db.get_user(user_id)
    if not u:
        raise HTTPException(404, "user not found")
    return u


@app.get("/api/users/{user_id}")
def get_user(user_id: int, request: Request, _: str = Depends(admin_required)):
    return user_out(_get_user_or_404(user_id), db.get_settings(), request)


@app.put("/api/users/{user_id}")
def update_user(user_id: int, body: UserUpdate, request: Request, _: str = Depends(admin_required)):
    u = _get_user_or_404(user_id)
    settings = db.get_settings()
    fields: dict = {}
    if body.status is not None:
        fields["status"] = body.status
    if body.data_limit_gb is not None:
        fields["data_limit"] = int(body.data_limit_gb * GB)
    if body.expire_days:
        fields["expire_at"] = max(db.now(), u["expire_at"]) + body.expire_days * 86400
    elif body.expire_at is not None:
        fields["expire_at"] = body.expire_at
    for k in ("reset_strategy", "note"):
        if getattr(body, k) is not None:
            fields[k] = getattr(body, k)
    if body.wg_enabled is True and not u["wg_enabled"]:
        fields.update(setup_wg_for_user(settings) if not u["wg_private"] else {"wg_enabled": True})
    elif body.wg_enabled is False:
        fields["wg_enabled"] = False
    db.update_user(user_id, fields, body.inbound_ids)
    apply_in_background()
    return user_out(db.get_user(user_id), settings, request)


@app.delete("/api/users/{user_id}")
def delete_user(user_id: int, _: str = Depends(admin_required)):
    _get_user_or_404(user_id)
    db.delete_user(user_id)
    apply_in_background()
    return {"ok": True}


@app.post("/api/users/{user_id}/reset-usage")
def reset_usage(user_id: int, _: str = Depends(admin_required)):
    u = _get_user_or_404(user_id)
    fields = {"used": 0, "last_reset": db.now()}
    if u["status"] == "limited":
        fields["status"] = "active"
    db.update_user(user_id, fields)
    apply_in_background()
    return {"ok": True}


@app.post("/api/users/{user_id}/revoke-sub")
def revoke_sub(user_id: int, request: Request, _: str = Depends(admin_required)):
    _get_user_or_404(user_id)
    db.update_user(user_id, {"sub_token": secrets.token_urlsafe(18)})
    return user_out(db.get_user(user_id), db.get_settings(), request)


@app.get("/api/users/{user_id}/links")
def user_links(user_id: int, _: str = Depends(admin_required)):
    u, settings = _get_user_or_404(user_id), db.get_settings()
    inbounds = db.list_inbounds()
    allowed = set(u.get("inbound_ids", []))
    proxies = []

    for ib in inbounds:
        proto = ib["protocol"]
        if proto not in ("socks", "http", "mixed"):
            continue
        if not ib["enabled"] or ib["id"] not in allowed:
            continue

        ib_settings = ib.get("settings") or {}
        address = (
            ib_settings.get("address")
            or settings.get("server_address")
            or ""
        )

        label = ib.get("remark") or ib["tag"]
        protocol_name = {"socks": "SOCKS5", "http": "HTTP Proxy"}.get(proto, "SOCKS5 / HTTP (Mixed)")

        copy_text = (
            f"{protocol_name}\n"
            f"Server: {address}\n"
            f"Port: {ib['port']}\n"
            f"Username: {u['username']}\n"
            f"Password: {u['password']}"
        )

        proxies.append({
            "protocol": proto,
            "protocol_name": protocol_name,
            "tag": ib["tag"],
            "remark": label,
            "address": address,
            "port": ib["port"],
            "username": u["username"],
            "password": u["password"],
            "copy_text": copy_text,
        })

    return {
        "links": protocols.user_links(u, inbounds, settings),
        "proxies": proxies,
        "wireguard": protocols.wireguard_client_config(u, settings),
        "configs": [{"title": f"ShadowTLS · {ib.get('remark') or ib['tag']} (sing-box)",
                     "text": protocols.shadowtls_singbox_client(ib, u, settings)}
                    for ib in inbounds if ib["protocol"] == "shadowtls" and ib["enabled"] and ib["id"] in allowed],
    }


# ------------------------------------------------------------------ inbounds
class InboundIn(BaseModel):
    tag: str = Field(pattern=TAG_RE)
    remark: str = ""
    protocol: Literal["vless", "vmess", "trojan", "shadowsocks", "socks", "http",
                      "hysteria2", "hysteria", "tuic", "anytls", "naive", "mixed", "shadowtls", "tunnel"]
    port: int | None = Field(default=None, ge=1, le=65535)  # empty = random
    network: Literal["tcp", "ws", "grpc", "httpupgrade", "xhttp", "kcp", "udp"] = "tcp"
    security: Literal["none", "tls", "reality"] = "none"
    settings: dict = {}
    enabled: bool = True


def normalize_inbound(data: dict, settings: dict, exclude_id: int | None = None) -> dict:
    existing = db.get_inbound(exclude_id) if exclude_id else None
    try:
        return inbound_rules.normalize(data, settings, db.list_inbounds(), existing=existing)
    except inbound_rules.RuleError as e:
        raise HTTPException(e.code, str(e))


@app.get("/api/inbounds")
def list_inbounds(_: str = Depends(admin_required)):
    return db.list_inbounds()


@app.post("/api/inbounds")
def create_inbound(body: InboundIn, _: str = Depends(admin_required)):
    data = normalize_inbound(body.model_dump(), db.get_settings())
    try:
        iid = db.create_inbound(data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"tag '{data['tag']}' already exists")
    apply_in_background()
    return db.get_inbound(iid)


@app.put("/api/inbounds/{inbound_id}")
def update_inbound(inbound_id: int, body: InboundIn, _: str = Depends(admin_required)):
    if not db.get_inbound(inbound_id):
        raise HTTPException(404, "inbound not found")
    data = normalize_inbound(body.model_dump(), db.get_settings(), exclude_id=inbound_id)
    try:
        db.update_inbound(inbound_id, data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"tag '{data['tag']}' already exists")
    apply_in_background()
    return db.get_inbound(inbound_id)


@app.delete("/api/inbounds/{inbound_id}")
def delete_inbound(inbound_id: int, _: str = Depends(admin_required)):
    if not db.get_inbound(inbound_id):
        raise HTTPException(404, "inbound not found")
    db.delete_inbound(inbound_id)
    apply_in_background()
    return {"ok": True}


@app.post("/api/tools/reality-keys")
def reality_keys(_: str = Depends(admin_required)):
    try:
        return {**system.reality_keypair(), "short_id": system.short_id()}
    except RuntimeError as e:
        raise HTTPException(500, str(e))


# ------------------------------------------------------------------ settings / system
HIDDEN_SETTINGS = {"wg_server_private"}


@app.get("/api/settings")
def get_settings(_: str = Depends(admin_required)):
    return {k: v for k, v in db.get_settings().items() if k not in HIDDEN_SETTINGS}


@app.put("/api/settings")
def put_settings(body: dict, _: str = Depends(admin_required)):
    body = {k: v for k, v in body.items() if k in db.DEFAULT_SETTINGS and k not in HIDDEN_SETTINGS
            and k not in ("wg_server_public", "sub_port", "server_ips")}
    for k in ("wg_port", "monitor_interval", "wg_mtu", "update_interval"):
        if k in body and not str(body[k]).isdigit():
            raise HTTPException(400, f"{k} must be a number")
    db.set_settings({k: ("1" if v is True else "0" if v is False else v) for k, v in body.items()})
    apply_in_background()
    return get_settings(_)


class SubPortIn(BaseModel):
    port: int = Field(default=0, ge=0, le=65535)


@app.get("/api/subport")
def get_subport(_: str = Depends(admin_required)):
    return subport.current()


@app.put("/api/subport")
def put_subport(body: SubPortIn, _: str = Depends(admin_required)):
    try:
        return subport.set_port(body.port)
    except subport.SubPortError as e:
        raise HTTPException(400, str(e))


class IpIn(BaseModel):
    ip: str


def _ip_call(fn, *a):
    try:
        return fn(*a)
    except serverips.IpError as e:
        raise HTTPException(400, str(e))


@app.get("/api/server-ips")
def server_ips(_: str = Depends(admin_required)):
    return serverips.listing()


@app.post("/api/server-ips")
def server_ips_add(body: IpIn, _: str = Depends(admin_required)):
    return _ip_call(serverips.add, body.ip)


@app.put("/api/server-ips/default")
def server_ips_default(body: IpIn, _: str = Depends(admin_required)):
    r = _ip_call(serverips.make_default, body.ip)
    apply_in_background()
    return r


@app.delete("/api/server-ips/{ip}")
def server_ips_delete(ip: str, _: str = Depends(admin_required)):
    return _ip_call(serverips.remove, ip)


@app.get("/api/dashboard")
def dashboard(_: str = Depends(admin_required)):
    return {**db.stats(), "system": system.system_info(), "history": db.usage_history(14)}


@app.post("/api/system/apply")
def apply(_: str = Depends(admin_required)):
    return monitor.apply_now()


@app.get("/api/backup")
def backup(_: str = Depends(admin_required)):
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    tmp.close()
    src, dst = db.conn(), sqlite3.connect(tmp.name)
    src.backup(dst)
    dst.close()
    src.close()
    return FileResponse(tmp.name, filename=f"panel-backup-{time.strftime('%Y%m%d-%H%M')}.db",
                        media_type="application/octet-stream")


# ------------------------------------------------------------------ subscription (public, token-protected)
def _sub_headers(u: dict, settings: dict) -> dict:
    title = base64.b64encode(settings.get("profile_title", "VPN").encode()).decode()
    h = {
        "Subscription-Userinfo": f"upload=0; download={u['used']}; total={u['data_limit']}; expire={u['expire_at']}",
        "Profile-Title": f"base64:{title}",
        "Profile-Update-Interval": settings.get("update_interval", "12"),
        "Cache-Control": "no-store",
    }
    if settings.get("support_url"):
        h["Support-Url"] = settings["support_url"]
    return h


@app.get("/sub/{token}")
def subscription(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    settings = db.get_settings()
    links = protocols.user_links(u, db.list_inbounds(), settings) if u["status"] == "active" else []
    body = base64.b64encode("\n".join(links).encode()).decode()
    return Response(body, media_type="text/plain; charset=utf-8", headers=_sub_headers(u, settings))


@app.get("/sub/{token}/raw")
def subscription_raw(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    settings = db.get_settings()
    links = protocols.user_links(u, db.list_inbounds(), settings) if u["status"] == "active" else []
    return PlainTextResponse("\n".join(links), headers=_sub_headers(u, settings))


@app.get("/sub/{token}/wg")
def subscription_wg(token: str):
    u = db.get_user_by_token(token)
    settings = db.get_settings()
    conf = protocols.wireguard_client_config(u, settings) if u and u["status"] == "active" else None
    if not conf:
        raise HTTPException(404, "not found")
    return PlainTextResponse(conf, headers={"Content-Disposition": f'attachment; filename="{u["username"]}.conf"'})


@app.get("/sub/{token}/info")
def subscription_info(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    return {"username": u["username"], "status": u["status"], "used": u["used"], "data_limit": u["data_limit"],
            "expire_at": u["expire_at"]}


# ------------------------------------------------------------------ UI
@app.get("/", include_in_schema=False)
def index():
    return FileResponse(config.STATIC_DIR / "index.html")


# UNIPANEL_ENGINE_CONTROL_V1
_ENGINE_SERVICES = {
    "xray": os.environ.get("XRAY_SERVICE", "xray"),
    "singbox": os.environ.get(
        "SINGBOX_SERVICE",
        os.environ.get("SINGBOX_SERVIC", "sing-box")
    ),
}

_ENGINE_BINARIES = {
    "xray": "xray",
    "singbox": "sing-box",
}

_ENGINE_CONFIGS = {
    "xray": os.environ.get(
        "XRAY_CONFIG", "/usr/local/etc/xray/config.json"
    ),
    "singbox": os.environ.get(
        "SINGBOX_CONFIG", "/etc/sing-box/config.json"
    ),
}


def _engine_command(args, timeout=12):
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return {
            "returncode": result.returncode,
            "stdout": (result.stdout or "").strip()[:3000],
            "stderr": (result.stderr or "").strip()[:3000],
        }
    except subprocess.TimeoutExpired:
        return {
            "returncode": 124,
            "stdout": "",
            "stderr": "Command timed out",
        }
    except Exception as exc:
        return {
            "returncode": 1,
            "stdout": "",
            "stderr": str(exc)[:1000],
        }


def _engine_status(name):
    service = _ENGINE_SERVICES[name]
    binary = _ENGINE_BINARIES[name]
    config_file = _ENGINE_CONFIGS[name]

    active = _engine_command(
        ["systemctl", "is-active", service]
    )
    enabled = _engine_command(
        ["systemctl", "is-enabled", service]
    )
    version = _engine_command(
        [binary, "version"] if name == "singbox"
        else [binary, "version"],
        timeout=8,
    )

    return {
        "name": name,
        "service": service,
        "active": active["stdout"] == "active",
        "state": active["stdout"] or "unknown",
        "enabled": enabled["stdout"] == "enabled",
        "startup": enabled["stdout"] or "unknown",
        "version": (
            (version["stdout"] or version["stderr"]).splitlines()[0]
            if (version["stdout"] or version["stderr"])
            else "unknown"
        ),
        "config_exists": os.path.isfile(config_file),
        "config_path": config_file,
    }


@app.get("/api/engines")
def engine_status_api():
    return {
        "success": True,
        "engines": {
            name: _engine_status(name)
            for name in _ENGINE_SERVICES
        },
    }


@app.post("/api/engines/{engine}/{action}")
@app.post("/api/engines/{engine}/{action}")
# UNIPANEL_ENGINE_AUTH_V1
def engine_action_api(engine: str, action: str):
    if engine not in _ENGINE_SERVICES:
        return {
            "success": False,
            "error": "Unsupported engine",
        }

    if action not in ("start", "stop", "restart", "enable", "disable"):
        return {
            "success": False,
            "error": "Unsupported action",
        }

    service = _ENGINE_SERVICES[engine]

    result = _engine_command(
        ["systemctl", action, service],
        timeout=25,
    )

    if result["returncode"] != 0:
        return {
            "success": False,
            "engine": engine,
            "action": action,
            "error": result["stderr"] or result["stdout"] or "systemctl failed",
            "status": _engine_status(engine),
        }

    return {
        "success": True,
        "engine": engine,
        "action": action,
        "message": "Operation completed",
        "status": _engine_status(engine),
    }

# END UNIPANEL_ENGINE_CONTROL_V1


# CLOUDFLARE_SSL_V1
cloudflare.register(app, admin_required)
