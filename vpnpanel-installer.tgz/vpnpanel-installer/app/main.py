import asyncio
import base64
import json
import logging
import os
import re
import secrets
import sqlite3
import tempfile
import threading
import time
from contextlib import asynccontextmanager
from typing import Literal

from fastapi import Depends, FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse, PlainTextResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import config, db, mihomo_config, monitor, protocols, security, system, cloudflare, inbound_rules, subport, serverips, outbounds
import subprocess
import shutil

log = logging.getLogger("panel")
GB = 1024 ** 3
USERNAME_RE = r"^[A-Za-z0-9_.-]{3,32}$"
TAG_RE = r"^[A-Za-z0-9_-]{2,32}$"
RESERVED_PORTS = {10085}


# ------------------------------------------------------------------ startup
def bootstrap_admin():
    if db.admin_count():
        return
    user = os.environ.get("PANEL_ADMIN_USER", "admin")
    pw = os.environ.get("PANEL_ADMIN_PASS") or secrets.token_urlsafe(12)
    db.create_admin(user, security.hash_password(pw))
    config.INITIAL_ADMIN_FILE.write_text(f"username: {user}\npassword: {pw}\n")
    os.chmod(config.INITIAL_ADMIN_FILE, 0o600)
    log.warning("Created admin '%s'. Credentials saved to %s", user, config.INITIAL_ADMIN_FILE)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logging.basicConfig(level=logging.INFO)
    db.init()
    try:
        inbound_rules.migrate(db)
    except Exception:
        log.exception("inbound migration failed")
    bootstrap_admin()
    asyncio.create_task(asyncio.to_thread(monitor.apply_now))
    task = asyncio.create_task(monitor.run_forever())
    yield
    task.cancel()


app = FastAPI(title="tcm19", lifespan=lifespan, docs_url=None, redoc_url=None, openapi_url=None)
if config.STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=config.STATIC_DIR), name="static")


# ------------------------------------------------------------------ auth
_fails: dict[str, list[float]] = {}


def admin_required(authorization: str | None = Header(default=None)) -> str:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "unauthorized")
    sub = security.read_token(authorization[7:])
    if not sub or not db.get_admin(sub):
        raise HTTPException(401, "unauthorized")
    return sub


class LoginIn(BaseModel):
    username: str
    password: str


@app.post("/api/auth/login")
def login(body: LoginIn, request: Request):
    ip = request.client.host if request.client else "?"
    recent = [t for t in _fails.get(ip, []) if time.time() - t < 600]
    if len(recent) >= 8:
        raise HTTPException(429, "too many attempts, try again later")
    admin = db.get_admin(body.username)
    if not admin or not security.verify_password(body.password, admin["password_hash"]):
        _fails[ip] = recent + [time.time()]
        raise HTTPException(401, "invalid credentials")
    _fails.pop(ip, None)
    return {"token": security.make_token(admin["username"]), "username": admin["username"]}


class PasswordIn(BaseModel):
    old_password: str
    new_password: str = Field(min_length=1)


@app.post("/api/me/password")
def change_password(body: PasswordIn, admin: str = Depends(admin_required)):
    row = db.get_admin(admin)
    if not security.verify_password(body.old_password, row["password_hash"]):
        raise HTTPException(400, "old password is wrong")
    db.set_admin_password(admin, security.hash_password(body.new_password))
    return {"ok": True}


@app.get("/api/me")
def me(admin: str = Depends(admin_required)):
    return {"username": admin}


# ------------------------------------------------------------------ helpers
def base_url(request: Request, settings: dict) -> str:
    root = (settings.get("sub_base_url") or "").rstrip("/") or str(request.base_url).rstrip("/")
    port = (settings.get("sub_port") or "").strip()
    if port.isdigit():  # separate subscription port: keep scheme + host, swap the port
        from urllib.parse import urlsplit
        u = urlsplit(root)
        host = u.hostname or ""
        if ":" in host:
            host = f"[{host}]"
        return f"{u.scheme}://{host}:{port}"
    return root


def user_out(u: dict, settings: dict, request: Request) -> dict:
    out = {k: u[k] for k in ("id", "username", "status", "data_limit", "used", "expire_at", "reset_strategy",
                              "note", "wg_enabled", "wg_ip", "inbound_ids", "created_at", "last_reset", "country_exits")}
    out["sub_url"] = f"{base_url(request, settings)}/sub/{u['sub_token']}"
    return out


def apply_in_background():
    # endpoints are sync (threadpool) so there is no running loop here; use a plain thread
    threading.Thread(target=monitor.apply_now, daemon=True).start()


def setup_wg_for_user(settings: dict) -> dict:
    if settings.get("wg_enabled") != "1":
        raise HTTPException(400, "WireGuard is disabled in settings")
    system.ensure_wg_server_keys(settings)
    kp = system.wg_keypair()
    return {"wg_enabled": True, "wg_private": kp["private"], "wg_public": kp["public"],
            "wg_psk": system.wg_psk(), "wg_ip": system.allocate_wg_ip(settings)}


# ------------------------------------------------------------------ users
class UserCreate(BaseModel):
    username: str = Field(pattern=USERNAME_RE)
    data_limit_gb: float = Field(default=0, ge=0)
    expire_days: int | None = Field(default=None, ge=0)
    expire_at: int = 0
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] = "none"
    note: str = ""
    inbound_ids: list[int] | None = None
    wg_enabled: bool = False
    country_exits: bool = False


class UserUpdate(BaseModel):
    status: Literal["active", "disabled"] | None = None
    data_limit_gb: float | None = Field(default=None, ge=0)
    expire_at: int | None = None
    expire_days: int | None = Field(default=None, ge=0)
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] | None = None
    note: str | None = None
    inbound_ids: list[int] | None = None
    wg_enabled: bool | None = None
    country_exits: bool | None = None


def _create_user(body: UserCreate, settings: dict) -> int:
    data = body.model_dump()
    data["data_limit"] = int(body.data_limit_gb * GB)
    if body.expire_days:
        data["expire_at"] = db.now() + body.expire_days * 86400
    if body.inbound_ids is None:
        data["inbound_ids"] = [i["id"] for i in db.list_inbounds() if i["enabled"]]
    if body.wg_enabled:
        data.update(setup_wg_for_user(settings))
    try:
        return db.create_user(data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"username '{body.username}' already exists")


@app.get("/api/users")
def list_users(request: Request, search: str = "", status: str = "", page: int = 1, per_page: int = 50,
               _: str = Depends(admin_required)):
    per_page = min(max(per_page, 1), 200)
    users, total = db.list_users(search, status, per_page, (max(page, 1) - 1) * per_page)
    settings = db.get_settings()
    return {"total": total, "items": [user_out(u, settings, request) for u in users]}


@app.post("/api/users")
def create_user(body: UserCreate, request: Request, _: str = Depends(admin_required)):
    settings = db.get_settings()
    uid = _create_user(body, settings)
    apply_in_background()
    return user_out(db.get_user(uid), settings, request)


class BulkCreate(BaseModel):
    prefix: str = Field(pattern=r"^[A-Za-z0-9_.-]{1,24}$")
    count: int = Field(ge=1, le=200)
    data_limit_gb: float = Field(default=0, ge=0)
    expire_days: int | None = Field(default=None, ge=0)
    reset_strategy: Literal["none", "daily", "weekly", "monthly"] = "none"
    inbound_ids: list[int] | None = None
    country_exits: bool = False


@app.post("/api/users/bulk")
def bulk_create(body: BulkCreate, request: Request, _: str = Depends(admin_required)):
    settings = db.get_settings()
    created = []
    for _i in range(body.count):
        name = f"{body.prefix}-{secrets.token_hex(3)}"
        uid = _create_user(UserCreate(username=name, data_limit_gb=body.data_limit_gb, expire_days=body.expire_days,
                                      reset_strategy=body.reset_strategy, inbound_ids=body.inbound_ids,
                                      country_exits=body.country_exits), settings)
        created.append(user_out(db.get_user(uid), settings, request))
    apply_in_background()
    return {"created": created}


def _get_user_or_404(user_id: int) -> dict:
    u = db.get_user(user_id)
    if not u:
        raise HTTPException(404, "user not found")
    return u


@app.get("/api/users/{user_id}")
def get_user(user_id: int, request: Request, _: str = Depends(admin_required)):
    return user_out(_get_user_or_404(user_id), db.get_settings(), request)


@app.put("/api/users/{user_id}")
def update_user(user_id: int, body: UserUpdate, request: Request, _: str = Depends(admin_required)):
    u = _get_user_or_404(user_id)
    settings = db.get_settings()
    fields: dict = {}
    if body.status is not None:
        fields["status"] = body.status
    if body.data_limit_gb is not None:
        fields["data_limit"] = int(body.data_limit_gb * GB)
    if body.expire_days:
        fields["expire_at"] = max(db.now(), u["expire_at"]) + body.expire_days * 86400
    elif body.expire_at is not None:
        fields["expire_at"] = body.expire_at
    for k in ("reset_strategy", "note"):
        if getattr(body, k) is not None:
            fields[k] = getattr(body, k)
    if body.country_exits is not None:
        fields["country_exits"] = body.country_exits
    if body.wg_enabled is True and not u["wg_enabled"]:
        fields.update(setup_wg_for_user(settings) if not u["wg_private"] else {"wg_enabled": True})
    elif body.wg_enabled is False:
        fields["wg_enabled"] = False
    db.update_user(user_id, fields, body.inbound_ids)
    apply_in_background()
    return user_out(db.get_user(user_id), settings, request)


@app.delete("/api/users/{user_id}")
def delete_user(user_id: int, _: str = Depends(admin_required)):
    _get_user_or_404(user_id)
    db.delete_user(user_id)
    apply_in_background()
    return {"ok": True}


@app.post("/api/users/{user_id}/reset-usage")
def reset_usage(user_id: int, _: str = Depends(admin_required)):
    u = _get_user_or_404(user_id)
    fields = {"used": 0, "last_reset": db.now()}
    if u["status"] == "limited":
        fields["status"] = "active"
    db.update_user(user_id, fields)
    apply_in_background()
    return {"ok": True}


@app.post("/api/users/{user_id}/revoke-sub")
def revoke_sub(user_id: int, request: Request, _: str = Depends(admin_required)):
    _get_user_or_404(user_id)
    db.update_user(user_id, {"sub_token": secrets.token_urlsafe(18)})
    return user_out(db.get_user(user_id), db.get_settings(), request)


@app.get("/api/users/{user_id}/links")
def user_links(user_id: int, _: str = Depends(admin_required)):
    u, settings = _get_user_or_404(user_id), db.get_settings()
    inbounds = db.list_inbounds()
    allowed = set(u.get("inbound_ids", []))
    proxies = []

    for ib in inbounds:
        proto = ib["protocol"]
        if proto not in ("socks", "http", "mixed"):
            continue
        if not ib["enabled"] or ib["id"] not in allowed:
            continue

        ib_settings = ib.get("settings") or {}
        address = (
            ib_settings.get("address")
            or settings.get("server_address")
            or ""
        )

        label = ib.get("remark") or ib["tag"]
        protocol_name = {"socks": "SOCKS5", "http": "HTTP Proxy"}.get(proto, "SOCKS5 / HTTP (Mixed)")

        copy_text = (
            f"{protocol_name}\n"
            f"Server: {address}\n"
            f"Port: {ib['port']}\n"
            f"Username: {u['username']}\n"
            f"Password: {u['password']}"
        )

        proxies.append({
            "protocol": proto,
            "protocol_name": protocol_name,
            "tag": ib["tag"],
            "remark": label,
            "address": address,
            "port": ib["port"],
            "username": u["username"],
            "password": u["password"],
            "copy_text": copy_text,
        })

    return {
        "links": protocols.user_links(u, inbounds, settings),
        "proxies": proxies,
        "wireguard": protocols.wireguard_client_config(u, settings),
        "clash": mihomo_config.client_config(u, inbounds, settings) if u["status"] == "active" else None,
        "configs": [{"title": f"ShadowTLS · {ib.get('remark') or ib['tag']} (sing-box)",
                     "text": protocols.shadowtls_singbox_client(ib, u, settings)}
                    for ib in inbounds if ib["protocol"] == "shadowtls" and ib["enabled"] and ib["id"] in allowed],
    }


# ------------------------------------------------------------------ inbounds
class InboundIn(BaseModel):
    tag: str = Field(pattern=TAG_RE)
    remark: str = ""
    protocol: Literal["vless", "vmess", "trojan", "shadowsocks", "socks", "http",
                      "hysteria2", "hysteria", "tuic", "anytls", "naive", "mixed", "shadowtls", "tunnel",
                      "mieru", "sudoku", "shadowquic", "trusttunnel"]
    port: int | None = Field(default=None, ge=1, le=65535)  # empty = random
    network: Literal["tcp", "ws", "grpc", "httpupgrade", "xhttp", "kcp", "udp"] = "tcp"
    security: Literal["none", "tls", "reality"] = "none"
    settings: dict = {}
    enabled: bool = True


def normalize_inbound(data: dict, settings: dict, exclude_id: int | None = None) -> dict:
    existing = db.get_inbound(exclude_id) if exclude_id else None
    try:
        return inbound_rules.normalize(data, settings, db.list_inbounds(), existing=existing)
    except inbound_rules.RuleError as e:
        raise HTTPException(e.code, str(e))


@app.get("/api/inbounds")
def list_inbounds(_: str = Depends(admin_required)):
    return db.list_inbounds()


@app.post("/api/inbounds")
def create_inbound(body: InboundIn, _: str = Depends(admin_required)):
    data = normalize_inbound(body.model_dump(), db.get_settings())
    try:
        iid = db.create_inbound(data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"tag '{data['tag']}' already exists")
    apply_in_background()
    return db.get_inbound(iid)


@app.put("/api/inbounds/{inbound_id}")
def update_inbound(inbound_id: int, body: InboundIn, _: str = Depends(admin_required)):
    if not db.get_inbound(inbound_id):
        raise HTTPException(404, "inbound not found")
    data = normalize_inbound(body.model_dump(), db.get_settings(), exclude_id=inbound_id)
    try:
        db.update_inbound(inbound_id, data)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"tag '{data['tag']}' already exists")
    apply_in_background()
    return db.get_inbound(inbound_id)


@app.delete("/api/inbounds/{inbound_id}")
def delete_inbound(inbound_id: int, _: str = Depends(admin_required)):
    if not db.get_inbound(inbound_id):
        raise HTTPException(404, "inbound not found")
    db.delete_inbound(inbound_id)
    apply_in_background()
    return {"ok": True}


@app.post("/api/tools/reality-keys")
def reality_keys(_: str = Depends(admin_required)):
    try:
        return {**system.reality_keypair(), "short_id": system.short_id()}
    except RuntimeError as e:
        raise HTTPException(500, str(e))



# ------------------------------------------------------------------ outbounds + routing
class OutboundIn(BaseModel):
    tag: str = Field(pattern=TAG_RE)
    remark: str = ""
    type: Literal["warp", "tor", "psiphon", "socks", "http", "shadowsocks", "wireguard"]
    settings: dict = {}
    enabled: bool = True


class RuleIn(BaseModel):
    remark: str = ""
    enabled: bool = True
    inbound_tags: list[str] = []
    domain: list[str] = []
    ip: list[str] = []
    port: str = ""
    network: str = ""
    protocol: list[str] = []
    outbound_tag: str


class FinalIn(BaseModel):
    outbound_tag: str


class PresetIn(BaseModel):
    outbound_tag: str = ""


class InstallIn(BaseModel):
    url: str = ""


def _oerr(e: outbounds.OutboundError) -> HTTPException:
    return HTTPException(e.code, str(e))


def _apply_checked(undo):
    """Apply now. If Xray / sing-box reject the new config, run undo() and report why (the old config stays live)."""
    res = monitor.apply_now()
    errs = [f"{k}: {v}" for k, v in res.items()
            if isinstance(v, str) and ("validation failed" in v or v.startswith("restart failed"))]
    if errs:
        try:
            undo()
        finally:
            monitor.apply_now()
        raise HTTPException(400, "تنظیم اعمال نشد و به حالت قبل برگشت: " + " | ".join(e[:500] for e in errs))
    return res


def _enabled_tags() -> set[str]:
    return {"direct", "block"} | {o["tag"] for o in db.list_outbounds() if o["enabled"]}


def _usage(tag: str) -> list[str]:
    users = [f"قانون «{r['remark'] or r['id']}»" for r in db.list_rules() if r["outbound_tag"] == tag]
    if db.get_settings().get("routing_final") == tag:
        users.append("اوتباند پیش‌فرض")
    n = outbounds.text_rules_using(tag)
    if n:
        users.append(f"{n} قانون متنی")
    return users


@app.get("/api/outbounds")
def list_outbounds_api(_: str = Depends(admin_required)):
    rules = db.list_rules()
    final = db.get_settings().get("routing_final", "direct") or "direct"
    out = [{"id": 0, "tag": "direct", "remark": "مستقیم", "type": "direct", "builtin": True, "enabled": True,
            "settings": {}, "rules_using": sum(r["outbound_tag"] == "direct" for r in rules), "is_final": final == "direct"},
           {"id": -1, "tag": "block", "remark": "بلاک", "type": "block", "builtin": True, "enabled": True,
            "settings": {}, "rules_using": sum(r["outbound_tag"] == "block" for r in rules), "is_final": final == "block"}]
    for o in db.list_outbounds():
        out.append({**o, "builtin": False, "rules_using": sum(r["outbound_tag"] == o["tag"] for r in rules),
                    "is_final": final == o["tag"],
                    "status": outbounds.service_status(o["type"]) if o["type"] in outbounds.SERVICES else None})
    return {"outbounds": out, "final": final,
            "inbounds": [{"tag": i["tag"], "engine": i["engine"], "remark": i["remark"]} for i in db.list_inbounds()]}


@app.post("/api/outbounds")
def create_outbound_api(body: OutboundIn, _: str = Depends(admin_required)):
    data = body.model_dump()
    try:
        if data["type"] == "warp" and not data["settings"].get("private_key"):
            reg = outbounds.warp_register(str(data["settings"].get("license") or "").strip())
            data["settings"] = {**data["settings"], **reg}
        norm = outbounds.normalize_outbound(data, db.list_outbounds())
    except outbounds.OutboundError as e:
        raise _oerr(e)
    try:
        oid = db.create_outbound(norm)
    except sqlite3.IntegrityError:
        raise HTTPException(409, f"تگ '{norm['tag']}' از قبل وجود دارد")
    _apply_checked(lambda: db.delete_outbound(oid))
    return db.get_outbound(oid)


@app.put("/api/outbounds/{outbound_id}")
def update_outbound_api(outbound_id: int, body: OutboundIn, _: str = Depends(admin_required)):
    old = db.get_outbound(outbound_id)
    if not old:
        raise HTTPException(404, "اوتباند پیدا نشد")
    data = body.model_dump()
    if data["tag"] != old["tag"]:
        raise HTTPException(400, "تگ بعد از ساخت قابل تغییر نیست (قانون‌ها با تگ به آن وصل‌اند)")
    if not data["enabled"] and _usage(old["tag"]):
        raise HTTPException(409, "این اوتباند استفاده می‌شود و نمی‌شود غیرفعالش کرد: " + "، ".join(_usage(old["tag"])))
    try:
        if data["type"] == "warp" and data["settings"].get("reregister"):
            reg = outbounds.warp_register(str(data["settings"].get("license") or old["settings"].get("license") or "").strip())
            data["settings"] = {**{k: v for k, v in data["settings"].items() if k != "reregister"}, **reg}
        norm = outbounds.normalize_outbound(data, db.list_outbounds(), existing=old)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    db.update_outbound(outbound_id, norm)
    _apply_checked(lambda: db.update_outbound(outbound_id, old))
    return db.get_outbound(outbound_id)


@app.delete("/api/outbounds/{outbound_id}")
def delete_outbound_api(outbound_id: int, _: str = Depends(admin_required)):
    old = db.get_outbound(outbound_id)
    if not old:
        raise HTTPException(404, "اوتباند پیدا نشد")
    used = _usage(old["tag"])
    if used:
        raise HTTPException(409, "این اوتباند استفاده می‌شود؛ اول این‌ها را تغییر بده یا حذف کن: " + "، ".join(used))
    db.delete_outbound(outbound_id)
    apply_in_background()
    return {"ok": True}


@app.post("/api/outbounds/test/{ref}")
def test_outbound_api(ref: str, _: str = Depends(admin_required)):
    rt = outbounds.load_routing()
    ports = outbounds.test_ports(rt)
    if ref == "0":
        tag = "direct"
    elif ref.isdigit():
        ob = db.get_outbound(int(ref))
        tag = ob["tag"] if ob else ""
    else:
        tag = ref
    if tag == "block":
        raise HTTPException(400, "اوتباند بلاک اتصال ندارد که تست شود")
    if tag not in ports:
        raise HTTPException(400, "اوتباند فعال نیست یا هنوز اعمال نشده؛ چند ثانیه بعد دوباره امتحان کن")
    if system.service_state(config.XRAY_SERVICE) != "active" and not config.DRY_RUN:
        raise HTTPException(400, "Xray روشن نیست؛ تست از مسیر Xray انجام می‌شود")
    return outbounds.test_outbound(ports[tag])


@app.get("/api/outbounds/services")
def outbound_services(_: str = Depends(admin_required)):
    return {n: outbounds.service_status(n) for n in outbounds.SERVICES}


@app.post("/api/outbounds/services/{name}/install")
def install_outbound_service(name: str, body: InstallIn, _: str = Depends(admin_required)):
    try:
        outbounds.install_service(name, body.url.strip())
    except outbounds.OutboundError as e:
        raise _oerr(e)
    return {"ok": True}


@app.get("/api/routing")
def get_routing(_: str = Depends(admin_required)):
    st = db.get_settings()
    return {"final": st.get("routing_final", "direct") or "direct",
            "toggles": outbounds.toggle_state(st), "text": st.get("routing_text", ""),
            "rules": db.list_rules(),
            "outbound_tags": sorted(_enabled_tags()),
            "presets": [{"key": k, "title": v["title"], "target": v["target"], "count": len(v["rules"])}
                        for k, v in outbounds.PRESETS.items()]}


@app.put("/api/routing/final")
def put_routing_final(body: FinalIn, _: str = Depends(admin_required)):
    if body.outbound_tag not in _enabled_tags():
        raise HTTPException(400, "اوتباند وجود ندارد یا غیرفعال است")
    old = db.get_settings().get("routing_final", "direct")
    db.set_settings({"routing_final": body.outbound_tag})
    _apply_checked(lambda: db.set_settings({"routing_final": old}))
    return {"final": body.outbound_tag}


def _norm_rule(data: dict) -> dict:
    try:
        return outbounds.normalize_rule(data, _enabled_tags(), {i["tag"] for i in db.list_inbounds()})
    except outbounds.OutboundError as e:
        raise _oerr(e)


@app.post("/api/routing/rules")
def create_rule_api(body: RuleIn, _: str = Depends(admin_required)):
    if len(db.list_rules()) >= outbounds.MAX_RULES:
        raise HTTPException(400, "تعداد قانون‌ها به سقف رسیده")
    rid = db.create_rule(_norm_rule(body.model_dump()))
    _apply_checked(lambda: db.delete_rule(rid))
    return db.get_rule(rid)


@app.put("/api/routing/rules/{rule_id}")
def update_rule_api(rule_id: int, body: RuleIn, _: str = Depends(admin_required)):
    old = db.get_rule(rule_id)
    if not old:
        raise HTTPException(404, "قانون پیدا نشد")
    db.update_rule(rule_id, _norm_rule(body.model_dump()))
    _apply_checked(lambda: db.update_rule(rule_id, old))
    return db.get_rule(rule_id)


@app.delete("/api/routing/rules/{rule_id}")
def delete_rule_api(rule_id: int, _: str = Depends(admin_required)):
    if not db.get_rule(rule_id):
        raise HTTPException(404, "قانون پیدا نشد")
    db.delete_rule(rule_id)
    apply_in_background()
    return {"ok": True}


class MoveIn(BaseModel):
    direction: Literal["up", "down"]


@app.post("/api/routing/rules/{rule_id}/move")
def move_rule_api(rule_id: int, body: MoveIn, _: str = Depends(admin_required)):
    if not db.move_rule(rule_id, body.direction):
        raise HTTPException(400, "قانون بیشتر از این جابه‌جا نمی‌شود")
    apply_in_background()
    return {"ok": True}


@app.post("/api/routing/presets/{key}")
def add_preset(key: str, body: PresetIn, _: str = Depends(admin_required)):
    pre = outbounds.PRESETS.get(key)
    if not pre:
        raise HTTPException(404, "قالب پیدا نشد")
    target = pre["target"] or body.outbound_tag
    if not target:
        raise HTTPException(400, "اوتباند مقصد را انتخاب کن")
    if len(db.list_rules()) + len(pre["rules"]) > outbounds.MAX_RULES:
        raise HTTPException(400, "تعداد قانون‌ها به سقف رسیده")
    norm = [_norm_rule({**r, "outbound_tag": target}) for r in pre["rules"]]
    ids = [db.create_rule(n) for n in norm]
    _apply_checked(lambda: [db.delete_rule(i) for i in ids])
    return {"added": len(ids)}


class QuickIn(BaseModel):
    toggles: dict[str, bool] = {}
    text: str = Field(default="", max_length=20000)


@app.put("/api/routing/quick")
def put_routing_quick(body: QuickIn, _: str = Depends(admin_required)):
    bad = [k for k in body.toggles if k not in outbounds.TOGGLES and k != "torrent"]
    if bad:
        raise HTTPException(400, f"سوئیچ ناشناخته: {bad[0]}")
    obs = [o for o in db.list_outbounds() if o["enabled"]]
    try:
        outbounds.parse_text_rules(body.text, _enabled_tags(), outbounds._type_tags(obs), strict=True)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    st = db.get_settings()
    old = {k: st.get(k, "") for k in ("routing_toggles", "routing_text", "block_bittorrent")}
    cur = outbounds.toggle_state(st)
    cur.update(body.toggles)
    db.set_settings({"routing_toggles": json.dumps({k: cur[k] for k in outbounds.TOGGLES}),
                     "routing_text": body.text.strip("\n"),
                     "block_bittorrent": "1" if cur["torrent"] else "0"})
    _apply_checked(lambda: db.set_settings(old))
    st = db.get_settings()
    return {"toggles": outbounds.toggle_state(st), "text": st.get("routing_text", "")}


# ------------------------------------------------------------------ Tor / Psiphon exits + WARP card
TOR_COUNTRIES = ("AE AR AT AU BE BG BR CA CH CL CO CZ DE DK EE ES FI FR GB GR HK HR HU ID IE IL IN IS IT JP KR LT LU "
                 "LV MD MX MY NL NO NZ PL PT RO RS RU SE SG SI SK TH TR TW UA US ZA").split()


def _exit_item(o: dict) -> dict:
    stt = outbounds.instance_status(o)
    return {"id": o["id"], "tag": o["tag"], "service": o["type"], "country": outbounds.ob_cc(o).upper(),
            "port": outbounds.ob_port(o), "enabled": o["enabled"],
            "installed": stt["installed"], "active": stt["active"],
            "custom_port": bool(o["settings"].get("port"))}


@app.get("/api/exits")
def get_exits(_: str = Depends(admin_required)):
    obs = db.list_outbounds()
    generic = {}
    for svc in ("tor", "psiphon"):
        o = next((x for x in obs if x["type"] == svc and not x["settings"].get("per_country")), None)
        generic[svc] = _exit_item(o) if o else None
    return {"generic": generic,
            "countries": [_exit_item(o) for o in obs if o["type"] in ("tor", "psiphon") and o["settings"].get("per_country")],
            "services": {n: outbounds.service_status(n) for n in outbounds.SERVICES},
            "country_codes": {"tor": TOR_COUNTRIES, "psiphon": outbounds.PSIPHON_COUNTRIES},
            "default_ports": {"tor": outbounds.LOCAL_PORT["tor"], "psiphon": outbounds.LOCAL_PORT["psiphon"]}}


class GenericExitIn(BaseModel):
    enabled: bool
    port: int = Field(default=0, ge=0, le=65535)


@app.put("/api/exits/generic/{service}")
def put_generic_exit(service: Literal["tor", "psiphon"], body: GenericExitIn, _: str = Depends(admin_required)):
    obs = db.list_outbounds()
    old = next((o for o in obs if o["type"] == service and not o["settings"].get("per_country")), None)
    try:
        if old is None:
            if not body.enabled:
                return {"ok": True}
            norm = outbounds.normalize_outbound(
                {"tag": service, "remark": service.capitalize(), "type": service, "enabled": True,
                 "settings": {"port": body.port}}, obs)
            oid = db.create_outbound(norm)
            _apply_checked(lambda: db.delete_outbound(oid))
            return {"ok": True}
        if not body.enabled and old["enabled"] and _usage(old["tag"]):
            raise HTTPException(409, "این خروجی استفاده می‌شود و نمی‌شود خاموشش کرد: " + "، ".join(_usage(old["tag"])))
        norm = outbounds.normalize_outbound({**old, "enabled": body.enabled,
                                             "settings": {**old["settings"], "port": body.port}}, obs, existing=old)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    db.update_outbound(old["id"], norm)
    _apply_checked(lambda: db.update_outbound(old["id"], old))
    return {"ok": True}


class CountryExitIn(BaseModel):
    service: Literal["tor", "psiphon"]
    country: str = Field(pattern=r"^[A-Za-z]{2}$")


@app.post("/api/exits")
def create_country_exit(body: CountryExitIn, _: str = Depends(admin_required)):
    cc = body.country.lower()
    if body.service == "psiphon" and cc.upper() not in outbounds.PSIPHON_COUNTRIES:
        raise HTTPException(400, "Psiphon این کشور را ندارد")
    key = "exit_country" if body.service == "tor" else "country"
    data = {"tag": f"{body.service}-{cc}", "remark": f"{body.service.capitalize()} {cc.upper()}", "type": body.service,
            "enabled": True, "settings": {"per_country": True, key: cc if body.service == "tor" else cc.upper()}}
    try:
        norm = outbounds.normalize_outbound(data, db.list_outbounds())
    except outbounds.OutboundError as e:
        raise _oerr(e)
    try:
        oid = db.create_outbound(norm)
    except sqlite3.IntegrityError:
        raise HTTPException(409, "این خروجی از قبل وجود دارد")
    _apply_checked(lambda: db.delete_outbound(oid))
    return _exit_item(db.get_outbound(oid))


@app.post("/api/exits/repair")
def repair_exits(_: str = Depends(admin_required)):
    res = {}
    if outbounds.installed("tor") and any(o["type"] == "tor" and o["settings"].get("per_country")
                                           for o in db.list_outbounds()):
        res["geoip"] = outbounds.ensure_geoip()
    res.update(outbounds.apply_services())
    return {"result": res}


def _warp_ob():
    return next((o for o in db.list_outbounds() if o["type"] == "warp"), None)


def _warp_state() -> dict:
    o, st = _warp_ob(), db.get_settings()
    s = o["settings"] if o else {}
    ep = s.get("endpoint", "")
    return {"registered": bool(o), "id": o["id"] if o else 0, "tag": o["tag"] if o else "",
            "account_id": s.get("account_id", ""), "plus": bool(s.get("license")),
            "enabled": bool(o and o["enabled"]), "mode": s.get("mode", "warp"),
            "endpoint": "" if ep == outbounds.WARP_DEFAULT_ENDPOINT else ep,
            "udp": st.get("warp_udp", "1") == "1", "clean": st.get("warp_clean", "1") == "1",
            "clean_endpoint": st.get("warp_clean_endpoint", ""), "binary": outbounds.installed("wow"),
            "usage": _usage(o["tag"]) if o else []}


@app.get("/api/warp")
def get_warp(_: str = Depends(admin_required)):
    return _warp_state()


class WarpRegIn(BaseModel):
    license: str = ""


@app.post("/api/warp/register")
def warp_register_api(body: WarpRegIn, _: str = Depends(admin_required)):
    o, obs = _warp_ob(), db.list_outbounds()
    try:
        reg = outbounds.warp_register(body.license.strip())
        if o:
            if o["settings"].get("endpoint") not in ("", outbounds.WARP_DEFAULT_ENDPOINT):
                reg.pop("endpoint", None)                         # keep the endpoint the user typed
            norm = outbounds.normalize_outbound({**o, "settings": {**o["settings"], **reg}}, obs, existing=o)
            db.update_outbound(o["id"], norm)
            _apply_checked(lambda: db.update_outbound(o["id"], o))
        else:
            tag = "warp" if all(x["tag"] != "warp" for x in obs) else "warp-cf"
            norm = outbounds.normalize_outbound({"tag": tag, "remark": "Cloudflare WARP", "type": "warp",
                                                 "enabled": True, "settings": reg}, obs)
            oid = db.create_outbound(norm)
            _apply_checked(lambda: db.delete_outbound(oid))
    except outbounds.OutboundError as e:
        raise _oerr(e)
    return _warp_state()


class WarpIn(BaseModel):
    enabled: bool = True
    udp: bool = True
    clean: bool = True
    mode: Literal["warp", "wow"] = "warp"
    endpoint: str = ""


@app.put("/api/warp")
def put_warp(body: WarpIn, _: str = Depends(admin_required)):
    o = _warp_ob()
    if not o:
        raise HTTPException(400, "اول حساب WARP را بساز")
    if not body.enabled and o["enabled"] and _usage(o["tag"]):
        raise HTTPException(409, "WARP استفاده می‌شود و نمی‌شود خاموشش کرد: " + "، ".join(_usage(o["tag"])))
    if body.mode == "wow" and not config.DRY_RUN and not outbounds.installed("wow"):
        raise HTTPException(400, "حالت WoW به warp-plus نیاز دارد؛ اول دکمه‌ی نصب را بزن")
    settings = {**o["settings"], "mode": body.mode, "endpoint": body.endpoint.strip() or outbounds.WARP_DEFAULT_ENDPOINT}
    try:
        norm = outbounds.normalize_outbound({**o, "enabled": body.enabled, "settings": settings},
                                            db.list_outbounds(), existing=o)
    except outbounds.OutboundError as e:
        raise _oerr(e)
    st = db.get_settings()
    old_st = {k: st.get(k, "") for k in ("warp_udp", "warp_clean")}
    db.update_outbound(o["id"], norm)
    db.set_settings({"warp_udp": "1" if body.udp else "0", "warp_clean": "1" if body.clean else "0"})

    def undo():
        db.update_outbound(o["id"], o)
        db.set_settings(old_st)
    _apply_checked(undo)
    return _warp_state()


@app.post("/api/warp/next-endpoint")
def warp_next_endpoint(_: str = Depends(admin_required)):
    old = db.get_settings().get("warp_clean_endpoint", "")
    outbounds.clean_endpoint(rotate=True)
    _apply_checked(lambda: db.set_settings({"warp_clean_endpoint": old}))
    return _warp_state()


# ------------------------------------------------------------------ settings / system
HIDDEN_SETTINGS = {"wg_server_private"}


@app.get("/api/settings")
def get_settings(_: str = Depends(admin_required)):
    return {k: v for k, v in db.get_settings().items() if k not in HIDDEN_SETTINGS}


@app.put("/api/settings")
def put_settings(body: dict, _: str = Depends(admin_required)):
    body = {k: v for k, v in body.items() if k in db.DEFAULT_SETTINGS and k not in HIDDEN_SETTINGS
            and k not in ("wg_server_public", "sub_port", "server_ips", "routing_final", "routing_toggles",
                                                  "routing_text", "warp_udp", "warp_clean", "warp_clean_endpoint")}
    for k in ("wg_port", "monitor_interval", "wg_mtu", "update_interval"):
        if k in body and not str(body[k]).isdigit():
            raise HTTPException(400, f"{k} must be a number")
    db.set_settings({k: ("1" if v is True else "0" if v is False else v) for k, v in body.items()})
    apply_in_background()
    return get_settings(_)


class SubPortIn(BaseModel):
    port: int = Field(default=0, ge=0, le=65535)


@app.get("/api/subport")
def get_subport(_: str = Depends(admin_required)):
    return subport.current()


@app.put("/api/subport")
def put_subport(body: SubPortIn, _: str = Depends(admin_required)):
    try:
        return subport.set_port(body.port)
    except subport.SubPortError as e:
        raise HTTPException(400, str(e))


class IpIn(BaseModel):
    ip: str


def _ip_call(fn, *a):
    try:
        return fn(*a)
    except serverips.IpError as e:
        raise HTTPException(400, str(e))


@app.get("/api/server-ips")
def server_ips(_: str = Depends(admin_required)):
    return serverips.listing()


@app.post("/api/server-ips")
def server_ips_add(body: IpIn, _: str = Depends(admin_required)):
    return _ip_call(serverips.add, body.ip)


@app.put("/api/server-ips/default")
def server_ips_default(body: IpIn, _: str = Depends(admin_required)):
    r = _ip_call(serverips.make_default, body.ip)
    apply_in_background()
    return r


@app.delete("/api/server-ips/{ip}")
def server_ips_delete(ip: str, _: str = Depends(admin_required)):
    return _ip_call(serverips.remove, ip)


@app.get("/api/dashboard")
def dashboard(_: str = Depends(admin_required)):
    return {**db.stats(), "system": system.system_info(), "history": db.usage_history(14)}


@app.post("/api/system/apply")
def apply(_: str = Depends(admin_required)):
    return monitor.apply_now()


@app.get("/api/backup")
def backup(_: str = Depends(admin_required)):
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".db")
    tmp.close()
    src, dst = db.conn(), sqlite3.connect(tmp.name)
    src.backup(dst)
    dst.close()
    src.close()
    return FileResponse(tmp.name, filename=f"panel-backup-{time.strftime('%Y%m%d-%H%M')}.db",
                        media_type="application/octet-stream")


# ------------------------------------------------------------------ subscription (public, token-protected)
def _sub_headers(u: dict, settings: dict) -> dict:
    title = base64.b64encode(settings.get("profile_title", "VPN").encode()).decode()
    h = {
        "Subscription-Userinfo": f"upload=0; download={u['used']}; total={u['data_limit']}; expire={u['expire_at']}",
        "Profile-Title": f"base64:{title}",
        "Profile-Update-Interval": settings.get("update_interval", "12"),
        "Cache-Control": "no-store",
    }
    if settings.get("support_url"):
        h["Support-Url"] = settings["support_url"]
    return h


@app.get("/sub/{token}")
def subscription(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    settings = db.get_settings()
    links = protocols.user_links(u, db.list_inbounds(), settings) if u["status"] == "active" else []
    body = base64.b64encode("\n".join(links).encode()).decode()
    return Response(body, media_type="text/plain; charset=utf-8", headers=_sub_headers(u, settings))


@app.get("/sub/{token}/raw")
def subscription_raw(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    settings = db.get_settings()
    links = protocols.user_links(u, db.list_inbounds(), settings) if u["status"] == "active" else []
    return PlainTextResponse("\n".join(links), headers=_sub_headers(u, settings))


@app.get("/sub/{token}/clash")
def subscription_clash(token: str):
    u = db.get_user_by_token(token)
    settings = db.get_settings()
    conf = mihomo_config.client_config(u, db.list_inbounds(), settings) if u and u["status"] == "active" else None
    if not conf:
        raise HTTPException(404, "not found")
    return PlainTextResponse(conf, headers=_sub_headers(u, settings))


@app.get("/sub/{token}/wg")
def subscription_wg(token: str):
    u = db.get_user_by_token(token)
    settings = db.get_settings()
    conf = protocols.wireguard_client_config(u, settings) if u and u["status"] == "active" else None
    if not conf:
        raise HTTPException(404, "not found")
    return PlainTextResponse(conf, headers={"Content-Disposition": f'attachment; filename="{u["username"]}.conf"'})


@app.get("/sub/{token}/info")
def subscription_info(token: str):
    u = db.get_user_by_token(token)
    if not u:
        raise HTTPException(404, "not found")
    return {"username": u["username"], "status": u["status"], "used": u["used"], "data_limit": u["data_limit"],
            "expire_at": u["expire_at"]}


# ------------------------------------------------------------------ UI
@app.get("/", include_in_schema=False)
def index():
    return FileResponse(config.STATIC_DIR / "index.html")


# UNIPANEL_ENGINE_CONTROL_V1
_ENGINE_SERVICES = {
    "xray": os.environ.get("XRAY_SERVICE", "xray"),
    "singbox": os.environ.get(
        "SINGBOX_SERVICE",
        os.environ.get("SINGBOX_SERVIC", "sing-box")
    ),
    "mihomo": os.environ.get("MIHOMO_SERVICE", "mihomo"),
}

_ENGINE_BINARIES = {
    "xray": "xray",
    "singbox": "sing-box",
    "mihomo": config.MIHOMO_BIN,
}

_ENGINE_CONFIGS = {
    "xray": os.environ.get(
        "XRAY_CONFIG", "/usr/local/etc/xray/config.json"
    ),
    "singbox": os.environ.get(
        "SINGBOX_CONFIG", "/etc/sing-box/config.json"
    ),
    "mihomo": str(config.MIHOMO_CONFIG),
}


def _engine_command(args, timeout=12):
    try:
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        return {
            "returncode": result.returncode,
            "stdout": (result.stdout or "").strip()[:3000],
            "stderr": (result.stderr or "").strip()[:3000],
        }
    except subprocess.TimeoutExpired:
        return {
            "returncode": 124,
            "stdout": "",
            "stderr": "Command timed out",
        }
    except Exception as exc:
        return {
            "returncode": 1,
            "stdout": "",
            "stderr": str(exc)[:1000],
        }


def _engine_status(name):
    service = _ENGINE_SERVICES[name]
    binary = _ENGINE_BINARIES[name]
    config_file = _ENGINE_CONFIGS[name]

    active = _engine_command(
        ["systemctl", "is-active", service]
    )
    enabled = _engine_command(
        ["systemctl", "is-enabled", service]
    )
    version = _engine_command(
        [binary, "-v"] if name == "mihomo"
        else [binary, "version"],
        timeout=8,
    )

    return {
        "name": name,
        "service": service,
        "active": active["stdout"] == "active",
        "state": active["stdout"] or "unknown",
        "enabled": enabled["stdout"] == "enabled",
        "startup": enabled["stdout"] or "unknown",
        "version": (
            (version["stdout"] or version["stderr"]).splitlines()[0]
            if (version["stdout"] or version["stderr"])
            else "unknown"
        ),
        "config_exists": os.path.isfile(config_file),
        "config_path": config_file,
    }


@app.get("/api/engines")
def engine_status_api():
    return {
        "success": True,
        "engines": {
            name: _engine_status(name)
            for name in _ENGINE_SERVICES
        },
    }


@app.post("/api/engines/{engine}/{action}")
@app.post("/api/engines/{engine}/{action}")
# UNIPANEL_ENGINE_AUTH_V1
def engine_action_api(engine: str, action: str):
    if engine not in _ENGINE_SERVICES:
        return {
            "success": False,
            "error": "Unsupported engine",
        }

    if action not in ("start", "stop", "restart", "enable", "disable"):
        return {
            "success": False,
            "error": "Unsupported action",
        }

    service = _ENGINE_SERVICES[engine]

    result = _engine_command(
        ["systemctl", action, service],
        timeout=25,
    )

    if result["returncode"] != 0:
        return {
            "success": False,
            "engine": engine,
            "action": action,
            "error": result["stderr"] or result["stdout"] or "systemctl failed",
            "status": _engine_status(engine),
        }

    return {
        "success": True,
        "engine": engine,
        "action": action,
        "message": "Operation completed",
        "status": _engine_status(engine),
    }

# END UNIPANEL_ENGINE_CONTROL_V1


# CLOUDFLARE_SSL_V1
cloudflare.register(app, admin_required)
