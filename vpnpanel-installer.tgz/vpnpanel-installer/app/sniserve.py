"""Starts uvicorn with per-domain certificates (SNI) on the panel port.

Usage: python3 sniserve.py <uvicorn args...>   (must run with the interpreter that has uvicorn installed)
If uvicorn's internals look different from what we expect, it just starts uvicorn normally.
"""
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def data_dir() -> Path:
    base = Path(os.environ.get("PANEL_HOME", HERE.parent))
    return Path(os.environ.get("PANEL_DATA", base / "data"))


def main():
    args = sys.argv[1:]
    try:
        import uvicorn.config as uc
        import snicerts
        orig = uc.create_ssl_context
        reg = data_dir() / "domains.json"

        def patched(*a, **k):
            ctx = orig(*a, **k)
            snicerts.install(ctx, reg)
            return ctx

        uc.create_ssl_context = patched
        os.environ["PANEL_SNI_ACTIVE"] = "1"
    except Exception as ex:
        print(f"sniserve: SNI disabled ({ex}); starting uvicorn normally", file=sys.stderr)
    from uvicorn.main import main as uvicorn_main
    sys.argv = ["uvicorn"] + args
    uvicorn_main()


if __name__ == "__main__":
    main()
