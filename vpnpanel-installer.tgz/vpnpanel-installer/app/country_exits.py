"""Per-country exits for users.

A user with country_exits turned on gets, for every enabled per-country Tor / Psiphon / NordVPN exit and for every
Xray inbound they are on (vless / vmess / trojan / shadowsocks), one extra client:
  * its own uuid / password, derived from the user's (so nothing extra is stored),
  * email "<user_id>-<inbound_id>-<exit tag>@panel" -> traffic is still counted for the user,
  * an Xray routing rule that sends that client's traffic to the exit.
The subscription then shows one extra config per country.
"""
import base64
import hashlib
import uuid

from . import outbounds

PROTOS = ("vless", "vmess", "trojan", "shadowsocks")

COUNTRY_NAMES = {
    "AE": "UAE", "AR": "Argentina", "AT": "Austria", "AU": "Australia", "BE": "Belgium", "BG": "Bulgaria",
    "BR": "Brazil", "CA": "Canada", "CH": "Switzerland", "CL": "Chile", "CO": "Colombia", "CZ": "Czechia",
    "DE": "Germany", "DK": "Denmark", "EE": "Estonia", "ES": "Spain", "FI": "Finland", "FR": "France",
    "GB": "United Kingdom", "GR": "Greece", "HK": "Hong Kong", "HR": "Croatia", "HU": "Hungary",
    "ID": "Indonesia", "IE": "Ireland", "IL": "Israel", "IN": "India", "IS": "Iceland", "IT": "Italy",
    "JP": "Japan", "KR": "South Korea", "LT": "Lithuania", "LU": "Luxembourg", "LV": "Latvia",
    "MD": "Moldova", "MX": "Mexico", "MY": "Malaysia", "NL": "Netherlands", "NO": "Norway",
    "NZ": "New Zealand", "PL": "Poland", "PT": "Portugal", "RO": "Romania", "RS": "Serbia", "RU": "Russia",
    "SE": "Sweden", "SG": "Singapore", "SI": "Slovenia", "SK": "Slovakia", "TH": "Thailand", "TR": "Turkey",
    "TW": "Taiwan", "UA": "Ukraine", "US": "United States", "ZA": "South Africa",
}


def exits_from(obs: list[dict]) -> list[dict]:
    """Enabled per-country exits out of a list of outbound rows -> [{tag, cc, service, label}]."""
    out = []
    for o in obs:
        cc = outbounds.ob_cc(o)
        if o.get("enabled", True) and cc:
            code = cc.upper()
            out.append({"tag": o["tag"], "cc": code, "service": outbounds.ob_service(o),
                        "label": COUNTRY_NAMES.get(code, code)})
    out.sort(key=lambda e: (e["cc"], e["service"]))
    seen: dict[str, int] = {}
    for e in out:                      # only the country name is shown; a second exit for the same country gets a number
        seen[e["cc"]] = seen.get(e["cc"], 0) + 1
        if seen[e["cc"]] > 1:
            e["label"] += f" {seen[e['cc']]}"
    return out


def applies(user: dict, ib: dict) -> bool:
    return bool(user.get("country_exits")) and ib["protocol"] in PROTOS and ib.get("engine", "xray") == "xray"


def email(user_id: int, inbound_id: int, tag: str) -> str:
    return f"{user_id}-{inbound_id}-{tag}@panel"


def variant(user: dict, tag: str) -> dict:
    """A copy of the user with credentials that are specific to one exit (stable across restarts)."""
    ns = uuid.UUID(user["uuid"])
    pw = base64.urlsafe_b64encode(hashlib.sha256(f"{user['password']}:{tag}".encode()).digest()[:18]).decode().rstrip("=")
    return {**user, "uuid": str(uuid.uuid5(ns, tag)), "password": pw}
