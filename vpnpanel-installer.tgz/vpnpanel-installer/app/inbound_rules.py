"""Inbound rules: supported protocols/transports, TLS from the panel-domain certificate, random ports.

Pure helpers (no FastAPI). main.py turns RuleError into an HTTP error.
"""
import os
import re
import secrets
import socket
import subprocess

from . import certstore as cs, config

DEFAULT_DEST = "www.cloudflare.com:443"
OLD_REALITY_HOSTS = ("www.microsoft.com",)

XRAY_PROTOCOLS = ("vless", "vmess", "trojan", "shadowsocks", "socks", "http", "tunnel")
SINGBOX_PROTOCOLS = ("hysteria2", "tuic", "hysteria", "anytls", "naive", "mixed", "shadowtls")
ENGINE = {**{p: "xray" for p in XRAY_PROTOCOLS}, **{p: "singbox" for p in SINGBOX_PROTOCOLS}}

UDP_PROTOCOLS = ("hysteria2", "tuic", "hysteria")
SB_TLS_PROTOCOLS = ("hysteria2", "tuic", "hysteria", "anytls", "naive")
PLAIN_PROTOCOLS = ("socks", "http", "mixed")
STREAM_PROTOCOLS = ("vless", "vmess", "trojan")
TRANSPORTS = ("tcp", "ws", "grpc", "httpupgrade", "xhttp", "kcp")
REALITY_NETS = ("tcp", "grpc", "xhttp")
PATH_NETS = ("ws", "httpupgrade", "xhttp")
MIN_SINGBOX = {"anytls": (1, 12, 0), "naive": (1, 13, 0)}
from .outbounds import RESERVED_PORTS  # API port, outbound test ports, local Tor/Psiphon ports
PORT_LOW, PORT_HIGH = 20000, 59999


class RuleError(Exception):
    def __init__(self, msg: str, code: int = 400):
        super().__init__(msg)
        self.code = code


# ---------------------------------------------------------------- certificate (panel domain only)
def panel_tls() -> dict | None:
    """The certificate of the panel domain: {'domain','cert','key'} or None."""
    try:
        d = cs.load()
        dom = d["panel"].get("domain", "")
        e = d["domains"].get(dom) if dom else None
        if e and os.path.exists(e["cert"]) and os.path.exists(e["key"]):
            return {"domain": dom, "cert": e["cert"], "key": e["key"]}
    except Exception:
        pass
    return None


def cert_paths(settings: dict) -> tuple[str, str]:
    """Panel-domain cert; falls back to the default pair (which the panel keeps synced to the same cert)."""
    tp = panel_tls()
    if tp:
        return tp["cert"], tp["key"]
    return settings["tls_cert"], settings["tls_key"]


def needs_tls(proto: str, security: str) -> bool:
    return security == "tls" or proto in SB_TLS_PROTOCOLS


def transports(proto: str, net: str) -> set[str]:
    if proto in UDP_PROTOCOLS:
        return {"udp"}
    if proto in ("shadowsocks", "tunnel"):
        return {"tcp", "udp"}
    if net == "kcp":
        return {"udp"}
    return {"tcp"}


# ---------------------------------------------------------------- ports
def _bind_free(port: int, kinds: set[str]) -> bool:
    for k in kinds:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM if k == "tcp" else socket.SOCK_DGRAM)
        try:
            s.bind(("0.0.0.0", port))
        except OSError:
            return False
        finally:
            s.close()
    return True


def random_port(kinds: set[str], taken: set[int], check_bind: bool = True) -> int:
    rng = secrets.SystemRandom()
    for _ in range(300):
        p = rng.randint(PORT_LOW, PORT_HIGH)
        if p in taken or p in RESERVED_PORTS:
            continue
        if check_bind and not _bind_free(p, kinds):
            continue
        return p
    raise RuleError("پورت آزاد پیدا نشد", 500)


def singbox_version() -> tuple[int, int, int] | None:
    if config.DRY_RUN or not os.path.exists(config.SINGBOX_BIN):
        return None
    try:
        out = subprocess.run([config.SINGBOX_BIN, "version"], capture_output=True, text=True, timeout=8).stdout
        m = re.search(r"(\d+)\.(\d+)\.(\d+)", out)
        return tuple(int(x) for x in m.groups()) if m else None
    except Exception:
        return None


# ---------------------------------------------------------------- VLESS Encryption (post-quantum)
ENC_MODES = ("none", "x25519", "mlkem768")
PRESERVE_KEYS = ("server_password", "inner_port", "decryption", "encryption")


def vlessenc_keys(mode: str) -> dict:
    """Runs `xray vlessenc` and returns {'decryption','encryption'} for 'x25519' or 'mlkem768'."""
    if config.DRY_RUN or not os.path.exists(config.XRAY_BIN):
        raise RuleError("Xray نصب نیست؛ برای VLESS Encryption باید Xray نسخه ۲۵.۹.۵ یا بالاتر باشد")
    try:
        out = subprocess.run([config.XRAY_BIN, "vlessenc"], capture_output=True, text=True, timeout=15)
        text = out.stdout + out.stderr
    except Exception as e:
        raise RuleError(f"اجرای xray vlessenc ممکن نشد: {e}")
    return parse_vlessenc(text, mode)


def parse_vlessenc(text: str, mode: str) -> dict:
    dec = re.findall(r'"decryption"\s*:\s*"([^"]+)"', text)
    enc = re.findall(r'"encryption"\s*:\s*"([^"]+)"', text)
    i = 0 if mode == "x25519" else 1
    if len(dec) <= i or len(enc) <= i:
        raise RuleError("این نسخه Xray دستور vlessenc را پشتیبانی نمی‌کند؛ Xray را به‌روز کن (۲۵.۹.۵ یا بالاتر)")
    return {"decryption": dec[i], "encryption": enc[i]}


# ---------------------------------------------------------------- normalize
def _int_field(s: dict, key: str, default: str | None = None) -> None:
    v = s.get(key, default)
    if v in (None, ""):
        s.pop(key, None)
        return
    if not str(v).isdigit() or int(v) <= 0:
        raise RuleError(f"{key} باید عدد مثبت باشد")
    s[key] = str(int(v))


def normalize(data: dict, settings: dict, others: list[dict], existing: dict | None = None,
              keygen=None, check_bind: bool = True, encgen=None) -> dict:
    proto = data["protocol"]
    net, sec = data.get("network", "tcp"), data.get("security", "none")
    s = dict(data.get("settings") or {})
    for k in ("cert_file", "key_file"):  # certificates always come from the panel domain
        s.pop(k, None)
    if proto not in ENGINE:
        raise RuleError("پروتکل پشتیبانی نمی‌شود")

    # the edit form does not carry generated secrets: keep them unless the thing they belong to changed
    if existing and existing["protocol"] == proto:
        es = existing["settings"]
        for k in PRESERVE_KEYS:
            if k in es and k not in s:
                if k == "server_password" and proto == "shadowsocks" and s.get("method", es.get("method")) != es.get("method"):
                    continue
                if k in ("decryption", "encryption") and (s.get("enc_mode") or "none") != (es.get("enc_mode") or "none"):
                    continue
                s[k] = es[k]

    if proto in UDP_PROTOCOLS:
        net, sec = "udp", "tls"
    elif proto in ("anytls", "naive"):
        net, sec = "tcp", "tls"
    elif proto in PLAIN_PROTOCOLS:
        net, sec = "tcp", "none"
        if proto == "socks":
            s["auth"], s["udp"] = "password", False
        elif proto == "http":
            s["allow_transparent"] = False
    elif proto == "tunnel":  # Xray dokodemo-door: forwards a port to a fixed target
        net, sec = "tcp", "none"
        host = (s.get("target_host") or "").strip()
        if not host or not str(s.get("target_port", "")).isdigit() or not 0 < int(s["target_port"]) < 65536:
            raise RuleError("برای Tunnel آدرس مقصد و پورت مقصد (۱ تا ۶۵۵۳۵) لازم است")
        s["target_host"], s["target_port"] = host, str(int(s["target_port"]))
        s["network_mode"] = s.get("network_mode") if s.get("network_mode") in ("tcp", "udp", "tcp,udp") else "tcp,udp"
    elif proto == "shadowtls":  # ShadowTLS v3 in front of an internal Shadowsocks-2022 inbound
        import base64
        net, sec = "tcp", "none"
        dest = (s.get("dest") or DEFAULT_DEST).strip()
        if ":" not in dest:
            dest += ":443"
        s["dest"] = dest
        s["sni"] = s.get("sni") or dest.rsplit(":", 1)[0]
        s["method"] = "2022-blake3-aes-128-gcm"
        if not s.get("server_password"):
            s["server_password"] = base64.b64encode(secrets.token_bytes(16)).decode()
    elif proto == "shadowsocks":
        net, sec = "tcp", "none"
        s.setdefault("method", "chacha20-ietf-poly1305")
        if s["method"].startswith("2022-") and not s.get("server_password"):
            import base64
            size = 16 if "128" in s["method"] else 32
            s["server_password"] = base64.b64encode(secrets.token_bytes(size)).decode()
    else:  # vless / vmess / trojan
        if net not in TRANSPORTS:
            raise RuleError(f"ترنسپورت «{net}» برای این پروتکل معتبر نیست")
        if net == "kcp" and sec != "none":
            raise RuleError("mKCP فقط بدون TLS/Reality کار می‌کند")
        if sec == "reality":
            if proto == "vmess":
                raise RuleError("Reality فقط برای VLESS و Trojan است")
            if net not in REALITY_NETS:
                raise RuleError("Reality فقط با tcp، grpc و xhttp کار می‌کند")
            if not s.get("private_key") or not s.get("public_key"):
                if keygen is None:
                    from . import system
                    keygen = system.reality_keypair
                s.update(keygen())
            dest = (s.get("dest") or DEFAULT_DEST).strip()
            if ":" not in dest:
                dest += ":443"
            s["dest"] = dest
            s["sni"] = s.get("sni") or dest.rsplit(":", 1)[0]
            s.setdefault("fp", "chrome")
            if not s.get("short_ids"):
                from . import system
                s["short_ids"] = [system.short_id()]
            if proto == "vless" and net == "tcp":
                s.setdefault("flow", "xtls-rprx-vision")
        if proto == "vless":
            mode = s.get("enc_mode") or "none"
            if mode not in ENC_MODES:
                raise RuleError("حالت VLESS Encryption نامعتبر است")
            if mode == "none":
                for k in ("enc_mode", "decryption", "encryption"):
                    s.pop(k, None)
            else:
                s["enc_mode"] = mode
                if not (s.get("decryption") and s.get("encryption")):
                    s.update((encgen or vlessenc_keys)(mode))
        if net in PATH_NETS:
            p = s.get("path") or "/" + secrets.token_hex(4)
            s["path"] = p if p.startswith("/") else "/" + p
        if net == "xhttp":
            s["mode"] = s.get("mode") or "auto"
        if net == "grpc":
            s.setdefault("service_name", secrets.token_hex(4))
        if net == "kcp":
            s["header"] = s.get("header") or "none"
            s["seed"] = s.get("seed") or secrets.token_urlsafe(8)

    # TLS: only the panel domain's certificate
    if needs_tls(proto, sec):
        tp = panel_tls()
        if not tp:
            raise RuleError("برای TLS اول باید در «دامنه‌ها و گواهی SSL» یک دامنه را «دامنه پنل» کنی")
        s["sni"] = (s.get("sni") or tp["domain"]).strip().lower()
        info = cs.cert_info(tp["cert"])
        if info.get("ok") and not cs.names_cover(info.get("names", []), s["sni"]):
            raise RuleError(f"SNI «{s['sni']}» توسط گواهی دامنه پنل ({tp['domain']}) پوشش داده نمی‌شود")
        if proto in ("vless", "vmess", "trojan"):
            s.setdefault("alpn", "h2,http/1.1")

    if proto == "hysteria2":
        _int_field(s, "up_mbps")
        _int_field(s, "down_mbps")
    elif proto == "hysteria":
        _int_field(s, "up_mbps", "100")
        _int_field(s, "down_mbps", "100")
    elif proto == "tuic":
        s.setdefault("congestion", "bbr")

    if proto in MIN_SINGBOX:
        v = singbox_version()
        if v and v < MIN_SINGBOX[proto]:
            need = ".".join(map(str, MIN_SINGBOX[proto]))
            raise RuleError(f"این پروتکل sing-box نسخه {need} یا بالاتر می‌خواهد (نسخه فعلی {'.'.join(map(str, v))})")

    data = {**data, "network": net, "security": sec, "settings": s}

    # port: random unless the person chose one
    kinds = transports(proto, net)
    ex_id = existing["id"] if existing else None
    taken = {o["port"] for o in others if o["id"] != ex_id}
    taken |= {int(o["settings"]["inner_port"]) for o in others if o["id"] != ex_id and o["settings"].get("inner_port")}
    if settings.get("wg_enabled") == "1":
        taken.add(int(settings.get("wg_port", 51820)))
    port = data.get("port")
    if not port:
        if existing:
            port = existing["port"]
        else:
            port = random_port(kinds, taken, check_bind)
    else:
        if port in RESERVED_PORTS:
            raise RuleError(f"پورت {port} رزرو است", 409)
        for o in others:
            if o["id"] != ex_id and o["port"] == port and transports(o["protocol"], o["network"]) & kinds:
                raise RuleError(f"پورت {port} قبلاً توسط «{o['tag']}» استفاده شده", 409)
    if settings.get("wg_enabled") == "1" and port == int(settings.get("wg_port", 51820)) and "udp" in kinds:
        raise RuleError(f"پورت {port} برای WireGuard رزرو است", 409)
    data["port"] = int(port)
    if proto == "shadowtls" and not s.get("inner_port"):
        s["inner_port"] = random_port({"tcp"}, taken | {int(port)}, check_bind)
    return data


# ---------------------------------------------------------------- migration of existing inbounds
def migrate(db) -> int:
    """Old Reality targets (microsoft) -> cloudflare; drop per-inbound certificate paths. Returns changed count."""
    n = 0
    for ib in db.list_inbounds():
        s, changed = dict(ib["settings"]), False
        for k in ("cert_file", "key_file"):
            if k in s:
                s.pop(k)
                changed = True
        if ib["security"] == "reality":
            dest = s.get("dest", "")
            if any(dest.startswith(h) for h in OLD_REALITY_HOSTS):
                s["dest"] = DEFAULT_DEST
                changed = True
            if s.get("sni") in OLD_REALITY_HOSTS:
                s["sni"] = "www.cloudflare.com"
                changed = True
        if changed:
            db.update_inbound(ib["id"], {"settings": s})
            n += 1
    return n
