"""Password hashing and JWT (HS256) using only the standard library."""
import base64
import hashlib
import hmac
import json
import os
import secrets
import time

from . import config


def hash_password(password: str) -> str:
    salt = os.urandom(16)
    h = hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt${salt.hex()}${h.hex()}"


def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, salt_hex, hash_hex = stored.split("$")
        if scheme != "scrypt":
            return False
        h = hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt_hex), n=2**14, r=8, p=1, dklen=32)
        return hmac.compare_digest(h.hex(), hash_hex)
    except Exception:
        return False


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def _b64u_dec(s: str) -> bytes:
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def get_secret() -> bytes:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not config.SECRET_FILE.exists():
        config.SECRET_FILE.write_text(secrets.token_hex(32))
        os.chmod(config.SECRET_FILE, 0o600)
    return config.SECRET_FILE.read_text().strip().encode()


def make_token(subject: str, ttl: int | None = None) -> str:
    header = _b64u(json.dumps({"alg": "HS256", "typ": "JWT"}, separators=(",", ":")).encode())
    payload = _b64u(json.dumps({"sub": subject, "exp": int(time.time()) + (ttl or config.TOKEN_TTL)},
                               separators=(",", ":")).encode())
    sig = hmac.new(get_secret(), f"{header}.{payload}".encode(), hashlib.sha256).digest()
    return f"{header}.{payload}.{_b64u(sig)}"


def read_token(token: str) -> str | None:
    try:
        header, payload, sig = token.split(".")
        expected = hmac.new(get_secret(), f"{header}.{payload}".encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(_b64u(expected), sig):
            return None
        data = json.loads(_b64u_dec(payload))
        if data.get("exp", 0) < time.time():
            return None
        return data.get("sub")
    except Exception:
        return None
