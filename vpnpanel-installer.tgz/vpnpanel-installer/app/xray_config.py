"""Builds the Xray server config from the panel database (pure function, no I/O)."""
from . import config, inbound_rules, outbounds as ob_mod
from .protocols import ss2022_user_key

API_PORT = int(config.XRAY_API.rsplit(":", 1)[1])


def client_email(user_id: int, inbound_id: int) -> str:
    return f"{user_id}-{inbound_id}@panel"


def parse_email(email: str) -> int | None:
    try:
        return int(email.split("-", 1)[0])
    except ValueError:
        return None


def _stream(ib: dict, settings: dict) -> dict:
    s = ib["settings"]
    st = {"network": ib["network"], "security": ib["security"]}
    net = ib["network"]
    if net == "ws":
        ws = {"path": s.get("path", "/")}
        if s.get("host"):
            ws["headers"] = {"Host": s["host"]}
        st["wsSettings"] = ws
    elif net == "grpc":
        st["grpcSettings"] = {"serviceName": s.get("service_name", "")}
    elif net == "httpupgrade":
        hu = {"path": s.get("path", "/")}
        if s.get("host"):
            hu["host"] = s["host"]
        st["httpupgradeSettings"] = hu
    elif net == "xhttp":
        xh = {"path": s.get("path", "/"), "mode": s.get("mode", "auto")}
        if s.get("host"):
            xh["host"] = s["host"]
        st["xhttpSettings"] = xh
    elif net == "kcp":
        kcp = {"header": {"type": s.get("header", "none")}}
        if s.get("seed"):
            kcp["seed"] = s["seed"]
        st["kcpSettings"] = kcp
    if ib["security"] == "tls":
        cert, key = inbound_rules.cert_paths(settings)  # always the panel domain's certificate
        st["tlsSettings"] = {
            "alpn": [a for a in s.get("alpn", "h2,http/1.1").split(",") if a],
            "certificates": [{"certificateFile": cert, "keyFile": key}],
        }
    elif ib["security"] == "reality":
        dest = s.get("dest", inbound_rules.DEFAULT_DEST)
        st["realitySettings"] = {
            "show": False, "dest": dest, "xver": 0,
            "serverNames": [s.get("sni") or dest.split(":")[0]],
            "privateKey": s.get("private_key", ""),
            "shortIds": s.get("short_ids") or [""],
        }
    return st


def _clients(ib: dict, users: list[dict]) -> list[dict]:
    proto, s = ib["protocol"], ib["settings"]
    out = []
    for u in users:
        email = client_email(u["id"], ib["id"])
        if proto == "vless":
            c = {"id": u["uuid"], "email": email}
            if s.get("flow") and ib["network"] == "tcp" and (ib["security"] in ("tls", "reality") or s.get("decryption")):
                c["flow"] = s["flow"]
        elif proto == "vmess":
            c = {"id": u["uuid"], "email": email, "alterId": 0}
        elif proto == "trojan":
            c = {"password": u["password"], "email": email}
        elif proto == "shadowsocks":
            method = s.get("method", "chacha20-ietf-poly1305")
            pw = ss2022_user_key(u, method) if method.startswith("2022-") else u["password"]
            c = {"password": pw, "email": email}
            if not method.startswith("2022-"):
                c["method"] = method
        else:
            continue
        out.append(c)
    return out


def build(inbounds: list[dict], users: list[dict], settings: dict, routing: dict | None = None) -> dict:
    """inbounds: enabled xray-engine inbounds; users: active users (with inbound_ids)."""
    xray_inbounds = [{
        "tag": "api", "listen": "127.0.0.1", "port": API_PORT, "protocol": "dokodemo-door",
        "settings": {"address": "127.0.0.1"},
    }]
    for ib in inbounds:
        members = [u for u in users if ib["id"] in u["inbound_ids"]]
        proto, s = ib["protocol"], ib["settings"]
        if proto == "shadowsocks":
            method = s.get("method", "chacha20-ietf-poly1305")
            st = {"clients": _clients(ib, members), "network": "tcp,udp"}
            if method.startswith("2022-"):
                st["method"] = method
                st["password"] = s.get("server_password", "")
            else:
                st["method"] = method
            settings_obj = st
        elif proto == "vless":
            settings_obj = {"clients": _clients(ib, members), "decryption": s.get("decryption") or "none"}

        elif proto == "tunnel":
            settings_obj = {"address": s.get("target_host", ""), "port": int(s.get("target_port", 0)),
                            "network": s.get("network_mode", "tcp,udp")}

        elif proto == "socks":
            settings_obj = {
                "auth": "password",
                "users": [
                    {"user": u["username"], "pass": u["password"]}
                    for u in members
                ],
                "udp": False,
                "userLevel": 0,
            }

        elif proto == "http":
            settings_obj = {
                "users": [
                    {"user": u["username"], "pass": u["password"]}
                    for u in members
                ],
                "allowTransparent": False,
                "userLevel": 0,
            }

        else:
            settings_obj = {"clients": _clients(ib, members)}
        entry = {
            "tag": ib["tag"], "listen": "0.0.0.0", "port": ib["port"], "protocol": "dokodemo-door" if proto == "tunnel" else proto,
            "settings": settings_obj,
            "sniffing": {"enabled": True, "destOverride": ["http", "tls", "quic"]},
        }
        if proto not in ("shadowsocks", "tunnel"):
            entry["streamSettings"] = _stream(ib, settings)
        xray_inbounds.append(entry)

    rt = routing or {"outbounds": [], "rules": [], "final": "direct", "inbound_engine": {}}
    out_list, test_inbounds, test_rules, user_rules = ob_mod.xray_routing(rt)
    xray_inbounds.extend(test_inbounds)

    rules = [{"type": "field", "inboundTag": ["api"], "outboundTag": "api"}] + test_rules
    if settings.get("block_bittorrent") == "1":
        rules.append({"type": "field", "protocol": ["bittorrent"], "outboundTag": "block"})
    if settings.get("block_private") == "1":
        rules.append({"type": "field", "ip": ["geoip:private"], "outboundTag": "block"})
    rules.extend(user_rules)

    dns_servers = [d for d in settings.get("dns", "1.1.1.1").split(",") if d]
    return {
        "log": {"loglevel": "warning"},
        "api": {"tag": "api", "services": ["StatsService"]},
        "stats": {},
        "policy": {
            "levels": {"0": {"statsUserUplink": True, "statsUserDownlink": True}},
            "system": {"statsInboundUplink": False, "statsInboundDownlink": False},
        },
        "dns": {"servers": dns_servers},
        "inbounds": xray_inbounds,
        "outbounds": out_list,
        "routing": {"domainStrategy": "IPIfNonMatch", "rules": rules},
    }
