"""Mihomo (Clash.Meta) engine: server config for Mieru, Sudoku, ShadowQUIC, TrustTunnel + client (Clash) config.

Mihomo reads YAML, and JSON is valid YAML, so the files are written as JSON (no extra Python dependency).
Field names follow the official Mihomo listener/proxy docs (wiki.metacubex.one).
"""
import json

from . import inbound_rules

PROTOS = inbound_rules.MIHOMO_PROTOCOLS
MIN_VERSION = {"trusttunnel": (1, 19, 21)}  # server+client support in Mihomo


def _members(ib: dict, users: list[dict]) -> list[dict]:
    return [u for u in users if ib["id"] in u["inbound_ids"]]


def _listener(ib: dict, users: list[dict], settings: dict) -> dict | None:
    s, proto = ib["settings"], ib["protocol"]
    base = {"name": ib["tag"], "type": proto, "port": ib["port"], "listen": "0.0.0.0"}
    members = _members(ib, users)
    if proto == "mieru":
        if not members:
            return None
        return {**base, "transport": s.get("transport", "TCP"),
                "users": {u["username"]: u["password"] for u in members}}
    if proto == "sudoku":
        if not members:  # a shared key with no users would mean an open door
            return None
        return {**base, "key": s["key"], "aead-method": s.get("aead_method", "chacha20-poly1305"),
                "padding-min": int(s.get("padding_min", 1)), "padding-max": int(s.get("padding_max", 15)),
                "table-type": s.get("table_type", "prefer_ascii"), "handshake-timeout": 5,
                "httpmask": {"disable": False, "mode": "legacy"}}
    if proto == "shadowquic":
        if not members:
            return None
        e = {**base, "users": [{"username": u["username"], "password": u["password"]} for u in members],
             "jls-upstream": {"addr": s.get("jls_addr", inbound_rules.DEFAULT_DEST), "sni": s.get("sni", "")},
             "alpn": ["h3"], "congestion-controller": s.get("congestion", "bbr")}
        return e
    if proto == "trusttunnel":
        if not members:
            return None
        cert, key = inbound_rules.cert_paths(settings)
        return {**base, "users": [{"username": u["username"], "password": u["password"]} for u in members],
                "certificate": cert, "private-key": key,
                "network": ["tcp", "udp"] if s.get("quic", "1") == "1" else ["tcp"],
                "congestion-controller": s.get("congestion", "bbr")}
    return None


def build(inbounds: list[dict], users: list[dict], settings: dict) -> dict:
    listeners = [l for l in (_listener(ib, users, settings) for ib in inbounds if ib["protocol"] in PROTOS) if l]
    return {
        "log-level": "warning",
        "mode": "direct",           # everything leaves from this server
        "allow-lan": False,
        "ipv6": True,
        "listeners": listeners,
        "rules": ["MATCH,DIRECT"],
    }


# ------------------------------------------------------------------ client side (Clash / Mihomo clients)
def _host(ib: dict, settings: dict) -> str:
    from .protocols import _host as h
    return h(ib, settings)


def client_proxy(ib: dict, user: dict, settings: dict) -> dict | None:
    s, proto = ib["settings"], ib["protocol"]
    host = _host(ib, settings)
    name = (ib.get("remark") or ib["tag"]) + "-" + user["username"] + user.get("_suffix", "")
    base = {"name": name, "type": proto, "server": host, "port": ib["port"]}
    if proto == "mieru":
        return {**base, "transport": s.get("transport", "TCP"), "username": user["username"],
                "password": user["password"], "multiplexing": "MULTIPLEXING_LOW"}
    if proto == "sudoku":
        return {**base, "key": s["key"], "aead-method": s.get("aead_method", "chacha20-poly1305"),
                "padding-min": int(s.get("padding_min", 1)), "padding-max": int(s.get("padding_max", 15)),
                "table-type": s.get("table_type", "prefer_ascii")}
    if proto == "shadowquic":
        return {**base, "username": user["username"], "password": user["password"],
                "sni": s.get("sni", ""), "alpn": ["h3"], "congestion-controller": s.get("congestion", "bbr")}
    if proto == "trusttunnel":
        return {**base, "username": user["username"], "password": user["password"],
                "sni": s.get("sni") or host, "quic": s.get("quic", "1") == "1",
                "congestion-controller": s.get("congestion", "bbr")}
    return None


def client_proxies(user: dict, inbounds: list[dict], settings: dict) -> list[dict]:
    allowed = set(user.get("inbound_ids", []))
    return [p for ib in inbounds
            if ib["enabled"] and ib["protocol"] in PROTOS and ib["id"] in allowed
            for p in [client_proxy(ib, user, settings)] if p]


def client_config(user: dict, inbounds: list[dict], settings: dict) -> str | None:
    """A complete Clash/Mihomo client config (JSON-as-YAML) with only this user's Mihomo-engine nodes."""
    prox = client_proxies(user, inbounds, settings)
    if not prox:
        return None
    names = [p["name"] for p in prox]
    cfg = {
        "mixed-port": 7890, "allow-lan": False, "mode": "rule", "log-level": "info", "ipv6": True,
        "proxies": prox,
        "proxy-groups": [
            {"name": "PROXY", "type": "select", "proxies": ["AUTO"] + names + ["DIRECT"]},
            {"name": "AUTO", "type": "url-test", "proxies": names, "url": "https://cp.cloudflare.com/generate_204",
             "interval": 300},
        ],
        "rules": ["GEOIP,PRIVATE,DIRECT,no-resolve", "MATCH,PROXY"],
    }
    return json.dumps(cfg, indent=2, ensure_ascii=False)
