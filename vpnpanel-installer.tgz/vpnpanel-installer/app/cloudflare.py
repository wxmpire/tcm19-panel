"""Cloudflare API integration (token, zones, DNS records). Certificates live in certstore/domains."""
import ipaddress
import json
import os
import re
import urllib.error
import urllib.request

from fastapi import Depends, HTTPException
from pydantic import BaseModel

from . import certstore as cs, db

CF_API = os.environ.get("CF_API_BASE", "https://api.cloudflare.com/client/v4")
LABEL_RE = re.compile(r"^(@|\*|[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*)$")


def _hint(token: str) -> str:
    return "••••" + token[-4:] if token else ""


def cf_request(method: str, path: str, token: str, body: dict | None = None, timeout: int = 20) -> dict:
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(CF_API + path, data=data, method=method, headers={
        "Authorization": f"Bearer {token}", "Content-Type": "application/json", "User-Agent": "vpnpanel/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            payload = json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode() or "{}")
        except Exception:
            payload = {}
        msg = "; ".join(x.get("message", "") for x in payload.get("errors", [])) or f"HTTP {e.code}"
        if e.code in (401, 403):
            msg = f"توکن نامعتبر است یا دسترسی کافی ندارد ({msg})"
        raise HTTPException(400, f"Cloudflare: {msg}")
    except (urllib.error.URLError, TimeoutError, OSError) as e:
        raise HTTPException(502, f"اتصال به Cloudflare ممکن نیست: {getattr(e, 'reason', e)}")
    if not payload.get("success", False):
        msg = "; ".join(x.get("message", "") for x in payload.get("errors", [])) or "unknown error"
        raise HTTPException(400, f"Cloudflare: {msg}")
    return payload


def list_zones(token: str) -> list[dict]:
    out, page = [], 1
    while page <= 10:
        p = cf_request("GET", f"/zones?per_page=50&page={page}", token)
        out += [{"id": z["id"], "name": z["name"], "status": z.get("status", "")} for z in p.get("result", [])]
        if page >= int((p.get("result_info") or {}).get("total_pages", 1) or 1):
            break
        page += 1
    return sorted(out, key=lambda z: z["name"])


def suggest_zone(zones: list[dict], address: str) -> str:
    address = (address or "").strip().lower()
    best = ""
    for z in zones:
        n = z["name"].lower()
        if (address == n or address.endswith("." + n)) and len(n) > len(best):
            best = n
    return best


def public_ip() -> str:
    for url in ("https://api.ipify.org", "https://ifconfig.me/ip", "https://ipv4.icanhazip.com"):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "curl/8"}), timeout=6) as r:
                ip = r.read().decode().strip()
            ipaddress.ip_address(ip)
            return ip
        except Exception:
            continue
    return ""


def _status() -> dict:
    try:
        d = json.loads(cs.CF_TOKEN_FILE.read_text())
    except Exception:
        d = {}
    tok = d.get("token", "")
    return {"configured": bool(tok), "token_hint": _hint(tok), "email": d.get("email", "")}


class TokenIn(BaseModel):
    token: str


class RecordIn(BaseModel):
    zone_id: str
    name: str
    ip: str = ""
    proxied: bool = False


def register(app, admin_required) -> None:
    from . import domains
    domains.register(app, admin_required)

    def token_or_400() -> str:
        t = cs.cf_token()
        if not t:
            raise HTTPException(400, "ابتدا توکن کلودفلر را وارد کن")
        return t

    @app.get("/api/cloudflare")
    def cf_status(_: str = Depends(admin_required)):
        return _status()

    @app.post("/api/cloudflare/token")
    def cf_set_token(body: TokenIn, _: str = Depends(admin_required)):
        tok = body.token.strip()
        if not re.fullmatch(r"[A-Za-z0-9_\-]{20,80}", tok):
            raise HTTPException(400, "فرمت توکن درست نیست")
        zones = list_zones(tok)
        if not zones:
            raise HTTPException(400, "این توکن به هیچ دامنه‌ای دسترسی ندارد (Zone:Read و Zone Resources را چک کن)")
        cs.cf_save_token(tok)
        return {**_status(), "zones": zones,
                "suggested": suggest_zone(zones, db.get_settings().get("server_address", ""))}

    @app.delete("/api/cloudflare/token")
    def cf_delete_token(_: str = Depends(admin_required)):
        for f in (cs.CF_TOKEN_FILE, cs.CF_CRED_FILE):
            try:
                f.unlink()
            except FileNotFoundError:
                pass
        return _status()

    @app.get("/api/cloudflare/zones")
    def cf_zones(_: str = Depends(admin_required)):
        zones = list_zones(token_or_400())
        return {"zones": zones, "suggested": suggest_zone(zones, db.get_settings().get("server_address", ""))}

    @app.get("/api/cloudflare/records")
    def cf_records(zone_id: str, _: str = Depends(admin_required)):
        if not re.fullmatch(r"[0-9a-f]{32}", zone_id):
            raise HTTPException(400, "zone_id نامعتبر است")
        p = cf_request("GET", f"/zones/{zone_id}/dns_records?per_page=100&type=A", token_or_400())
        return {"records": [{"id": r["id"], "name": r["name"], "ip": r["content"], "proxied": r.get("proxied", False)}
                            for r in p.get("result", [])], "my_ip": public_ip()}

    @app.post("/api/cloudflare/records")
    def cf_add_record(body: RecordIn, _: str = Depends(admin_required)):
        if not re.fullmatch(r"[0-9a-f]{32}", body.zone_id):
            raise HTTPException(400, "zone_id نامعتبر است")
        name = body.name.strip().lower()
        if not LABEL_RE.match(name):
            raise HTTPException(400, "نام ساب‌دامنه نامعتبر است (مثلاً vpn یا sub.vpn)")
        ip = body.ip.strip() or public_ip()
        try:
            ipaddress.IPv4Address(ip)
        except ValueError:
            raise HTTPException(400, "آی‌پی نامعتبر است (فقط IPv4)")
        p = cf_request("POST", f"/zones/{body.zone_id}/dns_records", token_or_400(),
                       {"type": "A", "name": name, "content": ip, "ttl": 1, "proxied": bool(body.proxied)})
        r = p["result"]
        return {"id": r["id"], "name": r["name"], "ip": r["content"], "proxied": r.get("proxied", False)}
