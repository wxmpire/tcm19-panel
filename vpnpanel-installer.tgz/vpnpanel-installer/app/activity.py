"""Activity log: who did what (panel, API keys, Telegram bot, system)."""
import re
import time

from . import db

_ready = False
_n = 0

DESC = [
    ("POST", r"^/api/users$", "ساخت کاربر"), ("POST", r"^/api/users/bulk$", "ساخت گروهی کاربر"),
    ("PUT", r"^/api/users/(\d+)$", "ویرایش کاربر"), ("DELETE", r"^/api/users/(\d+)$", "حذف کاربر"),
    ("POST", r"^/api/users/(\d+)/reset-usage$", "ریست مصرف کاربر"), ("POST", r"^/api/users/(\d+)/revoke-sub$", "لینک اشتراک جدید"),
    ("POST", r"^/api/inbounds$", "ساخت اینباند"), ("PUT", r"^/api/inbounds/(\d+)$", "ویرایش اینباند"), ("DELETE", r"^/api/inbounds/(\d+)$", "حذف اینباند"),
    ("POST", r"^/api/nordvpn/outbound$", "ساخت اوتباند NordVPN"),
    ("POST", r"^/api/outbounds", "اوتباند (ساخت/نصب/تست)"), ("PUT", r"^/api/outbounds/(\d+)$", "ویرایش اوتباند"), ("DELETE", r"^/api/outbounds/(\d+)$", "حذف اوتباند"),
    ("POST", r"^/api/tunnels$", "ساخت تونل"), ("PUT", r"^/api/tunnels/(\d+)$", "ویرایش تونل"), ("DELETE", r"^/api/tunnels/(\d+)$", "حذف تونل"),
    ("POST", r"^/api/tunnels/(\d+)/restart$", "ریستارت تونل"), ("POST", r"^/api/tunnel-tools/", "نصب برنامه‌ی تونل"),
    ("PUT", r"^/api/settings$", "تغییر تنظیمات"), ("PUT", r"^/api/routing", "تغییر مسیریابی"), ("POST", r"^/api/routing", "تغییر مسیریابی"), ("DELETE", r"^/api/routing", "حذف قانون مسیریابی"),
    ("POST", r"^/api/backups/restore", "بازیابی بکاپ"), ("POST", r"^/api/backups$", "ساخت بکاپ"), ("DELETE", r"^/api/backups/", "حذف بکاپ"),
    ("POST", r"^/api/api-keys$", "ساخت کلید API"), ("PUT", r"^/api/api-keys/", "تغییر کلید API"), ("DELETE", r"^/api/api-keys/", "حذف کلید API"),
    ("POST", r"^/api/tgbot", "تنظیم ربات تلگرام"), ("PUT", r"^/api/tgbot", "تنظیم ربات تلگرام"), ("DELETE", r"^/api/tgbot", "تنظیم ربات تلگرام"),
    ("POST", r"^/api/admins$", "ساخت ادمین"), ("PUT", r"^/api/admins/", "ویرایش ادمین"), ("DELETE", r"^/api/admins/", "حذف ادمین"),
    ("POST", r"^/api/nodes", "سرور (نود)"), ("PUT", r"^/api/nodes/", "ویرایش سرور (نود)"), ("DELETE", r"^/api/nodes/", "حذف سرور (نود)"),
    ("POST", r"^/api/engines/", "عملیات موتور"), ("POST", r"^/api/system/apply$", "اعمال دوباره‌ی کانفیگ‌ها"),
    ("POST", r"^/api/me/password$", "تغییر رمز"), ("POST", r"^/api/me/logout-all$", "خروج همه‌ی دستگاه‌ها"),
    ("POST", r"^/api/online/(\d+)/kick$", "قطع اتصال کاربر"), ("POST", r"^/api/server-ips", "IPهای سرور"),
    ("PUT", r"^/api/subport$", "تغییر پورت اشتراک"), ("PUT", r"^/api/warp", "تنظیم WARP"), ("POST", r"^/api/warp", "تنظیم WARP"),
]


def describe(method: str, path: str) -> str:
    for m, rx, text in DESC:
        if m == method and re.search(rx, path):
            mm = re.search(rx, path)
            return text + (f" #{mm.group(1)}" if mm and mm.groups() else "")
    return f"{method} {path}"


def _init():
    global _ready
    if _ready:
        return
    with db.tx() as c:
        c.execute("CREATE TABLE IF NOT EXISTS activity (id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, actor TEXT NOT NULL, "
                  "src TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL DEFAULT '', ip TEXT NOT NULL DEFAULT '')")
        c.execute("CREATE INDEX IF NOT EXISTS activity_ts ON activity(ts)")
    _ready = True


def log(actor: str, src: str, action: str, detail: str = "", ip: str = ""):
    global _n
    _init()
    with db.tx() as c:
        c.execute("INSERT INTO activity(ts,actor,src,action,detail,ip) VALUES(?,?,?,?,?,?)",
                  (int(time.time()), actor[:60], src[:30], action[:200], detail[:400], ip[:64]))
        _n += 1
        if _n % 200 == 0:  # keep the table small: 90 days / 20k rows
            c.execute("DELETE FROM activity WHERE ts < ?", (int(time.time()) - 90 * 86400,))
            c.execute("DELETE FROM activity WHERE id <= (SELECT MAX(id) FROM activity) - 20000")


def list_items(search: str = "", actor: str = "", limit: int = 50, offset: int = 0, after_id: int = 0, action: str = ""):
    _init()
    where, args = [], []
    if search:
        where.append("(action LIKE ? OR detail LIKE ? OR ip LIKE ?)")
        args += [f"%{search}%"] * 3
    if actor:
        where.append("actor=?")
        args.append(actor)
    if action:
        where.append("action=?")
        args.append(action)
    if after_id:
        where.append("id>?")
        args.append(after_id)
    cl = ("WHERE " + " AND ".join(where)) if where else ""
    with db.tx() as c:
        total = c.execute(f"SELECT COUNT(*) FROM activity {cl}", args).fetchone()[0]
        rows = c.execute(f"SELECT * FROM activity {cl} ORDER BY id DESC LIMIT ? OFFSET ?", args + [limit, offset]).fetchall()
        actors = [r[0] for r in c.execute("SELECT DISTINCT actor FROM activity ORDER BY actor")]
        return [dict(r) for r in rows], total, actors


def clear():
    _init()
    with db.tx() as c:
        c.execute("DELETE FROM activity")
