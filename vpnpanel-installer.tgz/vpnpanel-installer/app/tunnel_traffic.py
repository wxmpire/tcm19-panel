"""Per-tunnel traffic counters (bytes in / out) using iptables accounting rules.

Rules only count (-j RETURN), they never change traffic. Chains: TCM_TUN_IN (INPUT), TCM_TUN_OUT (OUTPUT) for
ports this server listens on, and TCM_TUN_FWD (FORWARD) for kernel forwarded tunnels (dnat, GRE/WireGuard expose).
Totals are accumulated in the panel database, so they survive reboots and iptables resets.
For reverse tunnels (Backhaul / Rathole / FRP) only the public port is counted, not the control port,
so the same bytes are not counted twice. Counters are per tunnel, not per user: the tunnel only sees encrypted bytes.
"""
import re
import threading

from . import config, db, tunnels
from . import tunnel_tools as tt

CHAINS = {"in": ("INPUT", "TCM_TUN_IN"), "out": ("OUTPUT", "TCM_TUN_OUT"), "fwd": ("FORWARD", "TCM_TUN_FWD")}
_lock = threading.Lock()
_ready = False


def ensure_table():
    global _ready
    if _ready:
        return
    with db.tx() as c:
        c.execute("CREATE TABLE IF NOT EXISTS tunnel_traffic (tid INTEGER NOT NULL, dir TEXT NOT NULL, total INTEGER NOT NULL DEFAULT 0, "
                  "last INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (tid, dir))")
    _ready = True


def desired(t: dict) -> list[tuple[str, list[str], str]]:
    """[(chain key, iptables match args, comment)] for one enabled tunnel."""
    if not t["enabled"]:
        return []
    k, s = t["kind"], t["settings"]
    out = []
    tid = t["id"]
    if k == "dnat":
        try:
            ip = tunnels._resolve(s["target_host"])
        except OSError:
            return []
        for proto in s["network"].split(","):
            out.append(("fwd", ["-d", ip, "-p", proto, "--dport", str(int(s["target_port"]))], f"tcm-tun-{tid}-in"))
            out.append(("fwd", ["-s", ip, "-p", proto, "--sport", str(int(s["target_port"]))], f"tcm-tun-{tid}-out"))
        return out
    if k not in tt.KINDS:
        return []
    info = tt.info(t)
    ctl = int(s.get("ctl_port") or 0)
    for port, proto in info["listen"]:
        if port == ctl or (k == "wg" and False):
            continue
        if s.get("expose_port") and port == int(s["expose_port"]):
            continue                                   # forwarded through the kernel: counted below
        out.append(("in", ["-p", proto, "--dport", str(port)], f"tcm-tun-{tid}-in"))
        out.append(("out", ["-p", proto, "--sport", str(port)], f"tcm-tun-{tid}-out"))
    if s.get("expose_port") and s.get("inner_remote"):
        for proto in s["network"].split(","):
            out.append(("fwd", ["-d", s["inner_remote"], "-p", proto, "--dport", str(int(s["target_port"]))], f"tcm-tun-{tid}-in"))
            out.append(("fwd", ["-s", s["inner_remote"], "-p", proto, "--sport", str(int(s["target_port"]))], f"tcm-tun-{tid}-out"))
    return out


def _canon(tokens: list[str], comment: str) -> str:
    """Order independent key; ignores the '-m tcp' style modules that `iptables -S` adds."""
    d: dict[str, str] = {}
    flags = {"-p": "p", "-d": "d", "-s": "s", "--dport": "dport", "--sport": "sport"}
    i = 0
    while i < len(tokens):
        if tokens[i] in flags and i + 1 < len(tokens):
            v = tokens[i + 1]
            d[flags[tokens[i]]] = v[:-3] if v.endswith("/32") else v
            i += 2
        else:
            i += 1
    return " ".join(f"{k}={d[k]}" for k in sorted(d)) + "|" + comment


def _existing(run, chain_name: str) -> dict[str, str]:
    """{canonical key: full -S line} for rules we own in a chain."""
    code, out = run(["iptables", "-S", chain_name], 10)
    res = {}
    if code != 0:
        return res
    for line in out.splitlines():
        m = re.search(r'--comment "?(tcm-tun-\d+-(?:in|out))"?', line)
        if not m or not line.startswith("-A"):
            continue
        res[_canon(line.split()[2:], m.group(1))] = line
    return res


def sync(rows: list[dict] | None = None):
    """Make the accounting rules match the tunnel table."""
    if config.DRY_RUN:
        return
    from .system import have, run
    if not have("iptables"):
        return
    rows = rows if rows is not None else db.list_tunnels()
    with _lock:
        for key, (hook, name) in CHAINS.items():
            run(["iptables", "-N", name], 10)
            if run(["iptables", "-C", hook, "-j", name], 10)[0] != 0:
                run(["iptables", "-I", hook, "1", "-j", name], 10)
        want: dict[str, dict[str, tuple[list[str], str]]] = {k: {} for k in CHAINS}
        for t in rows:
            for ck, args, cm in desired(t):
                want[ck][_canon(args, cm)] = (args, cm)
        for ck, (hook, name) in CHAINS.items():
            have_rules = _existing(run, name)
            for key, line in have_rules.items():
                if key not in want[ck]:
                    run(["iptables", "-D", name] + line.split()[2:], 10)
            for key, (args, cm) in want[ck].items():
                if key not in have_rules:
                    run(["iptables", "-A", name, *args, "-m", "comment", "--comment", cm, "-j", "RETURN"], 10)


def _read(run) -> dict[tuple[int, str], int]:
    """{(tunnel id, 'in'|'out'): raw bytes} summed over all our rules."""
    res: dict[tuple[int, str], int] = {}
    for ck, (hook, name) in CHAINS.items():
        code, out = run(["iptables", "-nvxL", name], 10)
        if code != 0:
            continue
        for line in out.splitlines():
            m = re.match(r"\s*\d+\s+(\d+)\s+.*tcm-tun-(\d+)-(in|out)", line)
            if m:
                key = (int(m.group(2)), m.group(3))
                res[key] = res.get(key, 0) + int(m.group(1))
    return res


def sample():
    """Add the bytes counted since the last call to the database totals."""
    if config.DRY_RUN:
        return
    from .system import run
    ensure_table()
    raw = _read(run)
    with _lock, db.tx() as c:
        for (tid, d), val in raw.items():
            r = c.execute("SELECT total, last FROM tunnel_traffic WHERE tid=? AND dir=?", (tid, d)).fetchone()
            if r is None:
                c.execute("INSERT INTO tunnel_traffic(tid, dir, total, last) VALUES (?,?,?,?)", (tid, d, val, val))
                continue
            delta = val - r["last"] if val >= r["last"] else val        # counters restart at 0 after a reboot / rule re-creation
            c.execute("UPDATE tunnel_traffic SET total=total+?, last=? WHERE tid=? AND dir=?", (delta, val, tid, d))


def totals() -> dict[int, dict]:
    ensure_table()
    with db.tx() as c:
        res: dict[int, dict] = {}
        for r in c.execute("SELECT tid, dir, total FROM tunnel_traffic"):
            res.setdefault(r["tid"], {"rx": 0, "tx": 0})["rx" if r["dir"] == "in" else "tx"] = r["total"]
        return res


def reset(tid: int):
    ensure_table()
    with db.tx() as c:
        c.execute("DELETE FROM tunnel_traffic WHERE tid=?", (tid,))
