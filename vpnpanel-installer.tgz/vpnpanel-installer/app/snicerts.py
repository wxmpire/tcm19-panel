"""Per-domain certificates for the panel's HTTPS port (SNI). Stdlib only (plus the openssl binary).

install(ctx, reg_file) makes `ctx` (the panel's default TLS context) switch to the certificate of the
domain the client asked for. Certificates are read from domains.json lazily and re-read whenever a
cert file or the registry changes, so new domains and renewals work without restarting the panel.
Anything that goes wrong falls back to the default certificate.
"""
import json
import os
import re
import ssl
import subprocess
import threading
from pathlib import Path

_lock = threading.Lock()
_names_cache: dict = {}
_state: dict = {"sig": None, "entries": []}


def names_cover(names, host: str) -> bool:
    host = host.lower()
    for n in names:
        n = n.lower()
        if n == host:
            return True
        if n.startswith("*.") and host.endswith(n[1:]) and len(host) > len(n) - 1 \
                and host.count(".") == n.count("."):
            return True
    return False


def cert_names(cert: str, fallback: str) -> list[str]:
    try:
        m = os.stat(cert).st_mtime
    except OSError:
        return [fallback]
    key = (cert, m)
    if key in _names_cache:
        return _names_cache[key]
    names = []
    try:
        out = subprocess.run(["openssl", "x509", "-noout", "-ext", "subjectAltName", "-in", cert],
                             capture_output=True, text=True, timeout=8).stdout
        names = [x.strip()[4:].lower() for x in out.replace("\n", ",").split(",") if x.strip().startswith("DNS:")]
    except Exception:
        pass
    names = names or [fallback]
    _names_cache[key] = names
    return names


def _signature(reg_file: Path, domains: dict):
    sig = []
    for p in [reg_file] + [Path(e.get("cert", "")) for e in domains.values()] + [Path(e.get("key", "")) for e in domains.values()]:
        try:
            sig.append((str(p), p.stat().st_mtime))
        except OSError:
            sig.append((str(p), 0))
    return tuple(sig)


def _entries(reg_file: Path) -> list:
    """[(names, ctx)] for every registered domain whose certificate loads."""
    try:
        domains = json.loads(reg_file.read_text()).get("domains", {})
    except Exception:
        return _state["entries"]
    sig = _signature(reg_file, domains)
    with _lock:
        if _state["sig"] == sig:
            return _state["entries"]
        out = []
        for dom, e in domains.items():
            try:
                c = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
                c.load_cert_chain(e["cert"], e["key"])
                out.append((cert_names(e["cert"], dom), c))
            except Exception:
                continue
        _state.update(sig=sig, entries=out)
        return out


def pick(reg_file: Path, server_name: str):
    """The context whose certificate covers server_name (exact name beats wildcard), or None."""
    host = (server_name or "").strip().lower().rstrip(".")
    if not host:
        return None
    wild = None
    for names, c in _entries(reg_file):
        if host in [n.lower() for n in names]:
            return c
        if wild is None and names_cover(names, host):
            wild = c
    return wild


def install(ctx: ssl.SSLContext, reg_file: Path) -> None:
    def cb(sslobj, server_name, _ctx):
        try:
            c = pick(reg_file, server_name)
            if c is not None:
                sslobj.context = c
        except Exception:
            pass
        return None
    ctx.sni_callback = cb
