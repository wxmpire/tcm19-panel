"""Full panel backup / restore: database (users, usage, inbounds, outbounds, routing, tunnels, settings, API keys),
data folder, panel certificates and the OpenVPN PKI, packed into one .tgz."""
import io
import json
import os
import re
import shutil
import sqlite3
import tarfile
import tempfile
import time
from pathlib import Path

from . import certstore, config, db, ovpn

BACKUP_DIR = config.DATA_DIR / "backups"
NAME_RE = re.compile(r"^tcm19-backup-[A-Za-z0-9._-]+\.tgz$")
MAX_UPLOAD = 300 * 1024 * 1024
SKIP_DATA = ("panel.db", "panel.db-wal", "panel.db-shm", "initial_admin.txt")
# archive prefix -> live directory
TREES = {"data": config.DATA_DIR, "certs": certstore.CERT_ROOT, "openvpn": ovpn.DIR}


def _db_copy(dst: Path):
    src = db.conn()
    out = sqlite3.connect(dst)
    try:
        src.backup(out)
    finally:
        out.close()
        src.close()


def contents() -> dict:
    """Row counts of every table, so the person can see what is inside the backup."""
    with db.tx() as c:
        names = [r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
        return {n: c.execute(f'SELECT COUNT(*) FROM "{n}"').fetchone()[0] for n in names}


def create(kind: str = "manual") -> Path:
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(BACKUP_DIR, 0o700)
    suffix = "" if kind == "manual" else f"-{kind}"
    path = BACKUP_DIR / f"tcm19-backup-{time.strftime('%Y%m%d-%H%M%S')}{suffix}.tgz"
    with tempfile.TemporaryDirectory() as t:
        dbf = Path(t) / "panel.db"
        _db_copy(dbf)
        manifest = {"format": 1, "created": int(time.time()), "kind": kind, "tables": contents(),
                    "has_openvpn": ovpn.DIR.exists(), "has_certs": certstore.CERT_ROOT.exists()}
        mf = Path(t) / "manifest.json"
        mf.write_text(json.dumps(manifest, ensure_ascii=False, indent=1))
        with tarfile.open(path, "w:gz") as tar:
            tar.add(mf, "manifest.json")
            tar.add(dbf, "panel.db")
            for prefix, root in TREES.items():
                if not root.exists():
                    continue
                for p in sorted(root.rglob("*")):
                    rel = p.relative_to(root)
                    if prefix == "data" and (rel.parts[0] in SKIP_DATA or rel.parts[0] == "backups"):
                        continue
                    if p.is_symlink() or not (p.is_file() or p.is_dir()):
                        continue
                    tar.add(p, f"{prefix}/{rel}", recursive=False)
    os.chmod(path, 0o600)
    return path


def list_backups() -> list[dict]:
    out = []
    if BACKUP_DIR.exists():
        for p in sorted(BACKUP_DIR.glob("tcm19-backup-*.tgz"), reverse=True):
            st = p.stat()
            out.append({"name": p.name, "size": st.st_size, "created": int(st.st_mtime),
                        "kind": "auto" if p.name.endswith("-auto.tgz") else "pre-restore" if p.name.endswith("-pre-restore.tgz") else "manual"})
    return out


def path_of(name: str) -> Path:
    if not NAME_RE.match(name):
        raise ValueError("bad name")
    p = BACKUP_DIR / name
    if not p.is_file():
        raise FileNotFoundError(name)
    return p


def delete(name: str):
    path_of(name).unlink()


def _prune(kind: str, keep: int):
    items = [b for b in list_backups() if b["kind"] == kind]
    for b in items[max(keep, 1):]:
        try:
            (BACKUP_DIR / b["name"]).unlink()
        except OSError:
            pass


def auto_tick():
    s = db.get_settings()
    if s.get("backup_auto") != "1":
        return
    last = max([b["created"] for b in list_backups() if b["kind"] == "auto"] or [0])
    if time.time() - last < 23 * 3600:
        return
    create("auto")
    _prune("auto", int(s.get("backup_keep", "7") or 7))


def _safe_members(tar: tarfile.TarFile) -> list[tarfile.TarInfo]:
    ok = []
    for m in tar.getmembers():
        n = m.name
        if n.startswith("/") or ".." in Path(n).parts:
            raise ValueError("مسیر نامعتبر در فایل بکاپ")
        if not (m.isfile() or m.isdir()):
            raise ValueError("فایل بکاپ شامل مورد غیرمجاز است")
        if not (n in ("manifest.json", "panel.db") or n.split("/")[0] in TREES):
            raise ValueError(f"محتوای ناشناخته در بکاپ: {n}")
        ok.append(m)
    return ok


def restore(archive: Path) -> dict:
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        try:
            with tarfile.open(archive, "r:gz") as tar:
                members = _safe_members(tar)
                for m in members:
                    m.mode &= 0o755 if m.isdir() else 0o700
                tar.extractall(t, members=members)
        except (tarfile.TarError, EOFError, OSError) as e:
            raise ValueError(f"فایل بکاپ معتبر نیست: {e}")
        dbf = t / "panel.db"
        if not dbf.exists():
            raise ValueError("panel.db در بکاپ نیست")
        try:
            chk = sqlite3.connect(dbf)
            chk.execute("SELECT COUNT(*) FROM settings")
            chk.execute("SELECT COUNT(*) FROM users")
            chk.execute("SELECT COUNT(*) FROM admins")
            chk.close()
        except sqlite3.Error:
            raise ValueError("دیتابیس داخل بکاپ معتبر نیست")
        safety = create("pre-restore")  # always keep a way back
        _prune("pre-restore", 3)
        src = sqlite3.connect(dbf)
        live = db.conn()
        try:
            src.backup(live)
        finally:
            src.close()
            live.close()
        db.init()
        for prefix, root in TREES.items():
            srcdir = t / prefix
            if not srcdir.exists():
                continue
            for p in sorted(srcdir.rglob("*")):
                dst = root / p.relative_to(srcdir)
                if p.is_dir():
                    dst.mkdir(parents=True, exist_ok=True)
                else:
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(p, dst)
                    os.chmod(dst, 0o600 if prefix != "certs" or "key" in p.name else 0o644)
        return {"safety_backup": safety.name, "tables": contents()}
