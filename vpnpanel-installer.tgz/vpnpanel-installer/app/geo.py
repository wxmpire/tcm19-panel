"""Offline IP -> country lookup (IPv4) from Xray's geoip.dat (or Tor's geoip file as a fallback)."""
import bisect
import ipaddress
import os
import threading
from pathlib import Path

_lock = threading.Lock()
_starts: list[int] = []
_ends: list[int] = []
_cc: list[str] = []
_loaded_from = ""
_mtime = 0.0

CANDIDATES = [os.environ.get("GEO_DIR", "/usr/local/share/xray") + "/geoip.dat", "/usr/share/xray/geoip.dat",
              "/usr/local/share/v2ray/geoip.dat", "/usr/share/v2ray/geoip.dat"]
TOR_FILE = "/usr/share/tor/geoip"


def _varint(b: bytes, i: int):
    n = shift = 0
    while True:
        c = b[i]
        i += 1
        n |= (c & 0x7F) << shift
        if not c & 0x80:
            return n, i
        shift += 7


def _fields(b: bytes):
    """Yield (field_number, wire_type, value) of one protobuf message."""
    i, n = 0, len(b)
    while i < n:
        key, i = _varint(b, i)
        f, w = key >> 3, key & 7
        if w == 0:
            v, i = _varint(b, i)
        elif w == 2:
            ln, i = _varint(b, i)
            v, i = b[i:i + ln], i + ln
        elif w == 1:
            v, i = b[i:i + 8], i + 8
        elif w == 5:
            v, i = b[i:i + 4], i + 4
        else:
            return
        yield f, w, v


def parse_dat(data: bytes) -> list[tuple[int, int, str]]:
    out = []
    for f, w, entry in _fields(data):
        if f != 1 or w != 2:
            continue
        code, cidrs = "", []
        for f2, w2, v in _fields(entry):
            if f2 == 1 and w2 == 2:
                code = v.decode("ascii", "ignore").upper()
            elif f2 == 2 and w2 == 2:
                ip, pre = b"", 0
                for f3, w3, v3 in _fields(v):
                    if f3 == 1 and w3 == 2:
                        ip = v3
                    elif f3 == 2 and w3 == 0:
                        pre = v3
                if len(ip) == 4 and 0 <= pre <= 32:
                    cidrs.append((int.from_bytes(ip, "big"), pre))
        if not code or code in ("PRIVATE",):
            continue
        for base, pre in cidrs:
            mask = (0xFFFFFFFF << (32 - pre)) & 0xFFFFFFFF if pre else 0
            lo = base & mask
            out.append((lo, lo | (~mask & 0xFFFFFFFF), code))
    return out


def _parse_tor(text: str) -> list[tuple[int, int, str]]:
    out = []
    for ln in text.splitlines():
        p = ln.split(",")
        if ln.startswith("#") or len(p) < 3 or not p[0].isdigit():
            continue
        out.append((int(p[0]), int(p[1]), p[2].strip('" ').upper()))
    return out


def _install(rows):
    global _starts, _ends, _cc
    rows = sorted(r for r in rows if len(r[2]) == 2)  # real countries only (skip lists like CLOUDFLARE, GOOGLE)
    _starts, _ends, _cc = [r[0] for r in rows], [r[1] for r in rows], [r[2] for r in rows]


def load(force: bool = False) -> str:
    """Load the database; returns the file used or '' when none exists."""
    global _loaded_from, _mtime
    with _lock:
        for path in CANDIDATES + [TOR_FILE]:
            p = Path(path)
            if not p.is_file():
                continue
            mt = p.stat().st_mtime
            if not force and _loaded_from == path and _mtime == mt:
                return path
            try:
                raw = p.read_bytes()
                rows = _parse_tor(raw.decode("utf-8", "ignore")) if path == TOR_FILE else parse_dat(raw)
            except Exception:
                continue
            if rows:
                _install(rows)
                _loaded_from, _mtime = path, mt
                return path
        return _loaded_from


def country(ip: str) -> str:
    """Two-letter code, or '' (private / unknown / IPv6 / no database)."""
    try:
        a = ipaddress.ip_address(ip)
    except ValueError:
        return ""
    if a.version != 4 or a.is_private or a.is_loopback:
        return ""
    if not _starts and not load():
        return ""
    n = int(a)
    i = bisect.bisect_right(_starts, n) - 1
    for k in range(i, max(i - 6, -1), -1):  # a wide range may start earlier than the closest start
        if n <= _ends[k]:
            return _cc[k]
    return ""


def set_rows_for_test(rows):
    _install(list(rows))
