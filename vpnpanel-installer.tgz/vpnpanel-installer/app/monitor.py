"""Background job: collect traffic, enforce quota / expiry / periodic resets, re-apply configs."""
import asyncio
import logging
import threading

from . import db, system

log = logging.getLogger("panel.monitor")
_apply_lock = threading.Lock()
PERIODS = {"daily": 86400, "weekly": 7 * 86400, "monthly": 30 * 86400}


def apply_now() -> dict:
    with _apply_lock:
        return system.apply_all()


def desired_status(u: dict, now: int) -> str:
    if u["expire_at"] and u["expire_at"] <= now:
        return "expired"
    if u["data_limit"] and u["used"] >= u["data_limit"]:
        return "limited"
    return "active"


def reset_due(u: dict, now: int) -> bool:
    period = PERIODS.get(u["reset_strategy"])
    if not period:
        return False
    return now - (u["last_reset"] or u["created_at"]) >= period


def tick() -> bool:
    """One monitoring cycle. Returns True if the active user set changed (configs re-applied)."""
    users = db.all_users()
    deltas: dict[int, int] = {}
    for src in (system.read_xray_traffic(), system.read_wg_traffic(users)):
        for uid, b in src.items():
            deltas[uid] = deltas.get(uid, 0) + b
    db.add_usage(deltas)

    now = db.now()
    changed = False
    for u in db.all_users():
        if u["status"] == "disabled":
            continue
        fields = {}
        if reset_due(u, now):
            fields.update(used=0, last_reset=now)
            u["used"] = 0
        want = desired_status(u, now)
        if want != u["status"]:
            fields["status"] = want
            changed = True
            log.info("user %s: %s -> %s", u["username"], u["status"], want)
        if fields:
            db.update_user(u["id"], fields)
    if changed:
        apply_now()
    return changed


async def run_forever():
    while True:
        try:
            interval = max(5, int(db.get_settings().get("monitor_interval", "30")))
        except Exception:
            interval = 30
        await asyncio.sleep(interval)
        try:
            await asyncio.to_thread(tick)
        except Exception:
            log.exception("monitor tick failed")
