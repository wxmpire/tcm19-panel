"""SQLite layer (stdlib sqlite3). Every call opens its own short-lived connection."""
import json
import secrets
import sqlite3
import time
import uuid as uuidlib
from contextlib import contextmanager

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    uuid TEXT NOT NULL,
    password TEXT NOT NULL,
    sub_token TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',      -- active | disabled | limited | expired
    data_limit INTEGER NOT NULL DEFAULT 0,      -- bytes, 0 = unlimited
    used INTEGER NOT NULL DEFAULT 0,            -- bytes
    expire_at INTEGER NOT NULL DEFAULT 0,       -- unix ts, 0 = never
    reset_strategy TEXT NOT NULL DEFAULT 'none',-- none | daily | weekly | monthly
    last_reset INTEGER NOT NULL DEFAULT 0,
    note TEXT NOT NULL DEFAULT '',
    wg_enabled INTEGER NOT NULL DEFAULT 0,
    wg_private TEXT NOT NULL DEFAULT '',
    wg_public TEXT NOT NULL DEFAULT '',
    wg_psk TEXT NOT NULL DEFAULT '',
    wg_ip TEXT NOT NULL DEFAULT '',
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS inbounds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tag TEXT UNIQUE NOT NULL,
    remark TEXT NOT NULL DEFAULT '',
    protocol TEXT NOT NULL,        -- vless | vmess | trojan | shadowsocks | socks | http | hysteria2 | hysteria | tuic | anytls | naive | mixed
    port INTEGER NOT NULL,
    network TEXT NOT NULL DEFAULT 'tcp',   -- tcp | ws | grpc | httpupgrade | xhttp | kcp  (udp-based protocols ignore this)
    security TEXT NOT NULL DEFAULT 'none', -- none | tls | reality
    settings TEXT NOT NULL DEFAULT '{}',
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_inbounds (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    inbound_id INTEGER NOT NULL REFERENCES inbounds(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, inbound_id)
);
CREATE TABLE IF NOT EXISTS usage_daily (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL,
    bytes INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, day)
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
"""

DEFAULT_SETTINGS = {
    "server_address": "",
    "sub_base_url": "",
    "sub_port": "",
    "server_ips": "[]",
    "profile_title": "VPN",
    "support_url": "",
    "update_interval": "12",
    "monitor_interval": "30",
    "block_bittorrent": "1",
    "block_private": "1",
    "dns": "1.1.1.1,8.8.8.8",
    "tls_cert": "/etc/ssl/vpnpanel/fullchain.pem",
    "tls_key": "/etc/ssl/vpnpanel/privkey.pem",
    "wg_enabled": "0",
    "wg_port": "51820",
    "wg_subnet": "10.66.66.0/24",
    "wg_mtu": "1280",
    "wg_server_private": "",
    "wg_server_public": "",
}

PROTOCOL_ENGINE = {
    "vless": "xray",
    "vmess": "xray",
    "trojan": "xray",
    "shadowsocks": "xray",
    "socks": "xray",
    "http": "xray",
    "hysteria2": "singbox",
    "tuic": "singbox",
    "hysteria": "singbox",
    "anytls": "singbox",
    "naive": "singbox",
    "mixed": "singbox",
    "shadowtls": "singbox",
    "tunnel": "xray",
}


def now() -> int:
    return int(time.time())


def conn() -> sqlite3.Connection:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


@contextmanager
def tx():
    c = conn()
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def init():
    with tx() as c:
        c.executescript(SCHEMA)
        for k, v in DEFAULT_SETTINGS.items():
            c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (k, v))


# ---------- settings ----------
def get_settings() -> dict:
    with tx() as c:
        return {r["key"]: r["value"] for r in c.execute("SELECT key, value FROM settings")}


def set_settings(values: dict):
    with tx() as c:
        for k, v in values.items():
            if k in DEFAULT_SETTINGS:
                c.execute("INSERT INTO settings(key, value) VALUES (?, ?) "
                          "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))


# ---------- admins ----------
def admin_count() -> int:
    with tx() as c:
        return c.execute("SELECT COUNT(*) FROM admins").fetchone()[0]


def get_admin(username: str):
    with tx() as c:
        r = c.execute("SELECT * FROM admins WHERE username=?", (username,)).fetchone()
        return dict(r) if r else None


def create_admin(username: str, password_hash: str):
    with tx() as c:
        c.execute("INSERT INTO admins(username, password_hash, created_at) VALUES (?,?,?)",
                  (username, password_hash, now()))


def set_admin_password(username: str, password_hash: str):
    with tx() as c:
        c.execute("UPDATE admins SET password_hash=? WHERE username=?", (password_hash, username))


# ---------- inbounds ----------
def _inbound(r) -> dict:
    d = dict(r)
    d["settings"] = json.loads(d["settings"] or "{}")
    d["enabled"] = bool(d["enabled"])
    d["engine"] = PROTOCOL_ENGINE.get(d["protocol"], "xray")
    return d


def list_inbounds() -> list[dict]:
    with tx() as c:
        return [_inbound(r) for r in c.execute("SELECT * FROM inbounds ORDER BY id")]


def get_inbound(inbound_id: int):
    with tx() as c:
        r = c.execute("SELECT * FROM inbounds WHERE id=?", (inbound_id,)).fetchone()
        return _inbound(r) if r else None


def create_inbound(data: dict) -> int:
    with tx() as c:
        cur = c.execute(
            "INSERT INTO inbounds(tag, remark, protocol, port, network, security, settings, enabled, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (data["tag"], data.get("remark", ""), data["protocol"], data["port"], data.get("network", "tcp"),
             data.get("security", "none"), json.dumps(data.get("settings", {})), int(data.get("enabled", True)), now()))
        return cur.lastrowid


def update_inbound(inbound_id: int, data: dict):
    cur = get_inbound(inbound_id)
    if not cur:
        return
    cur.update({k: v for k, v in data.items() if v is not None})
    with tx() as c:
        c.execute(
            "UPDATE inbounds SET tag=?, remark=?, protocol=?, port=?, network=?, security=?, settings=?, enabled=? "
            "WHERE id=?",
            (cur["tag"], cur["remark"], cur["protocol"], cur["port"], cur["network"], cur["security"],
             json.dumps(cur["settings"]), int(cur["enabled"]), inbound_id))


def delete_inbound(inbound_id: int):
    with tx() as c:
        c.execute("DELETE FROM inbounds WHERE id=?", (inbound_id,))


# ---------- users ----------
def _user(r, c) -> dict:
    d = dict(r)
    d["wg_enabled"] = bool(d["wg_enabled"])
    d["inbound_ids"] = [x[0] for x in c.execute(
        "SELECT inbound_id FROM user_inbounds WHERE user_id=? ORDER BY inbound_id", (d["id"],))]
    return d


def list_users(search: str = "", status: str = "", limit: int = 50, offset: int = 0):
    where, args = [], []
    if search:
        where.append("(username LIKE ? OR note LIKE ?)")
        args += [f"%{search}%", f"%{search}%"]
    if status:
        where.append("status=?")
        args.append(status)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    with tx() as c:
        total = c.execute(f"SELECT COUNT(*) FROM users {clause}", args).fetchone()[0]
        rows = c.execute(f"SELECT * FROM users {clause} ORDER BY id DESC LIMIT ? OFFSET ?",
                         args + [limit, offset]).fetchall()
        return [_user(r, c) for r in rows], total


def all_users() -> list[dict]:
    with tx() as c:
        return [_user(r, c) for r in c.execute("SELECT * FROM users ORDER BY id")]


def get_user(user_id: int):
    with tx() as c:
        r = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return _user(r, c) if r else None


def get_user_by_token(token: str):
    with tx() as c:
        r = c.execute("SELECT * FROM users WHERE sub_token=?", (token,)).fetchone()
        return _user(r, c) if r else None


def create_user(data: dict) -> int:
    with tx() as c:
        cur = c.execute(
            "INSERT INTO users(username, uuid, password, sub_token, status, data_limit, expire_at, reset_strategy, "
            "note, wg_enabled, wg_private, wg_public, wg_psk, wg_ip, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (data["username"], str(uuidlib.uuid4()), secrets.token_urlsafe(16), secrets.token_urlsafe(18),
             "active", data.get("data_limit", 0), data.get("expire_at", 0), data.get("reset_strategy", "none"),
             data.get("note", ""), int(data.get("wg_enabled", False)), data.get("wg_private", ""),
             data.get("wg_public", ""), data.get("wg_psk", ""), data.get("wg_ip", ""), now()))
        uid = cur.lastrowid
        for ib in data.get("inbound_ids", []):
            c.execute("INSERT OR IGNORE INTO user_inbounds(user_id, inbound_id) VALUES (?,?)", (uid, ib))
        return uid


USER_FIELDS = {"status", "data_limit", "expire_at", "reset_strategy", "note", "wg_enabled",
               "wg_private", "wg_public", "wg_psk", "wg_ip", "used", "sub_token", "last_reset"}


def update_user(user_id: int, fields: dict, inbound_ids: list[int] | None = None):
    sets, args = [], []
    for k, v in fields.items():
        if k in USER_FIELDS:
            sets.append(f"{k}=?")
            args.append(int(v) if isinstance(v, bool) else v)
    with tx() as c:
        if sets:
            c.execute(f"UPDATE users SET {', '.join(sets)} WHERE id=?", args + [user_id])
        if inbound_ids is not None:
            c.execute("DELETE FROM user_inbounds WHERE user_id=?", (user_id,))
            for ib in inbound_ids:
                c.execute("INSERT OR IGNORE INTO user_inbounds(user_id, inbound_id) VALUES (?,?)", (user_id, ib))


def delete_user(user_id: int):
    with tx() as c:
        c.execute("DELETE FROM users WHERE id=?", (user_id,))


def add_usage(deltas: dict[int, int]):
    """deltas: user_id -> bytes to add."""
    if not deltas:
        return
    day = time.strftime("%Y-%m-%d")
    with tx() as c:
        for uid, b in deltas.items():
            if b <= 0:
                continue
            c.execute("UPDATE users SET used = used + ? WHERE id=?", (b, uid))
            c.execute("INSERT INTO usage_daily(user_id, day, bytes) VALUES (?,?,?) "
                      "ON CONFLICT(user_id, day) DO UPDATE SET bytes = bytes + excluded.bytes", (uid, day, b))


def usage_history(days: int = 14) -> list[dict]:
    with tx() as c:
        rows = c.execute(
            "SELECT day, SUM(bytes) AS bytes FROM usage_daily GROUP BY day ORDER BY day DESC LIMIT ?", (days,))
        return list(reversed([dict(r) for r in rows]))


def stats() -> dict:
    with tx() as c:
        by_status = {r["status"]: r["n"] for r in c.execute("SELECT status, COUNT(*) AS n FROM users GROUP BY status")}
        total_used = c.execute("SELECT COALESCE(SUM(used),0) FROM users").fetchone()[0]
        return {"users_total": sum(by_status.values()), "by_status": by_status, "total_used": total_used,
                "inbounds_total": c.execute("SELECT COUNT(*) FROM inbounds").fetchone()[0]}
