"""SQLite layer (stdlib sqlite3). Every call opens its own short-lived connection."""
import json
import secrets
import sqlite3
import time
import uuid as uuidlib
from contextlib import contextmanager

from . import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS admins (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS nodes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    port INTEGER NOT NULL DEFAULT 8443,
    secret TEXT NOT NULL,
    fp TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    inbound_ids TEXT NOT NULL DEFAULT '[]',
    last_ok INTEGER NOT NULL DEFAULT 0,
    last_error TEXT NOT NULL DEFAULT '',
    xray TEXT NOT NULL DEFAULT '',
    wg INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    uuid TEXT NOT NULL,
    password TEXT NOT NULL,
    sub_token TEXT UNIQUE NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',      -- active | disabled | limited | expired
    data_limit INTEGER NOT NULL DEFAULT 0,      -- bytes, 0 = unlimited
    used INTEGER NOT NULL DEFAULT 0,            -- bytes
    expire_at INTEGER NOT NULL DEFAULT 0,       -- unix ts, 0 = never
    reset_strategy TEXT NOT NULL DEFAULT 'none',-- none | daily | weekly | monthly
    last_reset INTEGER NOT NULL DEFAULT 0,
    note TEXT NOT NULL DEFAULT '',
    wg_enabled INTEGER NOT NULL DEFAULT 0,
    wg_private TEXT NOT NULL DEFAULT '',
    wg_public TEXT NOT NULL DEFAULT '',
    wg_psk TEXT NOT NULL DEFAULT '',
    wg_ip TEXT NOT NULL DEFAULT '',
    country_exits INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS inbounds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tag TEXT UNIQUE NOT NULL,
    remark TEXT NOT NULL DEFAULT '',
    protocol TEXT NOT NULL,        -- vless | vmess | trojan | shadowsocks | socks | http | hysteria2 | hysteria | tuic | anytls | naive | mixed
    port INTEGER NOT NULL,
    network TEXT NOT NULL DEFAULT 'tcp',   -- tcp | ws | grpc | httpupgrade | xhttp | kcp  (udp-based protocols ignore this)
    security TEXT NOT NULL DEFAULT 'none', -- none | tls | reality
    settings TEXT NOT NULL DEFAULT '{}',
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS user_inbounds (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    inbound_id INTEGER NOT NULL REFERENCES inbounds(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, inbound_id)
);
CREATE TABLE IF NOT EXISTS usage_daily (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    day TEXT NOT NULL,
    bytes INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, day)
);
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS outbounds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tag TEXT UNIQUE NOT NULL,
    remark TEXT NOT NULL DEFAULT '',
    type TEXT NOT NULL,            -- warp | tor | psiphon | socks | http | shadowsocks | wireguard   (direct / block are built in)
    settings TEXT NOT NULL DEFAULT '{}',
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tunnels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL DEFAULT '',
    kind TEXT NOT NULL,            -- reverse | ssh | dnat   (port-forward / via-outbound tunnels live in inbounds)
    port INTEGER NOT NULL DEFAULT 0,
    settings TEXT NOT NULL DEFAULT '{}',
    enabled INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS routing_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    position INTEGER NOT NULL DEFAULT 0,
    remark TEXT NOT NULL DEFAULT '',
    enabled INTEGER NOT NULL DEFAULT 1,
    match TEXT NOT NULL DEFAULT '{}',
    outbound_tag TEXT NOT NULL,
    created_at INTEGER NOT NULL
);
"""

DEFAULT_SETTINGS = {
    "server_address": "",
    "sub_base_url": "",
    "sub_port": "",
    "server_ips": "[]",
    "profile_title": "VPN",
    "support_url": "",
    "sub_notice": "",
    "sub_accent": "",
    "sub_logo": "",
    "update_interval": "12",
    "monitor_interval": "30",
    "block_bittorrent": "1",
    "block_private": "1",
    "dns": "1.1.1.1,8.8.8.8",
    "tls_cert": "/etc/ssl/vpnpanel/fullchain.pem",
    "tls_key": "/etc/ssl/vpnpanel/privkey.pem",
    "wg_enabled": "0",
    "wg_port": "51820",
    "wg_subnet": "10.66.66.0/24",
    "wg_mtu": "1280",
    "wg_server_private": "",
    "wg_server_public": "",
    "tg_token": "",
    "tg_enabled": "0",
    "tg_username": "",
    "tg_admins": "[]",
    "tg_alerts": "1",
    "tg_backup": "0",
    "tg_backup_hours": "24",
    "tg_apikey": "",
    "tg_notified": "{}",
    "tg_pair": "",
    "tg_last_backup": "0",
    "tg_last_act": "0",
    "tg_last_geo": "0",
    "tg_last_health": "0",
    "ip_limit_action": "notify",
    "geo_action": "off",
    "health_alerts": "1",
    "health_cpu": "90",
    "health_mem": "90",
    "health_disk": "90",
    "backup_auto": "0",
    "backup_keep": "7",
    "ovpn_enabled": "0",
    "ovpn_port": "1194",
    "ovpn_proto": "udp",
    "ovpn_subnet": "10.77.0.0/24",
    "routing_final": "direct",
    "routing_toggles": "{}",
    "routing_text": "",
    "warp_udp": "1",
    "warp_clean": "1",
    "warp_clean_endpoint": "",
}

PROTOCOL_ENGINE = {
    "vless": "xray",
    "vmess": "xray",
    "trojan": "xray",
    "shadowsocks": "xray",
    "socks": "xray",
    "http": "xray",
    "hysteria2": "singbox",
    "tuic": "singbox",
    "hysteria": "singbox",
    "anytls": "singbox",
    "naive": "singbox",
    "mixed": "singbox",
    "shadowtls": "singbox",
    "tunnel": "xray",
    "mieru": "mihomo",
    "sudoku": "mihomo",
    "shadowquic": "mihomo",
    "trusttunnel": "mihomo",
}


def now() -> int:
    return int(time.time())


def conn() -> sqlite3.Connection:
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(config.DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


@contextmanager
def tx():
    c = conn()
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def init():
    with tx() as c:
        c.executescript(SCHEMA)
        cols = {r[1] for r in c.execute("PRAGMA table_info(users)")}
        if "country_exits" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN country_exits INTEGER NOT NULL DEFAULT 0")
        for col, typ in (("ovpn_enabled", "INTEGER NOT NULL DEFAULT 0"), ("ovpn_cert", "TEXT NOT NULL DEFAULT ''"),
                         ("ovpn_key", "TEXT NOT NULL DEFAULT ''")):
            if col not in cols:
                c.execute(f"ALTER TABLE users ADD COLUMN {col} {typ}")
        for col, typ in (("last_seen", "INTEGER NOT NULL DEFAULT 0"), ("max_ips", "INTEGER NOT NULL DEFAULT 0"),
                         ("speed_mbps", "INTEGER NOT NULL DEFAULT 0"), ("ovpn_ip", "TEXT NOT NULL DEFAULT ''")):
            if col not in cols:
                c.execute(f"ALTER TABLE users ADD COLUMN {col} {typ}")
        ncols = {r[1] for r in c.execute("PRAGMA table_info(nodes)")}
        if ncols and "wg" not in ncols:
            c.execute("ALTER TABLE nodes ADD COLUMN wg INTEGER NOT NULL DEFAULT 0")
        if "blocks" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN blocks TEXT NOT NULL DEFAULT ''")
        if "owner" not in cols:
            c.execute("ALTER TABLE users ADD COLUMN owner TEXT NOT NULL DEFAULT ''")
        acols = {r[1] for r in c.execute("PRAGMA table_info(admins)")}
        for col, typ in (("role", "TEXT NOT NULL DEFAULT 'owner'"), ("max_users", "INTEGER NOT NULL DEFAULT 0"),
                         ("max_gb", "INTEGER NOT NULL DEFAULT 0"), ("enabled", "INTEGER NOT NULL DEFAULT 1"),
                         ("inbound_ids", "TEXT NOT NULL DEFAULT '[]'"), ("note", "TEXT NOT NULL DEFAULT ''"),
                         ("blocks", "TEXT NOT NULL DEFAULT ''")):
            if col not in acols:
                c.execute(f"ALTER TABLE admins ADD COLUMN {col} {typ}")
        for col in ("up_bytes", "down_bytes"):  # upload / download split (counted from the day this was added)
            if col not in cols:
                c.execute(f"ALTER TABLE users ADD COLUMN {col} INTEGER NOT NULL DEFAULT 0")
        for k, v in DEFAULT_SETTINGS.items():
            c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES (?, ?)", (k, v))


# ---------- settings ----------
def get_settings() -> dict:
    with tx() as c:
        return {r["key"]: r["value"] for r in c.execute("SELECT key, value FROM settings")}


def set_settings(values: dict):
    with tx() as c:
        for k, v in values.items():
            if k in DEFAULT_SETTINGS:
                c.execute("INSERT INTO settings(key, value) VALUES (?, ?) "
                          "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))


# ---------- admins ----------
def admin_count() -> int:
    with tx() as c:
        return c.execute("SELECT COUNT(*) FROM admins").fetchone()[0]


def first_admin() -> str:
    with tx() as c:
        r = c.execute("SELECT username FROM admins ORDER BY (role!='owner'), id LIMIT 1").fetchone()
        return r["username"] if r else ""


def get_admin(username: str):
    with tx() as c:
        r = c.execute("SELECT * FROM admins WHERE username=?", (username,)).fetchone()
        return _admin(r) if r else None


def create_admin(username: str, password_hash: str):
    with tx() as c:
        c.execute("INSERT INTO admins(username, password_hash, created_at) VALUES (?,?,?)",
                  (username, password_hash, now()))


def _admin(r) -> dict:
    d = dict(r)
    d["enabled"] = bool(d["enabled"])
    try:
        d["inbound_ids"] = [int(x) for x in json.loads(d.get("inbound_ids") or "[]")]
    except (ValueError, TypeError):
        d["inbound_ids"] = []
    return d


def list_resellers() -> list[dict]:
    with tx() as c:
        out = []
        for r in c.execute("SELECT * FROM admins WHERE role='reseller' ORDER BY id"):
            d = _admin(r)
            d.pop("password_hash", None)
            d.update(owner_stats(d["username"], c))
            out.append(d)
        return out


def owner_stats(username: str, c=None) -> dict:
    q = ("SELECT COUNT(*), COALESCE(SUM(data_limit),0), COALESCE(SUM(used),0), "
         "COALESCE(SUM(CASE WHEN status='active' THEN 1 ELSE 0 END),0) FROM users WHERE owner=?")
    if c is None:
        with tx() as c2:
            r = c2.execute(q, (username,)).fetchone()
    else:
        r = c.execute(q, (username,)).fetchone()
    return {"users": r[0], "gb_allocated": r[1], "used": r[2], "active": r[3]}


def create_reseller(username: str, password_hash: str, max_users: int, max_gb: int, inbound_ids: list[int], note: str = "",
                    blocks: str = ""):
    with tx() as c:
        c.execute("INSERT INTO admins(username, password_hash, created_at, role, max_users, max_gb, enabled, inbound_ids, note, blocks) "
                  "VALUES (?,?,?,?,?,?,1,?,?,?)",
                  (username, password_hash, now(), "reseller", max_users, max_gb, json.dumps(inbound_ids), note, blocks))


def update_reseller(username: str, fields: dict):
    sets, args = [], []
    for k in ("max_users", "max_gb", "enabled", "note", "blocks"):
        if k in fields:
            sets.append(f"{k}=?")
            args.append(int(fields[k]) if isinstance(fields[k], bool) else fields[k])
    if "inbound_ids" in fields:
        sets.append("inbound_ids=?")
        args.append(json.dumps(fields["inbound_ids"]))
    if "password_hash" in fields:
        sets.append("password_hash=?")
        args.append(fields["password_hash"])
    if sets:
        with tx() as c:
            c.execute(f"UPDATE admins SET {', '.join(sets)} WHERE username=? AND role='reseller'", args + [username])


def delete_reseller(username: str) -> bool:
    with tx() as c:
        r = c.execute("DELETE FROM admins WHERE username=? AND role='reseller'", (username,))
        if r.rowcount:
            c.execute("UPDATE users SET owner='' WHERE owner=?", (username,))
        return bool(r.rowcount)


def set_admin_password(username: str, password_hash: str):
    with tx() as c:
        c.execute("UPDATE admins SET password_hash=? WHERE username=?", (password_hash, username))


# ---------- inbounds ----------
def _inbound(r) -> dict:
    d = dict(r)
    d["settings"] = json.loads(d["settings"] or "{}")
    d["enabled"] = bool(d["enabled"])
    d["engine"] = PROTOCOL_ENGINE.get(d["protocol"], "xray")
    return d


def list_inbounds() -> list[dict]:
    with tx() as c:
        return [_inbound(r) for r in c.execute("SELECT * FROM inbounds ORDER BY id")]


def get_inbound(inbound_id: int):
    with tx() as c:
        r = c.execute("SELECT * FROM inbounds WHERE id=?", (inbound_id,)).fetchone()
        return _inbound(r) if r else None


def create_inbound(data: dict) -> int:
    with tx() as c:
        cur = c.execute(
            "INSERT INTO inbounds(tag, remark, protocol, port, network, security, settings, enabled, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (data["tag"], data.get("remark", ""), data["protocol"], data["port"], data.get("network", "tcp"),
             data.get("security", "none"), json.dumps(data.get("settings", {})), int(data.get("enabled", True)), now()))
        return cur.lastrowid


def update_inbound(inbound_id: int, data: dict):
    cur = get_inbound(inbound_id)
    if not cur:
        return
    cur.update({k: v for k, v in data.items() if v is not None})
    with tx() as c:
        c.execute(
            "UPDATE inbounds SET tag=?, remark=?, protocol=?, port=?, network=?, security=?, settings=?, enabled=? "
            "WHERE id=?",
            (cur["tag"], cur["remark"], cur["protocol"], cur["port"], cur["network"], cur["security"],
             json.dumps(cur["settings"]), int(cur["enabled"]), inbound_id))


def delete_inbound(inbound_id: int):
    with tx() as c:
        c.execute("DELETE FROM inbounds WHERE id=?", (inbound_id,))


# ---------- users ----------
BLOCK_KEYS = ("torrent", "ads", "adult", "quic")


def _user(r, c) -> dict:
    d = dict(r)
    d["wg_enabled"] = bool(d["wg_enabled"])
    d["ovpn_enabled"] = bool(d.get("ovpn_enabled"))
    d["country_exits"] = bool(d.get("country_exits"))
    mine = {x for x in (d.get("blocks") or "").split(",") if x in BLOCK_KEYS}
    if d.get("owner"):
        r = c.execute("SELECT blocks FROM admins WHERE username=?", (d["owner"],)).fetchone()
        if r and r[0]:
            mine |= {x for x in r[0].split(",") if x in BLOCK_KEYS}
    d["blocks_own"] = sorted(x for x in (d.get("blocks") or "").split(",") if x in BLOCK_KEYS)
    d["blocks_eff"] = sorted(mine)
    d["inbound_ids"] = [x[0] for x in c.execute(
        "SELECT inbound_id FROM user_inbounds WHERE user_id=? ORDER BY inbound_id", (d["id"],))]
    return d


def list_users(search: str = "", status: str = "", limit: int = 50, offset: int = 0, owner: str | None = None):
    where, args = [], []
    if owner is not None:
        where.append("owner=?")
        args.append(owner)
    if search:
        where.append("(username LIKE ? OR note LIKE ?)")
        args += [f"%{search}%", f"%{search}%"]
    if status:
        where.append("status=?")
        args.append(status)
    clause = ("WHERE " + " AND ".join(where)) if where else ""
    with tx() as c:
        total = c.execute(f"SELECT COUNT(*) FROM users {clause}", args).fetchone()[0]
        rows = c.execute(f"SELECT * FROM users {clause} ORDER BY id DESC LIMIT ? OFFSET ?",
                         args + [limit, offset]).fetchall()
        return [_user(r, c) for r in rows], total


def all_users() -> list[dict]:
    with tx() as c:
        return [_user(r, c) for r in c.execute("SELECT * FROM users ORDER BY id")]


def get_user(user_id: int):
    with tx() as c:
        r = c.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        return _user(r, c) if r else None


def get_user_by_token(token: str):
    with tx() as c:
        r = c.execute("SELECT * FROM users WHERE sub_token=?", (token,)).fetchone()
        return _user(r, c) if r else None


def create_user(data: dict) -> int:
    with tx() as c:
        cur = c.execute(
            "INSERT INTO users(username, uuid, password, sub_token, status, data_limit, expire_at, reset_strategy, "
            "note, wg_enabled, wg_private, wg_public, wg_psk, wg_ip, country_exits, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (data["username"], str(uuidlib.uuid4()), secrets.token_urlsafe(16), secrets.token_urlsafe(18),
             "active", data.get("data_limit", 0), data.get("expire_at", 0), data.get("reset_strategy", "none"),
             data.get("note", ""), int(data.get("wg_enabled", False)), data.get("wg_private", ""),
             data.get("wg_public", ""), data.get("wg_psk", ""), data.get("wg_ip", ""),
             int(bool(data.get("country_exits", False))), now()))
        uid = cur.lastrowid
        for ib in data.get("inbound_ids", []):
            c.execute("INSERT OR IGNORE INTO user_inbounds(user_id, inbound_id) VALUES (?,?)", (uid, ib))
        return uid


USER_FIELDS = {"status", "data_limit", "expire_at", "reset_strategy", "note", "wg_enabled",
               "wg_private", "wg_public", "wg_psk", "wg_ip", "used", "sub_token", "last_reset", "country_exits",
               "up_bytes", "down_bytes", "owner", "blocks", "ovpn_enabled", "ovpn_cert", "ovpn_key", "last_seen", "max_ips", "speed_mbps", "ovpn_ip"}


def update_user(user_id: int, fields: dict, inbound_ids: list[int] | None = None):
    sets, args = [], []
    for k, v in fields.items():
        if k in USER_FIELDS:
            sets.append(f"{k}=?")
            args.append(int(v) if isinstance(v, bool) else v)
    with tx() as c:
        if sets:
            c.execute(f"UPDATE users SET {', '.join(sets)} WHERE id=?", args + [user_id])
        if inbound_ids is not None:
            c.execute("DELETE FROM user_inbounds WHERE user_id=?", (user_id,))
            for ib in inbound_ids:
                c.execute("INSERT OR IGNORE INTO user_inbounds(user_id, inbound_id) VALUES (?,?)", (user_id, ib))


def delete_user(user_id: int):
    with tx() as c:
        c.execute("DELETE FROM users WHERE id=?", (user_id,))


def add_usage(deltas: dict[int, int], split: dict[int, tuple[int, int]] | None = None):
    """deltas: user_id -> bytes to add. split: user_id -> (upload, download) bytes, for the page's two counters."""
    if not deltas:
        return
    day = time.strftime("%Y-%m-%d")
    with tx() as c:
        for uid, b in deltas.items():
            if b <= 0:
                continue
            up, down = (split or {}).get(uid, (0, 0))
            c.execute("UPDATE users SET used = used + ?, up_bytes = up_bytes + ?, down_bytes = down_bytes + ?, last_seen = ? WHERE id=?",
                      (b, max(0, up), max(0, down), int(time.time()), uid))
            c.execute("INSERT INTO usage_daily(user_id, day, bytes) VALUES (?,?,?) "
                      "ON CONFLICT(user_id, day) DO UPDATE SET bytes = bytes + excluded.bytes", (uid, day, b))


def usage_history(days: int = 14) -> list[dict]:
    with tx() as c:
        rows = c.execute(
            "SELECT day, SUM(bytes) AS bytes FROM usage_daily GROUP BY day ORDER BY day DESC LIMIT ?", (days,))
        return list(reversed([dict(r) for r in rows]))


def stats() -> dict:
    with tx() as c:
        by_status = {r["status"]: r["n"] for r in c.execute("SELECT status, COUNT(*) AS n FROM users GROUP BY status")}
        total_used = c.execute("SELECT COALESCE(SUM(used),0) FROM users").fetchone()[0]
        return {"users_total": sum(by_status.values()), "by_status": by_status, "total_used": total_used,
                "inbounds_total": c.execute("SELECT COUNT(*) FROM inbounds").fetchone()[0]}


# ---------- outbounds + routing rules ----------
def _outbound(r) -> dict:
    d = dict(r)
    d["settings"] = json.loads(d["settings"] or "{}")
    d["enabled"] = bool(d["enabled"])
    return d


def list_outbounds() -> list[dict]:
    with tx() as c:
        return [_outbound(r) for r in c.execute("SELECT * FROM outbounds ORDER BY id")]


def get_outbound(outbound_id: int):
    with tx() as c:
        r = c.execute("SELECT * FROM outbounds WHERE id=?", (outbound_id,)).fetchone()
        return _outbound(r) if r else None


def create_outbound(data: dict) -> int:
    with tx() as c:
        cur = c.execute(
            "INSERT INTO outbounds(tag, remark, type, settings, enabled, created_at) VALUES (?,?,?,?,?,?)",
            (data["tag"], data.get("remark", ""), data["type"], json.dumps(data.get("settings", {})),
             int(data.get("enabled", True)), now()))
        return cur.lastrowid


def update_outbound(outbound_id: int, data: dict):
    cur = get_outbound(outbound_id)
    if not cur:
        return
    cur.update({k: v for k, v in data.items() if v is not None})
    with tx() as c:
        c.execute("UPDATE outbounds SET tag=?, remark=?, type=?, settings=?, enabled=? WHERE id=?",
                  (cur["tag"], cur["remark"], cur["type"], json.dumps(cur["settings"]), int(cur["enabled"]),
                   outbound_id))


def delete_outbound(outbound_id: int):
    with tx() as c:
        c.execute("DELETE FROM outbounds WHERE id=?", (outbound_id,))


def _rule(r) -> dict:
    d = dict(r)
    d["match"] = json.loads(d["match"] or "{}")
    d["enabled"] = bool(d["enabled"])
    return d


def list_rules() -> list[dict]:
    with tx() as c:
        return [_rule(r) for r in c.execute("SELECT * FROM routing_rules ORDER BY position, id")]


def get_rule(rule_id: int):
    with tx() as c:
        r = c.execute("SELECT * FROM routing_rules WHERE id=?", (rule_id,)).fetchone()
        return _rule(r) if r else None


def create_rule(data: dict) -> int:
    with tx() as c:
        pos = c.execute("SELECT COALESCE(MAX(position), 0) + 1 FROM routing_rules").fetchone()[0]
        cur = c.execute(
            "INSERT INTO routing_rules(position, remark, enabled, match, outbound_tag, created_at) VALUES (?,?,?,?,?,?)",
            (pos, data.get("remark", ""), int(data.get("enabled", True)), json.dumps(data["match"]),
             data["outbound_tag"], now()))
        return cur.lastrowid


def update_rule(rule_id: int, data: dict):
    cur = get_rule(rule_id)
    if not cur:
        return
    cur.update({k: v for k, v in data.items() if v is not None})
    with tx() as c:
        c.execute("UPDATE routing_rules SET remark=?, enabled=?, match=?, outbound_tag=? WHERE id=?",
                  (cur["remark"], int(cur["enabled"]), json.dumps(cur["match"]), cur["outbound_tag"], rule_id))


def delete_rule(rule_id: int):
    with tx() as c:
        c.execute("DELETE FROM routing_rules WHERE id=?", (rule_id,))


def move_rule(rule_id: int, direction: str) -> bool:
    """Swap with the neighbour above ('up') or below ('down'). Returns False if it cannot move."""
    with tx() as c:
        rows = [r["id"] for r in c.execute("SELECT id FROM routing_rules ORDER BY position, id")]
        if rule_id not in rows:
            return False
        i = rows.index(rule_id)
        j = i - 1 if direction == "up" else i + 1
        if j < 0 or j >= len(rows):
            return False
        rows[i], rows[j] = rows[j], rows[i]
        for pos, rid in enumerate(rows, 1):
            c.execute("UPDATE routing_rules SET position=? WHERE id=?", (pos, rid))
        return True


# ---------------------------------------------------------------- tunnels (reverse / ssh / dnat)
def _tunnel(r) -> dict:
    d = dict(r)
    d["settings"] = json.loads(d["settings"] or "{}")
    d["enabled"] = bool(d["enabled"])
    return d


def list_tunnels() -> list[dict]:
    with tx() as c:
        return [_tunnel(r) for r in c.execute("SELECT * FROM tunnels ORDER BY id")]


def get_tunnel(tunnel_id: int):
    with tx() as c:
        r = c.execute("SELECT * FROM tunnels WHERE id=?", (tunnel_id,)).fetchone()
        return _tunnel(r) if r else None


def create_tunnel(data: dict) -> int:
    with tx() as c:
        cur = c.execute(
            "INSERT INTO tunnels(name, kind, port, settings, enabled, created_at) VALUES (?,?,?,?,?,?)",
            (data["name"], data["kind"], data["port"], json.dumps(data["settings"]), int(data.get("enabled", True)), now()))
        return cur.lastrowid


def update_tunnel(tunnel_id: int, data: dict):
    cur = get_tunnel(tunnel_id)
    if not cur:
        return
    cur.update(data)
    with tx() as c:
        c.execute("UPDATE tunnels SET name=?, port=?, settings=?, enabled=? WHERE id=?",
                  (cur["name"], cur["port"], json.dumps(cur["settings"]), int(cur["enabled"]), tunnel_id))


def delete_tunnel(tunnel_id: int):
    with tx() as c:
        c.execute("DELETE FROM tunnels WHERE id=?", (tunnel_id,))


def usage_user(user_id: int, days: int = 30) -> list[dict]:
    """Daily bytes for one user, oldest first, with zero-filled gaps."""
    import datetime
    days = min(max(days, 1), 120)
    start = datetime.date.today() - datetime.timedelta(days=days - 1)
    with tx() as c:
        rows = {r["day"]: r["bytes"] for r in c.execute(
            "SELECT day, bytes FROM usage_daily WHERE user_id=? AND day>=?", (user_id, start.isoformat()))}
    return [{"day": (start + datetime.timedelta(days=i)).isoformat(),
             "bytes": rows.get((start + datetime.timedelta(days=i)).isoformat(), 0)} for i in range(days)]


def usage_total(days: int = 30) -> list[dict]:
    import datetime
    days = min(max(days, 1), 120)
    start = datetime.date.today() - datetime.timedelta(days=days - 1)
    with tx() as c:
        rows = {r["day"]: r["b"] for r in c.execute(
            "SELECT day, SUM(bytes) AS b FROM usage_daily WHERE day>=? GROUP BY day", (start.isoformat(),))}
    return [{"day": (start + datetime.timedelta(days=i)).isoformat(),
             "bytes": rows.get((start + datetime.timedelta(days=i)).isoformat(), 0)} for i in range(days)]


def usage_top(days: int = 7, limit: int = 10) -> list[dict]:
    import datetime
    start = datetime.date.today() - datetime.timedelta(days=min(max(days, 1), 120) - 1)
    with tx() as c:
        return [dict(r) for r in c.execute(
            "SELECT u.id, u.username, SUM(d.bytes) AS bytes FROM usage_daily d JOIN users u ON u.id=d.user_id "
            "WHERE d.day>=? GROUP BY u.id ORDER BY bytes DESC LIMIT ?", (start.isoformat(), limit))]
