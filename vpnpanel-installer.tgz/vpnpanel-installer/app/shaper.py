"""Per-user speed limits with tc (WireGuard and OpenVPN only: their users have a fixed tunnel IP).
Xray / sing-box / Mihomo have no per-user rate limit."""
import ipaddress

from . import config, system


def plan(iface: str, entries: list[tuple[int, str, int]]) -> list[list[str]]:
    """entries: (user_id, ip, mbps). Returns the tc commands (without the leading 'tc')."""
    cmds = [["qdisc", "del", "dev", iface, "root"], ["qdisc", "del", "dev", iface, "ingress"]]
    entries = [e for e in entries if e[2] > 0 and 0 < e[0] + 10 < 65000]
    if not entries:
        return cmds
    cmds.append(["qdisc", "add", "dev", iface, "root", "handle", "1:", "htb", "default", "9999"])
    cmds.append(["class", "add", "dev", iface, "parent", "1:", "classid", "1:9999", "htb", "rate", "10gbit"])
    cmds.append(["qdisc", "add", "dev", iface, "handle", "ffff:", "ingress"])
    for uid, ip, mbps in entries:
        cid = f"1:{uid + 10}"
        cmds.append(["class", "add", "dev", iface, "parent", "1:", "classid", cid, "htb", "rate", f"{mbps}mbit", "ceil", f"{mbps}mbit"])
        cmds.append(["filter", "add", "dev", iface, "protocol", "ip", "parent", "1:", "prio", "1", "u32", "match", "ip", "dst", f"{ip}/32", "flowid", cid])
        cmds.append(["filter", "add", "dev", iface, "parent", "ffff:", "protocol", "ip", "prio", "1", "u32", "match", "ip", "src", f"{ip}/32",
                     "police", "rate", f"{mbps}mbit", "burst", "256k", "drop", "flowid", ":1"])
    return cmds


def _entries(users, ip_key, flag):
    out = []
    for u in users:
        ip = u.get(ip_key) or ""
        if u.get(flag) and u["status"] == "active" and (u.get("speed_mbps") or 0) > 0 and ip:
            try:
                ipaddress.ip_address(ip)
            except ValueError:
                continue
            out.append((u["id"], ip, int(u["speed_mbps"])))
    return out


def apply(users: list[dict], settings: dict) -> str:
    if config.DRY_RUN or not system.have("tc"):
        return "skipped"
    from . import ovpn
    done = []
    for iface, ip_key, flag, on in (
        (config.WG_IFACE, "wg_ip", "wg_enabled", settings.get("wg_enabled") == "1"),
        (ovpn.IFACE, "ovpn_ip", "ovpn_enabled", settings.get("ovpn_enabled") == "1"),
    ):
        if not on or system.run(["ip", "link", "show", iface])[0] != 0:
            continue
        ents = _entries(users, ip_key, flag)
        for c in plan(iface, ents):
            system.run(["tc", *c])
        done.append(f"{iface}:{len(ents)}")
    return "ok " + ",".join(done) if done else "nothing"
