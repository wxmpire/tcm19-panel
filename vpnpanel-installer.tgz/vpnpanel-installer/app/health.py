"""Server health: CPU / RAM / disk / network samples, and alerts (log + Telegram) when something is wrong."""
import shutil
import socket
import time

from . import activity, db

_prev_cpu: tuple[int, int] | None = None
_over: dict[str, int] = {}
_last_alert: dict[str, float] = {}
_down: dict[int, int] = {}
_last_sample = 0.0
KEEP = 2880          # samples kept (one per minute -> 2 days)
UDP_PROTOS = {"hysteria2", "hysteria", "tuic", "shadowquic", "wireguard", "tunnel"}
UDP_NETS = {"kcp", "udp"}


def _cpu_pct() -> float:
    global _prev_cpu
    try:
        f = open("/proc/stat").readline().split()[1:]
        v = [int(x) for x in f]
        idle, total = v[3] + (v[4] if len(v) > 4 else 0), sum(v)
    except (OSError, ValueError, IndexError):
        return 0.0
    prev, _prev_cpu = _prev_cpu, (idle, total)
    if not prev or total <= prev[1]:
        return 0.0
    return round(100.0 * (1 - (idle - prev[0]) / (total - prev[1])), 1)


def _mem_pct() -> float:
    try:
        m = {}
        for ln in open("/proc/meminfo"):
            k, v = ln.split(":", 1)
            m[k] = int(v.split()[0])
        tot, av = m["MemTotal"], m.get("MemAvailable", m.get("MemFree", 0))
        return round(100.0 * (1 - av / tot), 1) if tot else 0.0
    except (OSError, ValueError, KeyError):
        return 0.0


def _net_totals() -> tuple[int, int]:
    rx = tx = 0
    try:
        for ln in list(open("/proc/net/dev"))[2:]:
            name, rest = ln.split(":", 1)
            if name.strip() == "lo":
                continue
            p = rest.split()
            rx += int(p[0])
            tx += int(p[8])
    except (OSError, ValueError, IndexError):
        pass
    return rx, tx


def sample() -> dict:
    try:
        du = shutil.disk_usage("/")
        disk = round(100.0 * du.used / du.total, 1) if du.total else 0.0
    except OSError:
        disk = 0.0
    try:
        load1 = float(open("/proc/loadavg").read().split()[0])
        up = int(float(open("/proc/uptime").read().split()[0]))
    except (OSError, ValueError, IndexError):
        load1, up = 0.0, 0
    rx, tx = _net_totals()
    return {"ts": int(time.time()), "cpu": _cpu_pct(), "mem": _mem_pct(), "disk": disk, "rx": rx, "tx": tx,
            "load": load1, "uptime": up}


def _init():
    with db.tx() as c:
        c.execute("CREATE TABLE IF NOT EXISTS health (ts INTEGER PRIMARY KEY, cpu REAL, mem REAL, disk REAL, rx INTEGER, tx INTEGER)")


def history(limit: int = 180) -> list[dict]:
    _init()
    with db.tx() as c:
        rows = c.execute("SELECT ts,cpu,mem,disk,rx,tx FROM health ORDER BY ts DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in reversed(rows)]


def _alert(kind: str, msg: str, cooldown: int = 1800):
    now = time.time()
    if now - _last_alert.get(kind, 0) < cooldown:
        return
    _last_alert[kind] = now
    activity.log("system", "monitor", "health", msg)


def inbound_down(inbounds: list[dict]) -> list[dict]:
    """TCP inbounds that do not accept a connection on localhost."""
    bad = []
    for ib in inbounds:
        if not ib.get("enabled") or ib["protocol"] in UDP_PROTOS or ib.get("network") in UDP_NETS or not ib.get("port"):
            continue
        try:
            socket.create_connection(("127.0.0.1", int(ib["port"])), 1.0).close()
        except OSError:
            bad.append(ib)
    return bad


def tick(settings: dict, dry: bool = False) -> dict | None:
    """Called by the monitor every cycle. Stores at most one sample a minute and raises alerts."""
    global _last_sample
    now = time.time()
    if now - _last_sample < 55:
        return None
    _last_sample = now
    s = sample()
    _init()
    with db.tx() as c:
        c.execute("INSERT OR REPLACE INTO health(ts,cpu,mem,disk,rx,tx) VALUES(?,?,?,?,?,?)",
                  (s["ts"], s["cpu"], s["mem"], s["disk"], s["rx"], s["tx"]))
        c.execute("DELETE FROM health WHERE ts<?", (s["ts"] - KEEP * 60,))
    if settings.get("health_alerts", "1") != "1":
        return s
    for key, label, need in (("cpu", "پردازنده (CPU)", 5), ("mem", "حافظه (RAM)", 3), ("disk", "دیسک", 1)):
        lim = int(settings.get(f"health_{key}", "90") or 90)
        if s[key] >= lim:
            _over[key] = _over.get(key, 0) + 1
            if _over[key] >= need:
                _alert(key, f"{label} روی {s[key]:.0f}٪ است (آستانه {lim}٪)", 7200 if key == "disk" else 1800)
        else:
            _over.pop(key, None)
    if not dry:
        down = {i["id"]: i for i in inbound_down(db.list_inbounds())}
        for iid in list(_down):
            if iid not in down:
                _down.pop(iid)
        for iid, ib in down.items():
            _down[iid] = _down.get(iid, 0) + 1
            if _down[iid] >= 3:
                _alert(f"ib{iid}", f"اینباند «{ib.get('remark') or ib['tag']}» (پورت {ib['port']}) پاسخ نمی‌دهد", 3600)
    return s
