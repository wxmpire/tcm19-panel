"""systemd ExecStart wrapper: adds --ssl-* flags to the original uvicorn command when a panel domain is set.

Usage: python3 tlslaunch.py -- <original command...>
Stdlib only. If anything is wrong with the certificate it falls back to plain HTTP so the panel never goes dark.
"""
import json
import os
import ssl
import sys
from pathlib import Path


def data_dir() -> Path:
    base = Path(os.environ.get("PANEL_HOME", Path(__file__).resolve().parent.parent))
    return Path(os.environ.get("PANEL_DATA", base / "data"))


def build(argv: list[str], reg_file: Path):
    """Returns (argv, tls_active)."""
    clean, skip = [], False
    for a in argv:
        if skip:
            skip = False
            continue
        if a in ("--ssl-certfile", "--ssl-keyfile"):
            skip = True
            continue
        if a.startswith(("--ssl-certfile=", "--ssl-keyfile=")):
            continue
        clean.append(a)
    try:
        reg = json.loads(reg_file.read_text())
        dom = reg.get("panel", {}).get("domain", "")
        e = reg.get("domains", {}).get(dom)
        if not e:
            return clean, False
        if "uvicorn" not in " ".join(clean):
            print("tlslaunch: command is not uvicorn, starting without TLS", file=sys.stderr)
            return clean, False
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(e["cert"], e["key"])  # raises if unreadable / mismatched
        full = clean + ["--ssl-certfile", e["cert"], "--ssl-keyfile", e["key"]]
        return sni_command(full) or full, True
    except Exception as ex:
        print(f"tlslaunch: TLS disabled ({ex}); starting on plain HTTP", file=sys.stderr)
        return clean, False


def sni_command(full: list[str]):
    """Wrap the uvicorn command so every registered domain is served with its own certificate (SNI).
    Returns None when the command shape is unexpected; the caller then keeps the plain single-cert command."""
    try:
        here = Path(__file__).resolve().parent
        if os.environ.get("PANEL_SNI", "1") == "0" or not (here / "sniserve.py").exists():
            return None
        head = Path(full[0]).name
        if head.startswith("python") and full[1:3] == ["-m", "uvicorn"]:
            py, uargs = full[0], full[3:]
        elif head == "uvicorn":
            first = Path(full[0]).read_text(errors="ignore").splitlines()[0]
            if not first.startswith("#!"):
                return None
            py, uargs = first[2:].strip().split()[0], full[1:]
        else:
            return None
        if any(a.startswith(("--workers", "--reload")) for a in uargs) or not os.access(py, os.X_OK):
            return None
        return [py, str(here / "sniserve.py")] + uargs
    except Exception:
        return None


def main():
    if "--" not in sys.argv:
        sys.exit("usage: tlslaunch.py -- command...")
    argv, active = build(sys.argv[sys.argv.index("--") + 1:], data_dir() / "domains.json")
    env = dict(os.environ)
    env.pop("PANEL_TLS_ACTIVE", None)
    env.pop("PANEL_SNI_ACTIVE", None)
    if active:
        env["PANEL_TLS_ACTIVE"] = "1"
    os.execve(argv[0], argv, env)


if __name__ == "__main__":
    main()
