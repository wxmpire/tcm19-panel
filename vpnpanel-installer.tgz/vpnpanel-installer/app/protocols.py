"""Client link builders (vless://, vmess://, trojan://, ss://, hysteria2://, tuic://) and WireGuard client config."""
import base64
import json
from urllib.parse import quote, urlencode

from . import inbound_rules


def _host(inbound: dict, settings: dict) -> str:
    s = inbound["settings"]
    if s.get("address"):
        return s["address"]
    if inbound_rules.needs_tls(inbound["protocol"], inbound["security"]):
        tp = inbound_rules.panel_tls()  # TLS inbounds are served under the panel domain's certificate
        if tp:
            return tp["domain"]
    return settings.get("server_address") or "YOUR_SERVER"


def _remark(inbound: dict, user: dict) -> str:
    base = inbound.get("remark") or inbound["tag"]
    return f"{base}-{user['username']}"


def _short_id(s: dict) -> str:
    ids = s.get("short_ids") or [""]
    return ids[0] if isinstance(ids, list) else str(ids)


def _stream_params(ib: dict, host: str) -> dict:
    s, net, sec = ib["settings"], ib["network"], ib["security"]
    q = {"type": net, "security": sec}
    if net == "tcp":
        q["headerType"] = "none"
    elif net in ("ws", "httpupgrade", "xhttp"):
        q["path"] = s.get("path", "/")
        if s.get("host"):
            q["host"] = s["host"]
        if net == "xhttp":
            q["mode"] = s.get("mode", "auto")
    elif net == "kcp":
        q["headerType"] = s.get("header", "none")
        if s.get("seed"):
            q["seed"] = s["seed"]
    elif net == "grpc":
        q["serviceName"] = s.get("service_name", "")
        q["mode"] = "gun"
    if sec == "tls":
        q["sni"] = s.get("sni") or host
        q["fp"] = s.get("fp", "chrome")
        if s.get("alpn"):
            q["alpn"] = s["alpn"]
    elif sec == "reality":
        q["sni"] = s.get("sni", "")
        q["fp"] = s.get("fp", "chrome")
        q["pbk"] = s.get("public_key", "")
        q["sid"] = _short_id(s)
        q["spx"] = "/"
    return q


def _qs(q: dict) -> str:
    return urlencode({k: v for k, v in q.items() if v not in (None, "")}, quote_via=quote)


def build_link(ib: dict, user: dict, settings: dict) -> str | None:
    host, port, s = _host(ib, settings), ib["port"], ib["settings"]
    name = quote(_remark(ib, user))
    proto = ib["protocol"]

    if proto == "vless":
        q = _stream_params(ib, host)
        if s.get("flow") and ib["network"] == "tcp" and (ib["security"] in ("tls", "reality") or s.get("encryption")):
            q["flow"] = s["flow"]
        q["encryption"] = s.get("encryption") or "none"
        return f"vless://{user['uuid']}@{host}:{port}?{_qs(q)}#{name}"

    if proto == "vmess":
        net = ib["network"]
        obj = {
            "v": "2", "ps": _remark(ib, user), "add": host, "port": str(port), "id": user["uuid"], "aid": "0",
            "scy": "auto", "net": net,
            "type": (s.get("mode", "auto") if net == "xhttp" else s.get("header", "none") if net == "kcp" else "none"),
            "host": s.get("host", "") if net in ("ws", "httpupgrade", "xhttp") else "",
            "path": (s.get("path", "/") if net in ("ws", "httpupgrade", "xhttp")
                     else s.get("service_name", "") if net == "grpc" else s.get("seed", "") if net == "kcp" else ""),
            "tls": "tls" if ib["security"] == "tls" else "",
            "sni": (s.get("sni") or host) if ib["security"] == "tls" else "",
            "alpn": s.get("alpn", "") if ib["security"] == "tls" else "",
            "fp": s.get("fp", "chrome") if ib["security"] == "tls" else "",
        }
        return "vmess://" + base64.b64encode(json.dumps(obj, separators=(",", ":")).encode()).decode()

    if proto == "trojan":
        q = _stream_params(ib, host)
        return f"trojan://{quote(user['password'], safe='')}@{host}:{port}?{_qs(q)}#{name}"

    if proto == "shadowsocks":
        method = s.get("method", "chacha20-ietf-poly1305")
        if method.startswith("2022-"):
            userinfo = f"{method}:{s.get('server_password', '')}:{ss2022_user_key(user, method)}"
        else:
            userinfo = f"{method}:{user['password']}"
        enc = base64.urlsafe_b64encode(userinfo.encode()).decode().rstrip("=")
        return f"ss://{enc}@{host}:{port}#{name}"

    if proto == "hysteria2":
        q = {"sni": s.get("sni") or host, "insecure": "1" if s.get("insecure") else "0"}
        if s.get("obfs_password"):
            q["obfs"] = "salamander"
            q["obfs-password"] = s["obfs_password"]
        return f"hysteria2://{quote(user['password'], safe='')}@{host}:{port}?{_qs(q)}#{name}"

    if proto == "tuic":
        q = {"congestion_control": s.get("congestion", "bbr"), "alpn": "h3",
             "sni": s.get("sni") or host, "udp_relay_mode": "native",
             "allow_insecure": "1" if s.get("insecure") else "0"}
        return f"tuic://{user['uuid']}:{quote(user['password'], safe='')}@{host}:{port}?{_qs(q)}#{name}"

    if proto == "hysteria":
        q = {"protocol": "udp", "auth": user["password"], "peer": s.get("sni") or host, "insecure": "0",
             "upmbps": s.get("up_mbps", "100"), "downmbps": s.get("down_mbps", "100"), "alpn": "h3"}
        if s.get("obfs_password"):
            q["obfs"] = "xplus"
            q["obfsParam"] = s["obfs_password"]
        return f"hysteria://{host}:{port}?{_qs(q)}#{name}"

    if proto == "anytls":
        q = {"sni": s.get("sni") or host, "insecure": "0"}
        return f"anytls://{quote(user['password'], safe='')}@{host}:{port}?{_qs(q)}#{name}"

    if proto == "shadowtls":
        method = s.get("method", "2022-blake3-aes-128-gcm")
        userinfo = f"{method}:{s.get('server_password', '')}:{ss2022_user_key(user, method)}"
        enc = base64.urlsafe_b64encode(userinfo.encode()).decode().rstrip("=")
        st = base64.urlsafe_b64encode(json.dumps(
            {"version": "3", "host": s.get("sni", ""), "password": user["password"]}, separators=(",", ":")).encode()).decode().rstrip("=")
        return f"ss://{enc}@{host}:{port}?shadow-tls={st}#{name}"

    if proto == "naive":
        return f"naive+https://{quote(user['username'], safe='')}:{quote(user['password'], safe='')}@{host}:{port}#{name}"

    return None


def ss2022_user_key(user: dict, method: str) -> str:
    """Derive a valid base64 key for SS-2022 from the user's password (deterministic)."""
    import hashlib
    size = 16 if "128" in method else 32
    return base64.b64encode(hashlib.sha256(user["password"].encode()).digest()[:size]).decode()


def wireguard_client_config(user: dict, settings: dict) -> str | None:
    if not user.get("wg_enabled") or settings.get("wg_enabled") != "1":
        return None
    host = settings.get("server_address") or "YOUR_SERVER"
    lines = [
        "[Interface]",
        f"PrivateKey = {user['wg_private']}",
        f"Address = {user['wg_ip']}/32",
        f"DNS = {settings.get('dns', '1.1.1.1')}",
        f"MTU = {settings.get('wg_mtu', '1280')}",
        "",
        "[Peer]",
        f"PublicKey = {settings.get('wg_server_public', '')}",
        f"PresharedKey = {user['wg_psk']}",
        f"Endpoint = {host}:{settings.get('wg_port', '51820')}",
        "AllowedIPs = 0.0.0.0/0, ::/0",
        "PersistentKeepalive = 25",
        "",
    ]
    return "\n".join(lines)


def user_links(user: dict, inbounds: list[dict], settings: dict) -> list[str]:
    allowed = set(user.get("inbound_ids", []))
    out = []
    for ib in inbounds:
        if ib["enabled"] and ib["id"] in allowed:
            link = build_link(ib, user, settings)
            if link:
                out.append(link)
    return out


def shadowtls_singbox_client(ib: dict, user: dict, settings: dict) -> str:
    """sing-box client outbounds (shadowtls + shadowsocks) for a ShadowTLS inbound."""
    s, host = ib["settings"], _host(ib, settings)
    method = s.get("method", "2022-blake3-aes-128-gcm")
    tag = _remark(ib, user)
    return json.dumps({"outbounds": [
        {"type": "shadowsocks", "tag": tag, "method": method,
         "password": f"{s.get('server_password', '')}:{ss2022_user_key(user, method)}", "detour": tag + "-tls"},
        {"type": "shadowtls", "tag": tag + "-tls", "server": host, "server_port": ib["port"], "version": 3,
         "password": user["password"], "tls": {"enabled": True, "server_name": s.get("sni", "")}}]},
        indent=2, ensure_ascii=False)
