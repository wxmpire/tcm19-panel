"""Who is connected right now (OpenVPN, WireGuard, Xray) + per-user device (IP) limit."""
import json
import time

from . import activity, config, db, geo, ovpn, system, xray_config

WINDOW = 120  # seconds without traffic before a user counts as offline
_viol: dict[int, int] = {}
_gviol: dict[int, int] = {}


def _wg_sessions(users: list[dict]) -> list[dict]:
    if config.DRY_RUN or not system.have("wg"):
        return []
    code, out = system.run(["wg", "show", config.WG_IFACE, "dump"])
    if code != 0:
        return []
    by_pub = {u["wg_public"]: u for u in users if u.get("wg_public")}
    res = []
    for line in out.splitlines()[1:]:
        p = line.split("\t")
        if len(p) < 7 or p[0] not in by_pub:
            continue
        hs = int(p[4] or 0)
        if hs and time.time() - hs < 180:
            ep = p[2].rsplit(":", 1)[0].strip("[]") if p[2] != "(none)" else ""
            res.append({"uid": by_pub[p[0]]["id"], "ip": ep, "virt": by_pub[p[0]]["wg_ip"], "rx": int(p[5]), "tx": int(p[6]), "since": hs, "pub": p[0]})
    return res


def _xray_ips(u: dict) -> set[str]:
    if config.DRY_RUN or not system.have(config.XRAY_BIN):
        return set()
    ips = set()
    for ib in u.get("inbound_ids", [])[:6]:
        code, out = system.run([config.XRAY_BIN, "api", "statsonlineiplist", f"--server={config.XRAY_API}",
                                "-email", xray_config.client_email(u["id"], ib)], 6)
        if code != 0:
            continue
        try:
            data = json.loads(out)
        except ValueError:
            continue
        m = data.get("ips") if isinstance(data, dict) else None
        if isinstance(m, dict):
            now = time.time()
            ips |= {ip for ip, ts in m.items() if not isinstance(ts, (int, float)) or now - ts < WINDOW}
    return ips


def snapshot(users: list[dict] | None = None, with_xray: bool = True) -> list[dict]:
    users = users if users is not None else db.all_users()
    byid = {u["id"]: u for u in users}
    now = time.time()
    rows: dict[int, dict] = {}

    def row(uid):
        u = byid[uid]
        return rows.setdefault(uid, {"id": uid, "username": u["username"], "status": u["status"], "ips": [], "sessions": [],
                                     "last_seen": u.get("last_seen", 0), "protos": []})
    for s in ovpn.sessions():
        if s["uid"] in byid:
            r = row(s["uid"])
            r["sessions"].append({"proto": "openvpn", **s})
    for s in _wg_sessions(users):
        r = row(s["uid"])
        r["sessions"].append({"proto": "wireguard", **s})
    for u in users:
        if now - (u.get("last_seen") or 0) < WINDOW:
            r = row(u["id"])
            if with_xray and not r["sessions"]:
                for ip in sorted(_xray_ips(u)):
                    r["sessions"].append({"proto": "xray", "ip": ip})
    for r in rows.values():
        r["ips"] = sorted({s["ip"] for s in r["sessions"] if s.get("ip")})
        r["protos"] = sorted({s["proto"] for s in r["sessions"]})
        r["countries"] = sorted({c for c in (geo.country(ip) for ip in r["ips"]) if c})
    return sorted(rows.values(), key=lambda r: (-len(r["ips"]), r["username"]))


def kick(uid: int) -> dict:
    u = db.get_user(uid)
    if not u:
        return {"killed": 0}
    n = 0
    for s in ovpn.sessions():
        if s["uid"] == uid:
            n += ovpn.kick(s["cn"])
    for s in _wg_sessions([u]):
        if system.run(["wg", "set", config.WG_IFACE, "peer", s["pub"], "remove"])[0] == 0:
            n += 1  # the panel puts the peer back on its next apply
    return {"killed": n, "note": "" if n else "اتصال Xray/sing-box قابل قطع تکی نیست؛ برای قطع کردن، کاربر را غیرفعال کن."}


def enforce(users: list[dict], settings: dict) -> bool:
    """Device limit + account-sharing (several countries at once). Returns True when a user was disabled."""
    geo_act = settings.get("geo_action", "off")
    lim = [u for u in users if u["status"] == "active" and (u.get("max_ips") or geo_act != "off")]
    if not lim:
        _viol.clear()
        _gviol.clear()
        return False
    snap = {r["id"]: r for r in snapshot(users)}
    changed = False
    for u in lim:
        row = snap.get(u["id"], {})
        ips = row.get("ips", [])
        if u.get("max_ips") and len(ips) > u["max_ips"]:
            _viol[u["id"]] = _viol.get(u["id"], 0) + 1
            if _viol[u["id"]] == 2:  # still over the limit on the next check -> act
                activity.log("system", "monitor", "ip_limit", f"{u['username']}: {len(ips)} IP از {u['max_ips']} مجاز ({', '.join(ips[:6])})")
                if settings.get("ip_limit_action") == "disable":
                    changed |= _disable(u, "تعداد دستگاه")
        else:
            _viol.pop(u["id"], None)
        ccs = row.get("countries", [])
        if geo_act != "off" and len(ccs) >= 2:
            _gviol[u["id"]] = _gviol.get(u["id"], 0) + 1
            if _gviol[u["id"]] == 2:
                activity.log("system", "monitor", "geo_limit", f"{u['username']}: هم‌زمان از {len(ccs)} کشور ({', '.join(ccs)})")
                if geo_act == "disable":
                    changed |= _disable(u, "چند کشور هم‌زمان")
        else:
            _gviol.pop(u["id"], None)
    return changed


def _disable(u: dict, why: str) -> bool:
    db.update_user(u["id"], {"status": "disabled", "note": ((u.get("note") or "") + f" [خودکار: {why}]")[:200]})
    kick(u["id"])
    return True
