"""NordVPN (NordLynx = WireGuard) as an outbound: the panel turns a NordVPN access token into a normal wireguard outbound."""
import base64
import json
import re
import urllib.error
import urllib.parse
import urllib.request

from . import config

API = "https://api.nordvpn.com/v1"
LOCAL_ADDRESS = "10.5.0.2/32"       # the fixed tunnel address NordLynx clients use
PORT = 51820


class NordError(Exception):
    pass


def _get(path: str, token: str | None = None, timeout: int = 20):
    if config.DRY_RUN:
        raise NordError("dry-run")
    req = urllib.request.Request(API + path, headers={"User-Agent": "tcm19", "Accept": "application/json"})
    if token:
        req.add_header("Authorization", "Basic " + base64.b64encode(f"token:{token}".encode()).decode())
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read(4 * 1024 * 1024))
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            raise NordError("توکن NordVPN نامعتبر یا منقضی است")
        raise NordError(f"خطای NordVPN: HTTP {e.code}")
    except (urllib.error.URLError, OSError, ValueError) as e:
        raise NordError(f"اتصال به api.nordvpn.com ممکن نشد: {e}")


def countries() -> list[dict]:
    d = _get("/servers/countries")
    out = [{"id": c["id"], "code": c.get("code", ""), "name": c.get("name", "")} for c in d if c.get("id")]
    return sorted(out, key=lambda c: c["name"])


def private_key(token: str) -> str:
    d = _get("/users/services/credentials", token.strip())
    key = d.get("nordlynx_private_key") if isinstance(d, dict) else ""
    if not key:
        raise NordError("کلید NordLynx در حساب پیدا نشد (توکن را از بخش Advanced settings بساز)")
    return key


def pick_server(country_id: int | None) -> dict:
    q = "/servers/recommendations?filters[servers_technologies][identifier]=wireguard_udp&limit=5"
    if country_id:
        q += f"&filters[country_id]={int(country_id)}"
    for s in _get(q):
        pub = ""
        for t in s.get("technologies", []):
            if t.get("identifier") == "wireguard_udp":
                for m in t.get("metadata", []):
                    if m.get("name") == "public_key":
                        pub = m.get("value", "")
        if pub and s.get("station"):
            loc = (s.get("locations") or [{}])[0].get("country", {})
            return {"station": s["station"], "public_key": pub, "hostname": s.get("hostname", ""),
                    "load": s.get("load", 0), "cc": (loc.get("code") or "").lower(), "country": loc.get("name", "")}
    raise NordError("سرور WireGuard مناسبی از NordVPN پیدا نشد")


def check_token(token: str) -> str:
    if not re.fullmatch(r"[A-Za-z0-9]{20,200}", token.strip()):
        raise NordError("توکن نامعتبر است (فقط حروف و عدد، از my.nordaccount.com ← Advanced settings)")
    return private_key(token)


def settings_for(key: str, server: dict) -> dict:
    return {"private_key": key, "address": [LOCAL_ADDRESS], "peer_public_key": server["public_key"],
            "endpoint": f"{server['station']}:{PORT}", "mtu": 1420}


def build(token: str, country_id: int | None) -> dict:
    """Settings for a wireguard outbound + display info (one country)."""
    key = check_token(token)
    s = pick_server(country_id)
    return {"settings": settings_for(key, s), "server": s}


def is_nord(ob: dict) -> bool:
    """An outbound made by the panel's NordVPN flow (new ones are flagged; older ones are recognised by their tunnel address)."""
    if ob.get("type") != "wireguard":
        return False
    st = ob.get("settings") or {}
    addr = st.get("address") or []
    addr = [addr] if isinstance(addr, str) else list(addr)
    return bool(st.get("nord")) or (str(ob.get("tag", "")).startswith("nord-") and LOCAL_ADDRESS in addr)


def saved_key(obs: list[dict]) -> str:
    """The NordLynx private key of any Nord outbound already in the panel (one key works for every Nord server)."""
    for o in obs:
        if is_nord(o) and (o.get("settings") or {}).get("private_key"):
            return o["settings"]["private_key"]
    return ""


def country_by_code(code: str) -> dict:
    code = code.strip().upper()
    for c in countries():
        if (c.get("code") or "").upper() == code:
            return c
    raise NordError(f"NordVPN در کشور {code} سروری ندارد")
