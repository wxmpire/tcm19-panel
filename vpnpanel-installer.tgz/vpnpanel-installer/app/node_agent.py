#!/usr/bin/env python3
"""tcm19 node agent: runs on an extra server. The main panel pushes the Xray config here and reads traffic back.

Standalone (python3 standard library only). HTTPS with a self-signed certificate (the panel pins its fingerprint);
every request is signed with HMAC-SHA256 using a shared secret, timestamped, and replay-protected.
Run:  python3 node_agent.py   (settings from /opt/tcm19-node/: secret, cert.pem, key.pem; env NODE_PORT)
"""
import hashlib
import hmac
import json
import os
import re
import shutil
import ssl
import subprocess
import tempfile
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOME = Path(os.environ.get("NODE_HOME", "/opt/tcm19-node"))
XRAY_BIN = os.environ.get("XRAY_BIN", "/usr/local/bin/xray")
XRAY_CONFIG = Path(os.environ.get("XRAY_CONFIG", "/usr/local/etc/xray/config.json"))
XRAY_API = os.environ.get("XRAY_API", "127.0.0.1:10085")
XRAY_SERVICE = os.environ.get("XRAY_SERVICE", "xray")
PORT = int(os.environ.get("NODE_PORT", "8443"))
MAX_BODY = 8 * 1024 * 1024
SKEW = 120
_seen: dict[str, float] = {}


def secret() -> bytes:
    return (HOME / "secret").read_text().strip().encode()


def sign(sec: bytes, ts: str, method: str, path: str, body: bytes) -> str:
    return hmac.new(sec, f"{ts}.{method}.{path}.".encode() + body, hashlib.sha256).hexdigest()


def run(cmd, timeout=30):
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout + p.stderr)
    except (OSError, subprocess.TimeoutExpired) as e:
        return 1, str(e)


def have_xray() -> bool:
    return os.path.exists(XRAY_BIN) or shutil.which(XRAY_BIN) is not None


def do_status() -> dict:
    st = run(["systemctl", "is-active", XRAY_SERVICE])[1].strip() if have_xray() else "missing"
    ver = ""
    if have_xray():
        ver = (run([XRAY_BIN, "version"])[1].splitlines() or [""])[0][:60]
    try:
        up = int(float(open("/proc/uptime").read().split()[0]))
        load = float(open("/proc/loadavg").read().split()[0])
    except (OSError, ValueError):
        up, load = 0, 0.0
    return {"xray": st, "version": ver, "uptime": up, "load": load, "agent": 1}


def open_ports(ports) -> None:
    if not shutil.which("ufw") or "Status: active" not in run(["ufw", "status"])[1]:
        return
    for p in ports[:64]:
        try:
            n, proto = int(p["port"]), ("udp" if p.get("proto") == "udp" else "tcp")
        except (KeyError, TypeError, ValueError):
            continue
        if 1 <= n <= 65535:
            run(["ufw", "allow", f"{n}/{proto}"])


WG_MARK = HOME / "wg.managed"
WG_CONF = Path(os.environ.get("WG_CONF", "/etc/wireguard/wg0.conf"))


def default_iface() -> str:
    code, out = run(["ip", "-o", "route", "get", "1.1.1.1"])
    m = re.search(r"dev (\S+)", out) if code == 0 else None
    return m.group(1) if m else "eth0"


def do_wireguard(wg: dict) -> tuple[str, bool]:
    """Install/sync WireGuard using the panel's config. Only touches a setup this agent created."""
    if not isinstance(wg, dict):
        return ("", False)
    if not wg.get("enabled"):
        if WG_MARK.exists():
            run(["systemctl", "disable", "--now", "wg-quick@wg0"], 30)
            WG_MARK.unlink(missing_ok=True)
            return ("", True)
        return ("", False)
    conf = wg.get("conf")
    if not isinstance(conf, str) or "[Interface]" not in conf or len(conf) > 400000:
        return ("wg: کانفیگ نامعتبر", False)
    if WG_CONF.exists() and not WG_MARK.exists():
        return ("wg: روی این سرور WireGuard دیگری وجود دارد؛ دست نزدم", False)
    if not shutil.which("wg") or not shutil.which("wg-quick"):
        run(["apt-get", "update", "-qq"], 120)
        code, out = run(["apt-get", "install", "-y", "-qq", "wireguard-tools", "iptables"], 300)
        if code != 0 or not shutil.which("wg-quick"):
            return ("wg: نصب wireguard-tools ناموفق: " + out[-150:], False)
    conf = conf.replace("__OUTIF__", default_iface())
    try:
        port = int(wg.get("port", 51820))
    except (TypeError, ValueError):
        port = 51820
    run(["sysctl", "-w", "net.ipv4.ip_forward=1"])
    try:
        Path("/etc/sysctl.d/99-tcm19-node.conf").write_text("net.ipv4.ip_forward=1\n")
    except OSError:
        pass
    old = WG_CONF.read_text() if WG_CONF.exists() else ""
    open_ports([{"port": port, "proto": "udp"}])
    up = run(["ip", "link", "show", "wg0"])[0] == 0
    if old == conf and up:
        return ("", False)
    WG_CONF.parent.mkdir(parents=True, exist_ok=True)
    WG_CONF.write_text(conf)
    WG_CONF.chmod(0o600)
    WG_MARK.write_text("1")
    if not up:
        code, out = run(["systemctl", "enable", "--now", "wg-quick@wg0"], 40)
        return ("" if code == 0 else "wg: start failed: " + out[-150:], True)
    code, out = run(["bash", "-c", "wg syncconf wg0 <(wg-quick strip wg0)"], 20)
    return ("" if code == 0 else "wg: sync failed: " + out[-150:], True)


def do_apply(payload: dict) -> dict:
    r = do_apply_xray(payload)
    werr, wchg = do_wireguard(payload.get("wireguard"))
    if wchg:
        r["changed"] = True
    if werr:
        r["ok"] = False
        r["error"] = (r.get("error", "") + " " + werr).strip()
    return r


def do_apply_xray(payload: dict) -> dict:
    cfg = payload.get("config")
    if not isinstance(cfg, dict) or not have_xray():
        return {"ok": False, "error": "xray نصب نیست یا کانفیگ نامعتبر است"}
    text = json.dumps(cfg, indent=2)
    old = XRAY_CONFIG.read_text() if XRAY_CONFIG.exists() else ""
    open_ports(payload.get("ports") or [])
    if old == text:
        return {"ok": True, "changed": False}
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
        f.write(text)
        tmp = f.name
    try:
        os.chmod(tmp, 0o644)
        code, out = run([XRAY_BIN, "run", "-test", "-config", tmp])
        if code != 0:
            return {"ok": False, "error": "xray config test failed: " + out[-300:]}
        XRAY_CONFIG.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(tmp, XRAY_CONFIG)
        os.chmod(XRAY_CONFIG, 0o644)
    finally:
        try:
            os.unlink(tmp)
        except OSError:
            pass
    code, out = run(["systemctl", "restart", XRAY_SERVICE], 60)
    return {"ok": code == 0, "changed": True, "error": "" if code == 0 else out[-200:]}


def do_stats() -> dict:
    wg = run(["wg", "show", "wg0", "transfer"])[1] if WG_MARK.exists() and shutil.which("wg") else ""
    r = do_stats_xray()
    if wg:
        r["wg"] = wg
        r["ok"] = True
    return r


def do_stats_xray() -> dict:
    if not have_xray():
        return {"ok": False, "stat": []}
    code, out = run([XRAY_BIN, "api", "statsquery", f"--server={XRAY_API}", "-pattern", "user>>>", "-reset"], 15)
    if code != 0:
        return {"ok": False, "stat": []}
    try:
        return {"ok": True, "stat": json.loads(out).get("stat", [])}
    except ValueError:
        return {"ok": False, "stat": []}


class H(BaseHTTPRequestHandler):
    server_version = "tcm19-node"

    def log_message(self, *a):
        pass

    def _send(self, code: int, obj: dict):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def _auth(self, body: bytes) -> bool:
        ts, sig = self.headers.get("X-Ts", ""), self.headers.get("X-Sig", "")
        try:
            if abs(time.time() - int(ts)) > SKEW:
                return False
        except ValueError:
            return False
        good = sign(secret(), ts, self.command, self.path, body)
        if os.environ.get("AGENT_DEBUG") and not hmac.compare_digest(good, sig): print("AUTHFAIL", ts, self.command, self.path, len(body), flush=True)
        if not hmac.compare_digest(good, sig):
            return False
        now = time.time()
        for k in [k for k, t in _seen.items() if now - t > SKEW * 2]:
            _seen.pop(k, None)
        if sig in _seen:
            if os.environ.get('AGENT_DEBUG'): print('REPLAY', self.path, len(body), flush=True)
            return False
        _seen[sig] = now
        return True

    def _handle(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n > MAX_BODY:
            return self._send(413, {"ok": False})
        body = self.rfile.read(n) if n else b""
        if not self._auth(body):
            time.sleep(0.3)
            return self._send(401, {"ok": False, "error": "unauthorized"})
        path = self.path.split("?")[0]
        try:
            if self.command == "GET" and path == "/status":
                return self._send(200, do_status())
            if self.command == "POST" and path == "/apply":
                return self._send(200, do_apply(json.loads(body or b"{}")))
            if self.command == "POST" and path == "/stats":
                return self._send(200, do_stats())
        except Exception as e:  # never crash the agent on a bad request
            return self._send(500, {"ok": False, "error": str(e)[:200]})
        self._send(404, {"ok": False})

    do_GET = do_POST = _handle


def main():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(HOME / "cert.pem", HOME / "key.pem")
    srv = ThreadingHTTPServer(("0.0.0.0", PORT), H)
    srv.socket = ctx.wrap_socket(srv.socket, server_side=True)
    srv.serve_forever()


if __name__ == "__main__":
    main()
