"""Separate port for subscription links.

The panel keeps listening on its own port. A second systemd service (vpnpanel-sub) serves ONLY /sub/* on the
chosen port and answers 404 to everything else, using the same TLS wrapper (tlslaunch.py) as the panel.
"""
import re
import socket
from pathlib import Path

from . import certstore as cs, config, db

SERVICE = "vpnpanel-sub"
UNIT = Path("/etc/systemd/system/vpnpanel-sub.service")
RESERVED = {10085}
COPY_KEYS = ("User=", "Group=", "WorkingDirectory=", "Environment=")
SKIP_ENV = ("PANEL_ADMIN_PASS", "PANEL_ADMIN_USER")


class SubPortError(Exception):
    pass


def _panel_unit() -> str:
    r = cs.sh(["systemctl", "cat", cs.PANEL_SERVICE], 15)
    return r.stdout if r.returncode == 0 else ""


def panel_port() -> int:
    ports = re.findall(r"--port[ =](\d+)", _panel_unit())
    return int(ports[-1]) if ports else 0


def unit_port() -> int:
    try:
        m = re.findall(r"--port[ =](\d+)", UNIT.read_text())
        return int(m[-1]) if m else 0
    except OSError:
        return 0


def is_active() -> bool:
    return cs.sh(["systemctl", "is-active", SERVICE], 10).stdout.strip() == "active"


def build_unit(panel_text: str, port: int) -> str:
    """Derive the sub unit from the panel's own unit so User/WorkingDirectory/venv paths always match."""
    execs = [l.strip() for l in panel_text.splitlines() if l.startswith("ExecStart=") and len(l.strip()) > 10]
    if not execs:
        raise SubPortError("ExecStart پنل پیدا نشد")
    ex = execs[-1]
    if "app.main:app" not in ex:
        raise SubPortError("ExecStart پنل شکل ناشناخته دارد")
    ex = ex.replace("app.main:app", "app.subonly:app")
    ex = re.sub(r"--host[ =]\S+", "--host 0.0.0.0", ex) if re.search(r"--host[ =]\S+", ex) else ex + " --host 0.0.0.0"
    if re.search(r"--port[ =]\d+", ex):
        ex = re.sub(r"--port[ =]\d+", f"--port {port}", ex)
    else:
        ex += f" --port {port}"
    keep, seen = [], set()
    for l in panel_text.splitlines():
        l = l.strip()
        if l.startswith(COPY_KEYS) and not any(k in l for k in SKIP_ENV) and l not in seen:
            seen.add(l)
            keep.append(l)
    return ("[Unit]\nDescription=VPN panel subscription listener (managed by the panel)\n"
            "After=network.target vpnpanel.service\n\n[Service]\n" + "\n".join(keep) + "\n" + ex +
            "\nRestart=always\nRestartSec=3\n\n[Install]\nWantedBy=multi-user.target\n")


def _free(port: int) -> bool:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.bind(("0.0.0.0", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def validate(port: int, current: int) -> None:
    if not 1 <= port <= 65535:
        raise SubPortError("پورت باید بین ۱ تا ۶۵۵۳۵ باشد")
    pp = panel_port()
    if port == pp:
        raise SubPortError(f"این پورت مال خود پنل است ({pp}). یک پورت دیگر بگذار")
    if port in RESERVED:
        raise SubPortError("این پورت برای سیستم رزرو شده")
    for ib in db.list_inbounds():
        if str(ib.get("port")) == str(port):
            raise SubPortError(f"پورت {port} را اینباند «{ib.get('tag') or ib.get('id')}» استفاده می‌کند")
    if port != current and not _free(port):
        raise SubPortError(f"پورت {port} روی سرور اشغال است")


def disable() -> None:
    if config.DRY_RUN:
        return
    cs.sh(["systemctl", "disable", "--now", SERVICE], 30)
    try:
        UNIT.unlink()
    except OSError:
        pass
    cs.sh(["systemctl", "daemon-reload"], 20)


def enable(port: int) -> None:
    if config.DRY_RUN:
        return
    old = UNIT.read_text() if UNIT.exists() else None
    text = build_unit(_panel_unit(), port)
    UNIT.write_text(text)
    UNIT.chmod(0o644)
    cs.sh(["systemctl", "daemon-reload"], 20)
    r = cs.sh(["systemctl", "enable", SERVICE], 20)
    r = cs.sh(["systemctl", "restart", SERVICE], 40)
    import time
    for _ in range(10):
        time.sleep(1)
        if is_active() and unit_port() == port and not _free(port):
            return
    log = cs.sh(["journalctl", "-u", SERVICE, "-n", "6", "--no-pager"], 10).stdout.strip()
    # roll back so a bad value never leaves a broken service behind
    if old is not None:
        UNIT.write_text(old)
        cs.sh(["systemctl", "daemon-reload"], 20)
        cs.sh(["systemctl", "restart", SERVICE], 40)
    else:
        disable()
    raise SubPortError("سرویس پورت جدید بالا نیامد و تغییر برگردانده شد.\n" + log[-400:])


def current() -> dict:
    """Setting value, adopting an existing hand-made vpnpanel-sub unit if the setting is still empty."""
    s = db.get_settings()
    port = (s.get("sub_port") or "").strip()
    if not port and not config.DRY_RUN:
        up = unit_port()
        if up:
            db.set_settings({"sub_port": str(up)})
            port = str(up)
    on = bool(port.isdigit() and (config.DRY_RUN or is_active()))
    return {"port": int(port) if port.isdigit() else 0, "active": on, "panel_port": panel_port()}


def set_port(port: int) -> dict:
    s = db.get_settings()
    cur = int((s.get("sub_port") or "0") or 0) if (s.get("sub_port") or "").isdigit() else 0
    if port in (0, None):
        disable()
        db.set_settings({"sub_port": ""})
        return current()
    validate(port, cur)
    enable(port)
    db.set_settings({"sub_port": str(port)})
    return current()
