"""Certificate store shared by the panel API, the panelctl CLI and the certbot deploy hook.

Stdlib only (plus openssl/certbot binaries) so it can run outside the panel's virtualenv.
Registry lives in DATA_DIR/domains.json:
  {"domains": {"example.com": {"source": "cloudflare|http|manual", "cert": path, "key": path,
                               "certname": "vp-example.com", "method": "cloudflare|http", "wildcard": true,
                               "extra": [], "added": ts}},
   "panel": {"domain": ""}}
"""
import ipaddress
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from . import config

CERT_ROOT = Path(os.environ.get("PANEL_CERT_DIR", "/etc/ssl/vpnpanel"))
LE_LIVE = Path(os.environ.get("PANEL_LE_LIVE", "/etc/letsencrypt/live"))
REG_FILE = config.DATA_DIR / "domains.json"
CF_TOKEN_FILE = config.DATA_DIR / "cloudflare.json"
CF_CRED_FILE = config.DATA_DIR / "cf-credentials.ini"
HOOK_FILE = Path(os.environ.get("PANEL_CERT_HOOK", "/etc/letsencrypt/renewal-hooks/deploy/vpnpanel.sh"))
PANEL_SERVICE = os.environ.get("PANEL_SERVICE", "vpnpanel")

HOST_RE = re.compile(r"^(?=.{1,253}$)([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$")
_lock = threading.RLock()
job = {"state": "idle", "log": "", "domain": "", "started": 0, "finished": 0}


class CertError(Exception):
    pass


# ---------------------------------------------------------------- helpers
def sh(cmd, timeout=30):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        return subprocess.CompletedProcess(cmd, 127, "", str(e))


def norm_name(name: str, allow_wild: bool = False) -> str:
    n = (name or "").strip().lower().rstrip(".")
    base = n[2:] if allow_wild and n.startswith("*.") else n
    if not HOST_RE.match(base):
        raise CertError(f"نام دامنه نامعتبر است: {name}")
    return n


def is_ip(host: str) -> bool:
    try:
        ipaddress.ip_address(host.strip("[]"))
        return True
    except ValueError:
        return False


def names_cover(names: list[str], host: str) -> bool:
    host = host.lower()
    for n in names:
        n = n.lower()
        if n == host:
            return True
        if n.startswith("*.") and host.endswith(n[1:]) and len(host) > len(n) - 1 \
                and host.count(".") == n.count("."):
            return True
    return False


def _write(path: Path, data: str, mode: int) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)
    os.chmod(path, mode)


def _copy(src: Path, dst: Path, mode: int = 0o644) -> None:
    dst.parent.mkdir(parents=True, exist_ok=True)
    try:
        if dst.exists() and os.path.samefile(src, dst):
            os.chmod(dst, mode)
            return
    except OSError:
        pass
    shutil.copyfile(src, dst)
    os.chmod(dst, mode)


# ---------------------------------------------------------------- registry
def load() -> dict:
    with _lock:
        try:
            d = json.loads(REG_FILE.read_text())
        except Exception:
            d = {}
        d.setdefault("domains", {})
        d.setdefault("panel", {"domain": ""})
        return d


def save(d: dict) -> None:
    with _lock:
        config.DATA_DIR.mkdir(parents=True, exist_ok=True)
        tmp = REG_FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, indent=1))
        os.chmod(tmp, 0o600)
        os.replace(tmp, REG_FILE)


def panel_domain() -> str:
    return load()["panel"].get("domain", "")


# ---------------------------------------------------------------- certificate parsing
def cert_info(path) -> dict:
    p = Path(path)
    if not p.exists():
        return {"ok": False, "error": "فایل گواهی پیدا نشد"}
    r = sh(["openssl", "x509", "-in", str(p), "-noout", "-enddate", "-issuer", "-ext", "subjectAltName"], 10)
    if r.returncode != 0:
        return {"ok": False, "error": "فایل گواهی خوانده نشد"}
    text = r.stdout
    end = re.search(r"notAfter=(.+)", text)
    names = re.findall(r"DNS:([^\s,]+)", text)
    org = re.search(r"issuer=.*?\bO\s*=\s*([^,\n]+)", text)
    expires = 0
    if end:
        expires = int(datetime.strptime(end.group(1).strip(), "%b %d %H:%M:%S %Y %Z")
                      .replace(tzinfo=timezone.utc).timestamp())
    return {"ok": True, "names": names, "expires": expires, "issuer": (org.group(1).strip() if org else ""),
            "days_left": int((expires - time.time()) // 86400) if expires else None}


def key_matches(cert: str, key: str) -> bool:
    a = sh(["openssl", "x509", "-in", cert, "-noout", "-pubkey"], 10)
    b = sh(["openssl", "pkey", "-in", key, "-pubout"], 10)
    return a.returncode == 0 and b.returncode == 0 and a.stdout.strip() == b.stdout.strip() != ""


# ---------------------------------------------------------------- import (upload / manual paste)
def import_pem(domain: str, cert_text: str, key_text: str) -> dict:
    domain = norm_name(domain)
    ct, kt = (cert_text or "").strip() + "\n", (key_text or "").strip() + "\n"
    if len(ct) > 100_000 or len(kt) > 100_000:
        raise CertError("فایل خیلی بزرگ است")
    if "BEGIN CERTIFICATE" not in ct:
        raise CertError("گواهی معتبر نیست؛ متن باید با BEGIN CERTIFICATE شروع شود")
    if "PRIVATE KEY" not in kt:
        raise CertError("کلید خصوصی معتبر نیست؛ متن باید BEGIN ... PRIVATE KEY داشته باشد")
    if "ENCRYPTED" in kt:
        raise CertError("کلید خصوصی رمزدار است؛ نسخه‌ی بدون رمز لازم است")
    with tempfile.TemporaryDirectory() as td:
        c, k = Path(td) / "c.pem", Path(td) / "k.pem"
        _write(c, ct, 0o600)
        _write(k, kt, 0o600)
        info = cert_info(c)
        if not info["ok"]:
            raise CertError(info["error"])
        if not key_matches(str(c), str(k)):
            raise CertError("کلید خصوصی با این گواهی جور نیست")
        if info["expires"] and info["expires"] < time.time():
            raise CertError("این گواهی منقضی شده است")
        if not names_cover(info["names"], domain):
            raise CertError(f"گواهی برای این دامنه نیست (نام‌های گواهی: {', '.join(info['names']) or '—'})")
        dest = CERT_ROOT / domain
        _write(dest / "fullchain.pem", ct, 0o644)
        _write(dest / "privkey.pem", kt, 0o644)
    with _lock:
        d = load()
        old = d["domains"].get(domain, {})
        d["domains"][domain] = {"source": "manual", "cert": str(dest / "fullchain.pem"),
                                "key": str(dest / "privkey.pem"), "added": old.get("added", int(time.time()))}
        save(d)
    after_change(domain)
    return d["domains"][domain]


# ---------------------------------------------------------------- Cloudflare token (shared with cloudflare.py)
def cf_token() -> str:
    try:
        return json.loads(CF_TOKEN_FILE.read_text()).get("token", "")
    except Exception:
        return ""


def cf_save_token(tok: str, email: str | None = None) -> None:
    try:
        d = json.loads(CF_TOKEN_FILE.read_text())
    except Exception:
        d = {}
    d["token"] = tok
    if email is not None:
        d["email"] = email
    _write(CF_TOKEN_FILE, json.dumps(d), 0o600)
    _write(CF_CRED_FILE, f"dns_cloudflare_api_token = {tok}\n", 0o600)


# ---------------------------------------------------------------- issuing (certbot)
HOOK_SCRIPT = """#!/bin/sh
# Installed by vpnpanel: after certbot renews a cert, copy it to the panel's cert dir and reload services.
cd "{root}" && PANEL_DATA="{data}" exec "{py}" -m app.panelctl deploy-lineage
"""


def install_hook() -> None:
    _write(HOOK_FILE, HOOK_SCRIPT.format(root=str(config.BASE_DIR), data=str(config.DATA_DIR), py=sys.executable), 0o755)


def after_change(domain: str) -> None:
    """Reload things that read certs from disk."""
    if config.DRY_RUN:
        return
    sh(["systemctl", "try-restart", "xray", "sing-box"], 40)
    if domain and domain == panel_domain():
        _sync_default(domain)
        sh(["systemctl", "--no-block", "try-restart", PANEL_SERVICE], 10)
        sh(["systemctl", "--no-block", "try-restart", "vpnpanel-sub"], 10)


def _sync_default(domain: str) -> None:
    """The panel domain's cert doubles as the default cert (settings tls_cert/tls_key) for inbounds."""
    e = load()["domains"].get(domain)
    if e:
        _copy(Path(e["cert"]), CERT_ROOT / "fullchain.pem")
        _copy(Path(e["key"]), CERT_ROOT / "privkey.pem")


def _deploy_from_live(domain: str, certname: str, **meta) -> None:
    live = LE_LIVE / certname
    dest = CERT_ROOT / domain
    with _lock:
        d = load()
        e = d["domains"].get(domain, {})
        cert, key = Path(e.get("cert") or dest / "fullchain.pem"), Path(e.get("key") or dest / "privkey.pem")
        _copy(live / "fullchain.pem", cert)
        _copy(live / "privkey.pem", key)
        d["domains"][domain] = {**e, "cert": str(cert), "key": str(key), "certname": certname,
                                "added": e.get("added", int(time.time())), **meta}
        save(d)
    after_change(domain)


def deploy_lineage(lineage: str) -> int:
    certname = os.path.basename(lineage.rstrip("/"))
    n = 0
    for domain, e in load()["domains"].items():
        if e.get("certname") == certname:
            _deploy_from_live(domain, certname)
            n += 1
    return n


def issue(domain: str, method: str, wildcard: bool, extra: list[str], email: str, log) -> bool:
    domain = norm_name(domain)
    extra = [norm_name(x, allow_wild=True) for x in extra if x.strip()]
    if not shutil.which("certbot"):
        raise CertError("certbot روی سرور نصب نیست؛ اسکریپت apply.sh را اجرا کن")
    names = [domain]
    cmd = ["certbot", "certonly", "--non-interactive", "--agree-tos", "--keep-until-expiring", "--expand"]
    certname = f"vp-{domain}"
    if method == "cloudflare":
        tok = cf_token()
        if not tok:
            raise CertError("ابتدا توکن کلودفلر را وارد کن")
        _write(CF_CRED_FILE, f"dns_cloudflare_api_token = {tok}\n", 0o600)
        if wildcard:
            names.append("*." + domain)
        cmd += ["--dns-cloudflare", "--dns-cloudflare-credentials", str(CF_CRED_FILE),
                "--dns-cloudflare-propagation-seconds", "30"]
    elif method == "http":
        if wildcard or any(x.startswith("*.") for x in extra):
            raise CertError("Wildcard با روش HTTP ممکن نیست؛ از روش کلودفلر استفاده کن")
        cmd += ["--standalone", "--preferred-challenges", "http"]
    else:
        raise CertError("روش نامعتبر است")
    names += [x for x in extra if x not in names]
    cmd += ["--cert-name", certname]
    cmd += ["-m", email] if email else ["--register-unsafely-without-email"]
    for n in names:
        cmd += ["-d", n]
    install_hook()
    log("$ " + " ".join(cmd) + "\n")
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=900)
    out = p.stdout + p.stderr
    tok = cf_token()
    log((out.replace(tok, "***") if tok else out) + "\n")
    if p.returncode != 0:
        return False
    _deploy_from_live(domain, certname, source=method, method=method, wildcard=bool(wildcard), extra=extra)
    log("گواهی نصب شد.\n")
    return True


def start_job(domain: str, method: str, wildcard: bool, extra: list[str], email: str) -> None:
    domain = norm_name(domain)
    with _lock:
        if job["state"] == "running":
            raise CertError("یک درخواست گواهی در حال اجراست")
        job.update(state="running", log="", domain=domain, started=int(time.time()), finished=0)

    def run():
        try:
            ok = issue(domain, method, wildcard, extra, email, lambda s: job.__setitem__("log", job["log"] + s))
            job["state"] = "ok" if ok else "error"
        except subprocess.TimeoutExpired:
            job["log"] += "timeout: بیشتر از ۱۵ دقیقه طول کشید\n"
            job["state"] = "error"
        except Exception as e:
            job["log"] += f"error: {e}\n"
            job["state"] = "error"
        finally:
            job["finished"] = int(time.time())
    threading.Thread(target=run, daemon=True).start()


# ---------------------------------------------------------------- panel TLS
def set_panel(domain: str) -> dict:
    domain = norm_name(domain)
    with _lock:
        d = load()
        e = d["domains"].get(domain)
        if not e:
            raise CertError("این دامنه در لیست نیست")
        info = cert_info(e["cert"])
        if not info["ok"]:
            raise CertError(info["error"])
        if info["expires"] and info["expires"] < time.time():
            raise CertError("گواهی این دامنه منقضی شده است")
        if not key_matches(e["cert"], e["key"]):
            raise CertError("کلید و گواهی این دامنه جور نیستند")
        d["panel"]["domain"] = domain
        save(d)
    _sync_default(domain)
    return info


def clear_panel() -> None:
    with _lock:
        d = load()
        d["panel"]["domain"] = ""
        save(d)


def remove_domain(domain: str) -> None:
    domain = norm_name(domain)
    with _lock:
        d = load()
        if d["panel"].get("domain") == domain:
            raise CertError("این دامنه الان دامنه‌ی پنل است؛ اول HTTPS پنل را غیرفعال کن یا دامنه‌ی دیگری انتخاب کن")
        e = d["domains"].pop(domain, None)
        if e is None:
            raise CertError("این دامنه در لیست نیست")
        save(d)
    if e.get("certname") and shutil.which("certbot") and not config.DRY_RUN:
        sh(["certbot", "delete", "--non-interactive", "--cert-name", e["certname"]], 60)
    dest = CERT_ROOT / domain
    if dest.is_dir() and str(dest).startswith(str(CERT_ROOT) + os.sep):
        shutil.rmtree(dest, ignore_errors=True)


def ensure_migrated() -> None:
    """Adopt the single cert from the first Cloudflare version (/etc/ssl/vpnpanel/fullchain.pem)."""
    d = load()
    top = CERT_ROOT / "fullchain.pem"
    if d["domains"] or not top.exists():
        return
    info = cert_info(top)
    names = [n[2:] if n.startswith("*.") else n for n in info.get("names", [])] if info["ok"] else []
    if not names:
        return
    domain = sorted(names, key=len)[0]
    legacy = (LE_LIVE / "vpnpanel").exists()
    d["domains"][domain] = {"source": "cloudflare" if legacy else "manual", "cert": str(top),
                            "key": str(CERT_ROOT / "privkey.pem"), "added": int(time.time()),
                            **({"certname": "vpnpanel", "method": "cloudflare",
                                "wildcard": any(n.startswith("*.") for n in info["names"]), "extra": []}
                               if legacy else {})}
    save(d)


# ---------------------------------------------------------------- host guard
_names_cache: dict = {}


def allowed_hosts() -> list[str]:
    """Every name covered by a registered certificate. Each domain is served with its own certificate
    (SNI); when SNI is unavailable the panel cert still decides what the browser accepts."""
    d = load()
    if not d["panel"].get("domain", ""):
        return []
    names: list[str] = []
    for dom, e in d["domains"].items():
        try:
            m = os.stat(e["cert"]).st_mtime
        except OSError:
            names.append(dom)
            continue
        key = (e["cert"], m)
        v = _names_cache.get(key)
        if v is None:
            info = cert_info(e["cert"])
            v = (info.get("names") or [dom]) if info["ok"] else [dom]
            _names_cache[key] = v
        names += v
    return names


def host_allowed(host: str) -> bool:
    host = (host or "").strip().lower()
    if host.startswith("["):
        host = host.split("]")[0] + "]"
    elif host.count(":") == 1:
        host = host.rsplit(":", 1)[0]
    if not host or is_ip(host):
        return False
    return names_cover(allowed_hosts(), host)
