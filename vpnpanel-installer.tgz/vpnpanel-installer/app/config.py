import os
from pathlib import Path

BASE_DIR = Path(os.environ.get("PANEL_HOME", Path(__file__).resolve().parent.parent))
DATA_DIR = Path(os.environ.get("PANEL_DATA", BASE_DIR / "data"))
DB_PATH = DATA_DIR / "panel.db"
SECRET_FILE = DATA_DIR / "secret.key"
INITIAL_ADMIN_FILE = DATA_DIR / "initial_admin.txt"
STATIC_DIR = BASE_DIR / "static"

XRAY_BIN = os.environ.get("XRAY_BIN", "/usr/local/bin/xray")
XRAY_CONFIG = Path(os.environ.get("XRAY_CONFIG", "/usr/local/etc/xray/config.json"))
XRAY_API = os.environ.get("XRAY_API", "127.0.0.1:10085")
XRAY_SERVICE = os.environ.get("XRAY_SERVICE", "xray")

SINGBOX_BIN = os.environ.get("SINGBOX_BIN", "/usr/bin/sing-box")
SINGBOX_CONFIG = Path(os.environ.get("SINGBOX_CONFIG", "/etc/sing-box/config.json"))
SINGBOX_SERVICE = os.environ.get("SINGBOX_SERVICE", "sing-box")

WG_IFACE = os.environ.get("WG_IFACE", "wg0")
WG_CONFIG = Path(os.environ.get("WG_CONFIG", f"/etc/wireguard/{WG_IFACE}.conf"))

# When 1, the panel never touches system services or config files (useful for development).
DRY_RUN = os.environ.get("PANEL_DRY_RUN", "0") == "1"

TOKEN_TTL = int(os.environ.get("PANEL_TOKEN_TTL", 60 * 60 * 12))
