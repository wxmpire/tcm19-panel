"""Extra servers ("nodes"): the panel pushes the Xray config to each node's agent, reads traffic back,
and adds each node's connections to the users' subscriptions. Users, quotas and subscriptions stay in this panel."""
import base64
import hashlib
import hmac
import http.client
import json
import re
import ssl
import time

from . import config, db, xray_config

ELIGIBLE_PROTOS = {"vless", "vmess", "trojan", "shadowsocks"}
JOIN_PREFIX = "tcmn1."
_applied: dict[int, str] = {}
_wg_last: dict[int, dict] = {}
_state: dict[int, dict] = {}


class NodeError(Exception):
    pass


# ---------- storage ----------
def _row(r) -> dict:
    d = dict(r)
    d["enabled"] = bool(d["enabled"])
    d["wg"] = bool(d.get("wg"))
    try:
        d["inbound_ids"] = [int(x) for x in json.loads(d.get("inbound_ids") or "[]")]
    except (ValueError, TypeError):
        d["inbound_ids"] = []
    return d


def list_nodes() -> list[dict]:
    with db.tx() as c:
        return [_row(r) for r in c.execute("SELECT * FROM nodes ORDER BY id")]


def get_node(nid: int) -> dict | None:
    with db.tx() as c:
        r = c.execute("SELECT * FROM nodes WHERE id=?", (nid,)).fetchone()
        return _row(r) if r else None


def parse_join(code: str) -> dict:
    code = (code or "").strip()
    if not code.startswith(JOIN_PREFIX):
        raise NodeError("کد اتصال نامعتبر است (باید با tcmn1. شروع شود)")
    try:
        raw = code[len(JOIN_PREFIX):]
        d = json.loads(base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)))
        port, sec, fp = int(d["p"]), str(d["s"]), str(d["f"]).lower()
    except (ValueError, KeyError, TypeError):
        raise NodeError("کد اتصال خراب است")
    if not (1 <= port <= 65535 and re.fullmatch(r"[0-9a-f]{64}", fp) and 16 <= len(sec) <= 128):
        raise NodeError("کد اتصال نامعتبر است")
    return {"port": port, "secret": sec, "fp": fp}


def add_node(name: str, address: str, join: str) -> int:
    j = parse_join(join)
    with db.tx() as c:
        return c.execute("INSERT INTO nodes(name,address,port,secret,fp,created_at) VALUES (?,?,?,?,?,?)",
                         (name, address, j["port"], j["secret"], j["fp"], db.now())).lastrowid


def update_node(nid: int, fields: dict):
    sets, args = [], []
    for k in ("name", "address", "enabled", "wg"):
        if k in fields:
            sets.append(f"{k}=?")
            args.append(int(fields[k]) if isinstance(fields[k], bool) else fields[k])
    if "inbound_ids" in fields:
        sets.append("inbound_ids=?")
        args.append(json.dumps(fields["inbound_ids"]))
    if "join" in fields and fields["join"]:
        j = parse_join(fields["join"])
        sets += ["port=?", "secret=?", "fp=?"]
        args += [j["port"], j["secret"], j["fp"]]
    if sets:
        with db.tx() as c:
            c.execute(f"UPDATE nodes SET {', '.join(sets)} WHERE id=?", args + [nid])
    _applied.pop(nid, None)


def delete_node(nid: int) -> bool:
    _applied.pop(nid, None)
    with db.tx() as c:
        return bool(c.execute("DELETE FROM nodes WHERE id=?", (nid,)).rowcount)


def _mark(nid: int, ok: bool, err: str = "", xray: str | None = None):
    with db.tx() as c:
        if ok:
            c.execute("UPDATE nodes SET last_ok=?, last_error='', xray=COALESCE(?,xray) WHERE id=?", (db.now(), xray, nid))
        else:
            c.execute("UPDATE nodes SET last_error=? WHERE id=?", (err[:300], nid))


# ---------- talking to an agent ----------
def sign(secret: str, ts: str, method: str, path: str, body: bytes) -> str:
    return hmac.new(secret.encode(), f"{ts}.{method}.{path}.".encode() + body, hashlib.sha256).hexdigest()


def call(node: dict, method: str, path: str, payload: dict | None = None, timeout: int = 25) -> dict:
    if config.DRY_RUN:
        raise NodeError("dry-run")
    body = json.dumps(payload).encode() if payload is not None else b""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE   # identity is pinned by fingerprint below
    conn = http.client.HTTPSConnection(node["address"], node["port"], timeout=timeout, context=ctx)
    try:
        conn.connect()
        der = conn.sock.getpeercert(binary_form=True) or b""
        if hashlib.sha256(der).hexdigest() != node["fp"]:
            raise NodeError("اثرانگشت گواهی نود با کد اتصال نمی‌خواند (سرور عوض شده؟)")
        ts = str(int(time.time()))
        conn.request(method, path, body=body or None,
                     headers={"X-Ts": ts, "X-Sig": sign(node["secret"], ts, method, path, body),
                              "Content-Type": "application/json"})
        r = conn.getresponse()
        data = r.read(16 * 1024 * 1024)
        if r.status == 401:
            raise NodeError("رد شد (secret نادرست یا ساعت دو سرور اختلاف دارد)")
        if r.status != 200:
            raise NodeError(f"خطای نود: HTTP {r.status}")
        return json.loads(data or b"{}")
    except (OSError, ssl.SSLError, http.client.HTTPException, ValueError) as e:
        raise NodeError(f"اتصال به نود ممکن نشد: {e}")
    finally:
        conn.close()


# ---------- config ----------
def eligible(ib: dict) -> bool:
    return (ib["engine"] == "xray" and ib["enabled"] and ib["protocol"] in ELIGIBLE_PROTOS
            and ib["security"] in ("reality", "none") and ib["network"] not in ("kcp", "udp"))


def node_inbounds(node: dict, inbounds: list[dict]) -> list[dict]:
    ok = [i for i in inbounds if eligible(i)]
    if node["inbound_ids"]:
        ok = [i for i in ok if i["id"] in node["inbound_ids"]]
    return ok


def build_config(node: dict, settings: dict, inbounds: list[dict], users: list[dict]) -> dict:
    return xray_config.build(node_inbounds(node, inbounds), users, settings, None, None)


def wg_ready(settings: dict) -> bool:
    return settings.get("wg_enabled") == "1" and bool(settings.get("wg_server_private"))


def wg_payload(node: dict, settings: dict, users: list[dict]) -> dict:
    if not node.get("wg") or not wg_ready(settings):
        return {"enabled": False}
    from . import system
    return {"enabled": True, "conf": system.wg_node_config(settings, users), "port": int(settings.get("wg_port", 51820))}


def apply_one(node: dict, settings: dict, inbounds: list[dict], users: list[dict]) -> str:
    ibs = node_inbounds(node, inbounds)
    cfg = xray_config.build(ibs, users, settings, None, None)
    wg = wg_payload(node, settings, users)
    h = hashlib.sha256(json.dumps([cfg, wg], sort_keys=True).encode()).hexdigest()
    if _applied.get(node["id"]) == h:
        return "unchanged"
    try:
        r = call(node, "POST", "/apply", {"config": cfg, "ports": [{"port": i["port"], "proto": "tcp"} for i in ibs], "wireguard": wg}, 90)
    except NodeError as e:
        _applied.pop(node["id"], None)
        _mark(node["id"], False, str(e))
        return f"error: {e}"
    if not r.get("ok"):
        _applied.pop(node["id"], None)
        _mark(node["id"], False, r.get("error", "apply failed"))
        return f"error: {r.get('error', '')}"
    _applied[node["id"]] = h
    _mark(node["id"], True)
    return "written" if r.get("changed") else "unchanged"


def apply_all(settings: dict, inbounds: list[dict], users: list[dict]) -> dict | str:
    res = {}
    for n in list_nodes():
        if n["enabled"]:
            res[n["name"]] = apply_one(n, settings, inbounds, users)
    return res or "no nodes"


def read_traffic(split: dict | None = None) -> dict[int, int]:
    from . import system
    totals: dict[int, int] = {}
    for n in list_nodes():
        if not n["enabled"] or not n["last_ok"]:
            continue
        try:
            r = call(n, "POST", "/stats", {}, 8)
        except NodeError as e:
            _mark(n["id"], False, str(e))
            continue
        if r.get("ok"):
            _mark(n["id"], True)
            for uid, b in system.parse_xray_stats(r.get("stat", []), split).items():
                totals[uid] = totals.get(uid, 0) + b
            if n.get("wg") and r.get("wg"):
                users = db.all_users()
                last = _wg_last.setdefault(n["id"], {})
                for uid, b in system.wg_deltas(r["wg"], users, split, last).items():
                    totals[uid] = totals.get(uid, 0) + b
    return totals


def wg_nodes() -> list[dict]:
    return [n for n in list_nodes() if n["enabled"] and n["last_ok"] and n["wg"]]


def check(node: dict) -> dict:
    """Status of one node (used by the panel's test button and refreshed on a timer)."""
    try:
        st = call(node, "GET", "/status", None, 10)
    except NodeError as e:
        _mark(node["id"], False, str(e))
        return {"ok": False, "error": str(e)}
    _mark(node["id"], True, xray=st.get("xray", ""))
    return {"ok": True, **st}


# ---------- subscriptions ----------
def sub_inbounds() -> list[dict]:
    """All inbounds + a copy per (healthy node, eligible inbound) that points to the node's address."""
    base = db.list_inbounds()
    extra = []
    for n in list_nodes():
        if not n["enabled"] or not n["last_ok"]:
            continue
        for ib in node_inbounds(n, base):
            v = dict(ib)
            v["settings"] = {**ib["settings"], "address": n["address"]}
            v["remark"] = f"{ib.get('remark') or ib['tag']} @{n['name']}"
            extra.append(v)
    return base + extra
