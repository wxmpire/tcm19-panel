"""API keys for bots / scripts. Only a SHA-256 hash is stored; the key itself is shown once at creation."""
import hashlib
import secrets
import time

from . import db

PREFIX = "tcm_"
_ready = False
_touched: dict[int, float] = {}


def _init():
    global _ready
    if _ready:
        return
    with db.tx() as c:
        c.execute("CREATE TABLE IF NOT EXISTS api_keys (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, "
                  "hash TEXT UNIQUE NOT NULL, hint TEXT NOT NULL, scope TEXT NOT NULL DEFAULT 'read', "
                  "enabled INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL, last_used INTEGER NOT NULL DEFAULT 0)")
    _ready = True


def _h(key: str) -> str:
    return hashlib.sha256(key.encode()).hexdigest()


def create(name: str, scope: str) -> dict:
    _init()
    key = PREFIX + secrets.token_urlsafe(32)
    with db.tx() as c:
        cur = c.execute("INSERT INTO api_keys(name,hash,hint,scope,created_at) VALUES(?,?,?,?,?)",
                        (name, _h(key), key[:8] + "…" + key[-4:], scope, int(time.time())))
        return {"id": cur.lastrowid, "name": name, "scope": scope, "key": key}


def verify(key: str) -> dict | None:
    _init()
    with db.tx() as c:
        r = c.execute("SELECT * FROM api_keys WHERE hash=? AND enabled=1", (_h(key),)).fetchone()
        if not r:
            return None
        now = time.time()
        if now - _touched.get(r["id"], 0) > 60:  # avoid a write per request
            _touched[r["id"]] = now
            c.execute("UPDATE api_keys SET last_used=? WHERE id=?", (int(now), r["id"]))
        return dict(r)


def list_keys() -> list[dict]:
    _init()
    with db.tx() as c:
        return [{k: r[k] for k in ("id", "name", "hint", "scope", "enabled", "created_at", "last_used")}
                for r in c.execute("SELECT * FROM api_keys ORDER BY id DESC")]


def set_enabled(kid: int, on: bool):
    _init()
    with db.tx() as c:
        c.execute("UPDATE api_keys SET enabled=? WHERE id=?", (int(on), kid))


def delete(kid: int):
    _init()
    with db.tx() as c:
        c.execute("DELETE FROM api_keys WHERE id=?", (kid,))
