"""Domain management API: multiple domains, each with its own certificate (Cloudflare / Let's Encrypt HTTP / upload / paste)."""
import ipaddress
import os
import threading
from urllib.parse import urlparse

from fastapi import Depends, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

from . import certstore as cs, config, db


class ImportIn(BaseModel):
    domain: str
    cert: str
    key: str


class IssueIn(BaseModel):
    domain: str
    method: str = "cloudflare"
    wildcard: bool = True
    extra_names: list[str] = []
    email: str = ""


class PanelIn(BaseModel):
    port: int = 0


def _bad(e: Exception):
    raise HTTPException(400, str(e))


def overview() -> dict:
    cs.ensure_migrated()
    d = cs.load()
    pd = d["panel"].get("domain", "")
    out = []
    for name, e in sorted(d["domains"].items()):
        i = cs.cert_info(e["cert"])
        out.append({"name": name, "source": e.get("source", "manual"), "method": e.get("method", ""),
                    "wildcard": e.get("wildcard", False), "cert": e["cert"], "key": e["key"],
                    "names": i.get("names", []), "expires": i.get("expires", 0), "days_left": i.get("days_left"),
                    "issuer": i.get("issuer", ""), "error": "" if i["ok"] else i["error"], "panel": name == pd})
    import shutil
    return {"domains": out,
            "panel": {"domain": pd, "tls_active": os.environ.get("PANEL_TLS_ACTIVE") == "1",
                      "sni": os.environ.get("PANEL_SNI_ACTIVE") == "1",
                      "allowed": cs.allowed_hosts() if pd else []},
            "certbot": shutil.which("certbot") is not None, "cf_configured": bool(cs.cf_token()),
            "job": {"state": cs.job["state"], "domain": cs.job["domain"], "log": cs.job["log"][-4000:]}}


def _is_ip_host(url: str) -> bool:
    try:
        ipaddress.ip_address(urlparse(url).hostname or "")
        return True
    except ValueError:
        return False


def register(app, admin_required) -> None:
    @app.middleware("http")
    async def host_guard(request, call_next):
        # Once the panel is served over TLS with a domain, it only answers to that domain's names (never by IP).
        if os.environ.get("PANEL_TLS_ACTIVE") == "1":
            ip = request.client.host if request.client else ""
            if ip not in ("127.0.0.1", "::1") and not cs.host_allowed(request.headers.get("host", "")):
                return Response(status_code=404)
        return await call_next(request)

    @app.get("/api/domains")
    def domains_list(_: str = Depends(admin_required)):
        return overview()

    @app.post("/api/domains/import")
    def domains_import(body: ImportIn, _: str = Depends(admin_required)):
        try:
            cs.import_pem(body.domain, body.cert, body.key)
        except cs.CertError as e:
            _bad(e)
        return overview()

    @app.post("/api/domains/issue")
    def domains_issue(body: IssueIn, _: str = Depends(admin_required)):
        email = body.email.strip()
        import re
        if email and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", email):
            raise HTTPException(400, "ایمیل نامعتبر است")
        if len(body.extra_names) > 10:
            raise HTTPException(400, "حداکثر ۱۰ نام اضافه")
        try:
            cs.start_job(body.domain, body.method, body.wildcard, body.extra_names, email)
        except cs.CertError as e:
            _bad(e)
        return overview()

    @app.delete("/api/domains/{domain}")
    def domains_delete(domain: str, _: str = Depends(admin_required)):
        try:
            cs.remove_domain(domain)
        except cs.CertError as e:
            _bad(e)
        return overview()

    @app.post("/api/domains/{domain}/panel")
    def domains_set_panel(domain: str, body: PanelIn, _: str = Depends(admin_required)):
        try:
            domain = cs.norm_name(domain)
            cs.set_panel(domain)
        except cs.CertError as e:
            _bad(e)
        port = body.port if 0 < body.port < 65536 else 0
        s = db.get_settings()
        upd = {}
        if not s.get("server_address") or cs.is_ip(s["server_address"]):
            upd["server_address"] = domain
        sb = s.get("sub_base_url", "")
        if not sb or _is_ip_host(sb):
            upd["sub_base_url"] = f"https://{domain}" + (f":{port}" if port and port != 443 else "")
        if upd:
            db.set_settings(upd)
        if not config.DRY_RUN:
            threading.Timer(1.5, lambda: (cs.sh(["systemctl", "--no-block", "restart", cs.PANEL_SERVICE], 10), cs.sh(["systemctl", "--no-block", "try-restart", "vpnpanel-sub"], 10))).start()
        return {"url": f"https://{domain}" + (f":{port}" if port and port != 443 else ""), **overview()}

    @app.post("/api/panel/tls/disable")
    def panel_tls_disable(_: str = Depends(admin_required)):
        cs.clear_panel()
        if not config.DRY_RUN:
            threading.Timer(1.5, lambda: (cs.sh(["systemctl", "--no-block", "restart", cs.PANEL_SERVICE], 10), cs.sh(["systemctl", "--no-block", "try-restart", "vpnpanel-sub"], 10))).start()
        return overview()
