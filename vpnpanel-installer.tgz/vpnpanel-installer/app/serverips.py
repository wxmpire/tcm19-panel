"""Server IP addresses: detected on this machine + added by hand; one of them is the default (settings.server_address)."""
import ipaddress
import json
import re

from . import certstore as cs, db

SKIP_IFACE = ("lo", "docker", "veth", "br-", "virbr", "wg", "tun", "tap", "cni", "flannel", "cali", "kube")


class IpError(Exception):
    pass


def detect() -> list[str]:
    r = cs.sh(["ip", "-4", "-o", "addr", "show", "scope", "global"], 10)
    out: list[str] = []
    for line in (r.stdout or "").splitlines():
        m = re.match(r"\d+:\s+(\S+)\s+inet\s+(\d+\.\d+\.\d+\.\d+)/", line)
        if not m or m.group(1).startswith(SKIP_IFACE):
            continue
        try:
            ip = ipaddress.ip_address(m.group(2))
        except ValueError:
            continue
        if ip.is_global and m.group(2) not in out:
            out.append(m.group(2))
    return out


def manual() -> list[str]:
    try:
        v = json.loads(db.get_settings().get("server_ips") or "[]")
        return [x for x in v if isinstance(x, str)]
    except ValueError:
        return []


def _save(items: list[str]) -> None:
    db.set_settings({"server_ips": json.dumps(items)})


def listing() -> dict:
    s = db.get_settings()
    default = (s.get("server_address") or "").strip()
    det, man = detect(), manual()
    items = [{"ip": ip, "source": "detected", "default": ip == default} for ip in det]
    items += [{"ip": ip, "source": "manual", "default": ip == default} for ip in man if ip not in det]
    return {"default": default, "items": items}


def norm(raw: str) -> str:
    raw = (raw or "").strip()
    try:
        ip = ipaddress.IPv4Address(raw)
    except ValueError:
        raise IpError("آدرس IPv4 معتبر نیست (مثل 203.0.113.10)")
    if ip.is_loopback or ip.is_unspecified or ip.is_multicast or ip.is_link_local or ip.is_reserved:
        raise IpError("این آدرس قابل استفاده نیست")
    return str(ip)


def add(raw: str) -> dict:
    ip = norm(raw)
    if ip in detect() or ip in manual():
        raise IpError("این آدرس از قبل توی لیست هست")
    _save(manual() + [ip])
    return listing()


def remove(raw: str) -> dict:
    ip = (raw or "").strip()
    cur = listing()
    row = next((i for i in cur["items"] if i["ip"] == ip), None)
    if not row:
        raise IpError("آدرس توی لیست نیست")
    if row["source"] != "manual":
        raise IpError("آدرسی که روی خود سرور پیدا شده حذف نمی‌شود")
    if row["default"]:
        raise IpError("این آدرس پیش‌فرض است. اول یک آدرس دیگر را پیش‌فرض کن")
    _save([x for x in manual() if x != ip])
    return listing()


def make_default(raw: str) -> dict:
    ip = (raw or "").strip()
    if not any(i["ip"] == ip for i in listing()["items"]):
        raise IpError("آدرس توی لیست نیست")
    db.set_settings({"server_address": ip})
    return listing()
