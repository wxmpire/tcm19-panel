"""Tunnel kinds that run third party programs or kernel interfaces, driven by one schema per kind.

  socat gost chisel frp rathole backhaul   programs kept alive by a systemd unit
  gre ipip vxlan wg                        kernel / WireGuard interfaces (systemd oneshot)
  combo                                    chain: a local port that forwards into another tunnel

Every kind has: META (texts + form fields), normalize(), render() (files for THIS server),
guide() (step by step instructions for the OTHER server) and info() (data used by health / benchmark).
"""
import io
import ipaddress
import json
import re
import secrets
import shlex
import shutil
import socket
import stat
import tarfile
import urllib.request
import zipfile
import gzip
from pathlib import Path

from . import config

BIN_DIR = Path("/usr/local/bin")
CONF_DIR_REMOTE = "/etc/tcm19-tunnel"

# ------------------------------------------------------------------ programs
# "re": release asset regex ({A} = amd64|arm64, {X} = x86_64|aarch64). "bins": files taken out of the archive.
TOOLS = {
    "socat":    {"apt": "socat", "bins": ["socat"]},
    "gost":     {"repo": "go-gost/gost", "re": r"linux_{A}\.tar\.gz$", "bins": ["gost"]},
    "chisel":   {"repo": "jpillora/chisel", "re": r"linux_{A}\.gz$", "bins": ["chisel"]},
    "frp":      {"repo": "fatedier/frp", "re": r"linux_{A}\.tar\.gz$", "bins": ["frps", "frpc"]},
    "rathole":  {"repo": "rapiz1/rathole", "re": r"rathole-{X}-unknown-linux-(gnu|musl)\.zip$", "bins": ["rathole"]},
    "backhaul": {"repo": "Musixal/Backhaul", "re": r"linux_{A}\.tar\.gz$", "bins": ["backhaul"]},
    "wireguard": {"apt": "wireguard-tools", "bins": ["wg", "wg-quick"]},
    "iproute2": {"apt": "iproute2", "bins": ["ip"]},
}
ARCH = {"x86_64": ("amd64", "x86_64"), "amd64": ("amd64", "x86_64"), "aarch64": ("arm64", "aarch64"), "arm64": ("arm64", "aarch64")}


def bin_path(name: str) -> str | None:
    p = shutil.which(name)
    if p:
        return p
    q = BIN_DIR / name
    return str(q) if q.exists() else None


def tool_status() -> dict:
    out = {}
    for k, v in TOOLS.items():
        paths = {b: bin_path(b) for b in v["bins"]}
        out[k] = {"installed": all(paths.values()), "paths": paths, "auto": "repo" in v or "apt" in v,
                  "repo": v.get("repo", ""), "apt": v.get("apt", "")}
    return out


def pick_asset(tool: str, names: list[str], machine: str) -> str | None:
    a = ARCH.get(machine)
    if not a or "re" not in TOOLS[tool]:
        return None
    pat = re.compile(TOOLS[tool]["re"].format(A=a[0], X=a[1]))
    hits = [n for n in names if pat.search(n)]
    hits.sort(key=lambda n: ("musl" in n, len(n)))
    return hits[0] if hits else None


def _extract(tool: str, data: bytes, asset: str) -> dict[str, bytes]:
    want = TOOLS[tool]["bins"]
    out: dict[str, bytes] = {}
    if asset.endswith(".tar.gz"):
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
            for m in tf.getmembers():
                base = Path(m.name).name
                if m.isfile() and base in want:
                    out[base] = tf.extractfile(m).read()
    elif asset.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            for n in zf.namelist():
                if Path(n).name in want and not n.endswith("/"):
                    out[Path(n).name] = zf.read(n)
    elif asset.endswith(".gz"):
        out[want[0]] = gzip.decompress(data)
    return out


def install_tool(tool: str) -> str:
    """Install a program (apt package or latest GitHub release). Returns a short message, raises RuntimeError."""
    if tool not in TOOLS:
        raise RuntimeError("برنامه ناشناخته است")
    spec = TOOLS[tool]
    if config.DRY_RUN:
        return "dry-run"
    from .system import run
    if "apt" in spec:
        code, out = run(["apt-get", "install", "-y", spec["apt"]], 300)
        if code != 0:
            raise RuntimeError(f"نصب با apt ناموفق بود: {out[-300:]}")
        return "نصب شد"
    import platform
    machine = platform.machine()
    if machine not in ARCH:
        raise RuntimeError(f"معماری {machine} پشتیبانی نمی‌شود")
    try:
        req = urllib.request.Request(f"https://api.github.com/repos/{spec['repo']}/releases/latest",
                                     headers={"User-Agent": "tcm19-panel", "Accept": "application/vnd.github+json"})
        rel = json.load(urllib.request.urlopen(req, timeout=30))
    except Exception as e:
        raise RuntimeError(f"دسترسی به GitHub ممکن نشد: {e}")
    assets = {a["name"]: a["browser_download_url"] for a in rel.get("assets", [])}
    name = pick_asset(tool, list(assets), machine)
    if not name:
        raise RuntimeError("فایل مناسب این سیستم در آخرین نسخه پیدا نشد")
    try:
        data = urllib.request.urlopen(urllib.request.Request(assets[name], headers={"User-Agent": "tcm19-panel"}),
                                      timeout=180).read()
        files = _extract(tool, data, name)
    except Exception as e:
        raise RuntimeError(f"دانلود یا باز کردن فایل ناموفق بود: {e}")
    if set(files) != set(spec["bins"]):
        raise RuntimeError("فایل اجرایی داخل بسته پیدا نشد")
    BIN_DIR.mkdir(parents=True, exist_ok=True)
    for b, content in files.items():
        tmp = BIN_DIR / f".{b}.new"
        tmp.write_bytes(content)
        tmp.chmod(0o755)
        tmp.replace(BIN_DIR / b)
    return f"{rel.get('tag_name', '')} نصب شد"


def _install_snippet(tool: str) -> str:
    """Shell snippet for the OTHER server (same asset rules as install_tool)."""
    spec = TOOLS[tool]
    if "apt" in spec:
        return f"apt-get update -y && apt-get install -y {spec['apt']}"
    pat = spec["re"].replace("{A}", "$A").replace("{X}", "$X")
    bins = " ".join(spec["bins"])
    return (
        'A=amd64; X=x86_64; [ "$(uname -m)" = aarch64 ] && { A=arm64; X=aarch64; }\n'
        f"U=$(curl -fsSL https://api.github.com/repos/{spec['repo']}/releases/latest | grep -o 'https://[^\"]*' | grep -E \"{pat}\" | head -1)\n"
        '[ -n "$U" ] || { echo "release not found"; exit 1; }\n'
        'D=$(mktemp -d); curl -fsSL "$U" -o $D/pkg\n'
        'case "$U" in *.tar.gz) tar xzf $D/pkg -C $D;; *.zip) unzip -oq $D/pkg -d $D;; *.gz) gunzip -c $D/pkg > $D/' + spec["bins"][0] + ';; esac\n'
        f'for b in {bins}; do install -m755 "$(find $D -type f -name $b | head -1)" /usr/local/bin/$b; done'
    )


# ------------------------------------------------------------------ helpers
class _E(Exception):
    pass


def _T():
    from . import tunnels
    return tunnels


def F(k, label, t="text", **kw):
    return {"k": k, "label": label, "type": t, **kw}


ROLE_SRV = ["server", "این سرور «سرور» است: کاربرها به همین سرور وصل می‌شوند و سرور مقابل خودش وصل می‌شود"]
ROLE_CLI = ["client", "این سرور «کلاینت» است: خودش به سرور مقابل وصل می‌شود"]
NET = [["tcp", "فقط TCP"], ["udp", "فقط UDP"], ["tcp,udp", "TCP + UDP"]]
NET_TCP = [["tcp", "فقط TCP"], ["tcp,udp", "TCP + UDP"]]


def _role_field(label="نقش این سرور"):
    return F("role", label, "select", options=[ROLE_SRV, ROLE_CLI], default="server")


PEER = F("peer_host", "آدرس سرور مقابل (اختیاری، برای راهنما و تست)", "host", ex="5.6.7.8", optional=True)
CTL = F("ctl_port", "پورت کنترل (خالی = خودکار)", "port", optional=True, show={"role": ["server"]}, help="سرور مقابل از همین پورت به این سرور وصل می‌شود.")
REMOTE = [F("remote_host", "آدرس سرور مقابل", "host", show={"role": ["client"]}, ex="5.6.7.8"),
          F("remote_port", "پورت کنترل سرور مقابل", "port", show={"role": ["client"]}, ex="4000")]

META: dict[str, dict] = {
    "socat": dict(
        title="socat (فوروارد پروسه‌ای)", enc=False, perf=[4, 5, 1, 5],
        short="فوروارد TCP/UDP با برنامه‌ی socat؛ ساده‌تر و قابل‌اعتمادتر از iptables وقتی کرنل فوروارد رو مسدود می‌کنه.",
        what="هر اتصال به پورت این سرور توسط socat باز و به مقصد وصل می‌شود. برخلاف DNAT، مقصد می‌تواند لوکال یا دامنه باشد.",
        when="وقتی DNAT کار نمی‌کند یا مقصد 127.0.0.1 است، یا می‌خواهی یک تونل دیگر را زنجیره کنی.",
        pros="خیلی ساده، پایدار، TCP و UDP.", cons="رمزنگاری ندارد و برای هر اتصال یک پروسه می‌سازد (روی ترافیک خیلی زیاد از DNAT سنگین‌تر است).",
        fields=[F("port", "پورت این سرور", "port", req=True, ex="8443"), F("target_host", "آدرس مقصد", "host", ex="1.2.3.4"),
                F("target_port", "پورت مقصد", "port", ex="443"), F("network", "شبکه", "select", options=NET, default="tcp")]),
    "gost": dict(
        title="GOST (رمزدار، چندجهشی)", enc=True, perf=[3, 4, 4, 3],
        short="تونل رمزدار با پروتکل relay روی TLS/WebSocket/gRPC/QUIC/KCP؛ پشتیبانی از چند هاپ پشت‌سرهم.",
        what="یک سرور «ورودی» ترافیک را از طریق یک یا چند سرور واسطه به خروجی می‌رساند. کل مسیر رمزدار و (با wss/tls) شبیه HTTPS است.",
        when="وقتی تونل ساده فیلتر می‌شود یا می‌خواهی مسیر ایران ← واسطه ← خارج با چند هاپ بسازی.",
        pros="رمزدار، ظاهر HTTPS/WebSocket، TCP+UDP، چند هاپ، تنظیم ساده.", cons="روی هر دو سرور باید gost باشد. سرعتش از Backhaul/Rathole کمتر است.",
        fields=[F("role", "نقش این سرور", "select", options=[["entry", "ورودی: کاربرها به این سرور وصل می‌شوند، ترافیک به سرور مقابل می‌رود"], ["exit", "خروجی: سرور مقابل (ورودی) به این سرور وصل می‌شود"]], default="entry"),
                F("transport", "ترنسپورت", "select", options=[["tls", "TLS"], ["wss", "WebSocket + TLS (wss)"], ["ws", "WebSocket"], ["mwss", "mux + wss"], ["grpc", "gRPC"], ["tcp", "TCP ساده"], ["quic", "QUIC (UDP)"], ["kcp", "KCP (UDP)"]], default="tls"),
                F("port", "پورت", "port", req=True, ex="8443", help="ورودی: پورت کاربرها. خروجی: پورتی که gost روی آن گوش می‌دهد."),
                F("target_host", "آدرس مقصد (از دید سرور خروجی)", "host", show={"role": ["entry"]}, ex="127.0.0.1"),
                F("target_port", "پورت مقصد", "port", show={"role": ["entry"]}, ex="443"),
                F("network", "شبکه‌ی ورودی", "select", options=NET, default="tcp", show={"role": ["entry"]}),
                F("remote_host", "آدرس سرور اول مسیر (خروجی یا هاپ اول)", "host", show={"role": ["entry"]}, ex="5.6.7.8"),
                F("remote_port", "پورت gost روی آن سرور", "port", show={"role": ["entry"]}, ex="8443"),
                F("token", "توکن مشترک (خالی = خودکار)", "token", optional=True),
                F("hops", "هاپ‌های بعدی (اختیاری، هر خط host:port)", "hops", optional=True, show={"role": ["entry"]}, help="مسیر: این سرور ← سرور اول ← هاپ‌ها ← آخرین سرور = خروجی."),
                PEER]),
    "chisel": dict(
        title="Chisel (تونل روی HTTP/WebSocket)", enc=True, perf=[3, 3, 3, 3],
        short="تونل TCP/UDP داخل WebSocket؛ دو حالت: کلاینت (فوروارد) و سرور (معکوس).",
        what="سرور chisel روی یک پورت گوش می‌دهد؛ کلاینت وصل می‌شود و پورت‌هایی را باز می‌کند. با حالت reverse، سرور مقابل می‌تواند پورت عمومی روی همین سرور باز کند.",
        when="وقتی فقط HTTP/WebSocket از فایروال رد می‌شود یا سرور مقابل پشت NAT است.",
        pros="ظاهر HTTP، رمز عبور، نصب ساده، یک فایل اجرایی.", cons="سرعت متوسط، UDP ضعیف‌تر از TCP.",
        fields=[_role_field(), CTL, *REMOTE, F("token", "توکن مشترک (خالی = خودکار)", "token", optional=True, help="هر دو طرف باید دقیقاً همین توکن را داشته باشند. می‌توانی «تولید» را بزنی یا توکن سرور مقابل را بچسبانی."), F("target_host", "آدرس مقصد", "host", ex="127.0.0.1"), F("fports", "پورت‌های فوروارد", "ports", req=True, ex="443", help="با کاما جدا کن. نمونه: 443,8443:443,53/udp (پورت عمومی:پورت مقصد). بدون /udp یعنی TCP."), PEER]),
    "frp": dict(
        title="FRP (frps / frpc)", enc=False, perf=[4, 4, 2, 3],
        short="تونل معکوس معروف FRP با توکن؛ مناسب سرور پشت NAT.",
        what="frps روی سرور عمومی، frpc روی سروری که سرویس دارد. پورتی که در frps باز می‌شود مستقیم به سرویس می‌رسد.",
        when="سرور مقصد آی‌پی عمومی ندارد، یا پورت ورودی‌اش بسته است.",
        pros="پایدار و پرکاربرد، TCP+UDP، پشتیبانی TCP/KCP/QUIC/WebSocket، توکن.", cons="بدون رمزنگاری اضافه (روی TCP ساده)؛ توکن فقط احراز هویت است.",
        fields=[_role_field(), F("transport", "ترنسپورت اتصال کنترل", "select", options=[["tcp", "TCP"], ["websocket", "WebSocket"], ["kcp", "KCP (UDP)"], ["quic", "QUIC (UDP)"]], default="tcp"), CTL, *REMOTE, F("token", "توکن مشترک (خالی = خودکار)", "token", optional=True, help="هر دو طرف باید دقیقاً همین توکن را داشته باشند. می‌توانی «تولید» را بزنی یا توکن سرور مقابل را بچسبانی."), F("target_host", "آدرس سرویس (از دید کلاینت)", "host", ex="127.0.0.1"), F("fports", "پورت‌های فوروارد", "ports", req=True, ex="443", help="با کاما جدا کن. نمونه: 443,8443:443,53/udp (پورت عمومی:پورت مقصد). بدون /udp یعنی TCP."), PEER]),
    "rathole": dict(
        title="Rathole (سبک و سریع)", enc=False, perf=[5, 5, 2, 3],
        short="تونل معکوس سبک و بسیار سریع (نوشته‌شده با Rust).",
        what="مثل FRP ولی خیلی سبک‌تر: سرور روی پورت کنترل گوش می‌دهد، کلاینت وصل می‌شود و سرویس را از پورت عمومی سرور در دسترس می‌گذارد.",
        when="وقتی سرعت و مصرف کم CPU مهم است و سرور مقصد پشت NAT یا فایروال است.",
        pros="سرعت بالا، مصرف خیلی کم، TCP+UDP.", cons="در این پنل فقط ترنسپورت TCP ساده؛ بدون رمزنگاری (توکن فقط احراز هویت است).",
        fields=[_role_field(), CTL, *REMOTE, F("token", "توکن مشترک (خالی = خودکار)", "token", optional=True, help="هر دو طرف باید دقیقاً همین توکن را داشته باشند. می‌توانی «تولید» را بزنی یا توکن سرور مقابل را بچسبانی."), F("target_host", "آدرس سرویس (از دید کلاینت)", "host", ex="127.0.0.1"), F("fports", "پورت‌های فوروارد", "ports", req=True, ex="443", help="با کاما جدا کن. نمونه: 443,8443:443,53/udp (پورت عمومی:پورت مقصد). بدون /udp یعنی TCP."), PEER]),
    "backhaul": dict(
        title="Backhaul (سرعت بالا)", enc=False, perf=[5, 5, 3, 3],
        short="تونل معکوس پرسرعت با ترنسپورت TCP، mux، UDP و WebSocket؛ محبوب بین کاربران ایران.",
        what="سرور (معمولاً ایران) پورت‌ها را باز می‌کند و کلاینت (خارج) خودش وصل می‌شود و ترافیک را به مقصد می‌رساند. اتصال‌های آماده (pool) تأخیر را کم می‌کنند.",
        when="وقتی بهترین سرعت و تأخیر مهم است و می‌خواهی سرور خارج پورت باز نداشته باشد.",
        pros="خیلی سریع، چند ترنسپورت، توکن، اتصال مجدد خودکار.", cons="روی هر دو سرور باید نصب شود؛ بدون رمزنگاری اضافه (روی Xray/Reality سوار کن).",
        fields=[_role_field(), F("transport", "ترنسپورت", "select", options=[["tcp", "TCP"], ["tcpmux", "TCP + mux (پیشنهادی)"], ["ws", "WebSocket"], ["wsmux", "WebSocket + mux"], ["udp", "UDP"]], default="tcpmux"), CTL, *REMOTE, F("token", "توکن مشترک (خالی = خودکار)", "token", optional=True, help="هر دو طرف باید دقیقاً همین توکن را داشته باشند. می‌توانی «تولید» را بزنی یا توکن سرور مقابل را بچسبانی."), F("target_host", "آدرس مقصد (از دید کلاینت)", "host", ex="127.0.0.1"), F("fports", "پورت‌های فوروارد", "ports", req=True, ex="443", help="با کاما جدا کن. نمونه: 443,8443:443,53/udp (پورت عمومی:پورت مقصد). بدون /udp یعنی TCP."), PEER]),
    "gre": dict(
        title="GRE (تونل لایه ۳)", enc=False, perf=[5, 5, 1, 2],
        short="تونل کرنلی GRE بین دو سرور؛ سریع‌ترین حالت، بدون رمز.",
        what="یک اینترفیس مجازی بین دو سرور ساخته می‌شود. دو سرور با آی‌پی داخلی همدیگر را می‌بینند. اختیاری: یک پورت این سرور به یک پورت سرور مقابل فوروارد می‌شود.",
        when="وقتی هر دو سرور آی‌پی عمومی دارند و پروتکل GRE (۴۷) بین‌شان مسدود نیست.",
        pros="تقریباً بدون سربار، TCP/UDP/ICMP، سرعت کرنل.", cons="رمزنگاری ندارد؛ بعضی دیتاسنترها و ISPها GRE را می‌بندند.",
        fields=[F("remote_ip", "آی‌پی عمومی سرور مقابل", "ip", ex="5.6.7.8"), F("local_ip", "آی‌پی عمومی این سرور (خالی = خودکار)", "ip", optional=True),
                F("inner_local", "آی‌پی داخلی این سرور (خالی = خودکار)", "ip", optional=True), F("inner_remote", "آی‌پی داخلی سرور مقابل (خالی = خودکار)", "ip", optional=True),
                F("mtu", "MTU", "int", default=1400, min=1000, max=1500), F("expose_port", "پورت فوروارد روی این سرور (اختیاری)", "port", optional=True),
                F("target_port", "پورت مقصد روی سرور مقابل", "port", optional=True, ex="443"), F("network", "شبکه‌ی فوروارد", "select", options=NET, default="tcp")]),
    "ipip": dict(
        title="IPIP (تونل لایه ۳ سبک)", enc=False, perf=[5, 5, 1, 2],
        short="مثل GRE ولی با سربار کمتر (فقط IPv4 داخل IPv4).",
        what="اینترفیس مجازی IPIP بین دو سرور؛ سبک‌ترین هدر ممکن.",
        when="وقتی می‌خواهی کمترین سربار را داشته باشی و پروتکل ۴ (IPIP) مسدود نیست.",
        pros="کمترین سربار و سرعت بالا.", cons="بدون رمز، فقط IPv4، بعضی دیتاسنترها بسته‌اش می‌کنند.",
        fields=[F("remote_ip", "آی‌پی عمومی سرور مقابل", "ip", ex="5.6.7.8"), F("local_ip", "آی‌پی عمومی این سرور (خالی = خودکار)", "ip", optional=True),
                F("inner_local", "آی‌پی داخلی این سرور (خالی = خودکار)", "ip", optional=True), F("inner_remote", "آی‌پی داخلی سرور مقابل (خالی = خودکار)", "ip", optional=True),
                F("mtu", "MTU", "int", default=1420, min=1000, max=1500), F("expose_port", "پورت فوروارد روی این سرور (اختیاری)", "port", optional=True),
                F("target_port", "پورت مقصد روی سرور مقابل", "port", optional=True, ex="443"), F("network", "شبکه‌ی فوروارد", "select", options=NET, default="tcp")]),
    "vxlan": dict(
        title="VXLAN (لایه ۲ روی UDP)", enc=False, perf=[4, 4, 1, 2],
        short="تونل VXLAN روی UDP؛ چون UDP است از GRE/IPIP کمتر مسدود می‌شود.",
        what="شبکه‌ی مجازی بین دو سرور روی یک پورت UDP. آی‌پی داخلی مثل GRE تنظیم می‌شود.",
        when="وقتی GRE/IPIP بسته است ولی UDP باز است.",
        pros="روی UDP معمولی کار می‌کند، سرعت خوب.", cons="رمزنگاری ندارد، MTU کوچک‌تر.",
        fields=[F("remote_ip", "آی‌پی عمومی سرور مقابل", "ip", ex="5.6.7.8"), F("local_ip", "آی‌پی عمومی این سرور (خالی = خودکار)", "ip", optional=True),
                F("port", "پورت UDP تونل (هر دو سرور)", "port", req=True, ex="4789"), F("vni", "VNI", "int", default=100, min=1, max=16777215),
                F("inner_local", "آی‌پی داخلی این سرور (خالی = خودکار)", "ip", optional=True), F("inner_remote", "آی‌پی داخلی سرور مقابل (خالی = خودکار)", "ip", optional=True),
                F("mtu", "MTU", "int", default=1380, min=1000, max=1500), F("expose_port", "پورت فوروارد روی این سرور (اختیاری)", "port", optional=True),
                F("target_port", "پورت مقصد روی سرور مقابل", "port", optional=True, ex="443"), F("network", "شبکه‌ی فوروارد", "select", options=NET, default="tcp")]),
    "wg": dict(
        title="WireGuard (تونل رمزدار لایه ۳)", enc=True, perf=[4, 5, 3, 3],
        short="تونل WireGuard بین دو سرور با کلید، رمزدار و سریع.",
        what="پنل هر دو کلید را می‌سازد؛ کانفیگ سرور مقابل در راهنما آماده است. دو سرور با آی‌پی داخلی همدیگر را می‌بینند؛ اختیاری یک پورت فوروارد می‌شود.",
        when="وقتی تونل رمزدار سریع می‌خواهی و UDP باز است.",
        pros="رمزنگاری قوی، سرعت بالا، اتصال مجدد خودکار.", cons="UDP است (بعضی شبکه‌ها فیلتر می‌کنند) و امضای آن شناسایی‌پذیر است.",
        fields=[F("port", "پورت UDP این سرور (ListenPort)", "port", req=True, ex="51821"), F("remote_host", "آدرس سرور مقابل (اختیاری، اگر این سرور باید وصل شود)", "host", optional=True),
                F("remote_port", "پورت WireGuard سرور مقابل", "port", optional=True, ex="51821"),
                F("inner_local", "آی‌پی داخلی این سرور (خالی = خودکار)", "ip", optional=True), F("inner_remote", "آی‌پی داخلی سرور مقابل (خالی = خودکار)", "ip", optional=True),
                F("mtu", "MTU", "int", default=1380, min=1000, max=1500), F("expose_port", "پورت فوروارد روی این سرور (اختیاری)", "port", optional=True),
                F("target_port", "پورت مقصد روی سرور مقابل", "port", optional=True, ex="443"), F("network", "شبکه‌ی فوروارد", "select", options=NET, default="tcp"), PEER]),
    "combo": dict(
        title="ترکیبی (زنجیره‌ی تونل‌ها)", enc=False, perf=[3, 3, 3, 3],
        short="یک پورت جدید که ترافیک را داخل یک تونل دیگر می‌فرستد؛ برای ساختن مسیر چندمرحله‌ای.",
        what="مثلاً تونل A (Backhaul) را می‌سازی و بعد یک تونل ترکیبی روی پورت دیگر می‌گذاری که از تونل A رد شود. با زنجیره کردن چند تونل مسیر چندجهشی می‌سازی.",
        when="وقتی می‌خواهی دو نوع تونل را پشت هم بزنی (مثلاً socat ← Backhaul، یا WireGuard ← GOST).",
        pros="هر ترکیبی از تونل‌های پنل، بدون نصب چیز اضافه.", cons="هر مرحله کمی تأخیر اضافه می‌کند. اگر پورت تونل مرحله‌ی قبل عوض شود، این تونل را یک بار ذخیره کن.",
        fields=[F("via_id", "عبور از تونل", "tunnel", req=True), F("port", "پورت این سرور", "port", req=True, ex="9443"),
                F("network", "شبکه", "select", options=NET, default="tcp")]),
}
KINDS = tuple(META)
ONESHOT = ("gre", "ipip", "vxlan", "wg")
BIN_NEEDS = {"socat": ["socat"], "gost": ["gost"], "chisel": ["chisel"], "rathole": ["rathole"], "backhaul": ["backhaul"],
             "gre": ["ip"], "ipip": ["ip"], "vxlan": ["ip"], "wg": ["wg", "wg-quick"], "combo": ["socat"]}


def need_bins(t: dict) -> list[str]:
    if t["kind"] == "frp":
        return ["frps"] if t["settings"].get("role") == "server" else ["frpc"]
    return BIN_NEEDS.get(t["kind"], [])


def missing_bins(t: dict) -> list[str]:
    return [b for b in need_bins(t) if not bin_path(b)]


def public_meta() -> dict:
    return {k: {kk: vv for kk, vv in v.items()} for k, v in META.items()}


# ------------------------------------------------------------------ validation
def _val(f: dict, raw, label_err):
    t = f["type"]
    T = _T()
    if t == "select":
        v = str(raw if raw not in (None, "") else f.get("default", ""))
        if v not in [o[0] for o in f["options"]]:
            raise T.TunnelError(f"«{f['label']}» نامعتبر است")
        return v
    if t == "port":
        return T._port(raw, f["label"], required=bool(f.get("req") or not f.get("optional", False)))
    if t == "host":
        if f.get("optional") and not str(raw or "").strip():
            return ""
        return T._host(raw, f["label"])
    if t == "ip":
        v = str(raw or "").strip()
        if not v:
            if f.get("optional"):
                return ""
            raise T.TunnelError(f"«{f['label']}» را وارد کن")
        try:
            ip = ipaddress.ip_address(v)
        except ValueError:
            raise T.TunnelError(f"«{f['label']}» آی‌پی معتبر نیست")
        if ip.version != 4:
            raise T.TunnelError(f"«{f['label']}» باید IPv4 باشد")
        return v
    if t == "int":
        try:
            v = int(raw if raw not in (None, "") else f["default"])
        except (TypeError, ValueError):
            raise T.TunnelError(f"«{f['label']}» باید عدد باشد")
        if not f["min"] <= v <= f["max"]:
            raise T.TunnelError(f"«{f['label']}» باید بین {f['min']} و {f['max']} باشد")
        return v
    if t == "ports":
        toks = [x.strip() for x in str(raw or "").replace("،", ",").replace(" ", ",").split(",") if x.strip()]
        if not toks:
            raise T.TunnelError(f"«{f['label']}» را وارد کن")
        out = []
        for tok in toks[:32]:
            m = re.match(r"^(\d{1,5})(?::(\d{1,5}))?(?:/(tcp|udp))?$", tok)
            if not m or not 1 <= int(m.group(1)) <= 65535 or (m.group(2) and not 1 <= int(m.group(2)) <= 65535):
                raise T.TunnelError(f"پورت «{tok}» نامعتبر است (نمونه: 443 یا 8443:443 یا 53/udp)")
            out.append(m.group(1) + (":" + m.group(2) if m.group(2) else "") + ("/udp" if m.group(3) == "udp" else ""))
        return ",".join(out)
    if t == "token":
        v = str(raw or "").strip()
        if v and not re.match(r"^[A-Za-z0-9_\-]{8,64}$", v):
            raise T.TunnelError("توکن باید ۸ تا ۶۴ حرف انگلیسی/عدد باشد")
        return v
    if t == "hops":
        out = []
        for line in str(raw or "").splitlines():
            line = line.strip()
            if not line:
                continue
            h, _, p = line.rpartition(":")
            out.append(f"{T._host(h, 'هاپ')}:{T._port(p, 'پورت هاپ')}")
        return "\n".join(out[:8])
    return str(raw or "").strip()[:100]


def _shown(f: dict, s: dict) -> bool:
    return all(s.get(k) in v for k, v in (f.get("show") or {}).items())


def _local_ip() -> str:
    try:
        so = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        so.connect(("1.1.1.1", 53))
        ip = so.getsockname()[0]
        so.close()
        return ip
    except OSError:
        return ""


def _inner(tid: int) -> tuple[str, str]:
    n = (tid * 4) % 1000
    return f"10.{200 + n // 250}.{n % 250}.1", f"10.{200 + n // 250}.{n % 250}.2"


def _gen_keys() -> dict:
    from .system import run
    T = _T()
    if not bin_path("wg"):
        raise T.TunnelError("wireguard-tools نصب نیست. دکمه‌ی «نصب» کنار این تونل را بزن یا: apt install -y wireguard-tools", 500)

    def pair():
        c, priv = run(["wg", "genkey"], 10)
        if c != 0 or not priv:
            raise T.TunnelError("ساخت کلید WireGuard ناموفق بود", 500)
        c, pub = run("echo " + shlex.quote(priv) + " | wg pubkey", 10, shell=True)
        return priv.strip(), pub.strip()

    priv, pub = pair()
    rpriv, rpub = pair()
    c, psk = run(["wg", "genpsk"], 10)
    return {"priv": priv, "pub": pub, "rpriv": rpriv, "rpub": rpub, "psk": psk.strip()}


def normalize(kind: str, data: dict, existing: dict | None, inbounds: list, tunnels: list, settings: dict):
    """-> (settings dict, top-level port)."""
    T = _T()
    meta = META[kind]
    src = dict(data.get("settings") or {})
    old = dict(existing["settings"]) if existing else {}
    ex_id = existing["id"] if existing else None
    s: dict = {}
    port = 0
    if any(f["k"] == "fports" for f in meta["fields"]) and not src.get("fports") and data.get("port") and src.get("target_port"):
        src["fports"] = ",".join(f"{data['port']}:{src['target_port']}" + ("/udp" if p == "udp" else "")
                                 for p in str(src.get("network", "tcp")).split(","))   # old style single port
    for f in meta["fields"]:
        if not _shown(f, s):
            continue
        raw = data.get("port") if f["k"] == "port" else src.get(f["k"])
        if f["type"] == "tunnel":
            s[f["k"]] = int(raw or 0)
            continue
        if f["k"] == "port":
            port = _val(f, raw, None)
        else:
            s[f["k"]] = _val(f, raw, None)
    s.setdefault("network", "tcp")
    if s.get("fports"):
        first = s["fports"].split(",")[0]
        a, _, b = first.split("/")[0].partition(":")
        port, s["target_port"] = int(a), int(b or a)
        s["network"] = "tcp,udp" if "/udp" in s["fports"] and "/udp" != s["fports"] and any(not x.endswith("/udp") for x in s["fports"].split(",")) else ("udp" if "/udp" in s["fports"] else "tcp")
    # token shared with the other server
    if kind in ("gost", "chisel", "frp", "rathole", "backhaul"):
        s["token"] = s.get("token") or old.get("token") or secrets.token_urlsafe(12).replace("-", "x").replace("_", "y")
        role = s.get("role", "")
        if kind in ("chisel", "frp", "rathole", "backhaul") and role == "server":
            if not s.get("ctl_port"):
                s["ctl_port"] = old.get("ctl_port") or T._free_port({i["port"] for i in inbounds} | {p for t in tunnels for p in T.local_ports(t)} | {port})
        if kind in ("chisel", "frp", "rathole", "backhaul") and role == "client":
            s["ctl_port"] = 0
        if kind == "backhaul" and any(m[3] == "udp" for m in maps({"port": port, "settings": s})) and s.get("transport") != "tcp":
            raise T.TunnelError("UDP فقط با ترنسپورت tcp در Backhaul پشتیبانی می‌شود")
    if kind in ONESHOT:
        tid = ex_id or (max([t["id"] for t in tunnels] + [0]) + 1)
        il, ir = _inner(tid)
        s["inner_local"] = s.get("inner_local") or old.get("inner_local") or il
        s["inner_remote"] = s.get("inner_remote") or old.get("inner_remote") or ir
        if s["inner_local"] == s["inner_remote"]:
            raise T.TunnelError("آی‌پی داخلی دو سرور نباید یکی باشد")
        if kind in ("gre", "ipip", "vxlan"):
            s["local_ip"] = s.get("local_ip") or old.get("local_ip") or _local_ip()
            if not s["local_ip"]:
                raise T.TunnelError("آی‌پی عمومی این سرور پیدا نشد؛ دستی وارد کن")
        if s.get("expose_port") and not s.get("target_port"):
            raise T.TunnelError("برای فوروارد، پورت مقصد را هم وارد کن")
        if s.get("target_port") and not s.get("expose_port"):
            raise T.TunnelError("برای فوروارد، پورت روی این سرور را هم وارد کن")
        if kind == "wg":
            keys = {k: old[k] for k in ("priv", "pub", "rpriv", "rpub", "psk") if old.get(k)}
            s.update(keys if len(keys) == 5 else _gen_keys())
    if kind == "combo":
        via = next((t for t in tunnels if t["id"] == s["via_id"]), None)
        if not via or via["id"] == ex_id:
            raise T.TunnelError("تونل مرحله‌ی قبل را انتخاب کن")
        lp = [p for p in local_ports(via) if p]
        if not lp:
            raise T.TunnelError("این تونل پورتی روی این سرور باز نمی‌کند؛ تونل دیگری را انتخاب کن")
        s["hop_host"], s["hop_port"], s["via_name"] = "127.0.0.1", lp[0], via["name"]
    # ports this tunnel will occupy on the panel server
    tmp = {"id": ex_id, "kind": kind, "port": port, "settings": s}
    ports = [p for p in local_ports(tmp) if p]
    T._check_ports(ports, ex_id, inbounds, tunnels, settings)
    return s, port


def local_ports(t: dict) -> list[int]:
    k, s, P = t["kind"], t["settings"], t["port"]
    if k not in META:
        return []
    out = []
    if k in ("socat", "gost", "combo"):
        out = [P]
    elif k in ("chisel", "frp", "rathole", "backhaul"):
        pubs = sorted({m[0] for m in maps(t)})
        if k == "chisel" and s.get("role") == "client":
            out = pubs
        else:
            out = [*pubs, int(s.get("ctl_port") or 0)] if s.get("role") == "server" else []
    elif k in ("vxlan", "wg"):
        out = [P]
    if k in ("gre", "ipip", "vxlan", "wg") and s.get("expose_port"):
        out.append(int(s["expose_port"]))
    return out


# ------------------------------------------------------------------ rendering (this server)
def _name(t: dict) -> str:
    return f"tcm{t['id']}"


def _dir(t: dict) -> Path:
    return _T().TUN_DIR / f"t{t['id']}"


def _unit(t: dict, exec_start: str, desc: str) -> str:
    return (f"[Unit]\nDescription=Panel tunnel {t['id']} ({desc}: {t['name']})\nAfter=network-online.target\nWants=network-online.target\n\n"
            f"[Service]\nExecStart={exec_start}\nRestart=always\nRestartSec=3\nLimitNOFILE=1048576\n\n[Install]\nWantedBy=multi-user.target\n")


def _oneshot(t: dict, script: Path) -> str:
    return (f"[Unit]\nDescription=Panel tunnel {t['id']} ({t['kind']}: {t['name']})\nAfter=network-online.target\nWants=network-online.target\n\n"
            f"[Service]\nType=oneshot\nRemainAfterExit=yes\nExecStart=/bin/sh {script} start\nExecStop=/bin/sh {script} stop\n\n[Install]\nWantedBy=multi-user.target\n")


def _toml_s(v) -> str:
    return json.dumps(str(v))


def _svcs(t: dict) -> list[tuple[str, str]]:
    return [(f"{_name(t)}-{p}", p) for p in t["settings"]["network"].split(",")]


def maps(t: dict) -> list[tuple[int, str, int, str]]:
    """Forwarded ports: [(public port, target host, target port, 'tcp'|'udp')]."""
    s = t["settings"]
    if s.get("fports"):
        out = []
        for tok in s["fports"].split(","):
            if not tok:
                continue
            proto = "udp" if tok.endswith("/udp") else "tcp"
            a, _, b = tok.split("/")[0].partition(":")
            out.append((int(a), s["target_host"], int(b or a), proto))
        return out
    return [(t["port"], s["target_host"], int(s["target_port"]), p) for p in s["network"].split(",")]


def gost_args(t: dict, role: str | None = None, host: str = "") -> list[str]:
    s, P = t["settings"], t["port"]
    auth = f"tcm:{s['token']}@"
    role = role or s["role"]
    if role == "exit":
        return ["-L", f"relay+{s['transport']}://{auth}:{P}"]
    a: list[str] = []
    for proto in s["network"].split(","):
        a += ["-L", f"{proto}://:{P}/{s['target_host']}:{int(s['target_port'])}"]
    hops = [f"{host or s['remote_host']}:{int(s['remote_port'])}"] + [h for h in (s.get("hops") or "").splitlines() if h]
    for h in hops:
        a += ["-F", f"relay+{s['transport']}://{auth}{h}"]
    return a


def frp_toml(t: dict, side: str, host: str = "") -> str:
    s = t["settings"]
    tr = s.get("transport", "tcp")
    ms = maps(t)
    if side == "server":
        txt = f"bindPort = {int(s['ctl_port'])}\nauth.method = \"token\"\nauth.token = {_toml_s(s['token'])}\n"
        if tr == "kcp":
            txt += f"kcpBindPort = {int(s['ctl_port'])}\n"
        if tr == "quic":
            txt += f"quicBindPort = {int(s['ctl_port'])}\n"
        singles = ", ".join(f"{{ single = {p} }}" for p in sorted({m[0] for m in ms}))
        return txt + f"allowPorts = [{singles}]\n"
    addr = host or s.get("remote_host") or "SERVER_IP"
    port = int(s.get("remote_port") or s.get("ctl_port") or 0)
    txt = (f"serverAddr = {_toml_s(addr)}\nserverPort = {port}\nauth.method = \"token\"\nauth.token = {_toml_s(s['token'])}\n"
           f"transport.protocol = {_toml_s(tr)}\nloginFailExit = false\n")
    for pub, th, tp, proto in ms:
        txt += (f"\n[[proxies]]\nname = {_toml_s(f'{_name(t)}-{pub}-{proto}')}\ntype = {_toml_s(proto)}\nlocalIP = {_toml_s(th)}\n"
                f"localPort = {tp}\nremotePort = {pub}\n")
    return txt


def rathole_toml(t: dict, side: str, host: str = "") -> str:
    s = t["settings"]
    ms = maps(t)
    if side == "server":
        txt = f"[server]\nbind_addr = \"0.0.0.0:{int(s['ctl_port'])}\"\ndefault_token = {_toml_s(s['token'])}\n"
        for pub, th, tp, proto in ms:
            txt += f"\n[server.services.{_name(t)}-{pub}-{proto}]\nbind_addr = \"0.0.0.0:{pub}\"\ntype = {_toml_s(proto)}\n"
        return txt
    addr = host or s.get("remote_host") or "SERVER_IP"
    port = int(s.get("remote_port") or s.get("ctl_port") or 0)
    txt = f"[client]\nremote_addr = \"{addr}:{port}\"\ndefault_token = {_toml_s(s['token'])}\n"
    for pub, th, tp, proto in ms:
        txt += f"\n[client.services.{_name(t)}-{pub}-{proto}]\nlocal_addr = \"{th}:{tp}\"\ntype = {_toml_s(proto)}\n"
    return txt


def backhaul_toml(t: dict, side: str, host: str = "") -> str:
    s = t["settings"]
    ms = maps(t)
    if side == "server":
        txt = (f"[server]\nbind_addr = \"0.0.0.0:{int(s['ctl_port'])}\"\ntransport = {_toml_s(s['transport'])}\ntoken = {_toml_s(s['token'])}\n"
               "log_level = \"info\"\nkeepalive_period = 75\nnodelay = true\n")
        if any(m[3] == "udp" for m in ms) and s["transport"] == "tcp":
            txt += "accept_udp = true\n"
        rows = sorted({f"{pub}={th}:{tp}" for pub, th, tp, proto in ms})
        return txt + "ports = [" + ", ".join(f'"{r}"' for r in rows) + "]\n"
    addr = host or s.get("remote_host") or "SERVER_IP"
    port = int(s.get("remote_port") or s.get("ctl_port") or 0)
    return (f"[client]\nremote_addr = \"{addr}:{port}\"\ntransport = {_toml_s(s['transport'])}\ntoken = {_toml_s(s['token'])}\n"
            "connection_pool = 8\nretry_interval = 3\ndial_timeout = 10\nkeepalive_period = 75\nnodelay = true\nlog_level = \"info\"\n")


def chisel_args(t: dict, side: str, host: str = "") -> list[str]:
    s = t["settings"]
    if side == "server":
        return ["server", "--port", str(int(s["ctl_port"])), "--reverse", "--auth", f"tcm:{s['token']}", "--keepalive", "25s"]
    addr = host or s.get("remote_host") or "SERVER_IP"
    port = int(s.get("remote_port") or s.get("ctl_port") or 0)
    # panel is the client: forward mode (local port -> target through the server)
    return ["client", "--auth", f"tcm:{s['token']}", "--keepalive", "25s", f"http://{addr}:{port}",
            *[f"0.0.0.0:{pub}:{th}:{tp}{'/udp' if proto == 'udp' else ''}" for pub, th, tp, proto in maps(t)]]


def _l3_script(t: dict) -> str:
    s, k, P = t["settings"], t["kind"], t["port"]
    n = f"ptun{t['id']}"
    up, down = [], []
    if k in ("gre", "ipip"):
        up += [f"ip tunnel add {n} mode {k} local {s['local_ip']} remote {s['remote_ip']} ttl 255"]
        down += [f"ip link del {n}"]
    elif k == "vxlan":
        up += [f"ip link add {n} type vxlan id {int(s['vni'])} local {s['local_ip']} remote {s['remote_ip']} dstport {P}"]
        down += [f"ip link del {n}"]
    if k != "wg":
        up += [f"ip addr add {s['inner_local']}/30 dev {n}", f"ip link set {n} mtu {int(s['mtu'])} up"]
    lines = ["#!/bin/sh", 'if [ "$1" = start ]; then', "  sysctl -w net.ipv4.ip_forward=1 >/dev/null"]
    if k == "wg":
        lines += [f"  wg-quick up {_dir(t) / (n + '.conf')}"]
    else:
        lines += [f"  ip link del {n} 2>/dev/null"] + [f"  {u}" for u in up]
    T = _T()
    rules = []
    if s.get("expose_port"):
        fake = {"port": int(s["expose_port"]), "settings": {"target_port": int(s["target_port"]), "network": s["network"]}}
        rules = T._dnat_rules(fake, s["inner_remote"])
        for tbl, r in rules:
            chain, rest = r.split(" ", 1)
            lines.append(f"  iptables {tbl} -C {chain} {rest} 2>/dev/null || iptables {tbl} -I {chain} {rest}".replace("iptables  ", "iptables "))
    lines.append("else")
    for tbl, r in rules:
        lines.append(f"  iptables {tbl} -D {r} 2>/dev/null || true".replace("iptables  ", "iptables "))
    if k == "wg":
        lines.append(f"  wg-quick down {_dir(t) / (n + '.conf')} 2>/dev/null || true")
    else:
        lines += [f"  {d} 2>/dev/null || true" for d in down]
    lines += ["fi", "exit 0"]
    return "\n".join(lines) + "\n"


def _wg_conf(t: dict, side: str, host: str = "") -> str:
    s, P = t["settings"], t["port"]
    if side == "local":
        txt = (f"[Interface]\nPrivateKey = {s['priv']}\nAddress = {s['inner_local']}/30\nListenPort = {P}\nMTU = {int(s['mtu'])}\n\n"
               f"[Peer]\nPublicKey = {s['rpub']}\nPresharedKey = {s['psk']}\nAllowedIPs = {s['inner_remote']}/32\n")
        if s.get("remote_host") and s.get("remote_port"):
            txt += f"Endpoint = {s['remote_host']}:{int(s['remote_port'])}\nPersistentKeepalive = 25\n"
        return txt
    txt = (f"[Interface]\nPrivateKey = {s['rpriv']}\nAddress = {s['inner_remote']}/30\nMTU = {int(s['mtu'])}\n"
           + (f"ListenPort = {int(s['remote_port'])}\n" if s.get("remote_port") else "") +
           f"\n[Peer]\nPublicKey = {s['pub']}\nPresharedKey = {s['psk']}\nAllowedIPs = {s['inner_local']}/32\n")
    if not (s.get("remote_host") and s.get("remote_port")):
        txt += f"Endpoint = {host or 'PANEL_IP'}:{P}\nPersistentKeepalive = 25\n"
    return txt


def render(t: dict) -> dict[Path, str]:
    """{path: content}; the unit file is always the first entry."""
    T = _T()
    k, s, P = t["kind"], t["settings"], t["port"]
    unit = T.UNIT_DIR / f"{T.unit_name(t)}.service"
    d = _dir(t)
    if k in ("socat", "combo"):
        host, tp, net = (s["target_host"], int(s["target_port"]), s["network"]) if k == "socat" else (s["hop_host"], int(s["hop_port"]), s["network"])
        script = d / "run.sh"
        body = ["#!/bin/bash", "trap 'kill 0' EXIT"]
        for proto in net.split(","):
            up = proto.upper()
            opt = "fork,reuseaddr,backlog=1024" if proto == "tcp" else "fork,reuseaddr"
            body.append(f"socat {up}-LISTEN:{P},{opt} {up}:{host}:{tp} &")
        body += ["wait -n", "exit 1"]
        return {unit: _unit(t, f"/bin/bash {script}", k), script: "\n".join(body) + "\n"}
    if k == "gost":
        return {unit: _unit(t, f"{bin_path('gost') or '/usr/local/bin/gost'} " + shlex.join(gost_args(t)), "gost")}
    if k == "chisel":
        return {unit: _unit(t, f"{bin_path('chisel') or '/usr/local/bin/chisel'} " + shlex.join(chisel_args(t, s["role"])), "chisel")}
    if k == "frp":
        side = s["role"]
        f = d / ("frps.toml" if side == "server" else "frpc.toml")
        bn = "frps" if side == "server" else "frpc"
        b = bin_path(bn) or f"/usr/local/bin/{bn}"
        return {unit: _unit(t, f"{b} -c {f}", "frp"), f: frp_toml(t, side)}
    if k == "rathole":
        side = s["role"]
        f = d / f"rathole-{side}.toml"
        return {unit: _unit(t, f"{bin_path('rathole') or '/usr/local/bin/rathole'} --{side} {f}", "rathole"), f: rathole_toml(t, side)}
    if k == "backhaul":
        side = s["role"]
        f = d / f"backhaul-{side}.toml"
        return {unit: _unit(t, f"{bin_path('backhaul') or '/usr/local/bin/backhaul'} -c {f}", "backhaul"), f: backhaul_toml(t, side)}
    # kernel / wireguard
    script = d / "up.sh"
    files = {unit: _oneshot(t, script), script: _l3_script(t)}
    if k == "wg":
        files[d / f"ptun{t['id']}.conf"] = _wg_conf(t, "local")
    return files


# ------------------------------------------------------------------ info for health / benchmark
def info(t: dict) -> dict:
    """{line, listen: [(port, proto)], peer: (host, port) | None, peer_icmp: host | None, entry: (host, port) | None}"""
    k, s, P = t["kind"], t["settings"], t["port"]
    role = s.get("role", "")
    net = s.get("network", "tcp")
    protos = net.split(",")
    listen = []
    peer = None
    icmp = s.get("peer_host") or s.get("remote_host") or s.get("remote_ip") or None
    entry = None
    if k in ("socat", "combo"):
        tgt = (s["target_host"], int(s["target_port"])) if k == "socat" else (s["hop_host"], int(s["hop_port"]))
        listen = [(P, p) for p in protos]
        peer = tgt if k == "socat" else None
        entry = ("127.0.0.1", P)
        line = f":{P} ← {tgt[0]}:{tgt[1]} · socat" if k == "socat" else f":{P} ⇒ تونل «{s.get('via_name', '')}» (:{tgt[1]})"
    elif k == "gost":
        if role == "exit":
            listen = [(P, "udp" if s["transport"] in ("quic", "kcp") else "tcp")]
            line = f"خروجی gost روی :{P} ({s['transport']})"
        else:
            listen = [(P, p) for p in protos]
            peer = (s["remote_host"], int(s["remote_port"]))
            entry = ("127.0.0.1", P)
            hops = [h for h in (s.get("hops") or "").splitlines() if h]
            line = f":{P} ← {s['target_host']}:{s['target_port']} · {s['transport']} از {s['remote_host']}:{s['remote_port']}" + (f" + {len(hops)} هاپ" if hops else "")
    elif k in ("chisel", "frp", "rathole", "backhaul"):
        if role == "server":
            ctl_proto = "udp" if (k == "frp" and s.get("transport") in ("kcp", "quic")) or (k == "backhaul" and s.get("transport") == "udp") else "tcp"
            listen = [(int(s["ctl_port"]), ctl_proto)] + [(P, p) for p in protos]
            line = f"سرور {k} · عمومی :{P} · کنترل :{s['ctl_port']} ← سرور مقابل ← {s['target_host']}:{s['target_port']}"
            entry = ("127.0.0.1", P)
        else:
            peer = (s["remote_host"], int(s["remote_port"]))
            if k == "chisel":
                listen = [(P, p) for p in protos]
                entry = ("127.0.0.1", P)
            line = f"کلاینت {k} ← {s['remote_host']}:{s['remote_port']} · سرویس {s['target_host']}:{s['target_port']} → پورت {P} سرور مقابل"
    else:
        icmp = s.get("remote_ip") or s.get("remote_host") or s.get("peer_host")
        if k in ("vxlan", "wg"):
            listen = [(P, "udp")]
        if s.get("expose_port"):
            listen += [(int(s["expose_port"]), p) for p in protos]
            entry = ("127.0.0.1", int(s["expose_port"]))
        if k == "wg" and s.get("remote_host") and s.get("remote_port"):
            peer = None
        line = f"{k.upper()} · {s['inner_local']} ⇄ {s['inner_remote']}" + (f" · :{s['expose_port']} ⇒ :{s['target_port']}" if s.get("expose_port") else "")
    return {"line": line, "listen": listen, "peer": peer, "icmp": icmp, "entry": entry}


# ------------------------------------------------------------------ guides (instructions for the OTHER server)
def _step(title, text="", code=None):
    return {"t": title, "x": text, "c": [c for c in (code or []) if c]}


def _svc_steps(name: str, exec_start: str, conf: dict[str, str], fw: str) -> list[dict]:
    cmds = [f"mkdir -p {CONF_DIR_REMOTE}"]
    for fn, content in conf.items():
        cmds.append(f"cat > {CONF_DIR_REMOTE}/{fn} <<'EOF'\n{content.rstrip()}\nEOF")
    cmds.append(f"chmod 600 {CONF_DIR_REMOTE}/*")
    unit = (f"[Unit]\nDescription=tcm19 tunnel {name}\nAfter=network-online.target\nWants=network-online.target\n\n[Service]\n"
            f"ExecStart={exec_start}\nRestart=always\nRestartSec=3\nLimitNOFILE=1048576\n\n[Install]\nWantedBy=multi-user.target")
    return [
        _step("ساخت فایل تنظیمات", "این دستور را روی سرور مقابل بزن (متن تنظیمات آماده است):", ["\n".join(cmds)]),
        _step("ساخت و اجرای سرویس", "با این سرویس، برنامه همیشه زنده می‌ماند و بعد از ریبوت خودکار اجرا می‌شود:",
              [f"cat > /etc/systemd/system/tcm19-{name}.service <<'EOF'\n{unit}\nEOF", f"systemctl daemon-reload && systemctl enable --now tcm19-{name}"]),
        _step("بررسی", "باید جلوی Active نوشته باشد active (running):", [f"systemctl status tcm19-{name} --no-pager", f"journalctl -u tcm19-{name} -n 30 --no-pager"]),
        *([_step("باز کردن پورت", fw)] if fw else []),
    ]


def guide(t: dict, host: str) -> list[dict]:
    k, s, P = t["kind"], t["settings"], t["port"]
    name = _name(t)
    role = s.get("role", "")
    H = host or "PANEL_IP"
    tg = f"{s.get('target_host', '')}:{s.get('target_port', '')}"
    steps: list[dict] = []
    me_fw = lambda ports: f"روی این سرور (پنل) و در پنل هاستینگ، این پورت‌ها را باز کن: {ports}."
    client_step = lambda: _step("تنظیم برنامه‌ی کاربر",
                                f"کانفیگی که برای سرور مقصد (سرویس {tg}) ساخته‌ای را بردار و فقط «آدرس» را {H} و «پورت» را {P} بگذار. بقیه‌ی مقادیر (UUID، رمز، SNI، Public key...) همان بماند.")

    def inst(tool):
        return _step(f"نصب {tool} روی سرور مقابل", "این دستور آخرین نسخه را دانلود و نصب می‌کند (سرور مقابل باید به GitHub دسترسی داشته باشد؛ اگر ندارد، فایل را دستی آپلود کن):", [_install_snippet(tool)])

    if k == "socat":
        steps = [_step("آدرس اتصال", "هر اتصال به این آدرس توسط socat به مقصد می‌رسد:", [f"{H}:{P}"]),
                 _step("باز کردن پورت", me_fw(f"{P} ({s['network']})")), client_step(),
                 _step("تست", "روی همین سرور:", [f"ss -lntup | grep :{P}", f"systemctl status panel-tun-{t['id']} --no-pager"])]
    elif k == "gost":
        tr = s["transport"]
        proto = "UDP" if tr in ("quic", "kcp") else "TCP"
        if role == "entry":
            hops = [h for h in (s.get("hops") or "").splitlines() if h]
            chain = [f"{s['remote_host']}:{s['remote_port']}"] + hops
            steps.append(_step("نقشه‌ی مسیر", "کاربر ← این سرور ← " + " ← ".join(chain) + f" ← مقصد {tg}. روی هر سرور مسیر (همه‌ی آدرس‌های زیر) یک gost با نقش «گیرنده» اجرا کن."))
            for i, h in enumerate(chain):
                hp = h.rsplit(":", 1)[1]
                steps.append(_step(f"سرور {i + 1} از مسیر ({h})", "روی این سرور gost را نصب کن و سرویس را بساز:",
                                   [_install_snippet("gost"),
                                    f"cat > /etc/systemd/system/tcm19-{name}.service <<'EOF'\n[Unit]\nDescription=tcm19 gost relay\nAfter=network-online.target\n\n[Service]\nExecStart=/usr/local/bin/gost -L relay+{tr}://tcm:{s['token']}@:{hp}\nRestart=always\nRestartSec=3\nLimitNOFILE=1048576\n\n[Install]\nWantedBy=multi-user.target\nEOF",
                                    f"systemctl daemon-reload && systemctl enable --now tcm19-{name}",
                                    f"# پورت {hp}/{proto.lower()} را در فایروال باز کن"]))
            steps += [_step("باز کردن پورت روی این سرور", me_fw(f"{P} ({s['network']})")), client_step(),
                      _step("تست", "اگر وصل نشد، لاگ این سرور را ببین:", [f"journalctl -u panel-tun-{t['id']} -n 30 --no-pager", f"ss -lntup | grep :{P}"])]
        else:
            ex = f"/usr/local/bin/gost -L tcp://:{{PORT}}/{{TARGET}} -F relay+{tr}://tcm:{s['token']}@{H}:{P}"
            steps = [_step("نقشه‌ی مسیر", f"این سرور «خروجی» است و روی :{P} گوش می‌دهد. روی سرور مقابل (ورودی) gost را با آدرس این سرور اجرا کن."),
                     inst("gost"),
                     _step("اجرای ورودی روی سرور مقابل", "به‌جای PORT پورتی که کاربرها وصل می‌شوند و به‌جای TARGET آدرس سرویس (از دید این سرور) را بگذار، مثلاً 127.0.0.1:443:",
                           [f"/usr/local/bin/gost -L tcp://:8443/127.0.0.1:443 -F relay+{tr}://tcm:{s['token']}@{H}:{P}", "# برای سرویس دائمی همین دستور را داخل ExecStart یک سرویس systemd بگذار"]),
                     _step("باز کردن پورت", me_fw(f"{P} ({proto})"))]
    elif k in ("frp", "rathole", "backhaul"):
        tool = {"frp": "frp", "rathole": "rathole", "backhaul": "backhaul"}[k]
        toml = {"frp": frp_toml, "rathole": rathole_toml, "backhaul": backhaul_toml}[k]
        if role == "server":
            other_cfg = toml(t, "client", H)
            fn = f"{name}-" + {"frp": "frpc.toml", "rathole": "rathole-client.toml", "backhaul": "backhaul-client.toml"}[k]
            ex = {"frp": f"/usr/local/bin/frpc -c {CONF_DIR_REMOTE}/{fn}", "rathole": f"/usr/local/bin/rathole --client {CONF_DIR_REMOTE}/{fn}",
                  "backhaul": f"/usr/local/bin/backhaul -c {CONF_DIR_REMOTE}/{fn}"}[k]
            ctl = int(s["ctl_port"])
            ctl_proto = "UDP" if (k == "frp" and s.get("transport") in ("kcp", "quic")) or (k == "backhaul" and s.get("transport") == "udp") else "TCP"
            steps = [_step("نقشه‌ی مسیر", f"این سرور «سرور» است: کاربرها به {H}:{P} وصل می‌شوند، سرور مقابل از بیرون به {H}:{ctl} وصل می‌شود و ترافیک را به {tg} (روی خودش) می‌رساند. روی سرور مقابل هیچ پورتی لازم نیست باز باشد."),
                     _step("باز کردن پورت‌ها روی این سرور", me_fw(f"{P} ({s['network']}) و {ctl} ({ctl_proto}، پورت کنترل)")),
                     inst(tool) if k != "frp" else _step("نصب frpc روی سرور مقابل", "", [_install_snippet("frp")]),
                     *_svc_steps(name, ex, {fn: other_cfg}, ""),
                     client_step()]
        else:
            other_cfg = toml(t, "server")
            fn = f"{name}-" + {"frp": "frps.toml", "rathole": "rathole-server.toml", "backhaul": "backhaul-server.toml"}[k]
            ex = {"frp": f"/usr/local/bin/frps -c {CONF_DIR_REMOTE}/{fn}", "rathole": f"/usr/local/bin/rathole --server {CONF_DIR_REMOTE}/{fn}",
                  "backhaul": f"/usr/local/bin/backhaul -c {CONF_DIR_REMOTE}/{fn}"}[k]
            steps = [_step("نقشه‌ی مسیر", f"این سرور «کلاینت» است و به {s.get('remote_host', 'سرور مقابل')}:{s.get('remote_port', '')} وصل می‌شود. سرور مقابل پورت {P} را عمومی می‌کند و ترافیک از تونل به {tg} (روی این سرور) می‌رسد."),
                     inst(tool),
                     *_svc_steps(name, ex, {fn: other_cfg}, f"پورت کنترل {s.get('remote_port', '')} و پورت عمومی {P} را روی سرور مقابل باز کن."),
                     _step("اتصال کاربر", f"کاربر به آدرس سرور مقابل و پورت {P} وصل می‌شود.")]
    elif k == "chisel":
        if role == "server":
            sfx = "/udp" if s["network"] == "udp" else ""
            steps = [_step("نقشه‌ی مسیر", f"این سرور «سرور» chisel است (با reverse). سرور مقابل به {H}:{s['ctl_port']} وصل می‌شود و پورت {P} روی این سرور باز می‌شود و به {tg} روی سرور مقابل می‌رسد."),
                     _step("باز کردن پورت‌ها", me_fw(f"{P} و {s['ctl_port']} (TCP)")), inst("chisel"),
                     *_svc_steps(name, f"/usr/local/bin/chisel client --auth tcm:{s['token']} --keepalive 25s http://{H}:{s['ctl_port']} R:0.0.0.0:{P}:{tg}{sfx}", {}, ""), client_step()]
            steps = [x for x in steps if not (x["t"] == "ساخت فایل تنظیمات")]
        else:
            steps = [_step("نقشه‌ی مسیر", f"این سرور کلاینت است و به {s.get('remote_host')}:{s.get('remote_port')} وصل می‌شود؛ پورت {P} این سرور به {tg} (از دید سرور مقابل) فوروارد می‌شود."),
                     inst("chisel"),
                     *[x for x in _svc_steps(name, f"/usr/local/bin/chisel server --port {s.get('remote_port')} --reverse --auth tcm:{s['token']} --keepalive 25s", {}, f"پورت {s.get('remote_port')} (TCP) را روی سرور مقابل باز کن.") if x["t"] != "ساخت فایل تنظیمات"],
                     client_step()]
    elif k in ("gre", "ipip", "vxlan"):
        n = f"ptun{t['id']}"
        if k == "vxlan":
            mk = f"ip link add {n} type vxlan id {s['vni']} local {s['remote_ip']} remote {s['local_ip']} dstport {P}"
            fw = f"iptables -I INPUT -p udp --dport {P} -s {s['local_ip']} -j ACCEPT"
        else:
            mk = f"ip tunnel add {n} mode {k} local {s['remote_ip']} remote {s['local_ip']} ttl 255"
            fw = f"iptables -I INPUT -p {'gre' if k == 'gre' else 'ipip'} -s {s['local_ip']} -j ACCEPT"
        script = f"#!/bin/sh\nip link del {n} 2>/dev/null\n{mk}\nip addr add {s['inner_remote']}/30 dev {n}\nip link set {n} mtu {s['mtu']} up"
        unit = f"[Unit]\nDescription=tcm19 {k} {n}\nAfter=network-online.target\n\n[Service]\nType=oneshot\nRemainAfterExit=yes\nExecStart=/bin/sh {CONF_DIR_REMOTE}/{n}.sh\nExecStop=/sbin/ip link del {n}\n\n[Install]\nWantedBy=multi-user.target"
        steps = [_step("نقشه‌ی مسیر", f"دو سرور با آی‌پی داخلی همدیگر را می‌بینند: این سرور {s['inner_local']} و سرور مقابل {s['inner_remote']}. آی‌پی عمومی این سرور {s['local_ip']} و سرور مقابل {s['remote_ip']}."),
                 _step("باز کردن پروتکل در فایروال هر دو سرور", ("GRE پروتکل ۴۷ است و IPIP پروتکل ۴ (نه پورت). " if k != "vxlan" else f"پورت UDP {P} را باز کن. ") + "اگر دیتاسنتر آن را مسدود کند، تونل کار نمی‌کند؛ در این صورت VXLAN یا WireGuard را امتحان کن.", [fw]),
                 _step("ساخت تونل روی سرور مقابل", "این دستورها را روی سرور مقابل بزن:",
                       [f"mkdir -p {CONF_DIR_REMOTE}\ncat > {CONF_DIR_REMOTE}/{n}.sh <<'EOF'\n{script}\nEOF", f"cat > /etc/systemd/system/tcm19-{n}.service <<'EOF'\n{unit}\nEOF",
                        f"systemctl daemon-reload && systemctl enable --now tcm19-{n}"]),
                 _step("تست", "از این سرور بزن؛ باید جواب بدهد:", [f"ping -c 3 {s['inner_remote']}", f"ip -d link show {n}"])]
        if s.get("expose_port"):
            steps.append(_step("اتصال کاربر", f"کاربر به {H}:{s['expose_port']} وصل می‌شود و ترافیک از تونل به {s['inner_remote']}:{s['target_port']} می‌رسد؛ سرویس روی سرور مقابل باید روی همین پورت (یا 0.0.0.0) گوش بدهد."))
    elif k == "wg":
        n = f"ptun{t['id']}"
        steps = [_step("نقشه‌ی مسیر", f"آی‌پی داخلی: این سرور {s['inner_local']} و سرور مقابل {s['inner_remote']}. پورت UDP این سرور {P}."),
                 _step("نصب WireGuard روی سرور مقابل", "", ["apt-get update -y && apt-get install -y wireguard-tools"]),
                 _step("ساخت کانفیگ روی سرور مقابل", "کل این کانفیگ را (با کلید خصوصی آن سرور) بگذار:",
                       [f"cat > /etc/wireguard/{n}.conf <<'EOF'\n{_wg_conf(t, 'remote', H).rstrip()}\nEOF\nchmod 600 /etc/wireguard/{n}.conf"]),
                 _step("اجرا روی سرور مقابل", "", [f"systemctl enable --now wg-quick@{n}", f"wg show {n}"]),
                 _step("باز کردن پورت UDP", me_fw(f"{P} (UDP)") + (f" روی سرور مقابل هم پورت {s['remote_port']} (UDP)." if s.get("remote_port") else "")),
                 _step("تست", "هر دو طرف باید جواب بدهند و در wg show مقدار latest handshake دیده شود:", [f"ping -c 3 {s['inner_remote']}", f"wg show {n}"])]
        if s.get("expose_port"):
            steps.append(_step("اتصال کاربر", f"کاربر به {H}:{s['expose_port']} وصل می‌شود و از تونل به {s['inner_remote']}:{s['target_port']} می‌رسد."))
    elif k == "combo":
        steps = [_step("نقشه‌ی مسیر", f"کاربر ← {H}:{P} ← تونل «{s.get('via_name', '')}» (پورت {s.get('hop_port')}) ← مقصد آن تونل."),
                 _step("باز کردن پورت", me_fw(f"{P} ({s['network']})")),
                 _step("تنظیم برنامه‌ی کاربر", f"آدرس را {H} و پورت را {P} بگذار؛ بقیه‌ی مقادیر مثل کانفیگ سرور نهایی بماند."),
                 _step("تست", "", [f"ss -lntup | grep :{P}", f"systemctl status panel-tun-{t['id']} --no-pager"])]
    return steps


def example(kind: str, host: str, role: str = "") -> dict:
    """A fake saved tunnel with sample values, to show the tutorial before anything is created."""
    meta = META[kind]
    s: dict = {}
    port = 0
    for f in meta["fields"]:
        if f["k"] == "role" and role:
            s["role"] = role
            continue
        if not _shown(f, s):
            continue
        v = f.get("default", f.get("ex", ""))
        if f["k"] == "port":
            port = int(v) if str(v).isdigit() else 8443
        elif f["type"] in ("port",):
            s[f["k"]] = int(v) if str(v).isdigit() else 0
        elif f["type"] == "int":
            s[f["k"]] = int(v)
        elif f["type"] == "tunnel":
            s[f["k"]] = 0
        else:
            s[f["k"]] = v
    s.setdefault("network", "tcp")
    if s.get("fports"):
        a, _, b = s["fports"].split(",")[0].split("/")[0].partition(":")
        port, s["target_port"] = int(a), int(b or a)
    s.update(token="TOKEN_EXAMPLE", ctl_port=4000 if s.get("role") == "server" else 0)
    if kind in ("gre", "ipip", "vxlan", "wg"):
        s.update(inner_local="10.200.0.1", inner_remote="10.200.0.2", local_ip=host or "PANEL_IP", remote_ip="5.6.7.8",
                 priv="PRIVATE_KEY_THIS", pub="PUBLIC_KEY_THIS", rpriv="PRIVATE_KEY_OTHER", rpub="PUBLIC_KEY_OTHER", psk="PRESHARED_KEY")
        if "expose_port" in s and not s["expose_port"]:
            s.update(expose_port=8443, target_port=443)
    if kind == "combo":
        s.update(hop_host="127.0.0.1", hop_port=8443, via_name="تونل قبلی")
    return {"id": 0, "name": "example", "kind": kind, "port": port, "settings": s, "enabled": True}


# ------------------------------------------------------------------ one-paste script for the OTHER server
def remote_parts(t: dict, host: str):
    """-> (tool, exec_start, {file: content}) for the program the other server must run, or None."""
    k, s = t["kind"], t["settings"]
    role = s.get("role", "")
    H = host or "PANEL_IP"
    fn = {"frp": ("frps.toml", "frpc.toml"), "rathole": ("rathole-server.toml", "rathole-client.toml"), "backhaul": ("backhaul-server.toml", "backhaul-client.toml")}
    if k == "gost" and role == "entry":
        hp = f"{s['remote_port']}"
        return "gost", f"/usr/local/bin/gost -L relay+{s['transport']}://tcm:{s['token']}@:{hp}", {}
    if k == "chisel":
        if role == "server":
            reverse = " ".join(f"R:0.0.0.0:{pub}:{th}:{tp}{'/udp' if pr == 'udp' else ''}" for pub, th, tp, pr in maps(t))
            return "chisel", f"/usr/local/bin/chisel client --auth tcm:{s['token']} --keepalive 25s http://{H}:{s['ctl_port']} {reverse}", {}
        return "chisel", f"/usr/local/bin/chisel server --port {s['remote_port']} --reverse --auth tcm:{s['token']} --keepalive 25s", {}
    if k in fn:
        other = "client" if role == "server" else "server"
        name = f"{_name(t)}-" + fn[k][0 if other == "server" else 1]
        toml = {"frp": frp_toml, "rathole": rathole_toml, "backhaul": backhaul_toml}[k]
        cfg = toml(t, other, H) if other == "client" else toml(t, other)
        ex = {"frp": f"/usr/local/bin/{'frps' if other == 'server' else 'frpc'} -c {CONF_DIR_REMOTE}/{name}",
              "rathole": f"/usr/local/bin/rathole --{other} {CONF_DIR_REMOTE}/{name}",
              "backhaul": f"/usr/local/bin/backhaul -c {CONF_DIR_REMOTE}/{name}"}[k]
        return ("frp" if k == "frp" else k), ex, {name: cfg}
    return None


def remote_script(t: dict, host: str) -> str | None:
    parts = remote_parts(t, host)
    if not parts:
        return None
    tool, ex, conf = parts
    name = _name(t)
    unit = (f"[Unit]\nDescription=tcm19 tunnel {name}\nAfter=network-online.target\nWants=network-online.target\n\n[Service]\n"
            f"ExecStart={ex}\nRestart=always\nRestartSec=3\nLimitNOFILE=1048576\n\n[Install]\nWantedBy=multi-user.target")
    out = ["#!/bin/bash", "set -e", "# tcm19: راه‌اندازی سرور مقابل برای تونل «%s»" % t["name"].replace("\n", " "), _install_snippet(tool), f"mkdir -p {CONF_DIR_REMOTE}"]
    for fn, content in conf.items():
        out.append(f"cat > {CONF_DIR_REMOTE}/{fn} <<'EOF'\n{content.rstrip()}\nEOF")
    if conf:
        out.append(f"chmod 600 {CONF_DIR_REMOTE}/*")
    out += [f"cat > /etc/systemd/system/tcm19-{name}.service <<'EOF'\n{unit}\nEOF", f"systemctl daemon-reload && systemctl enable --now tcm19-{name}",
            "sleep 2", f"systemctl status tcm19-{name} --no-pager | head -8", f"journalctl -u tcm19-{name} -n 15 --no-pager"]
    body = "\n".join(out)
    return f"cat > /root/tcm19-{name}.sh <<'TCMEOF'\n{body}\nTCMEOF\nbash /root/tcm19-{name}.sh"
