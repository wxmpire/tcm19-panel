"""OpenVPN engine: private CA (EC P-256), tls-crypt, one client certificate per user.

Access control: the server runs a tls-verify script that only accepts certificates whose CN is listed in
allowed.txt (active users with OpenVPN enabled), so disabling / expiring a user works without a CRL.
Traffic is read from the local management interface (status 2).
"""
import ipaddress
import os
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
import time
from pathlib import Path

from . import config, db, system

NAME = "tcm19"
DIR = Path(os.environ.get("OVPN_DIR", f"/etc/openvpn/server/{NAME}"))
CONF = Path(os.environ.get("OVPN_CONF", f"/etc/openvpn/server/{NAME}.conf"))
SERVICE = f"openvpn-server@{NAME}"
IFACE = "tcmvpn"
MGMT_PORT = 7505
_started = time.time()
_last: dict[str, tuple[int, int]] = {}

VERIFY_SH = """#!/bin/sh
# tcm19: accept only certificates of allowed users
[ "$1" != "0" ] && exit 0
cn=$(printf '%s' "$2" | sed -n 's/.*CN *= *\\([^,\\/]*\\).*/\\1/p')
[ -n "$cn" ] && grep -qxF "$cn" "@DIR@/allowed.txt"
"""


def cn_for(u: dict) -> str:
    return f"u{u['id']}-{u['username']}"


def _sh(cmd: list[str], cwd: Path | None = None) -> str:
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=60, cwd=cwd)
    if p.returncode != 0:
        raise RuntimeError(f"{cmd[0]} failed: {(p.stderr or p.stdout).strip()[-300:]}")
    return p.stdout


def _write(path: Path, data: str, mode: int):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)
    os.chmod(path, mode)


def _read(name: str) -> str:
    return (DIR / name).read_text()


def _issue(cn: str, usage: str) -> tuple[str, str]:
    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        _sh(["openssl", "ecparam", "-name", "prime256v1", "-genkey", "-noout", "-out", str(t / "k.pem")])
        _sh(["openssl", "req", "-new", "-key", str(t / "k.pem"), "-subj", f"/CN={cn}", "-out", str(t / "c.csr")])
        (t / "ext").write_text(f"basicConstraints=CA:FALSE\nkeyUsage=digitalSignature\nextendedKeyUsage={usage}\n")
        _sh(["openssl", "x509", "-req", "-in", str(t / "c.csr"), "-CA", str(DIR / "ca.crt"), "-CAkey", str(DIR / "ca.key"),
             "-CAcreateserial", "-CAserial", str(DIR / "ca.srl"), "-out", str(t / "c.pem"), "-days", "3650",
             "-sha256", "-extfile", str(t / "ext")])
        return (t / "c.pem").read_text(), (t / "k.pem").read_text()


def ensure_pki():
    """Create CA, server certificate and tls-crypt key once."""
    if (DIR / "server.crt").exists() and (DIR / "ta.key").exists():
        return
    DIR.mkdir(parents=True, exist_ok=True)
    os.chmod(DIR, 0o755)
    if not (DIR / "ca.crt").exists():
        _sh(["openssl", "ecparam", "-name", "prime256v1", "-genkey", "-noout", "-out", str(DIR / "ca.key")])
        os.chmod(DIR / "ca.key", 0o600)
        _sh(["openssl", "req", "-x509", "-new", "-key", str(DIR / "ca.key"), "-sha256", "-days", "3650",
             "-subj", "/CN=tcm19-openvpn-ca", "-out", str(DIR / "ca.crt")])
    crt, key = _issue("server", "serverAuth")
    _write(DIR / "server.crt", crt, 0o644)
    _write(DIR / "server.key", key, 0o600)
    body = "\n".join(secrets.token_hex(16) for _ in range(16))
    _write(DIR / "ta.key", "#\n# 2048 bit OpenVPN static key\n#\n-----BEGIN OpenVPN Static key V1-----\n"
           + body + "\n-----END OpenVPN Static key V1-----\n", 0o600)


def issue_client(u: dict) -> dict:
    ensure_pki()
    crt, key = _issue(cn_for(u), "clientAuth")
    return {"ovpn_enabled": True, "ovpn_cert": crt, "ovpn_key": key}


def client_config(u: dict, settings: dict) -> str | None:
    if not u.get("ovpn_enabled") or not u.get("ovpn_cert") or settings.get("ovpn_enabled") != "1":
        return None
    if not (DIR / "ca.crt").exists():
        return None
    proto = "tcp-client" if settings.get("ovpn_proto") == "tcp" else "udp"
    host = settings.get("server_address") or "YOUR_SERVER"
    lines = ["client", "dev tun", f"proto {proto}", f"remote {host} {settings.get('ovpn_port', '1194')}",
             "nobind", "persist-key", "persist-tun", "remote-cert-tls server", "auth SHA256",
             "data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305", "verb 3",
             "<ca>", _read("ca.crt").strip(), "</ca>", "<cert>", u["ovpn_cert"].strip(), "</cert>",
             "<key>", u["ovpn_key"].strip(), "</key>", "<tls-crypt>", _read("ta.key").strip(), "</tls-crypt>", ""]
    return "\n".join(l for i, l in enumerate(lines) if l or i == len(lines) - 1)


def server_conf(s: dict) -> str:
    net = ipaddress.ip_network(s.get("ovpn_subnet", "10.77.0.0/24"), strict=False)
    tcp = s.get("ovpn_proto") == "tcp"
    group = "nogroup" if shutil.which("getent") and subprocess.run(["getent", "group", "nogroup"],
                                                                      capture_output=True).returncode == 0 else "nobody"
    lines = [f"port {s.get('ovpn_port', '1194')}", f"proto {'tcp-server' if tcp else 'udp'}",
             f"dev {IFACE}", "dev-type tun", "topology subnet", f"server {net.network_address} {net.netmask}",
             f"ca {DIR}/ca.crt", f"cert {DIR}/server.crt", f"key {DIR}/server.key", "dh none",
             f"tls-crypt {DIR}/ta.key", "tls-version-min 1.2", "auth SHA256",
             "data-ciphers AES-256-GCM:AES-128-GCM:CHACHA20-POLY1305",
             'push "redirect-gateway def1 bypass-dhcp"']
    for d in [x.strip() for x in s.get("dns", "1.1.1.1").split(",") if x.strip()][:3]:
        lines.append(f'push "dhcp-option DNS {d}"')
    lines += ["keepalive 10 60", f"user nobody", f"group {group}", "persist-key", "persist-tun",
              f"management 127.0.0.1 {MGMT_PORT} {DIR}/mgmt.pass", "script-security 2",
              f"tls-verify {DIR}/verify.sh", f"client-config-dir {DIR}/ccd", "max-clients 500", "verb 3"]
    if not tcp:
        lines.append("explicit-exit-notify 1")
    return "\n".join(lines) + "\n"


# ---------- management interface ----------
def _mgmt(cmds: list[str]) -> str:
    try:
        pw = _read("mgmt.pass").strip()
        sk = socket.create_connection(("127.0.0.1", MGMT_PORT), timeout=4)
        sk.settimeout(4)
        buf = b""

        def until(tokens: tuple[bytes, ...]):
            nonlocal buf
            while not any(t in buf for t in tokens):
                d = sk.recv(65536)
                if not d:
                    break
                buf += d
        until((b"PASSWORD:",))
        sk.sendall(pw.encode() + b"\n")
        until((b"SUCCESS",))
        buf = b""
        out = ""
        for c in cmds:
            sk.sendall(c.encode() + b"\n")
            buf = b""
            until((b"\nEND\n", b"SUCCESS:", b"ERROR:") if c.startswith("status") else (b"SUCCESS:", b"ERROR:"))
            out += buf.decode(errors="replace")
        sk.sendall(b"quit\n")
        sk.close()
        return out
    except Exception:
        return ""


def sessions() -> list[dict]:
    """Live OpenVPN sessions from the management interface."""
    if config.DRY_RUN or not (DIR / "mgmt.pass").exists():
        return []
    out = []
    for line in _mgmt(["status 2"]).splitlines():
        p = line.strip().split(",")
        if len(p) < 9 or p[0] != "CLIENT_LIST":
            continue
        m = re.match(r"u(\d+)-", p[1])
        if not m:
            continue
        try:
            out.append({"uid": int(m.group(1)), "cn": p[1], "ip": p[2].rsplit(":", 1)[0].strip("[]"), "virt": p[3],
                        "rx": int(p[5]), "tx": int(p[6]), "since": int(p[8])})
        except ValueError:
            continue
    return out


def kick(cn: str) -> int:
    out = _mgmt([f"kill {cn}"])
    return 1 if "SUCCESS" in out else 0


def _ensure_ips(s: dict, users: list[dict]):
    """Fixed tunnel IP per OpenVPN user (needed for per-user speed limits); returns {cn: (ip, mask)}."""
    net = ipaddress.ip_network(s.get("ovpn_subnet", "10.77.0.0/24"), strict=False)
    used = {u["ovpn_ip"] for u in users if u.get("ovpn_ip")}
    hosts = net.hosts()
    next(hosts, None)  # .1 is the server
    out = {}
    for u in users:
        if not u.get("ovpn_enabled"):
            continue
        ip = u.get("ovpn_ip")
        try:
            if not ip or ipaddress.ip_address(ip) not in net:
                raise ValueError
        except ValueError:
            ip = next((str(h) for h in hosts if str(h) not in used), "")
            if not ip:
                continue
            used.add(ip)
            db.update_user(u["id"], {"ovpn_ip": ip})
            u["ovpn_ip"] = ip
        out[cn_for(u)] = (ip, str(net.netmask))
    return out


def _write_ccd(fixed: dict):
    d = DIR / "ccd"
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o755)
    for cn, (ip, mask) in fixed.items():
        _write(d / cn, f"ifconfig-push {ip} {mask}\n", 0o644)
    for f in d.iterdir():
        if f.name not in fixed:
            f.unlink()


def read_traffic(split: dict | None = None) -> dict[int, int]:
    if config.DRY_RUN or not (DIR / "mgmt.pass").exists():
        return {}
    out = _mgmt(["status 2"])
    seen, deltas = set(), {}
    for line in out.splitlines():
        p = line.strip().split(",")
        if len(p) < 9 or p[0] != "CLIENT_LIST":
            continue
        m = re.match(r"u(\d+)-", p[1])
        if not m:
            continue
        uid = int(m.group(1))
        try:
            rx, tx, since = int(p[5]), int(p[6]), int(p[8])
        except ValueError:
            continue
        key = f"{p[1]}|{p[2]}|{since}"
        seen.add(key)
        prev = _last.get(key)
        _last[key] = (rx, tx)
        if prev is None:
            if since < _started - 5:  # session existed before the panel started: count from now on
                continue
            prev = (0, 0)
        d_rx, d_tx = max(rx - prev[0], 0), max(tx - prev[1], 0)
        deltas[uid] = deltas.get(uid, 0) + d_rx + d_tx
        if split is not None:  # rx = received from the client (their upload)
            cur = split.get(uid, (0, 0))
            split[uid] = (cur[0] + d_rx, cur[1] + d_tx)
    for k in [k for k in _last if k not in seen]:
        _last.pop(k, None)
    return deltas


# ---------- apply ----------
def _firewall(s: dict):
    net = str(ipaddress.ip_network(s.get("ovpn_subnet", "10.77.0.0/24"), strict=False))
    out_if = system.default_iface()
    proto = "tcp" if s.get("ovpn_proto") == "tcp" else "udp"
    port = str(s.get("ovpn_port", "1194"))
    system.run(["sysctl", "-w", "net.ipv4.ip_forward=1"])
    rules = [(["-t", "nat"], "POSTROUTING", ["-s", net, "-o", out_if, "-j", "MASQUERADE"], "A"),
             ([], "FORWARD", ["-i", IFACE, "-j", "ACCEPT"], "I"),
             ([], "FORWARD", ["-o", IFACE, "-m", "state", "--state", "RELATED,ESTABLISHED", "-j", "ACCEPT"], "I"),
             ([], "INPUT", ["-p", proto, "--dport", port, "-j", "ACCEPT"], "I")]
    for tbl, chain, spec, mode in rules:
        code, _ = system.run(["iptables", *tbl, "-C", chain, *spec])
        if code != 0:
            system.run(["iptables", *tbl, f"-{mode}", chain] + (["1"] if mode == "I" else []) + spec)
    code, out = system.run(["ufw", "status"])
    if code == 0 and "Status: active" in out:
        system.run(["ufw", "allow", f"{port}/{proto}"])


def apply(s: dict, users: list[dict]) -> str:
    enabled = s.get("ovpn_enabled") == "1"
    if not enabled:
        if not config.DRY_RUN and CONF.exists():
            system.run(["systemctl", "disable", "--now", SERVICE], 30)
        return "disabled"
    if not system.have("openssl"):
        return "error: openssl is not installed"
    ensure_pki()
    allowed = [cn_for(u) for u in users if u.get("ovpn_enabled") and u["status"] == "active"]
    _write(DIR / "allowed.txt", "\n".join(allowed) + "\n", 0o644)
    _write(DIR / "verify.sh", VERIFY_SH.replace("@DIR@", str(DIR)), 0o755)
    if not (DIR / "mgmt.pass").exists():
        _write(DIR / "mgmt.pass", secrets.token_urlsafe(24) + "\n", 0o600)
    _write_ccd(_ensure_ips(s, users))
    conf = server_conf(s)
    changed = not CONF.exists() or CONF.read_text() != conf
    if config.DRY_RUN:
        _write(CONF, conf, 0o644)
        return "dry-run"
    if not system.have("openvpn"):
        env = dict(os.environ, DEBIAN_FRONTEND="noninteractive")
        subprocess.run(["apt-get", "install", "-y", "openvpn"], capture_output=True, timeout=400, env=env)
        if not system.have("openvpn"):
            return "error: could not install openvpn (apt-get install openvpn)"
    if changed:
        _write(CONF, conf, 0o644)
    _firewall(s)
    code, state = system.run(["systemctl", "is-active", SERVICE])
    if state.strip() != "active" or changed:
        code, out = system.run(["bash", "-c", f"systemctl enable {SERVICE} >/dev/null 2>&1; systemctl restart {SERVICE}"], 40)
        return "started" if code == 0 else f"start failed: {out[-300:]}"
    # users removed / disabled: drop their live sessions
    live = _mgmt(["status 2"])
    kills = []
    for line in live.splitlines():
        p = line.split(",")
        if len(p) > 2 and p[0] == "CLIENT_LIST" and p[1] not in allowed:
            kills.append(f"kill {p[1]}")
    if kills:
        _mgmt(kills)
    return "ok"
