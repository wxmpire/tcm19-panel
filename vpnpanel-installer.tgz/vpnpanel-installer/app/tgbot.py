"""Telegram bot for tcm19.  Runs as its own systemd service (tcm19-bot) so it keeps working - and can start the
panel again - when the panel itself is down.  Users / configs go through the panel's local HTTP API (an API key is
created automatically); engines, services and backups are handled directly.

Stdlib only.  Entry point:  python -m app.tgbot
"""
import hashlib
import hmac
import html
import json
import os
import re
import secrets
import shutil
import socket
import ssl
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

from . import config, db

SERVICE = "tcm19-bot"
UNIT = Path("/etc/systemd/system/tcm19-bot.service")
TCM19 = "/usr/local/bin/tcm19"
ENGINES = [("xray", "Xray"), ("singbox", "sing-box"), ("mihomo", "Mihomo"), ("wireguard", "WireGuard"), ("openvpn", "OpenVPN")]
ENGINE_SVC = {"xray": "xray", "singbox": "sing-box", "mihomo": "mihomo", "wireguard": "wg-quick@wg0", "openvpn": "openvpn-server@tcm19"}
ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
E = html.escape


# ------------------------------------------------------------------ settings helpers (shared with the panel)
def cfg() -> dict:
    return db.get_settings()


def admins() -> list[dict]:
    try:
        return json.loads(cfg().get("tg_admins") or "[]")
    except ValueError:
        return []


def save_admins(items: list[dict]):
    db.set_settings({"tg_admins": json.dumps(items, ensure_ascii=False)})


def add_admin(uid: int, name: str = "") -> bool:
    items = admins()
    if any(int(a["id"]) == int(uid) for a in items):
        return False
    items.append({"id": int(uid), "name": name[:40]})
    save_admins(items)
    return True


def new_pair_code(hours: float = 0.17) -> str:
    code = secrets.token_hex(4).upper()
    db.set_settings({"tg_pair": f"{code}|{int(time.time() + hours * 3600)}"})
    return code


def use_pair_code(code: str) -> bool:
    raw = cfg().get("tg_pair", "")
    if "|" not in raw:
        return False
    c, exp = raw.split("|", 1)
    if c and code.strip().upper() == c and time.time() < int(exp or 0):
        db.set_settings({"tg_pair": ""})
        return True
    return False


def panel_port() -> str:
    try:
        out = subprocess.run(["systemctl", "cat", "vpnpanel"], capture_output=True, text=True, timeout=10).stdout
        m = re.findall(r"--port (\d+)", out)
        return m[-1] if m else "8000"
    except Exception:
        return "8000"


def public_url() -> tuple[str, bool]:
    """(panel URL as users reach it, is_https)"""
    port = panel_port()
    try:
        from . import certstore
        dom = certstore.panel_domain()
    except Exception:
        dom = ""
    if dom:
        return f"https://{dom}:{port}", True
    host = cfg().get("server_address") or _public_ip()
    return f"http://{host}:{port}", False


def _public_ip() -> str:
    for u in ("https://api.ipify.org", "https://ifconfig.me/ip"):
        try:
            return urllib.request.urlopen(u, timeout=5).read().decode().strip()
        except Exception:
            continue
    return "SERVER_IP"


# ------------------------------------------------------------------ service install (used by the panel / panelctl)
def install_service():
    py = config.BASE_DIR / "venv/bin/python"
    py = str(py) if py.exists() else sys.executable
    UNIT.write_text(f"""[Unit]
Description=tcm19 Telegram bot
After=network-online.target

[Service]
User=root
WorkingDirectory={config.BASE_DIR}
Environment=PANEL_HOME={config.BASE_DIR}
ExecStart={py} -m app.tgbot
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
""")
    subprocess.run(["systemctl", "daemon-reload"], timeout=30)


def validate_token(token: str) -> str:
    """Returns the bot username or raises ValueError."""
    if not re.fullmatch(r"\d{6,12}:[A-Za-z0-9_-]{30,50}", token or ""):
        raise ValueError("فرمت توکن درست نیست (مثل 123456789:AAH...)")
    try:
        r = json.load(urllib.request.urlopen(f"https://api.telegram.org/bot{token}/getMe", timeout=15))
    except urllib.error.HTTPError as e:
        raise ValueError("توکن از طرف تلگرام قبول نشد (از @BotFather دوباره بگیر)" if e.code in (401, 404) else f"خطای تلگرام {e.code}")
    except Exception as e:
        raise ValueError(f"اتصال سرور به تلگرام ممکن نیست: {e}")
    if not r.get("ok"):
        raise ValueError("توکن نامعتبر است")
    return r["result"]["username"]


def setup(token: str, owner_id: int | None = None) -> str:
    uname = validate_token(token.strip())
    db.set_settings({"tg_token": token.strip(), "tg_enabled": "1", "tg_username": uname})
    if owner_id:
        add_admin(owner_id, "owner")
    install_service()
    subprocess.run(["systemctl", "enable", SERVICE], capture_output=True, timeout=30)
    subprocess.run(["systemctl", "restart", SERVICE], capture_output=True, timeout=30)
    return uname


def stop_service(clear_token: bool = False):
    subprocess.run(["systemctl", "disable", "--now", SERVICE], capture_output=True, timeout=30)
    vals = {"tg_enabled": "0"}
    if clear_token:
        vals.update(tg_token="", tg_username="")
    db.set_settings(vals)


def service_state() -> str:
    if not UNIT.exists():
        return "not-installed"
    return subprocess.run(["systemctl", "is-active", SERVICE], capture_output=True, text=True).stdout.strip() or "unknown"


def verify_webapp(init_data: str, token: str) -> int | None:
    """Validates Telegram Mini App initData; returns the Telegram user id or None."""
    try:
        pairs = dict(urllib.parse.parse_qsl(init_data, keep_blank_values=True))
        h = pairs.pop("hash", "")
        dcs = "\n".join(f"{k}={v}" for k, v in sorted(pairs.items()))
        secret = hmac.new(b"WebAppData", token.encode(), hashlib.sha256).digest()
        if not hmac.compare_digest(hmac.new(secret, dcs.encode(), hashlib.sha256).hexdigest(), h):
            return None
        if time.time() - int(pairs.get("auth_date", "0")) > 86400:
            return None
        return int(json.loads(pairs["user"])["id"])
    except Exception:
        return None


# ------------------------------------------------------------------ Telegram API
class TG:
    def __init__(self, token: str):
        self.base = f"https://api.telegram.org/bot{token}/"
        self.token = token

    def call(self, method: str, params: dict | None = None, timeout: int = 40):
        data = json.dumps(params or {}).encode()
        req = urllib.request.Request(self.base + method, data, {"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return json.load(r)
        except urllib.error.HTTPError as e:
            try:
                return json.load(e)
            except Exception:
                return {"ok": False, "description": str(e)}

    def send(self, chat, text, kb=None, **kw):
        out = None
        chunks = [text[i:i + 3900] for i in range(0, len(text), 3900)] or [""]
        for i, part in enumerate(chunks):
            p = {"chat_id": chat, "text": part, "parse_mode": "HTML", "disable_web_page_preview": True, **kw}
            if kb and i == len(chunks) - 1:
                p["reply_markup"] = {"inline_keyboard": kb}
            out = self.call("sendMessage", p)
        return out

    def edit(self, chat, mid, text, kb=None):
        p = {"chat_id": chat, "message_id": mid, "text": text[:3900], "parse_mode": "HTML", "disable_web_page_preview": True}
        if kb:
            p["reply_markup"] = {"inline_keyboard": kb}
        return self.call("editMessageText", p)

    def doc(self, chat, name: str, data: bytes, caption: str = ""):
        b = "----tcm" + secrets.token_hex(8)
        body = b""
        for k, v in (("chat_id", str(chat)), ("caption", caption[:1000]), ("parse_mode", "HTML")):
            body += f'--{b}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n{v}\r\n'.encode()
        body += (f'--{b}\r\nContent-Disposition: form-data; name="document"; filename="{name}"\r\n'
                 f"Content-Type: application/octet-stream\r\n\r\n").encode() + data + f"\r\n--{b}--\r\n".encode()
        req = urllib.request.Request(self.base + "sendDocument", body, {"Content-Type": f"multipart/form-data; boundary={b}"})
        try:
            with urllib.request.urlopen(req, timeout=120) as r:
                return json.load(r)
        except Exception as e:
            return {"ok": False, "description": str(e)}

    def download(self, file_id: str) -> bytes | None:
        r = self.call("getFile", {"file_id": file_id})
        if not r.get("ok"):
            return None
        url = f"https://api.telegram.org/file/bot{self.token}/{r['result']['file_path']}"
        return urllib.request.urlopen(url, timeout=120).read()


# ------------------------------------------------------------------ panel API client
class PanelDown(Exception):
    pass


class ApiError(Exception):
    def __init__(self, code, msg):
        super().__init__(msg)
        self.code = code


_base: str | None = None


def ensure_key() -> str:
    from . import apikeys
    key = cfg().get("tg_apikey", "")
    if key and apikeys.verify(key):
        return key
    key = apikeys.create("telegram-bot", "full")["key"]
    db.set_settings({"tg_apikey": key})
    return key


def api(method: str, path: str, body=None, timeout: int = 90):
    global _base
    key = ensure_key()
    port = panel_port()
    bases = [_base] if _base else [f"http://127.0.0.1:{port}", f"https://127.0.0.1:{port}"]
    ctx = ssl._create_unverified_context()
    last = None
    for b in bases:
        try:
            req = urllib.request.Request(b + path, json.dumps(body).encode() if body is not None else None, method=method,
                                         headers={"X-API-Key": key, "Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
                _base = b
                raw = r.read()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            _base = b
            try:
                d = json.load(e).get("detail")
            except Exception:
                d = None
            raise ApiError(e.code, d if isinstance(d, str) else (json.dumps(d, ensure_ascii=False) if d else f"HTTP {e.code}"))
        except Exception as ex:
            last = ex
    _base = None
    raise PanelDown(str(last))


# ------------------------------------------------------------------ formatting helpers
def gb(n) -> str:
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or u == "TB":
            return f"{n:.0f} {u}" if u in ("B", "KB") else f"{n:.2f} {u}"
        n /= 1024


def days_left(ts) -> str:
    if not ts:
        return "نامحدود"
    d = (int(ts) - time.time()) / 86400
    return f"{int(d)} روز" if d >= 1 else ("امروز" if d > 0 else "منقضی")


def uline(u: dict) -> str:
    st = {"active": "🟢", "disabled": "⚪️", "limited": "🟠", "expired": "🔴"}.get(u["status"], "⚪️")
    lim = gb(u["data_limit"]) if u["data_limit"] else "∞"
    return f"{st} {u['username']} · {gb(u['used'])}/{lim} · {days_left(u['expire_at'])}"


def sh(cmd, timeout=60, env=None) -> str:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env={**os.environ, **(env or {})})
        return ANSI.sub("", (p.stdout + p.stderr)).strip()
    except subprocess.TimeoutExpired:
        return "timeout"
    except Exception as e:
        return str(e)


def tail(text: str, n=18) -> str:
    return "\n".join(text.splitlines()[-n:])[-1800:]


def active(svc: str) -> str:
    return sh(["systemctl", "is-active", svc], 10) or "unknown"


def flag(cc: str) -> str:
    cc = (cc or "").upper()
    return "".join(chr(0x1F1E6 + ord(c) - 65) for c in cc) if len(cc) == 2 and cc.isalpha() else "🌐"


# ------------------------------------------------------------------ check-host.net
def _chget(path: str):
    req = urllib.request.Request("https://check-host.net" + path, headers={"Accept": "application/json", "User-Agent": "tcm19-bot"})
    return json.load(urllib.request.urlopen(req, timeout=20))


def checkhost(kind: str, target: str, wait: int = 28) -> str:
    nodes = _chget("/nodes/hosts").get("nodes", {})
    ir = [n for n in nodes if n.startswith("ir")][:5]
    world, seen = [], set()
    for n, info in nodes.items():
        cc = (info.get("location") or [""])[0]
        if cc in ("de", "nl", "us", "fr", "tr", "fi", "gb") and cc not in seen and len(world) < 4:
            seen.add(cc)
            world.append(n)
    sel = ir + world
    q = "host=" + urllib.parse.quote(target) + "".join("&node=" + n for n in sel)
    r = _chget(f"/check-{kind}?{q}")
    rid = r.get("request_id")
    if not rid:
        return "check-host درخواست را قبول نکرد."
    meta = r.get("nodes", {})
    res = {}
    t0 = time.time()
    while time.time() - t0 < wait:
        time.sleep(4)
        res = _chget(f"/check-result/{rid}")
        if res and all(res.get(n) is not None for n in sel):
            break
    lines = []
    for n in sel:
        info = meta.get(n) or []
        label = f"{flag(info[0] if info else '')} {info[2] if len(info) > 2 else n}"
        v = res.get(n)
        if v is None:
            lines.append(f"{label}: ⏳ جواب نیامد")
        elif kind == "ping":
            att = v[0] if v and isinstance(v[0], list) else []
            oks = [a[1] for a in att if isinstance(a, list) and a and a[0] == "OK" and a[1] is not None]
            if oks:
                lines.append(f"{label}: ✅ {len(oks)}/{len(att)} · میانگین {sum(oks) / len(oks) * 1000:.0f}ms")
            else:
                lines.append(f"{label}: ❌ بدون جواب")
        else:
            d = v[0] if v else {}
            if isinstance(d, dict) and "time" in d:
                lines.append(f"{label}: ✅ {d['time'] * 1000:.0f}ms")
            else:
                lines.append(f"{label}: ❌ {(d or {}).get('error', 'خطا') if isinstance(d, dict) else 'خطا'}")
    return "\n".join(lines) + f"\n\n🔗 https://check-host.net/check-report/{rid}"


# ------------------------------------------------------------------ server-side speed test (outside Iran)
def speed_server() -> str:
    out = []
    t = []
    for _ in range(3):
        s = time.time()
        try:
            socket.create_connection(("1.1.1.1", 443), timeout=4).close()
            t.append((time.time() - s) * 1000)
        except OSError:
            pass
    out.append(f"🏓 تأخیر تا Cloudflare: {sum(t) / len(t):.0f}ms" if t else "🏓 تأخیر: ناموفق")
    try:
        s, got = time.time(), 0
        with urllib.request.urlopen("https://speed.cloudflare.com/__down?bytes=40000000", timeout=15) as r:
            while time.time() - s < 9:
                c = r.read(262144)
                if not c:
                    break
                got += len(c)
        out.append(f"⬇️ دانلود: {got * 8 / (time.time() - s) / 1e6:.0f} Mbps")
    except Exception as e:
        out.append(f"⬇️ دانلود: ناموفق ({str(e)[:40]})")
    try:
        data = b"0" * 8_000_000
        s = time.time()
        urllib.request.urlopen(urllib.request.Request("https://speed.cloudflare.com/__up", data, {"Content-Type": "text/plain"}), timeout=20).read()
        out.append(f"⬆️ آپلود: {len(data) * 8 / (time.time() - s) / 1e6:.0f} Mbps")
    except Exception as e:
        out.append(f"⬆️ آپلود: ناموفق ({str(e)[:40]})")
    return "\n".join(out)


# ------------------------------------------------------------------ the bot
STATE: dict[int, dict] = {}
LOCK = threading.Lock()


class Bot:
    def __init__(self, token: str):
        self.tg = TG(token)

    # ---------- helpers
    def is_admin(self, uid: int) -> bool:
        return any(int(a["id"]) == int(uid) for a in admins())

    def notify(self, text: str, kb=None):
        for a in admins():
            try:
                self.tg.send(a["id"], text, kb)
            except Exception:
                pass

    def show(self, chat, mid, text, kb=None):
        if mid:
            r = self.tg.edit(chat, mid, text, kb)
            if r.get("ok") or "not modified" in str(r.get("description", "")):
                return
        self.tg.send(chat, text, kb)

    @staticmethod
    def back(to="m", label="◀️ برگشت"):
        return [{"text": label, "callback_data": to}]

    # ---------- menus
    def main_menu(self, chat, mid=None, note=""):
        url, https = public_url()
        kb = [
            [{"text": "📊 وضعیت", "callback_data": "st"}, {"text": "👥 کاربران", "callback_data": "us:0"}],
            [{"text": "➕ ساخت کاربر", "callback_data": "nu"}, {"text": "🧪 کانفیگ تست", "callback_data": "tc"}],
            [{"text": "⚙️ موتورها", "callback_data": "en"}, {"text": "🚇 تونل‌ها", "callback_data": "tn"}],
            [{"text": "💾 بکاپ", "callback_data": "bk"}, {"text": "🚀 اسپید تست", "callback_data": "sp"}],
            [{"text": "🏓 پینگ (Check-Host)", "callback_data": "pg"}, {"text": "🖥 پنل", "callback_data": "pn"}],
            [{"text": "🟢 آنلاین‌ها", "callback_data": "on"}, {"text": "📜 لاگ فعالیت", "callback_data": "ac"}],
        ]
        if https:
            kb.append([{"text": "📱 باز کردن مینی‌اپ", "web_app": {"url": url + "/miniapp"}}])
        else:
            kb.append([{"text": "📱 مینی‌اپ", "callback_data": "ma"}])
        self.show(chat, mid, (note + "\n\n" if note else "") + "🤖 <b>مدیریت پنل tcm19</b>\nیکی را انتخاب کن:", kb)

    def status(self, chat, mid):
        lines = ["📊 <b>وضعیت</b>"]
        ps = active("vpnpanel")
        lines.append(f"پنل: {'🟢 روشن' if ps == 'active' else '🔴 ' + ps}")
        kb = []
        if ps == "active":
            try:
                d = api("GET", "/api/dashboard")
                bs = d.get("by_status", {})
                lines.append(f"👥 کاربران: {d.get('users_total', 0)} (فعال {bs.get('active', 0)} · محدود {bs.get('limited', 0)} · منقضی {bs.get('expired', 0)})")
                lines.append(f"📶 مصرف کل: {gb(d.get('total_used', 0))}")
                s = d.get("system", {})
                if s.get("mem_total"):
                    lines.append(f"💻 رم: {gb(s['mem_total'] - s['mem_available'])}/{gb(s['mem_total'])} · دیسک: {gb(s['disk_used'])}/{gb(s['disk_total'])}")
                if s.get("load"):
                    lines.append(f"⚡️ لود: {' '.join(str(x) for x in s['load'])} · آپتایم: {s.get('uptime', 0) // 3600} ساعت")
            except (PanelDown, ApiError) as e:
                lines.append(f"⚠️ API پنل جواب نداد: {E(str(e)[:80])}")
        else:
            kb.append([{"text": "▶️ روشن کردن پنل", "callback_data": "pna:start"}])
        eng = []
        for k, name in ENGINES:
            st = active(ENGINE_SVC[k])
            if k in ("wireguard", "openvpn") and st != "active":
                continue
            eng.append(f"{'🟢' if st == 'active' else '🔴'} {name}")
        lines.append("⚙️ موتورها: " + " · ".join(eng))
        kb.append(self.back())
        self.show(chat, mid, "\n".join(lines), kb)

    # ---------- users
    def users(self, chat, mid, page=0):
        q = STATE.get(chat, {}).get("q", "")
        try:
            d = api("GET", f"/api/users?per_page=8&page={page + 1}&search={urllib.parse.quote(q)}")
        except (PanelDown, ApiError) as e:
            return self.panel_err(chat, mid, e)
        kb = [[{"text": uline(u)[:60], "callback_data": f"u:{u['id']}"}] for u in d["items"]]
        nav = []
        if page > 0:
            nav.append({"text": "◀️", "callback_data": f"us:{page - 1}"})
        if (page + 1) * 8 < d["total"]:
            nav.append({"text": "▶️", "callback_data": f"us:{page + 1}"})
        if nav:
            kb.append(nav)
        kb.append([{"text": "🔍 جستجو", "callback_data": "usq"}, {"text": "➕ کاربر جدید", "callback_data": "nu"}])
        if q:
            kb.append([{"text": f"❌ حذف فیلتر «{q}»", "callback_data": "usc"}])
        kb.append(self.back())
        self.show(chat, mid, f"👥 <b>کاربران</b> ({d['total']}){' — جستجو: ' + E(q) if q else ''}", kb)

    def user_view(self, chat, mid, uid):
        try:
            u = api("GET", f"/api/users/{uid}")
        except (PanelDown, ApiError) as e:
            return self.panel_err(chat, mid, e)
        on = u["status"] != "disabled"
        try:
            us = api("GET", f"/api/users/{uid}/usage?days=14")
            mx = max([x["bytes"] for x in us] or [1]) or 1
            spark = "".join("▁▂▃▄▅▆▇█"[min(7, int(x["bytes"] / mx * 7.99))] if x["bytes"] else "·" for x in us)
            spark = f"\n📈 ۱۴ روز: <code>{spark}</code> (بیشترین {gb(mx)})"
        except (PanelDown, ApiError, TypeError, KeyError):
            spark = ""
        t = (f"👤 <b>{E(u['username'])}</b>\nوضعیت: {u['status']}\nمصرف: {gb(u['used'])} از {gb(u['data_limit']) if u['data_limit'] else 'نامحدود'}\n"
             f"انقضا: {days_left(u['expire_at'])}\nWG: {'✅' if u.get('wg_enabled') else '—'} · OpenVPN: {'✅' if u.get('ovpn_enabled') else '—'}\n"
             f"دستگاه مجاز: {u.get('max_ips') or '∞'} · سقف سرعت: {str(u.get('speed_mbps')) + ' Mbps' if u.get('speed_mbps') else '∞'}{spark}\n📝 {E(u.get('note') or '-')}\n\n🔗 اشتراک:\n<code>{E(u['sub_url'])}</code>")
        kb = [[{"text": "🔗 کانفیگ‌ها", "callback_data": f"ul:{uid}"}, {"text": "⏸ غیرفعال" if on else "▶️ فعال", "callback_data": f"ua:{uid}:tog"}],
              [{"text": "➕ تمدید (روز)", "callback_data": f"ua:{uid}:days"}, {"text": "📦 حجم (GB)", "callback_data": f"ua:{uid}:gb"}],
              [{"text": "♻️ ریست مصرف", "callback_data": f"ua:{uid}:reset"}, {"text": "🔄 لینک جدید", "callback_data": f"ua:{uid}:revoke"}],
              [{"text": "WG " + ("خاموش" if u.get("wg_enabled") else "روشن"), "callback_data": f"ua:{uid}:wg"},
               {"text": "OpenVPN " + ("خاموش" if u.get("ovpn_enabled") else "روشن"), "callback_data": f"ua:{uid}:ovpn"}],
              [{"text": "📝 یادداشت", "callback_data": f"ua:{uid}:note"}, {"text": "🗑 حذف", "callback_data": f"ua:{uid}:del"}],
              self.back("us:0")]
        self.show(chat, mid, t, kb)

    def user_action(self, chat, mid, uid, act):
        try:
            if act == "tog":
                u = api("GET", f"/api/users/{uid}")
                api("PUT", f"/api/users/{uid}", {"status": "active" if u["status"] == "disabled" else "disabled"})
            elif act in ("days", "gb", "note"):
                STATE[chat] = {"kind": "edit", "uid": uid, "what": act}
                q = {"days": "چند روز اضافه شود؟ (عدد)", "gb": "حجم جدید چند گیگ؟ (۰ = نامحدود)", "note": "یادداشت جدید را بنویس:"}[act]
                return self.tg.send(chat, "✏️ " + q, [self.back(f"u:{uid}", "انصراف")])
            elif act == "reset":
                api("POST", f"/api/users/{uid}/reset-usage")
            elif act == "revoke":
                api("POST", f"/api/users/{uid}/revoke-sub")
            elif act in ("wg", "ovpn"):
                u = api("GET", f"/api/users/{uid}")
                key = "wg_enabled" if act == "wg" else "ovpn_enabled"
                api("PUT", f"/api/users/{uid}", {key: not u.get(key)})
            elif act == "del":
                return self.show(chat, mid, "⚠️ این کاربر حذف شود؟", [[{"text": "✅ بله، حذف", "callback_data": f"ua:{uid}:delok"}, {"text": "انصراف", "callback_data": f"u:{uid}"}]])
            elif act == "delok":
                api("DELETE", f"/api/users/{uid}")
                return self.users(chat, mid, 0)
        except (PanelDown, ApiError) as e:
            return self.panel_err(chat, mid, e)
        self.user_view(chat, mid, uid)

    def send_links(self, chat, uid):
        try:
            u = api("GET", f"/api/users/{uid}")
            d = api("GET", f"/api/users/{uid}/links")
        except (PanelDown, ApiError) as e:
            return self.tg.send(chat, f"⚠️ {E(str(e))}")
        parts = [f"🔗 <b>اشتراک {E(u['username'])}</b>\n<code>{E(u['sub_url'])}</code>"]
        for ln in d.get("links", [])[:12]:
            parts.append(f"<code>{E(ln)}</code>")
        for p in d.get("proxies", [])[:3]:
            parts.append(f"🧦 {E(p.get('remark', ''))}\n<code>{E(p.get('copy_text', ''))}</code>")
        self.tg.send(chat, "\n\n".join(parts))
        if d.get("wireguard"):
            self.tg.doc(chat, f"{u['username']}.conf", d["wireguard"].encode(), "WireGuard")
        if d.get("openvpn"):
            self.tg.doc(chat, f"{u['username']}.ovpn", d["openvpn"].encode(), "OpenVPN")
        if d.get("clash"):
            self.tg.doc(chat, f"{u['username']}-clash.yaml", d["clash"].encode(), "Clash/Mihomo")

    def create_user(self, chat, name, gb_, days, test=False):
        body = {"username": name, "data_limit_gb": gb_, "expire_days": days or None, "note": "telegram-bot" + (" test" if test else "")}
        try:
            u = api("POST", "/api/users", body)
        except (PanelDown, ApiError) as e:
            return self.tg.send(chat, f"⚠️ ساخت کاربر ناموفق: {E(str(e)[:200])}", [self.back()])
        self.tg.send(chat, f"✅ کاربر <b>{E(u['username'])}</b> ساخته شد.\nحجم: {gb_ or 'نامحدود'} GB · اعتبار: {days or 'نامحدود'} روز")
        self.send_links(chat, u["id"])
        kb = [[{"text": "👤 مشاهده کاربر", "callback_data": f"u:{u['id']}"}]]
        if test:
            kb.append([{"text": "🗑 حذف کاربر تست", "callback_data": f"ua:{u['id']}:delok"}])
        self.tg.send(chat, "چه کار دیگری؟", kb + [self.back()])

    # ---------- online / activity
    def online(self, chat, mid):
        try:
            d = api("GET", "/api/online")
        except (PanelDown, ApiError) as e:
            return self.panel_err(chat, mid, e)
        items = d["items"]
        lines = [f"🟢 <b>آنلاین‌ها</b> ({len(items)})"]
        kb = []
        for r in items[:20]:
            lines.append(f"• {E(r['username'])} — {len(r['ips'])} IP {E(' '.join(r['protos']))}" + (f"\n   <code>{E(', '.join(r['ips'][:4]))}</code>" if r["ips"] else ""))
            kb.append([{"text": f"✂️ قطع {r['username']}"[:40], "callback_data": f"ok:{r['id']}"}])
        if not items:
            lines.append("الان کسی وصل نیست.")
        kb.append([{"text": "🔃 بروزرسانی", "callback_data": "on"}])
        kb.append(self.back())
        self.show(chat, mid, "\n".join(lines), kb)

    def activity(self, chat, mid):
        try:
            d = api("GET", "/api/activity?per_page=12")
        except (PanelDown, ApiError) as e:
            return self.panel_err(chat, mid, e)
        lines = ["📜 <b>آخرین فعالیت‌ها</b>"]
        for i in d["items"]:
            lines.append(f"{time.strftime('%m/%d %H:%M', time.localtime(i['ts']))} · <b>{E(i['actor'])}</b>: {E(i['action'])}" + (f" ({E(i['detail'][:50])})" if i["detail"] else ""))
        self.show(chat, mid, "\n".join(lines), [[{"text": "🔃 بروزرسانی", "callback_data": "ac"}], self.back()])

    # ---------- engines
    def engines(self, chat, mid):
        kb, lines = [], ["⚙️ <b>موتورها</b>"]
        for k, name in ENGINES:
            inst = sh([TCM19, "engine", k, "state"], 20)
            installed = "installed=yes" in inst
            st = active(ENGINE_SVC[k]) if installed else "-"
            ic = "🟢" if st == "active" else ("⚪️ نصب نیست" if not installed else "🔴")
            lines.append(f"{ic} {name}")
            kb.append([{"text": f"{name}", "callback_data": f"e:{k}"}])
        kb.append(self.back())
        self.show(chat, mid, "\n".join(lines), kb)

    def engine_menu(self, chat, mid, k):
        name = dict(ENGINES)[k]
        inst = sh([TCM19, "engine", k, "state"], 20)
        installed = "installed=yes" in inst
        ver = (re.search(r"version=(\S*)", inst) or [None, ""])[1]
        st = active(ENGINE_SVC[k]) if installed else "نصب نیست"
        kb = [[{"text": "▶️ روشن", "callback_data": f"ea:{k}:start"}, {"text": "⏹ خاموش", "callback_data": f"ea:{k}:stop"}, {"text": "🔄 ریستارت", "callback_data": f"ea:{k}:restart"}],
              [{"text": "⬇️ نصب", "callback_data": f"ea:{k}:install"}, {"text": "⬆️ آپدیت", "callback_data": f"ea:{k}:update"}, {"text": "🗑 حذف", "callback_data": f"ea:{k}:remove"}],
              [{"text": "📜 لاگ", "callback_data": f"ea:{k}:logs"}], self.back("en")]
        self.show(chat, mid, f"⚙️ <b>{name}</b> {('v' + ver) if ver else ''}\nوضعیت: {E(st)}", kb)

    def engine_action(self, chat, mid, k, act, yes=False):
        name = dict(ENGINES)[k]
        if act in ("stop", "remove") and not yes:
            return self.show(chat, mid, f"⚠️ {'خاموش کردن' if act == 'stop' else 'حذف'} {name} — مطمئنی؟", [[{"text": "✅ بله", "callback_data": f"eay:{k}:{act}"}, {"text": "انصراف", "callback_data": f"e:{k}"}]])
        self.show(chat, mid, f"⏳ {name}: {act} …")

        def work():
            out = sh([TCM19, "engine", k, act], 900, {"TCM_YES": "1"})
            self.tg.send(chat, f"<b>{name} — {act}</b>\n<pre>{E(tail(out) or 'انجام شد')}</pre>", [[{"text": "⚙️ برگشت به موتور", "callback_data": f"e:{k}"}]])
        threading.Thread(target=work, daemon=True).start()

    # ---------- tunnels
    def tunnels(self, chat, mid):
        try:
            rows = api("GET", "/api/tunnel-diag/health")
        except (PanelDown, ApiError) as e:
            return self.panel_err(chat, mid, e)
        if not rows:
            return self.show(chat, mid, "🚇 هنوز تونلی نساخته‌ای.", [self.back()])
        ic = {"ok": "🟢", "warn": "🟠", "bad": "🔴", "off": "⚪️"}
        lines, kb = ["🚇 <b>وضعیت تونل‌ها</b>"], []
        for t in rows:
            lines.append(f"{ic.get(t['level'], '⚪️')} {E(t['name'])} ({t['kind']})")
            if t["level"] in ("bad", "warn") and t.get("hints"):
                lines.append("   ↳ " + E(t["hints"][0][:110]))
            if t["id"] > 0 and t["level"] != "off":
                kb.append([{"text": f"🔄 ریستارت {t['name']}"[:40], "callback_data": f"tr:{t['id']}"}])
        kb.append([{"text": "🔃 بروزرسانی", "callback_data": "tn"}])
        kb.append(self.back())
        self.show(chat, mid, "\n".join(lines), kb)

    # ---------- backup
    def backup_menu(self, chat, mid):
        s = cfg()
        on = s.get("tg_backup") == "1"
        kb = [[{"text": "📤 ارسال بکاپ کامل همین الان", "callback_data": "bks"}],
              [{"text": ("✅ ارسال خودکار: روشن" if on else "⛔️ ارسال خودکار: خاموش") + f" (هر {s.get('tg_backup_hours', '24')} ساعت)", "callback_data": "bka"}],
              self.back()]
        self.show(chat, mid, "💾 <b>بکاپ</b>\nبکاپ کامل شامل کاربران، حجم‌ها، اینباندها، اوتباندها، مسیریابی، تونل‌ها، API، تنظیمات و گواهی‌هاست.", kb)

    def send_backup(self, chat, caption="💾 بکاپ کامل tcm19"):
        from . import backup
        try:
            p = backup.create("tgsend")
        except Exception as e:
            return self.tg.send(chat, f"⚠️ ساخت بکاپ ناموفق: {E(str(e)[:200])}")
        try:
            if p.stat().st_size > 49 * 1024 * 1024:
                return self.tg.send(chat, "⚠️ بکاپ بزرگ‌تر از ۵۰ مگ است و تلگرام نمی‌پذیرد؛ از بخش «بکاپ» پنل دانلودش کن.")
            r = self.tg.doc(chat, p.name.replace("-tgsend", ""), p.read_bytes(), caption)
            if not r.get("ok"):
                self.tg.send(chat, f"⚠️ ارسال بکاپ ناموفق: {E(str(r.get('description'))[:150])}")
        finally:
            p.unlink(missing_ok=True)

    # ---------- speed / ping
    def speed_menu(self, chat, mid):
        self.show(chat, mid, "🚀 <b>اسپید تست</b>\n• «از سرور»: سرعت خود سرور به اینترنت جهانی (بیرون ایران).\n• «از داخل ایران»: لینکی که باید با اینترنت ایران (بدون VPN) روی گوشی باز کنی؛ سرعت واقعی بین تو و سرور را می‌سنجد.",
                  [[{"text": "🌍 تست از سرور (خارج)", "callback_data": "sps"}], [{"text": "🇮🇷 تست از داخل ایران (لینک)", "callback_data": "spi"}], self.back()])

    def speed_link(self, chat):
        from . import security
        url, https = public_url()
        tok = security.make_token("speed", ttl=3600)
        self.tg.send(chat, f"🇮🇷 این لینک را روی گوشی/کامپیوتر داخل ایران (VPN خاموش) باز کن و «شروع» را بزن. ۱ ساعت اعتبار دارد:\n\n{url}/speed?t={tok}")

    def ping_menu(self, chat, mid):
        self.show(chat, mid, "🏓 <b>پینگ از چند نقطه با Check-Host</b>\nهدف را انتخاب کن:",
                  [[{"text": "🖥 IP/دامنه‌ی همین سرور", "callback_data": "pgm"}], [{"text": "🔌 پورت TCP پنل", "callback_data": "pgt"}],
                   [{"text": "✏️ هاست دیگر", "callback_data": "pgh"}], self.back()])

    def run_ping(self, chat, target, kind="ping"):
        m = self.tg.send(chat, f"⏳ در حال تست {kind} برای <code>{E(target)}</code> از نودهای ایران و جهان… (حدود ۳۰ ثانیه)")
        mid = (m.get("result") or {}).get("message_id")

        def work():
            try:
                txt = checkhost(kind, target)
            except Exception as e:
                txt = f"⚠️ check-host در دسترس نیست: {E(str(e)[:100])}"
            self.show(chat, mid, f"🏓 <b>{kind.upper()}</b> — <code>{E(target)}</code>\n\n{txt}", [[{"text": "🔁 دوباره", "callback_data": "pg"}], self.back()])
        threading.Thread(target=work, daemon=True).start()

    # ---------- panel
    def panel_menu(self, chat, mid):
        ps = active("vpnpanel")
        url, https = public_url()
        kb = [[{"text": "▶️ روشن", "callback_data": "pna:start"}, {"text": "⏹ خاموش", "callback_data": "pna:stop"}, {"text": "🔄 ریستارت", "callback_data": "pna:restart"}],
              [{"text": "⬆️ آپدیت (ارسال فایل tgz)", "callback_data": "pna:update"}, {"text": "📜 لاگ", "callback_data": "pna:logs"}], self.back()]
        self.show(chat, mid, f"🖥 <b>پنل</b>\nوضعیت: {'🟢 روشن' if ps == 'active' else '🔴 ' + ps}\nآدرس: {E(url)}", kb)

    def panel_action(self, chat, mid, act, yes=False):
        if act == "stop" and not yes:
            return self.show(chat, mid, "⚠️ پنل خاموش شود؟ (موتورها به کارشان ادامه می‌دهند)", [[{"text": "✅ بله", "callback_data": "pna:stopy"}, {"text": "انصراف", "callback_data": "pn"}]])
        if act == "update":
            return self.show(chat, mid, "⬆️ فایل بسته‌ی جدید (مثل <code>tcm19-v33.tgz</code>) را همین‌جا برای من بفرست؛ بعد از دریافت تأیید می‌گیرم و آپدیت می‌کنم.", [self.back("pn")])
        if act == "logs":
            return self.show(chat, mid, f"<pre>{E(tail(sh(['journalctl', '-u', 'vpnpanel', '-n', '25', '--no-pager', '-o', 'cat'], 15), 25))}</pre>", [self.back("pn")])
        cmd = {"start": ["systemctl", "start", "vpnpanel"], "stopy": ["systemctl", "stop", "vpnpanel"], "restart": ["systemctl", "restart", "vpnpanel"]}[act]
        sh(cmd, 60)
        time.sleep(3)
        self.panel_menu(chat, mid)

    def run_update(self, chat, fname):
        marker = config.DATA_DIR / "bot_update.json"
        log = "/root/tcm19-update.log"
        marker.write_text(json.dumps({"chat": chat, "log": log, "file": fname}))
        cmd = f"TCM_YES=1 {TCM19} update /root/{fname} > {log} 2>&1; systemctl try-restart {SERVICE}"
        r = sh(["systemd-run", "--unit", f"tcm19-update-{int(time.time())}", "--collect", "bash", "-c", cmd], 20)
        self.tg.send(chat, "⏳ آپدیت شروع شد. بعد از اتمام، ربات خودش خبر می‌دهد (چند ثانیه تا یک دقیقه)." + (f"\n<pre>{E(r[:200])}</pre>" if r and "Running" not in r else ""))

    def panel_err(self, chat, mid, e):
        if isinstance(e, PanelDown):
            self.show(chat, mid, "🔴 پنل جواب نمی‌دهد.", [[{"text": "▶️ روشن کردن پنل", "callback_data": "pna:start"}, {"text": "🔄 ریستارت", "callback_data": "pna:restart"}], self.back()])
        else:
            self.show(chat, mid, f"⚠️ {E(str(e)[:300])}", [self.back()])

    # ---------- dispatch
    def on_callback(self, cq):
        chat = cq["message"]["chat"]["id"]
        mid = cq["message"]["message_id"]
        uid = cq["from"]["id"]
        self.tg.call("answerCallbackQuery", {"callback_query_id": cq["id"]})
        if not self.is_admin(uid):
            return
        d = cq["data"]
        a = d.split(":")
        c = a[0]
        if c == "m":
            STATE.pop(chat, None)
            return self.main_menu(chat, mid)
        if c == "st":
            return self.status(chat, mid)
        if c == "us":
            return self.users(chat, mid, int(a[1]))
        if c == "usq":
            STATE[chat] = {"kind": "search"}
            return self.tg.send(chat, "🔍 بخشی از نام یا یادداشت کاربر را بنویس:", [self.back("us:0", "انصراف")])
        if c == "usc":
            STATE.pop(chat, None)
            return self.users(chat, mid, 0)
        if c == "u":
            return self.user_view(chat, mid, int(a[1]))
        if c == "ul":
            return self.send_links(chat, int(a[1]))
        if c == "ua":
            return self.user_action(chat, mid, int(a[1]), a[2])
        if c == "nu":
            STATE[chat] = {"kind": "new", "step": "name"}
            return self.tg.send(chat, "➕ <b>کاربر جدید</b>\nنام کاربری را بنویس (انگلیسی/عدد، حداقل ۳ حرف):", [self.back("m", "انصراف")])
        if c == "nug":
            st = STATE.get(chat) or {}
            st.update(gb=float(a[1]), step="days")
            STATE[chat] = st
            return self.ask_days(chat)
        if c == "nud":
            st = STATE.pop(chat, None) or {}
            if st.get("name"):
                self.create_user(chat, st["name"], st.get("gb", 0), int(a[1]))
            return
        if c == "tc":
            return self.create_user(chat, "test-" + secrets.token_hex(2), 1, 1, test=True)
        if c == "on":
            return self.online(chat, mid)
        if c == "ac":
            return self.activity(chat, mid)
        if c == "ok":
            try:
                r = api("POST", f"/api/online/{a[1]}/kick")
            except (PanelDown, ApiError) as e:
                return self.panel_err(chat, mid, e)
            self.tg.send(chat, f"✂️ {r.get('killed', 0)} اتصال قطع شد." + (f"\n{E(r['note'])}" if r.get("note") else ""))
            return self.online(chat, None)
        if c == "en":
            return self.engines(chat, mid)
        if c == "e":
            return self.engine_menu(chat, mid, a[1])
        if c == "ea":
            return self.engine_action(chat, mid, a[1], a[2])
        if c == "eay":
            return self.engine_action(chat, mid, a[1], a[2], True)
        if c == "tn":
            return self.tunnels(chat, mid)
        if c == "tr":
            try:
                api("POST", f"/api/tunnels/{a[1]}/restart")
            except (PanelDown, ApiError) as e:
                return self.panel_err(chat, mid, e)
            time.sleep(2)
            return self.tunnels(chat, mid)
        if c == "bk":
            return self.backup_menu(chat, mid)
        if c == "bks":
            self.tg.send(chat, "⏳ در حال ساخت بکاپ…")
            return self.send_backup(chat)
        if c == "bka":
            db.set_settings({"tg_backup": "0" if cfg().get("tg_backup") == "1" else "1"})
            return self.backup_menu(chat, mid)
        if c == "sp":
            return self.speed_menu(chat, mid)
        if c == "sps":
            self.show(chat, mid, "⏳ در حال تست سرعت سرور… (حدود ۲۰ ثانیه)")
            threading.Thread(target=lambda: self.show(chat, mid, "🌍 <b>سرعت سرور (خارج ایران)</b>\n\n" + speed_server(), [self.back("sp")]), daemon=True).start()
            return
        if c == "spi":
            return self.speed_link(chat)
        if c == "pg":
            return self.ping_menu(chat, mid)
        if c == "pgm":
            host = cfg().get("server_address") or _public_ip()
            return self.run_ping(chat, host)
        if c == "pgt":
            return self.run_ping(chat, f"{cfg().get('server_address') or _public_ip()}:{panel_port()}", "tcp")
        if c == "pgh":
            STATE[chat] = {"kind": "ping"}
            return self.tg.send(chat, "✏️ آدرس را بنویس (IP یا دامنه، برای TCP به شکل host:port):", [self.back("pg", "انصراف")])
        if c == "ma":
            return self.show(chat, mid, "📱 مینی‌اپ تلگرام فقط روی HTTPS کار می‌کند. برای فعال شدن، در پنل بخش «دامنه و آدرس» یک دامنه با گواهی SSL برای پنل تنظیم کن؛ بعد از آن دکمه‌ی مینی‌اپ خودکار فعال می‌شود.", [self.back()])
        if c == "pn":
            return self.panel_menu(chat, mid)
        if c == "pna":
            return self.panel_action(chat, mid, a[1], a[1] == "stopy")
        if c == "upd":
            fn = (STATE.pop(chat, None) or {}).get("file")
            return self.run_update(chat, fn) if fn else None

    def ask_days(self, chat):
        kb = [[{"text": str(n) if n else "نامحدود", "callback_data": f"nud:{n}"} for n in (7, 30, 60, 90, 0)], self.back("m", "انصراف")]
        self.tg.send(chat, "⏳ اعتبار چند روز باشد؟ (دکمه یا عدد بنویس)", kb)

    def ask_gb(self, chat):
        kb = [[{"text": str(n) if n else "نامحدود", "callback_data": f"nug:{n}"} for n in (0, 5, 10, 20, 50, 100)], self.back("m", "انصراف")]
        self.tg.send(chat, "📦 حجم چند گیگ باشد؟ (دکمه یا عدد بنویس)", kb)

    def on_message(self, m):
        chat = m["chat"]["id"]
        uid = m["from"]["id"]
        text = (m.get("text") or "").strip()
        if not self.is_admin(uid):
            parts = text.split(maxsplit=1)
            if parts and parts[0] == "/start" and len(parts) == 2 and use_pair_code(parts[1]):
                add_admin(uid, m["from"].get("username") or m["from"].get("first_name") or "")
                self.tg.send(chat, "✅ شما به‌عنوان ادمین ربات ثبت شدید.")
                return self.main_menu(chat)
            return self.tg.send(chat, f"⛔️ دسترسی ندارید.\nشناسه‌ی عددی شما: <code>{uid}</code>\nاین عدد را به مدیر پنل بدهید تا در بخش «ربات تلگرام» پنل اضافه‌تان کند.")
        doc = m.get("document")
        if doc:
            name = doc.get("file_name", "")
            if re.search(r"\.t(ar\.)?gz$", name) and doc.get("file_size", 0) < 20_000_000:
                data = self.tg.download(doc["file_id"])
                if not data:
                    return self.tg.send(chat, "⚠️ دانلود فایل از تلگرام ناموفق بود.")
                safe = re.sub(r"[^A-Za-z0-9._-]", "_", name)
                Path("/root").joinpath(safe).write_bytes(data)
                STATE[chat] = {"kind": "upd", "file": safe}
                return self.tg.send(chat, f"📦 فایل <code>{E(safe)}</code> ({gb(len(data))}) دریافت شد.\nآپدیت پنل با این فایل اجرا شود؟ (قبلش از کد فعلی بکاپ گرفته می‌شود)",
                                    [[{"text": "✅ آپدیت کن", "callback_data": "upd"}, {"text": "انصراف", "callback_data": "m"}]])
            return self.tg.send(chat, "برای آپدیت، فایل با پسوند .tgz بفرست.")
        st = STATE.get(chat) or {}
        if text.startswith("/"):
            STATE.pop(chat, None)
            return self.main_menu(chat)
        k = st.get("kind")
        if k == "search":
            STATE[chat] = {"q": text}
            return self.users(chat, None, 0)
        if k == "ping":
            STATE.pop(chat, None)
            return self.run_ping(chat, text, "tcp" if re.search(r":\d+$", text) else "ping")
        if k == "edit":
            STATE.pop(chat, None)
            try:
                if st["what"] == "days":
                    api("PUT", f"/api/users/{st['uid']}", {"expire_days": int(float(text))})
                elif st["what"] == "gb":
                    api("PUT", f"/api/users/{st['uid']}", {"data_limit_gb": float(text)})
                else:
                    api("PUT", f"/api/users/{st['uid']}", {"note": text[:200]})
            except ValueError:
                return self.tg.send(chat, "⚠️ عدد معتبر بنویس.")
            except (PanelDown, ApiError) as e:
                return self.panel_err(chat, None, e)
            return self.user_view(chat, None, st["uid"])
        if k == "new":
            if st["step"] == "name":
                if not re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", text):
                    return self.tg.send(chat, "⚠️ نام باید ۳ تا ۳۲ حرف انگلیسی/عدد/_/-/. باشد.")
                STATE[chat] = {"kind": "new", "step": "gb", "name": text}
                return self.ask_gb(chat)
            try:
                val = float(text)
            except ValueError:
                return self.tg.send(chat, "⚠️ عدد بنویس.")
            if st["step"] == "gb":
                st.update(gb=val, step="days")
                return self.ask_days(chat)
            STATE.pop(chat, None)
            return self.create_user(chat, st["name"], st.get("gb", 0), int(val))
        self.main_menu(chat)

    # ---------- background: alerts, watchdog, backups
    def worker(self):
        last = {"watch": 0, "users": 0, "tun": 0}
        fails: dict[str, int] = {}
        down_notified: dict[str, float] = {}
        tun_bad: set = set()
        while True:
            try:
                time.sleep(15)
                s = cfg()
                now = time.time()
                # watchdog: panel + engines that are enabled at boot
                if s.get("tg_alerts", "1") == "1" and now - last["watch"] > 30:
                    last["watch"] = now
                    svcs = {"vpnpanel": "پنل"}
                    for k, n in ENGINES:
                        svcs[ENGINE_SVC[k]] = n
                    for svc, name in svcs.items():
                        if sh(["systemctl", "is-enabled", svc], 10) != "enabled":
                            continue
                        st = active(svc)
                        if st == "active":
                            if fails.pop(svc, 0) >= 2:
                                self.notify(f"✅ {name} دوباره روشن است.")
                            continue
                        if st != "failed":  # "inactive" = stopped on purpose; only crashed services are restarted
                            fails.pop(svc, None)
                            continue
                        fails[svc] = fails.get(svc, 0) + 1
                        if fails[svc] == 2:
                            sh(["systemctl", "restart", svc], 60)
                            time.sleep(4)
                            ok = active(svc) == "active"
                            self.notify(f"🔧 {name} از کار افتاده بود و {'با موفقیت ریستارت شد ✅' if ok else 'ریستارت نشد ❌ — دستی بررسی کن'}")
                        elif fails[svc] > 2 and now - down_notified.get(svc, 0) > 1800:
                            down_notified[svc] = now
                            self.notify(f"❌ {name} هنوز خاموش است.")
                    # tunnels
                    if now - last["tun"] > 300 and active("vpnpanel") == "active":
                        last["tun"] = now
                        try:
                            bad = {t["name"] for t in api("GET", "/api/tunnel-diag/health") if t["level"] == "bad"}
                            for n in bad - tun_bad:
                                self.notify(f"🚇❌ تونل «{E(n)}» مشکل دارد.", [[{"text": "🚇 وضعیت تونل‌ها", "callback_data": "tn"}]])
                            for n in tun_bad - bad:
                                self.notify(f"🚇✅ تونل «{E(n)}» سالم شد.")
                            tun_bad = bad
                        except (PanelDown, ApiError):
                            pass
                    # users
                    if now - last["users"] > 600 and active("vpnpanel") == "active":
                        last["users"] = now
                        self.user_alerts()
                # device-limit alerts raised by the panel's monitor
                if s.get("tg_alerts", "1") == "1" and active("vpnpanel") == "active":
                    for act, key, title in (("ip_limit", "tg_last_act", "📵 <b>تعداد دستگاه بیش از حد مجاز</b>"),
                                            ("geo_limit", "tg_last_geo", "🌍 <b>اکانت هم‌زمان از چند کشور</b>"),
                                            ("health", "tg_last_health", "🩺 <b>هشدار سلامت سرور</b>")):
                        try:
                            last_id = int(s.get(key, "0") or 0)
                            res = api("GET", f"/api/activity?action={act}&per_page=20&after_id={last_id}")
                            if last_id == 0 and res["items"]:
                                db.set_settings({key: str(res["items"][0]["id"])})
                            else:
                                for it in reversed(res["items"]):
                                    self.notify(f"{title}\n{E(it['detail'])}")
                                    last_id = max(last_id, it["id"])
                                if res["items"]:
                                    db.set_settings({key: str(last_id)})
                        except (PanelDown, ApiError):
                            break
                # auto backup to Telegram
                if s.get("tg_backup") == "1":
                    hrs = max(1, int(s.get("tg_backup_hours", "24") or 24))
                    if now - float(s.get("tg_last_backup", "0") or 0) >= hrs * 3600:
                        db.set_settings({"tg_last_backup": str(int(now))})
                        for a in admins():
                            self.send_backup(a["id"], "💾 بکاپ خودکار tcm19")
            except Exception as e:
                print("worker error:", e, file=sys.stderr)

    def user_alerts(self):
        try:
            seen = json.loads(cfg().get("tg_notified") or "{}")
        except ValueError:
            seen = {}
        changed, page = False, 1
        while page < 20:
            try:
                d = api("GET", f"/api/users?per_page=200&page={page}")
            except (PanelDown, ApiError):
                return
            for u in d["items"]:
                if u["status"] == "disabled":
                    continue
                sig = f"{u['expire_at']}:{u['data_limit']}"
                kinds = []
                if u["status"] == "limited":
                    kinds.append(("limited", f"📦 حجم کاربر «{u['username']}» تمام شد."))
                elif u["status"] == "expired":
                    kinds.append(("expired", f"⌛️ اشتراک «{u['username']}» منقضی شد."))
                else:
                    if u["data_limit"] and u["used"] >= 0.9 * u["data_limit"]:
                        kinds.append(("low", f"⚠️ «{u['username']}» بیش از ۹۰٪ حجمش را مصرف کرده ({gb(u['used'])}/{gb(u['data_limit'])})."))
                    if u["expire_at"] and 0 < u["expire_at"] - time.time() < 3 * 86400:
                        kinds.append(("exp3", f"⏰ اشتراک «{u['username']}» کمتر از ۳ روز دیگر تمام می‌شود."))
                for kind, msg in kinds:
                    key = f"{u['id']}:{kind}"
                    if seen.get(key) != sig:
                        seen[key] = sig
                        changed = True
                        self.notify(msg, [[{"text": "👤 مشاهده/تمدید", "callback_data": f"u:{u['id']}"}]])
            if page * 200 >= d["total"]:
                break
            page += 1
        if changed:
            db.set_settings({"tg_notified": json.dumps(seen)})

    # ---------- main loop
    def run(self):
        me = self.tg.call("getMe")
        if not me.get("ok"):
            print("bad token:", me, file=sys.stderr)
            time.sleep(30)
            return
        db.set_settings({"tg_username": me["result"]["username"]})
        self.tg.call("deleteWebhook")
        self.tg.call("setMyCommands", {"commands": [{"command": "start", "description": "منوی اصلی"}]})
        url, https = public_url()
        if https:
            self.tg.call("setChatMenuButton", {"menu_button": {"type": "web_app", "text": "پنل", "web_app": {"url": url + "/miniapp"}}})
        marker = config.DATA_DIR / "bot_update.json"
        if marker.exists():
            try:
                mk = json.loads(marker.read_text())
                marker.unlink()
                lg = ANSI.sub("", Path(mk["log"]).read_text(errors="ignore")) if Path(mk["log"]).exists() else ""
                self.tg.send(mk["chat"], f"✅ آپدیت تمام شد. پنل: {'🟢 روشن' if active('vpnpanel') == 'active' else '🔴 خاموش'}\n<pre>{E(tail(lg, 10))}</pre>")
            except Exception:
                pass
        threading.Thread(target=self.worker, daemon=True).start()
        off = 0
        while True:
            r = self.tg.call("getUpdates", {"offset": off, "timeout": 25, "allowed_updates": ["message", "callback_query"]}, timeout=40)
            if not r.get("ok"):
                time.sleep(5)
                continue
            for u in r["result"]:
                off = u["update_id"] + 1
                try:
                    if "callback_query" in u:
                        self.on_callback(u["callback_query"])
                    elif "message" in u:
                        self.on_message(u["message"])
                except Exception as e:
                    print("handler error:", repr(e), file=sys.stderr)
                    try:
                        chat = (u.get("message") or u["callback_query"]["message"])["chat"]["id"]
                        self.tg.send(chat, f"⚠️ خطا: {E(str(e)[:150])}")
                    except Exception:
                        pass


def main():
    db.init()
    while True:
        s = cfg()
        tok = s.get("tg_token", "")
        if not tok or s.get("tg_enabled") != "1":
            time.sleep(10)
            continue
        try:
            ensure_key()
            Bot(tok).run()
        except Exception as e:
            print("bot crashed:", repr(e), file=sys.stderr)
            time.sleep(10)


if __name__ == "__main__":
    main()
