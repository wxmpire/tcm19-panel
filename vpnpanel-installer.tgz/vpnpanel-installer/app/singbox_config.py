"""Builds the sing-box server config (Hysteria2, Hysteria, TUIC, AnyTLS, NaiveProxy, Mixed)."""
from . import inbound_rules, outbounds as ob_mod
from .protocols import ss2022_user_key


def build(inbounds: list[dict], users: list[dict], settings: dict, routing: dict | None = None) -> dict:
    out = []
    for ib in inbounds:
        s = ib["settings"]
        members = [u for u in users if ib["id"] in u["inbound_ids"]]
        base0 = {"tag": ib["tag"], "listen": "::", "listen_port": ib["port"]}
        if ib["protocol"] == "shadowtls":
            if not members:
                continue
            host, _, hport = s.get("dest", inbound_rules.DEFAULT_DEST).rpartition(":")
            method = s.get("method", "2022-blake3-aes-128-gcm")
            out.append({"type": "shadowsocks", "tag": ib["tag"] + "-ss", "listen": "127.0.0.1",
                        "listen_port": int(s["inner_port"]), "method": method, "password": s.get("server_password", ""),
                        "users": [{"name": u["username"], "password": ss2022_user_key(u, method)} for u in members]})
            out.append({**base0, "type": "shadowtls", "version": 3,
                        "users": [{"name": u["username"], "password": u["password"]} for u in members],
                        "handshake": {"server": host, "server_port": int(hport or 443)},
                        "strict_mode": True, "detour": ib["tag"] + "-ss"})
            continue
        cert, key = inbound_rules.cert_paths(settings)  # always the panel domain's certificate
        tp = inbound_rules.panel_tls()
        tls = {
            "enabled": True,
            "server_name": s.get("sni") or (tp["domain"] if tp else settings.get("server_address", "")),
            "certificate_path": cert,
            "key_path": key,
        }
        base = {"tag": ib["tag"], "listen": "::", "listen_port": ib["port"]}
        if ib["protocol"] == "hysteria2":
            entry = {**base, "type": "hysteria2",
                     "users": [{"name": u["username"], "password": u["password"]} for u in members],
                     "tls": {**tls, "alpn": ["h3"]}}
            if s.get("up_mbps"):
                entry["up_mbps"] = int(s["up_mbps"])
            if s.get("down_mbps"):
                entry["down_mbps"] = int(s["down_mbps"])
            if s.get("obfs_password"):
                entry["obfs"] = {"type": "salamander", "password": s["obfs_password"]}
        elif ib["protocol"] == "tuic":
            entry = {**base, "type": "tuic",
                     "users": [{"name": u["username"], "uuid": u["uuid"], "password": u["password"]}
                               for u in members],
                     "congestion_control": s.get("congestion", "bbr"),
                     "tls": {**tls, "alpn": ["h3"]}}
        elif ib["protocol"] == "hysteria":
            entry = {**base, "type": "hysteria",
                     "users": [{"name": u["username"], "auth_str": u["password"]} for u in members],
                     "up_mbps": int(s.get("up_mbps") or 100), "down_mbps": int(s.get("down_mbps") or 100),
                     "tls": {**tls, "alpn": ["h3"]}}
            if s.get("obfs_password"):
                entry["obfs"] = s["obfs_password"]
        elif ib["protocol"] == "anytls":
            entry = {**base, "type": "anytls",
                     "users": [{"name": u["username"], "password": u["password"]} for u in members],
                     "tls": tls}
        elif ib["protocol"] == "naive":
            entry = {**base, "type": "naive", "network": "tcp",
                     "users": [{"username": u["username"], "password": u["password"]} for u in members],
                     "tls": tls}
        elif ib["protocol"] == "mixed":
            if not members:  # no users would mean an open proxy
                continue
            entry = {**base, "type": "mixed",
                     "users": [{"username": u["username"], "password": u["password"]} for u in members]}
        else:
            continue
        out.append(entry)

    # Rule actions and WireGuard endpoints require sing-box >= 1.11
    rt = routing or {"outbounds": [], "rules": [], "final": "direct", "inbound_engine": {}}
    sb_outs, sb_eps, user_rules, final = ob_mod.singbox_routing(rt)
    rules = [{"action": "sniff"}]
    if settings.get("block_bittorrent") == "1":
        rules.append({"protocol": "bittorrent", "action": "reject"})
    if settings.get("block_private") == "1":
        rules.append({"ip_is_private": True, "action": "reject"})
    rules.extend(user_rules)
    cfg = {
        "log": {"level": "warn"},
        "inbounds": out,
        "outbounds": sb_outs,
        "route": {"rules": rules, "final": final},
    }
    if sb_eps:
        cfg["endpoints"] = sb_eps
    return cfg
