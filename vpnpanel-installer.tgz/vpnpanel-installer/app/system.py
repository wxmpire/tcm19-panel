"""Talks to the OS: keygen, writing configs, restarting services, reading traffic counters."""
import base64
import hashlib
import ipaddress
import json
import re
import secrets
import shutil
import subprocess
import tempfile
from pathlib import Path

from . import config, db, outbounds, singbox_config, xray_config

_last_hash: dict[str, str] = {}
_wg_last: dict[str, tuple[int, int]] = {}


def run(cmd: list[str] | str, timeout: int = 20, shell: bool = False) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, shell=shell)
        return p.returncode, (p.stdout + p.stderr).strip()
    except FileNotFoundError:
        return 127, f"command not found: {cmd if isinstance(cmd, str) else cmd[0]}"
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def have(binary: str) -> bool:
    return shutil.which(binary) is not None or Path(binary).exists()


# ---------- key generation ----------
def _x25519_fallback() -> tuple[str, str]:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric import x25519
    priv = x25519.X25519PrivateKey.generate()
    raw_priv = priv.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                                  serialization.NoEncryption())
    raw_pub = priv.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)
    return raw_priv, raw_pub


def reality_keypair() -> dict:
    """Returns {'private_key','public_key'} (base64url, no padding)."""
    if have(config.XRAY_BIN):
        code, out = run([config.XRAY_BIN, "x25519"])
        priv = pub = None
        for line in out.splitlines():
            low = line.lower()
            val = line.split(":", 1)[-1].strip()
            if low.startswith("private"):
                priv = val
            elif low.startswith("public") or low.startswith("password"):
                pub = val
        if code == 0 and priv and pub:
            return {"private_key": priv, "public_key": pub}
    try:
        rp, ru = _x25519_fallback()
        enc = lambda b: base64.urlsafe_b64encode(b).rstrip(b"=").decode()
        return {"private_key": enc(rp), "public_key": enc(ru)}
    except Exception as e:
        raise RuntimeError("cannot generate Reality keys: install Xray or the 'cryptography' package") from e


def wg_keypair() -> dict:
    if have("wg"):
        code, priv = run(["wg", "genkey"])
        if code == 0:
            p = subprocess.run(["wg", "pubkey"], input=priv, capture_output=True, text=True)
            return {"private": priv.strip(), "public": p.stdout.strip()}
    rp, ru = _x25519_fallback()
    return {"private": base64.b64encode(rp).decode(), "public": base64.b64encode(ru).decode()}


def wg_psk() -> str:
    return base64.b64encode(secrets.token_bytes(32)).decode()


def short_id() -> str:
    return secrets.token_hex(8)


# ---------- WireGuard IP allocation ----------
def allocate_wg_ip(settings: dict) -> str:
    net = ipaddress.ip_network(settings["wg_subnet"], strict=False)
    used = {u["wg_ip"] for u in db.all_users() if u["wg_ip"]}
    hosts = net.hosts()
    next(hosts)  # .1 is the server
    for h in hosts:
        if str(h) not in used:
            return str(h)
    raise RuntimeError("WireGuard subnet is full")


def ensure_wg_server_keys(settings: dict) -> dict:
    if not settings.get("wg_server_private"):
        kp = wg_keypair()
        db.set_settings({"wg_server_private": kp["private"], "wg_server_public": kp["public"]})
        settings = db.get_settings()
    return settings


# ---------- applying configs ----------
def default_iface() -> str:
    code, out = run(["ip", "route", "show", "default"])
    m = re.search(r"dev (\S+)", out) if code == 0 else None
    return m.group(1) if m else "eth0"


def _secure_file(path: Path, group: str | None):
    """Config files hold private keys: root-owned, readable only by root and the service's group."""
    try:
        if group == "world":
            path.chmod(0o644)
        elif group:
            shutil.chown(path, group=group)
            path.chmod(0o640)
        else:
            path.chmod(0o600)
    except (LookupError, PermissionError, OSError):
        path.chmod(0o644)  # group missing: fall back so the service can still read it


def _write_if_changed(key: str, path: Path, content: str, validate_cmd: list[str] | None = None,
                      group: str | None = None) -> str:
    digest = hashlib.sha256(content.encode()).hexdigest()
    if _last_hash.get(key) == digest and path.exists():
        return "unchanged"
    if config.DRY_RUN:
        _last_hash[key] = digest
        return "dry-run"
    path.parent.mkdir(parents=True, exist_ok=True)
    if validate_cmd:
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as f:
            f.write(content)
            tmp = f.name
        code, out = run([a.replace("{file}", tmp) for a in validate_cmd], timeout=30)
        Path(tmp).unlink(missing_ok=True)
        if code != 0:
            raise RuntimeError(f"{key} config validation failed: {out[-500:]}")
    path.write_text(content)
    _secure_file(path, group)
    _last_hash[key] = digest
    return "written"


def _restart(service: str) -> str:
    if config.DRY_RUN:
        return "dry-run"
    code, out = run(["systemctl", "restart", service], timeout=30)
    return "restarted" if code == 0 else f"restart failed: {out[-300:]}"


def apply_xray(settings: dict, inbounds: list[dict], users: list[dict]) -> str:
    xi = [i for i in inbounds if i["engine"] == "xray" and i["enabled"]]
    cfg = xray_config.build(xi, users, settings, outbounds.load_routing())
    res = _write_if_changed("xray", config.XRAY_CONFIG, json.dumps(cfg, indent=2),
                            [config.XRAY_BIN, "run", "-test", "-config", "{file}"] if have(config.XRAY_BIN) else None,
                            group="world")
    if res == "written":
        return _restart(config.XRAY_SERVICE)
    return res


def apply_singbox(settings: dict, inbounds: list[dict], users: list[dict]) -> str:
    si = [i for i in inbounds if i["engine"] == "singbox" and i["enabled"]]
    cfg = singbox_config.build(si, users, settings, outbounds.load_routing())
    res = _write_if_changed("singbox", config.SINGBOX_CONFIG, json.dumps(cfg, indent=2),
                            [config.SINGBOX_BIN, "check", "-c", "{file}"] if have(config.SINGBOX_BIN) else None,
                            group="world")
    if res == "written":
        if not si:
            return "no inbounds (service left as is)"
        return _restart(config.SINGBOX_SERVICE)
    return res


def wg_server_config(settings: dict, users: list[dict]) -> str:
    net = ipaddress.ip_network(settings["wg_subnet"], strict=False)
    server_ip = str(next(net.hosts()))
    out_if = default_iface()
    lines = [
        "[Interface]",
        f"Address = {server_ip}/{net.prefixlen}",
        f"ListenPort = {settings['wg_port']}",
        f"PrivateKey = {settings['wg_server_private']}",
        f"MTU = {settings['wg_mtu']}",
        f"PostUp = iptables -A FORWARD -i %i -j ACCEPT; iptables -A FORWARD -o %i -j ACCEPT; "
        f"iptables -t nat -A POSTROUTING -s {net} -o {out_if} -j MASQUERADE",
        f"PostDown = iptables -D FORWARD -i %i -j ACCEPT; iptables -D FORWARD -o %i -j ACCEPT; "
        f"iptables -t nat -D POSTROUTING -s {net} -o {out_if} -j MASQUERADE",
        "",
    ]
    for u in users:
        if u["wg_enabled"] and u["status"] == "active":
            lines += ["[Peer]", f"# {u['username']}", f"PublicKey = {u['wg_public']}",
                      f"PresharedKey = {u['wg_psk']}", f"AllowedIPs = {u['wg_ip']}/32", ""]
    return "\n".join(lines)


def apply_wireguard(settings: dict, users: list[dict]) -> str:
    if settings.get("wg_enabled") != "1":
        return "disabled"
    settings = ensure_wg_server_keys(settings)
    content = wg_server_config(settings, users)
    res = _write_if_changed("wireguard", config.WG_CONFIG, content)
    if config.DRY_RUN:
        return res
    if res == "written":
        if config.WG_CONFIG.exists():
            config.WG_CONFIG.chmod(0o600)
        code, _ = run(["ip", "link", "show", config.WG_IFACE])
        if code != 0:
            code, out = run(["systemctl", "enable", "--now", f"wg-quick@{config.WG_IFACE}"], timeout=30)
            return "started" if code == 0 else f"start failed: {out[-300:]}"
        code, out = run(["bash", "-c", f"wg syncconf {config.WG_IFACE} <(wg-quick strip {config.WG_IFACE})"])
        return "synced" if code == 0 else f"sync failed: {out[-300:]}"
    return res


def apply_all() -> dict:
    settings = db.get_settings()
    inbounds = db.list_inbounds()
    users = [u for u in db.all_users() if u["status"] == "active"]
    all_users = db.all_users()
    result = {}
    for name, fn in (("xray", lambda: apply_xray(settings, inbounds, users)),
                     ("singbox", lambda: apply_singbox(settings, inbounds, users)),
                     ("wireguard", lambda: apply_wireguard(settings, all_users)),
                     ("outbound-services", lambda: outbounds.apply_services())):
        try:
            result[name] = fn()
        except Exception as e:  # keep going so one engine's error doesn't block the others
            result[name] = f"error: {e}"
    return result


# ---------- traffic counters ----------
def read_xray_traffic() -> dict[int, int]:
    """Returns user_id -> bytes since last read (counters are reset on read)."""
    if config.DRY_RUN or not have(config.XRAY_BIN):
        return {}
    code, out = run([config.XRAY_BIN, "api", "statsquery", f"--server={config.XRAY_API}", "-pattern", "user>>>",
                     "-reset"], timeout=15)
    if code != 0:
        return {}
    try:
        stats = json.loads(out).get("stat", [])
    except json.JSONDecodeError:
        return {}
    totals: dict[int, int] = {}

    # SOCKS/HTTP use the authenticated username as Xray user email.
    # Resolve those usernames to database user IDs.
    username_to_id = {
        str(u["username"]): int(u["id"])
        for u in db.all_users()
    }

    for item in stats:
        parts = item.get("name", "").split(">>>")
        if len(parts) == 4 and parts[0] == "user":
            uid = username_to_id.get(parts[1])

            # Preserve existing VLESS/VMess/Trojan/SS identity handling.
            if uid is None:
                uid = xray_config.parse_email(parts[1])

            if uid is not None:
                totals[uid] = totals.get(uid, 0) + int(item.get("value", 0))

    return totals


def read_wg_traffic(users: list[dict]) -> dict[int, int]:
    if config.DRY_RUN or not have("wg"):
        return {}
    code, out = run(["wg", "show", config.WG_IFACE, "transfer"])
    if code != 0:
        return {}
    by_pub = {u["wg_public"]: u["id"] for u in users if u["wg_public"]}
    deltas: dict[int, int] = {}
    for line in out.splitlines():
        parts = line.split()
        if len(parts) != 3 or parts[0] not in by_pub:
            continue
        rx, tx = int(parts[1]), int(parts[2])
        prev = _wg_last.get(parts[0])
        _wg_last[parts[0]] = (rx, tx)
        if prev is None:
            continue
        d_rx = rx - prev[0] if rx >= prev[0] else rx  # counter reset after interface restart
        d_tx = tx - prev[1] if tx >= prev[1] else tx
        deltas[by_pub[parts[0]]] = d_rx + d_tx
    return deltas


# ---------- system info ----------
def service_state(name: str) -> str:
    if config.DRY_RUN:
        return "dry-run"
    code, out = run(["systemctl", "is-active", name])
    return out.strip() or ("unknown" if code else "active")


def system_info() -> dict:
    info = {}
    try:
        info["load"] = [float(x) for x in Path("/proc/loadavg").read_text().split()[:3]]
        mem = {l.split(":")[0]: int(re.findall(r"\d+", l)[0]) * 1024
               for l in Path("/proc/meminfo").read_text().splitlines()[:5]}
        info["mem_total"], info["mem_available"] = mem.get("MemTotal", 0), mem.get("MemAvailable", 0)
        info["uptime"] = int(float(Path("/proc/uptime").read_text().split()[0]))
        du = shutil.disk_usage("/")
        info["disk_total"], info["disk_used"] = du.total, du.used
    except Exception:
        pass
    info["services"] = {
        "xray": service_state(config.XRAY_SERVICE),
        "sing-box": service_state(config.SINGBOX_SERVICE),
        "wireguard": service_state(f"wg-quick@{config.WG_IFACE}"),
    }
    return info
