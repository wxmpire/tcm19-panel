tcm19 installer
===================

A) From this folder (no hosting needed)
   Upload vpnpanel-installer.tgz to /root with SFTP, then:
   cd /root && tar xzf vpnpanel-installer.tgz && bash vpnpanel-installer/install.sh

B) One-line installer (needs the two files hosted at a direct-download URL, e.g. a GitHub repo)
   Upload install.sh and vpnpanel-installer.tgz to the same place, then on any new server:
   bash <(curl -Ls https://YOUR-HOST/install.sh) https://YOUR-HOST/vpnpanel-installer.tgz

Options: PANEL_PORT=34567 bash install.sh   (default: random free port)

After install, type:  vpnpanel   (or: panel)   for the menu.
Re-running the installer updates the code and keeps your data and service.
