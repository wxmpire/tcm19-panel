tcm19 installer
===============

A) From this folder (no hosting needed)
   Upload tcm19-v13.tgz to /root with SFTP, then:
   cd /root && tar xzf tcm19-v13.tgz && bash vpnpanel-installer/install.sh

B) One-line installer (files hosted at a direct-download URL, e.g. GitHub)
   bash <(curl -Ls https://YOUR-HOST/install.sh) https://YOUR-HOST/vpnpanel-installer.tgz

The installer asks: IP or domain (https + free SSL), admin username, admin password
(Enter = random for both), then Xray / sing-box / WireGuard one by one.
Optional env vars skip questions: PANEL_MODE PANEL_DOMAIN PANEL_PORT PANEL_USER PANEL_PASS
INSTALL_XRAY INSTALL_SINGBOX INSTALL_WIREGUARD.

After install, type:  tcm19   for the menu.
Re-running the installer on an installed server only updates the code (data and service are kept).

Outbounds and routing (menu: Outbounds + Routing, two separate pages)
---------------------------------------
Outbounds: direct, block, Cloudflare WARP (account registered by the panel), Tor, Psiphon (official psiphon-tunnel-core, one config per country),
plus SOCKS5 / HTTP / Shadowsocks / WireGuard upstreams. Tor needs the "Install" button once; Psiphon installs itself (official client downloaded by the panel, per-country configs generated).
Routing rules are checked top to bottom; a rule can match inbound, domain (geosite:/domain:/full:/keyword:/regexp:),
ip (geoip:/CIDR), port, network and sniffed protocol. Every save is validated by Xray / sing-box first and rolled back on error.
Test button: sends a real request through the outbound and shows the exit IP / country.
geosite and geoip rules apply to Xray inbounds only (sing-box inbounds skip them).

Per-country exit for users
  User form: switch "Per-country exit". For every enabled Tor/Psiphon per-country exit (Routing page) the user gets one
  extra config in the subscription, routed through that country. Xray inbounds only (vless/vmess/trojan/shadowsocks).
