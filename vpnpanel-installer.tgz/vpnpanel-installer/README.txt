tcm19 installer
===============

A) From this folder (no hosting needed)
   Upload tcm19-v3.tgz to /root with SFTP, then:
   cd /root && tar xzf tcm19-v3.tgz && bash vpnpanel-installer/install.sh

B) One-line installer (files hosted at a direct-download URL, e.g. GitHub)
   bash <(curl -Ls https://YOUR-HOST/install.sh) https://YOUR-HOST/vpnpanel-installer.tgz

The installer asks: IP or domain (https + free SSL), admin username, admin password
(Enter = random for both), then Xray / sing-box / WireGuard one by one.
Optional env vars skip questions: PANEL_MODE PANEL_DOMAIN PANEL_PORT PANEL_USER PANEL_PASS
INSTALL_XRAY INSTALL_SINGBOX INSTALL_WIREGUARD.

After install, type:  tcm19   for the menu.
Re-running the installer on an installed server only updates the code (data and service are kept).
