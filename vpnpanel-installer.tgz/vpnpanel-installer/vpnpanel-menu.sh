#!/usr/bin/env bash
# tcm19 management menu. Run:  tcm19
# Direct commands: tcm19 status|info|restart|port|password|logs|backup|update|engines|uninstall
P=/opt/vpnpanel
SVC=/etc/systemd/system/vpnpanel.service
SUBSVC=/etc/systemd/system/vpnpanel-sub.service
R=$'\033[1;31m'; G=$'\033[1;32m'; Y=$'\033[1;33m'; C=$'\033[1;36m'; N=$'\033[0m'

[ "$(id -u)" = 0 ] || { echo "Run as root: sudo tcm19"; exit 1; }
[ -d "$P/app" ] || { echo "Panel is not installed in $P"; exit 1; }

panel_port() { systemctl cat vpnpanel 2>/dev/null | grep -o -- '--port [0-9]*' | tail -1 | awk '{print $2}'; }
sub_port()   { grep -o -- '--port [0-9]*' "$SUBSVC" 2>/dev/null | tail -1 | awk '{print $2}'; }
tls_on()     { ss -ltn 2>/dev/null | grep -q ":$(panel_port) " && curl -sk -m 4 -o /dev/null "https://127.0.0.1:$(panel_port)/" 2>/dev/null && echo yes || echo no; }
panel_url()  { local d; d="$(python3 -c 'import json;print(json.load(open("/opt/vpnpanel/data/domains.json")).get("panel",{}).get("domain",""))' 2>/dev/null)"
               if [ -n "$d" ]; then echo "https://$d:$(panel_port)"; else echo "http://$(pubip):$(panel_port)"; fi; }
pubip()      { curl -4 -s -m 5 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}'; }
state()      { local s; s="$(systemctl is-active "$1" 2>/dev/null)"; [ "$s" = active ] && echo "${G}active${N}" || echo "${R}${s:-missing}${N}"; }
pause()      { echo; read -rp "Press Enter to continue..." _; }
pyrun()      { ( cd "$P" && PANEL_HOME="$P" "$P/venv/bin/python" "$@" ); }

do_status() {
  echo "${C}Services${N}"
  printf '  %-16s %s\n' tcm19 "$(state vpnpanel)" xray "$(state xray)" sing-box "$(state sing-box)"
  [ -f "$SUBSVC" ] && printf '  %-16s %s\n' "panel-sub" "$(state vpnpanel-sub)"
  systemctl list-unit-files 2>/dev/null | grep -q '^wg-quick@' && printf '  %-16s %s\n' wireguard "$(state wg-quick@wg0)"
  echo; echo "${C}Panel${N}"
  local pp; pp="$(panel_port)"
  echo "  Address : $(panel_url)"
  [ -n "$(sub_port)" ] && echo "  Sub port: $(sub_port)"
  echo "  Version : xray $(xray version 2>/dev/null | head -1 | awk '{print $2}')  sing-box $(sing-box version 2>/dev/null | head -1 | awk '{print $3}')"
}

do_info() {
  echo "${C}Login info${N}"
  echo "  Panel: $(panel_url)"
  local f="$P/data/initial_admin.txt"
  if [ -f "$f" ]; then
    cat "$f" | sed 's/^/  /'
    echo "  (This is the first-run password. If you changed it in the panel, it is no longer valid.)"
    read -rp "  Delete this file now? [y/N] " a
    [[ "$a" =~ ^[Yy]$ ]] && rm -f "$f" && echo "  Deleted."
  else
    echo "  No stored password. Use 'Reset admin password' if you forgot it."
  fi
  pyrun - <<'PY'
import sqlite3
try:
    r = sqlite3.connect("/opt/vpnpanel/data/panel.db").execute("select username from admins").fetchall()
    print("  Admin users:", ", ".join(x[0] for x in r) or "-")
except Exception as e:
    print("  (could not read admins:", e, ")")
PY
}

do_restart() {
  echo "1) Panel   2) Xray   3) sing-box   4) All"
  read -rp "Choose: " c
  case "$c" in
    1) systemctl restart vpnpanel ;;
    2) systemctl restart xray ;;
    3) systemctl restart sing-box ;;
    4) systemctl restart vpnpanel xray sing-box 2>/dev/null; [ -f "$SUBSVC" ] && systemctl restart vpnpanel-sub ;;
    *) return ;;
  esac
  sleep 3; do_status
}

do_port() {
  local old new; old="$(panel_port)"
  echo "Current panel port: $old"
  read -rp "New port (1-65535, empty = cancel): " new
  [ -z "$new" ] && return
  [[ "$new" =~ ^[0-9]+$ ]] && [ "$new" -ge 1 ] && [ "$new" -le 65535 ] || { echo "${R}Invalid port${N}"; return; }
  [ "$new" = "$(sub_port)" ] && { echo "${R}That port is used by the subscription listener${N}"; return; }
  ss -ltn | awk '{print $4}' | grep -q ":$new\$" && { echo "${R}Port $new is already in use${N}"; return; }
  grep -rl -- "--port $old" /etc/systemd/system/vpnpanel.service /etc/systemd/system/vpnpanel.service.d/ 2>/dev/null \
    | xargs -r sed -i "s/--port $old/--port $new/"
  # keep subscription links working when they carry the old panel port
  pyrun - "$old" "$new" <<'PY'
import sqlite3, sys
old, new = sys.argv[1], sys.argv[2]
c = sqlite3.connect("/opt/vpnpanel/data/panel.db")
r = c.execute("select value from settings where key='sub_base_url'").fetchone()
if r and r[0].rstrip("/").endswith(":" + old):
    c.execute("update settings set value=? where key='sub_base_url'", (r[0].rstrip("/")[: -len(old)] + new,))
    c.commit(); print("  sub_base_url updated")
PY
  systemctl daemon-reload
  systemctl restart vpnpanel; sleep 4
  if [ "$(systemctl is-active vpnpanel)" = active ] && ss -ltn | awk '{print $4}' | grep -q ":$new\$"; then
    command -v ufw >/dev/null && ufw status | grep -q "Status: active" && ufw allow "$new/tcp" >/dev/null && echo "  ufw: opened $new"
    echo "${G}Panel now listens on $new.${N} Open TCP $new in your provider firewall."
  else
    echo "${R}Failed, reverting.${N}"
    grep -rl -- "--port $new" /etc/systemd/system/vpnpanel.service /etc/systemd/system/vpnpanel.service.d/ 2>/dev/null | xargs -r sed -i "s/--port $new/--port $old/"
    systemctl daemon-reload; systemctl restart vpnpanel
  fi
}

do_password() {
  local u pw pw2
  u="$(pyrun - <<'PY'
import sqlite3
r = sqlite3.connect("/opt/vpnpanel/data/panel.db").execute("select username from admins order by rowid").fetchall()
print(r[0][0] if r else "")
PY
)"
  read -rp "Admin username [${u:-admin}]: " x; u="${x:-${u:-admin}}"
  read -rp "New password (any length, empty = random): " pw
  if [ -z "$pw" ]; then pw="$(head -c 12 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 14)"; GEN=1
  else GEN=0; fi
  PW="$pw" U="$u" pyrun - <<'PY'
import os, sys
from app import db, security
u, pw = os.environ["U"], os.environ["PW"]
if db.get_admin(u):
    db.set_admin_password(u, security.hash_password(pw)); print("  Password updated for", u)
else:
    db.create_admin(u, security.hash_password(pw)); print("  Admin created:", u)
PY
  [ "$GEN" = 1 ] && echo "  New password: $pw"
  rm -f "$P/data/initial_admin.txt"
}

do_tls() {
  echo "1) HTTPS / domain status   2) Unlock panel (back to plain HTTP + IP access)"
  read -rp "Choose: " c
  case "$c" in
    1) pyrun -m app.panelctl status ;;
    2) read -rp "This disables panel HTTPS/domain lock and restarts. Continue? [y/N] " a
       [[ "$a" =~ ^[Yy]$ ]] && pyrun -m app.panelctl unlock ;;
  esac
}

do_logs() {
  echo "1) Panel   2) Xray   3) sing-box   4) Subscription listener"
  read -rp "Choose: " c
  case "$c" in
    1) journalctl -u vpnpanel -n 60 --no-pager ;;
    2) journalctl -u xray -n 60 --no-pager ;;
    3) journalctl -u sing-box -n 60 --no-pager ;;
    4) journalctl -u vpnpanel-sub -n 60 --no-pager ;;
  esac
}

do_backup() {
  local out="/root/panel-backup-$(date +%Y%m%d-%H%M%S).db"
  pyrun - "$out" <<'PY'
import sqlite3, sys
s = sqlite3.connect("/opt/vpnpanel/data/panel.db"); d = sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close()
PY
  chmod 600 "$out"
  echo "${G}Database saved:${N} $out  (download it with Termius SFTP)"
  tar czf "${out%.db}-certs.tgz" -C "$P/data" . 2>/dev/null && chmod 600 "${out%.db}-certs.tgz" && echo "Full data folder: ${out%.db}-certs.tgz"
}

do_update() {
  local src="${1:-}" tmp main root
  [ -n "$src" ] || read -rp "Path or URL of the update .tgz: " src
  [ -n "$src" ] || return
  tmp="$(mktemp -d)"
  if [[ "$src" =~ ^https?:// ]]; then curl -fL -o "$tmp/u.tgz" "$src" || { echo "${R}Download failed${N}"; rm -rf "$tmp"; return; }
  else cp "$src" "$tmp/u.tgz" 2>/dev/null || { echo "${R}File not found${N}"; rm -rf "$tmp"; return; }; fi
  tar xzf "$tmp/u.tgz" -C "$tmp" 2>/dev/null || { echo "${R}Not a valid .tgz${N}"; rm -rf "$tmp"; return; }
  main="$(find "$tmp" -path '*/app/main.py' | head -1)"
  [ -n "$main" ] || { echo "${R}No app/main.py in package${N}"; rm -rf "$tmp"; return; }
  root="$(dirname "$(dirname "$main")")"
  local b="/root/panel-backup-update-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$b" && cp -a "$P/app" "$P/static" "$b/" && echo "Backup: $b"
  cp -a "$root/app/." "$P/app/"
  [ -d "$root/static" ] && cp -a "$root/static/." "$P/static/"
  if ! python3 -m py_compile "$P"/app/*.py; then
    echo "${R}Syntax error, reverting${N}"; cp -a "$b/app/." "$P/app/"; cp -a "$b/static/." "$P/static/"; rm -rf "$tmp"; return
  fi
  [ -f "$root/vpnpanel-menu.sh" ] && install -m 755 "$root/vpnpanel-menu.sh" /usr/local/bin/tcm19
  systemctl restart vpnpanel; sleep 5
  if [ "$(systemctl is-active vpnpanel)" != active ]; then
    echo "${R}Panel did not start, reverting${N}"
    cp -a "$b/app/." "$P/app/"; cp -a "$b/static/." "$P/static/"; systemctl restart vpnpanel
    journalctl -u vpnpanel -n 12 --no-pager
  else
    systemctl try-restart vpnpanel-sub 2>/dev/null
    echo "${G}Updated.${N} Close and reopen the browser."
  fi
  rm -rf "$tmp"
}

do_engines() {
  echo "Reinstall/upgrade engines:  1) Xray   2) sing-box   3) Both"
  read -rp "Choose: " c
  [[ "$c" =~ ^[13]$ ]] && bash -c "$(curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install
  [[ "$c" =~ ^[23]$ ]] && { curl -fsSL https://sing-box.app/install.sh | sh; }
  systemctl restart xray sing-box 2>/dev/null; do_status
}

do_firewall() {
  command -v ufw >/dev/null || { echo "ufw is not installed (the provider firewall is separate and must be set in their panel)."; return; }
  ufw status | head -12
  read -rp "Open which TCP/UDP port? (empty = cancel): " p
  [[ "$p" =~ ^[0-9]+$ ]] && ufw allow "$p" && echo "Opened $p"
}

do_uninstall() {
  echo "${R}This removes the panel service and code.${N} Xray/sing-box stay installed."
  read -rp "Type YES to continue: " a; [ "$a" = YES ] || return
  read -rp "Also DELETE all data (users, inbounds, certs)? [y/N] " d
  [ -d "$P/data" ] && ! [[ "$d" =~ ^[Yy]$ ]] && { mkdir -p /root/vpnpanel-data-kept && cp -a "$P/data/." /root/vpnpanel-data-kept/ && echo "Data copied to /root/vpnpanel-data-kept"; }
  systemctl disable --now vpnpanel vpnpanel-sub 2>/dev/null
  rm -f "$SVC" "$SUBSVC"; rm -rf /etc/systemd/system/vpnpanel.service.d; systemctl daemon-reload
  rm -rf "$P"; rm -f /usr/local/bin/tcm19 /usr/local/bin/panel /usr/local/bin/vpnpanel
  echo "Removed."; exit 0
}

menu() {
  while true; do
    clear
    echo "${C}============== tcm19 ==============${N}"
    echo "  tcm19 $(state vpnpanel)   xray $(state xray)   sing-box $(state sing-box)"
    echo "  $(panel_url)"
    echo "---------------------------------"
    echo " 1) Status"
    echo " 2) Login info"
    echo " 3) Restart services"
    echo " 4) Change panel port"
    echo " 5) Reset admin password"
    echo " 6) HTTPS / unlock panel"
    echo " 7) Logs"
    echo " 8) Backup"
    echo " 9) Update panel (file or URL)"
    echo "10) Reinstall / upgrade Xray & sing-box"
    echo "11) Firewall (ufw)"
    echo "12) Uninstall"
    echo " 0) Exit"
    read -rp "Choose: " c
    echo
    case "$c" in
      1) do_status; pause ;;  2) do_info; pause ;;     3) do_restart; pause ;;
      4) do_port; pause ;;    5) do_password; pause ;; 6) do_tls; pause ;;
      7) do_logs; pause ;;    8) do_backup; pause ;;   9) do_update; pause ;;
      10) do_engines; pause ;; 11) do_firewall; pause ;; 12) do_uninstall; pause ;;
      0|q) exit 0 ;;
    esac
  done
}

case "${1:-menu}" in
  menu) menu ;;            status) do_status ;;     info) do_info ;;
  restart) systemctl restart vpnpanel; do_status ;; port) do_port ;;
  password) do_password ;; logs) journalctl -u vpnpanel -n 60 --no-pager ;;
  backup) do_backup ;;     update) do_update "${2:-}" ;; engines) do_engines ;;
  uninstall) do_uninstall ;; *) echo "Usage: tcm19 [status|info|restart|port|password|logs|backup|update <file|url>|engines|uninstall]" ;;
esac
