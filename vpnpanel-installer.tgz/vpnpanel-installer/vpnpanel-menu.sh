#!/usr/bin/env bash
# tcm19 management menu.  Run:  tcm19
# Direct commands: tcm19 status|settings|start|stop|restart|port|password|unlock|logs|backup|update [file|url]|
#                  ssl|ips|firewall|bind|engines|bbr|geo|speedtest|uninstall
P=/opt/vpnpanel
SVC=/etc/systemd/system/vpnpanel.service
SUBSVC=/etc/systemd/system/vpnpanel-sub.service
UPDATE_REPO="${TCM19_REPO:-wxmpire/TCM19-panel}"
UPDATE_FILE="${TCM19_FILE:-vpnpanel-installer.tgz}"
SHA_FILE="$P/data/.update_sha"
R=$'\033[1;31m'; G=$'\033[0;32m'; GB=$'\033[1;32m'; Y=$'\033[1;33m'; C=$'\033[1;36m'; N=$'\033[0m'

[ "$(id -u)" = 0 ] || { echo "Run as root: sudo tcm19"; exit 1; }
[ -d "$P/app" ] || { echo "Panel is not installed in $P"; exit 1; }

# ------------------------------------------------------------------ helpers
panel_port() { systemctl cat vpnpanel 2>/dev/null | grep -o -- '--port [0-9]*' | tail -1 | awk '{print $2}'; }
panel_host() { systemctl cat vpnpanel 2>/dev/null | grep -o -- '--host [^ ]*' | tail -1 | awk '{print $2}'; }
sub_port()   { grep -o -- '--port [0-9]*' "$SUBSVC" 2>/dev/null | tail -1 | awk '{print $2}'; }
PUBIP=""
pubip()      { [ -n "$PUBIP" ] || PUBIP="$(curl -4 -s -m 4 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')"; printf '%s' "$PUBIP"; }
panel_domain() { python3 -c 'import json;print(json.load(open("/opt/vpnpanel/data/domains.json")).get("panel",{}).get("domain",""))' 2>/dev/null; }
panel_url()  { local d; d="$(panel_domain)"; if [ -n "$d" ]; then echo "https://$d:$(panel_port)"; else echo "http://$(pubip):$(panel_port)"; fi; }
rstate()     { # Running / Stopped / Not installed
  systemctl cat "$1" >/dev/null 2>&1 || { echo "${Y}Not installed${N}"; return; }
  [ "$(systemctl is-active "$1" 2>/dev/null)" = active ] && echo "${GB}Running${N}" || echo "${R}Stopped${N}"; }
autostart()  { [ "$(systemctl is-enabled vpnpanel 2>/dev/null)" = enabled ] && echo "${GB}Yes${N}" || echo "${R}No${N}"; }
pause()      { echo; read -rp "Press Enter to return to the menu... " _; }
confirm()    { local a; read -rp "$1 [y/N] " a; [[ "$a" =~ ^[Yy]$ ]]; }
pyrun()      { ( cd "$P" && PANEL_HOME="$P" "$P/venv/bin/python" "$@" ); }
ctl()        { ( cd "$P" && PANEL_HOME="$P" "$P/venv/bin/python" -m app.panelctl "$@" ); }
ok()         { echo "${GB}$*${N}"; }
bad()        { echo "${R}$*${N}"; }
has_ufw()    { command -v ufw >/dev/null 2>&1; }
ufw_active() { has_ufw && ufw status 2>/dev/null | grep -q "Status: active"; }
restart_panel() { systemctl restart vpnpanel; [ -f "$SUBSVC" ] && systemctl try-restart vpnpanel-sub; sleep 3; }

# ------------------------------------------------------------------ box drawing
W=40
hl()  { local i s=""; for ((i=0;i<W;i++)); do s+="═"; done; printf '%s' "$s"; }
top() { echo "${G}╔$(hl)╗${N}"; }
mid() { echo "${G}╠$(hl)╣${N}"; }
bot() { echo "${G}╚$(hl)╝${N}"; }
row() { printf "${G}║${N} %-$((W-2))s ${G}║${N}\n" "$1"; }

show_menu() {
  clear
  top
  row "tcm19 Panel Management Script"
  row "0.  Exit Script"
  mid
  row "1.  Reinstall (keep data)"
  row "2.  Update"
  row "3.  Update from file / URL"
  row "4.  Update Menu"
  row "5.  Rollback (restore old code)"
  row "6.  Uninstall"
  mid
  row "7.  Reset Username & Password"
  row "8.  Unlock Panel (reset HTTPS)"
  row "9.  Reset Settings"
  row "10. Change Port"
  row "11. View Current Settings"
  mid
  row "12. Start"
  row "13. Stop"
  row "14. Restart"
  row "15. Restart Xray / sing-box"
  row "16. Check Status"
  row "17. Logs Management"
  mid
  row "18. Enable Autostart"
  row "19. Disable Autostart"
  mid
  row "20. SSL Certificate Management"
  row "21. Cloudflare SSL Certificate"
  row "22. Server IP Addresses"
  row "23. Firewall Management"
  row "24. SSH Tunnel / Panel Bind"
  row "25. Engines (Xray/sing-box/WG)"
  mid
  row "26. Enable BBR"
  row "27. Update Geo Files"
  row "28. Speedtest by Ookla"
  row "29. Backup / Restore Data"
  bot
  echo
  echo "Panel state: $(rstate vpnpanel)"
  echo "Start automatically: $(autostart)"
  echo "xray state: $(rstate xray)"
  echo "sing-box state: $(rstate sing-box)"
  echo "URL: $(panel_url)"
  echo
}

# ------------------------------------------------------------------ 11/16 status + settings
do_status() {
  echo "${C}Services${N}"
  printf '  %-14s %s\n' tcm19 "$(rstate vpnpanel)" xray "$(rstate xray)" sing-box "$(rstate sing-box)"
  [ -f "$SUBSVC" ] && printf '  %-14s %s\n' "sub listener" "$(rstate vpnpanel-sub)"
  systemctl cat wg-quick@wg0 >/dev/null 2>&1 && printf '  %-14s %s\n' wireguard "$(rstate wg-quick@wg0)"
  echo; echo "${C}Panel${N}"
  echo "  URL     : $(panel_url)"
  [ -n "$(sub_port)" ] && echo "  Sub port: $(sub_port)"
  echo "  Build   : $(cut -c1-7 "$SHA_FILE" 2>/dev/null || echo unknown)"
  echo "  Engines : xray $(xray version 2>/dev/null | head -1 | awk '{print $2}')  sing-box $(sing-box version 2>/dev/null | head -1 | awk '{print $3}')"
  echo "  Uptime  : $(systemctl show vpnpanel -p ActiveEnterTimestamp --value 2>/dev/null)"
}

do_settings() {
  echo "${C}Current settings${N}"
  echo "  Panel URL     : $(panel_url)"
  echo "  Listen        : $(panel_host):$(panel_port)"
  echo "  Autostart     : $(autostart)"
  local dm; dm="$(panel_domain)"
  echo "  HTTPS domain  : ${dm:-(none)}"
  echo "  Sub listener  : $([ -n "$(sub_port)" ] && echo "port $(sub_port) ($(rstate vpnpanel-sub))" || echo "off (uses panel port)")"
  pyrun - <<'PY'
import sqlite3
c = sqlite3.connect("/opt/vpnpanel/data/panel.db")
s = dict(c.execute("select key,value from settings").fetchall())
adm = [r[0] for r in c.execute("select username from admins")]
print("  Admin users   :", ", ".join(adm) or "-")
print("  Server address:", s.get("server_address") or "(not set)")
print("  Sub base URL  :", s.get("sub_base_url") or "(auto)")
print("  Users         :", c.execute("select count(*) from users").fetchone()[0])
print("  Inbounds      :", c.execute("select count(*) from inbounds").fetchone()[0])
PY
  [ -f "$P/data/initial_admin.txt" ] && echo "  ${Y}First-run password file still exists:${N} $P/data/initial_admin.txt"
  if [ -f "$P/data/initial_admin.txt" ] && confirm "  Show and then delete it?"; then cat "$P/data/initial_admin.txt" | sed 's/^/    /'; rm -f "$P/data/initial_admin.txt"; fi
}

# ------------------------------------------------------------------ 12-15, 18-19 service control
do_start()   { systemctl start vpnpanel; [ -f "$SUBSVC" ] && systemctl start vpnpanel-sub; sleep 2; echo "Panel: $(rstate vpnpanel)"; }
do_stop()    { confirm "Stop the panel? (Xray/sing-box keep running)" || return; systemctl stop vpnpanel; [ -f "$SUBSVC" ] && systemctl stop vpnpanel-sub; echo "Panel: $(rstate vpnpanel)"; }
do_restart() { restart_panel; echo "Panel: $(rstate vpnpanel)"; }
do_restart_engines() {
  for s in xray sing-box; do systemctl cat "$s" >/dev/null 2>&1 && systemctl restart "$s"; done
  sleep 2; echo "xray: $(rstate xray)"; echo "sing-box: $(rstate sing-box)"
}
do_autostart() {
  if [ "$1" = on ]; then systemctl enable vpnpanel >/dev/null 2>&1; [ -f "$SUBSVC" ] && systemctl enable vpnpanel-sub >/dev/null 2>&1; ok "Autostart enabled"
  else systemctl disable vpnpanel >/dev/null 2>&1; [ -f "$SUBSVC" ] && systemctl disable vpnpanel-sub >/dev/null 2>&1; ok "Autostart disabled"; fi
}

# ------------------------------------------------------------------ 17 logs
do_logs() {
  echo " 1) Panel (last 80 lines)"
  echo " 2) Xray"
  echo " 3) sing-box"
  echo " 4) Subscription listener"
  echo " 5) Follow panel log live (Ctrl+C to stop)"
  echo " 6) Clear all logs"
  echo " 0) Back"
  read -rp "Choose: " c
  case "$c" in
    1) journalctl -u vpnpanel -n 80 --no-pager ;;
    2) journalctl -u xray -n 80 --no-pager ;;
    3) journalctl -u sing-box -n 80 --no-pager ;;
    4) journalctl -u vpnpanel-sub -n 80 --no-pager ;;
    5) trap ':' INT; journalctl -fu vpnpanel; trap - INT ;;
    6) confirm "Delete all journal logs?" && { journalctl --rotate >/dev/null 2>&1; journalctl --vacuum-time=1s >/dev/null 2>&1; : > /var/log/xray/access.log 2>/dev/null; : > /var/log/xray/error.log 2>/dev/null; ok "Logs cleared"; } ;;
  esac
}

# ------------------------------------------------------------------ 7 password, 8 unlock, 9 reset settings
do_password() {
  local u pw x GEN
  u="$(pyrun - <<'PY'
import sqlite3
r = sqlite3.connect("/opt/vpnpanel/data/panel.db").execute("select username from admins order by rowid").fetchall()
print(r[0][0] if r else "")
PY
)"
  read -rp "Admin username [${u:-admin}] (Enter = keep, type 'random' for random): " x
  if [ "$x" = random ]; then u="$(LC_ALL=C tr -dc 'a-z0-9' </dev/urandom | head -c 8)"; else u="${x:-${u:-admin}}"; fi
  read -rp "New password (any length, Enter = random): " pw
  GEN=0
  if [ -z "$pw" ]; then pw="$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 16)"; GEN=1; fi
  PW="$pw" U="$u" pyrun - <<'PY'
import os
from app import db, security
u, pw = os.environ["U"], os.environ["PW"]
if db.get_admin(u):
    db.set_admin_password(u, security.hash_password(pw)); print("  Password updated for", u)
else:
    db.create_admin(u, security.hash_password(pw)); print("  Admin created:", u)
PY
  echo "  Username: $u"
  [ "$GEN" = 1 ] && echo "  Password: $pw"
  rm -f "$P/data/initial_admin.txt"
}

do_unlock() {
  echo "This turns off the panel HTTPS/domain lock so it answers on plain HTTP and by IP again."
  confirm "Continue?" && ctl unlock
}

do_reset_settings() {
  echo "${Y}Resets panel settings (server address, subscription URL/port, ...) to defaults.${N}"
  echo "Users, inbounds, admin accounts and certificates are kept. A backup is made first."
  local a; read -rp "Type YES to continue: " a; [ "$a" = YES ] || return
  do_backup >/dev/null 2>&1
  pyrun - <<'PY'
import sqlite3
c = sqlite3.connect("/opt/vpnpanel/data/panel.db"); c.execute("DELETE FROM settings"); c.commit()
PY
  if [ -f "$SUBSVC" ]; then systemctl disable --now vpnpanel-sub >/dev/null 2>&1; rm -f "$SUBSVC"; systemctl daemon-reload; echo "  Subscription listener removed"; fi
  confirm "Also remove the HTTPS/domain lock?" && ctl unlock >/dev/null 2>&1
  restart_panel
  local ip; ip="$(pubip)"
  [ -n "$ip" ] && pyrun - "$ip" <<'PY'
import sqlite3, sys
c = sqlite3.connect("/opt/vpnpanel/data/panel.db")
c.execute("UPDATE settings SET value=? WHERE key='server_address' AND value=''", (sys.argv[1],)); c.commit()
PY
  ok "Settings reset. Server address set to $ip."
}

# ------------------------------------------------------------------ 10 port
do_port() {
  local old new; old="$(panel_port)"
  echo "Current panel port: $old"
  read -rp "New port (1-65535, empty = cancel): " new
  [ -z "$new" ] && return
  [[ "$new" =~ ^[0-9]+$ ]] && [ "$new" -ge 1 ] && [ "$new" -le 65535 ] || { bad "Invalid port"; return; }
  [ "$new" = "$(sub_port)" ] && { bad "That port is used by the subscription listener"; return; }
  ss -ltn | awk '{print $4}' | grep -q ":$new\$" && { bad "Port $new is already in use"; return; }
  grep -rl -- "--port $old" /etc/systemd/system/vpnpanel.service /etc/systemd/system/vpnpanel.service.d/ 2>/dev/null \
    | xargs -r sed -i "s/--port $old/--port $new/"
  pyrun - "$old" "$new" <<'PY'
import sqlite3, sys
old, new = sys.argv[1], sys.argv[2]
c = sqlite3.connect("/opt/vpnpanel/data/panel.db")
r = c.execute("select value from settings where key='sub_base_url'").fetchone()
if r and r[0].rstrip("/").endswith(":" + old):
    c.execute("update settings set value=? where key='sub_base_url'", (r[0].rstrip("/")[: -len(old)] + new,))
    c.commit(); print("  sub_base_url updated")
PY
  systemctl daemon-reload
  systemctl restart vpnpanel; sleep 4
  if [ "$(systemctl is-active vpnpanel)" = active ] && ss -ltn | awk '{print $4}' | grep -q ":$new\$"; then
    ufw_active && ufw allow "$new/tcp" >/dev/null && echo "  ufw: opened $new"
    ok "Panel now listens on $new. Open TCP $new in your provider firewall."
  else
    bad "Failed, reverting."
    grep -rl -- "--port $new" /etc/systemd/system/vpnpanel.service /etc/systemd/system/vpnpanel.service.d/ 2>/dev/null | xargs -r sed -i "s/--port $new/--port $old/"
    systemctl daemon-reload; systemctl restart vpnpanel
  fi
}

# ------------------------------------------------------------------ 1-5 install / update / rollback / uninstall
fetch_update() {  # fetch_update OUTFILE  (GitHub API first: never cached; raw URL as fallback)
  local api="https://api.github.com/repos/$UPDATE_REPO/contents/$UPDATE_FILE"
  local raw="https://raw.githubusercontent.com/$UPDATE_REPO/main/$UPDATE_FILE"
  curl -fsSL -m 90 -H "Accept: application/vnd.github.raw" -o "$1" "$api" 2>/dev/null && tar tzf "$1" >/dev/null 2>&1 && return 0
  curl -fsSL -m 90 -o "$1" "$raw" 2>/dev/null && tar tzf "$1" >/dev/null 2>&1
}

do_update() {
  # tcm19 update            -> latest from GitHub
  # tcm19 update FILE|URL   -> a specific .tgz
  local src="${1:-}" tmp main root sha b menu_changed=0
  tmp="$(mktemp -d)"
  if [ -z "$src" ]; then
    echo "Checking GitHub: $UPDATE_REPO ..."
    if ! fetch_update "$tmp/u.tgz"; then
      bad "Could not download the update from GitHub."
      read -rp "Enter a file path or URL instead (empty = cancel): " src
      [ -n "$src" ] || { rm -rf "$tmp"; return; }
    fi
  fi
  if [ -n "$src" ]; then
    if [[ "$src" =~ ^https?:// ]]; then curl -fL -o "$tmp/u.tgz" "$src" || { bad "Download failed"; rm -rf "$tmp"; return; }
    else cp "$src" "$tmp/u.tgz" 2>/dev/null || { bad "File not found: $src"; rm -rf "$tmp"; return; }; fi
  fi
  tar xzf "$tmp/u.tgz" -C "$tmp" 2>/dev/null || { bad "Not a valid .tgz"; rm -rf "$tmp"; return; }
  sha="$(sha256sum "$tmp/u.tgz" | cut -d' ' -f1)"
  if [ -z "$src" ] && [ "$sha" = "$(cat "$SHA_FILE" 2>/dev/null)" ]; then ok "Already up to date."; rm -rf "$tmp"; return; fi
  main="$(find "$tmp" -path '*/app/main.py' | head -1)"
  [ -n "$main" ] || { bad "No app/main.py in the package"; rm -rf "$tmp"; return; }
  root="$(dirname "$(dirname "$main")")"
  b="/root/panel-backup-update-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$b" && cp -a "$P/app" "$P/static" "$b/" && echo "Backup: $b"
  cp -a "$root/app/." "$P/app/"
  [ -d "$root/static" ] && cp -a "$root/static/." "$P/static/"
  rm -rf "$P/app/__pycache__"
  if ! python3 -m py_compile "$P"/app/*.py; then
    bad "Syntax error in the update, reverting"
    cp -a "$b/app/." "$P/app/"; cp -a "$b/static/." "$P/static/"; rm -rf "$tmp"; return
  fi
  if [ -f "$root/vpnpanel-menu.sh" ] && ! cmp -s "$root/vpnpanel-menu.sh" /usr/local/bin/tcm19; then
    install -m 755 "$root/vpnpanel-menu.sh" /usr/local/bin/tcm19; menu_changed=1
  fi
  systemctl restart vpnpanel; sleep 5
  if [ "$(systemctl is-active vpnpanel)" != active ]; then
    bad "Panel did not start, reverting"
    cp -a "$b/app/." "$P/app/"; cp -a "$b/static/." "$P/static/"; systemctl restart vpnpanel
    journalctl -u vpnpanel -n 12 --no-pager
  else
    systemctl try-restart vpnpanel-sub 2>/dev/null
    echo "$sha" > "$SHA_FILE"
    ok "Updated to build ${sha:0:7}. Close and reopen the browser."
    [ "$menu_changed" = 1 ] && echo "${Y}The menu itself was updated: exit and run  tcm19  again.${N}"
  fi
  rm -rf "$tmp"
}

do_reinstall() {
  echo "Downloads the latest package and runs the installer in update mode."
  echo "Your data, port, users and service are kept."
  confirm "Continue?" || return
  local tmp main root; tmp="$(mktemp -d)"
  fetch_update "$tmp/u.tgz" || { bad "Download from GitHub failed"; rm -rf "$tmp"; return; }
  tar xzf "$tmp/u.tgz" -C "$tmp"; main="$(find "$tmp" -path '*/app/main.py' | head -1)"
  [ -n "$main" ] || { bad "Bad package"; rm -rf "$tmp"; return; }
  root="$(dirname "$(dirname "$main")")"
  bash "$root/install.sh"
  sha256sum "$tmp/u.tgz" | cut -d' ' -f1 > "$SHA_FILE"
  rm -rf "$tmp"
}

do_menu_update() {
  local tmp main root; tmp="$(mktemp -d)"
  echo "Checking GitHub: $UPDATE_REPO ..."
  fetch_update "$tmp/u.tgz" || { bad "Download from GitHub failed"; rm -rf "$tmp"; return; }
  tar xzf "$tmp/u.tgz" -C "$tmp"; main="$(find "$tmp" -name vpnpanel-menu.sh | head -1)"
  [ -n "$main" ] || { bad "Package has no menu script"; rm -rf "$tmp"; return; }
  if cmp -s "$main" /usr/local/bin/tcm19; then ok "Menu is already up to date."
  else bash -n "$main" && install -m 755 "$main" /usr/local/bin/tcm19 && ok "Menu updated. Exit and run  tcm19  again."; fi
  rm -rf "$tmp"
}

do_rollback() {
  local list i c d b
  mapfile -t list < <(ls -dt /root/panel-backup-update-* /root/panel-backup-before-rollback-* 2>/dev/null | head -10)
  [ "${#list[@]}" -gt 0 ] || { echo "No code backups found in /root (they are created by every update)."; return; }
  echo "Available code backups (newest first):"
  for i in "${!list[@]}"; do echo "  $((i+1))) $(basename "${list[$i]}")"; done
  read -rp "Restore which one? (empty = cancel): " c
  [[ "$c" =~ ^[0-9]+$ ]] && [ "$c" -ge 1 ] && [ "$c" -le "${#list[@]}" ] || return
  d="${list[$((c-1))]}"
  [ -d "$d/app" ] || { bad "Backup has no app folder"; return; }
  confirm "Restore $(basename "$d")? Your data is not touched." || return
  b="/root/panel-backup-before-rollback-$(date +%Y%m%d-%H%M%S)"
  mkdir -p "$b" && cp -a "$P/app" "$P/static" "$b/"
  cp -a "$d/app/." "$P/app/"; [ -d "$d/static" ] && cp -a "$d/static/." "$P/static/"
  rm -f "$SHA_FILE"
  systemctl restart vpnpanel; sleep 5
  if [ "$(systemctl is-active vpnpanel)" = active ]; then systemctl try-restart vpnpanel-sub 2>/dev/null; ok "Rolled back. Close and reopen the browser."
  else bad "Panel did not start, undoing"; cp -a "$b/app/." "$P/app/"; cp -a "$b/static/." "$P/static/"; systemctl restart vpnpanel; fi
}

do_uninstall() {
  echo "${R}This removes the panel service and code.${N} Xray/sing-box stay installed."
  local a d; read -rp "Type YES to continue: " a; [ "$a" = YES ] || return
  read -rp "Also DELETE all data (users, inbounds, certs)? [y/N] " d
  [ -d "$P/data" ] && ! [[ "$d" =~ ^[Yy]$ ]] && { mkdir -p /root/vpnpanel-data-kept && cp -a "$P/data/." /root/vpnpanel-data-kept/ && echo "Data copied to /root/vpnpanel-data-kept"; }
  systemctl disable --now vpnpanel vpnpanel-sub 2>/dev/null
  rm -f "$SVC" "$SUBSVC"; rm -rf /etc/systemd/system/vpnpanel.service.d; systemctl daemon-reload
  rm -rf "$P"; rm -f /usr/local/bin/tcm19 /usr/local/bin/panel /usr/local/bin/vpnpanel
  echo "Removed."; exit 0
}

# ------------------------------------------------------------------ 20/21 SSL
use_for_panel() {  # use_for_panel DOMAIN
  local dom="$1" port; port="$(panel_port)"
  ctl set-panel "$dom" --no-restart || return 1
  DOM="$dom" PORT="$port" pyrun - <<'PY'
import os
from urllib.parse import urlsplit
from app import db, certstore as cs
dom, port = os.environ["DOM"], os.environ["PORT"]
s = db.get_settings(); upd = {}
if not s.get("server_address") or cs.is_ip(s["server_address"]):
    upd["server_address"] = dom
sb = s.get("sub_base_url", "")
if not sb or cs.is_ip(urlsplit(sb).hostname or ""):
    upd["sub_base_url"] = f"https://{dom}:{port}"
if upd:
    db.set_settings(upd)
PY
  restart_panel
  ok "Panel is now served over HTTPS: https://$dom:$port"
}

ask_domain() {
  local d; read -rp "Domain: " d
  d="$(printf '%s' "$d" | tr 'A-Z' 'a-z' | sed -E 's#^https?://##; s#[/:].*$##')"
  [[ "$d" =~ ^([a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$ ]] || { bad "Not a valid domain" >&2; return 1; }
  printf '%s' "$d"
}

do_ssl() {
  echo " 1) List certificates"
  echo " 2) Get a free certificate (HTTP, needs port 80)"
  echo " 3) Import your own certificate (PEM files)"
  echo " 4) Use a domain's certificate for the panel"
  echo " 5) Renew all certificates now"
  echo " 6) Remove the panel HTTPS lock"
  echo " 0) Back"
  read -rp "Choose: " c
  local d cert key
  case "$c" in
    1) ctl status ;;
    2) d="$(ask_domain)" || return
       ufw_active && ufw allow 80/tcp >/dev/null 2>&1
       ss -ltn | awk '{print $4}' | grep -q ':80$' && { bad "Port 80 is in use; free it first."; return; }
       ctl issue-http "$d" && confirm "Use $d for the panel (HTTPS)?" && use_for_panel "$d" ;;
    3) d="$(ask_domain)" || return
       read -rp "Path to certificate (fullchain.pem): " cert; read -rp "Path to private key: " key
       ctl import "$d" "$cert" "$key" && confirm "Use $d for the panel (HTTPS)?" && use_for_panel "$d" ;;
    4) d="$(ask_domain)" || return; use_for_panel "$d" ;;
    5) certbot renew && ok "Renew finished" ; restart_panel ;;
    6) do_unlock ;;
  esac
}

do_cloudflare() {
  echo "Gets a certificate with the Cloudflare DNS challenge (works behind the orange cloud, supports wildcard)."
  echo "You will be asked for the Cloudflare API token once (Zone:DNS:Edit); it is stored for renewals."
  local d w; d="$(ask_domain)" || return
  local args=(issue-cloudflare "$d")
  confirm "Include wildcard *.$d ?" || args+=(--no-wildcard)
  ctl "${args[@]}" && confirm "Use $d for the panel (HTTPS)?" && use_for_panel "$d"
}

# ------------------------------------------------------------------ 22 server IPs
do_ips() {
  pyrun - <<'PY'
from app import serverips as s
d = s.listing()
for i in d["items"]:
    print(f"  {i['ip']:<18} {'detected' if i['source']=='detected' else 'added by you':<13} {'DEFAULT' if i['default'] else ''}")
if d["default"] and not any(i["default"] for i in d["items"]):
    print("  current default address:", d["default"])
PY
  echo; echo " 1) Add an IP   2) Make default   3) Delete an added IP   0) Back"
  read -rp "Choose: " c; local ip
  case "$c" in
    1) read -rp "IPv4 address: " ip; IPX="$ip" pyrun - <<'PY'
import os
from app import serverips as s
try: s.add(os.environ["IPX"]); print("  added")
except s.IpError as e: print("  ERROR:", e)
PY
    ;;
    2) read -rp "IPv4 address: " ip; IPX="$ip" pyrun - <<'PY'
import os
from app import serverips as s
try: s.make_default(os.environ["IPX"]); print("  default changed (restart the panel to apply to engine configs)")
except s.IpError as e: print("  ERROR:", e)
PY
       confirm "Restart the panel now?" && restart_panel ;;
    3) read -rp "IPv4 address: " ip; IPX="$ip" pyrun - <<'PY'
import os
from app import serverips as s
try: s.remove(os.environ["IPX"]); print("  deleted")
except s.IpError as e: print("  ERROR:", e)
PY
    ;;
  esac
}

# ------------------------------------------------------------------ 23 firewall
ssh_ports() {  # every SSH port we can find (current session, sshd config, listeners); 22 as a last resort
  { [ -n "${SSH_CONNECTION:-}" ] && echo "$SSH_CONNECTION" | awk '{print $4}'
    sshd -T 2>/dev/null | awk '/^port /{print $2}'
    ss -ltnp 2>/dev/null | awk '/sshd/{n=split($4,a,":"); print a[n]}'
  } | grep -E '^[0-9]+$' | sort -un | tr '\n' ' ' | sed 's/ *$//' | sed 's/^$/22/'; }
panel_ports() {  # tcp ports the panel needs + inbound ports (tcp+udp)
  { echo "tcp $(panel_port)"; [ -n "$(sub_port)" ] && echo "tcp $(sub_port)"
    pyrun - <<'PY'
import sqlite3
c = sqlite3.connect("/opt/vpnpanel/data/panel.db")
for (p,) in c.execute("select distinct port from inbounds where enabled=1"):
    print("tcp", p); print("udp", p)
r = c.execute("select value from settings where key='wg_port'").fetchone()
if r and str(r[0]).isdigit(): print("udp", r[0])
PY
  } | sort -u
}
do_firewall() {
  has_ufw || { confirm "ufw is not installed. Install it?" && apt-get install -y ufw >/dev/null 2>&1 || return; }
  echo " 1) Status / rules"
  echo " 2) Enable (opens SSH, panel and inbound ports first)"
  echo " 3) Disable"
  echo " 4) Open a port"
  echo " 5) Close a port"
  echo " 6) Open all panel + inbound ports again"
  echo " 0) Back"
  read -rp "Choose: " c; local p x
  case "$c" in
    1) ufw status numbered ;;
    2) echo "SSH port(s): $(ssh_ports)"; echo "Will allow:"; panel_ports | sed 's/^/  /'
       confirm "Enable the firewall with these rules?" || return
       for p in $(ssh_ports); do ufw allow "$p/tcp" >/dev/null; done
       ufw allow 80/tcp >/dev/null
       while read -r proto port; do ufw allow "$port/$proto" >/dev/null; done < <(panel_ports)
       ufw --force enable && ok "Firewall enabled" ;;
    3) ufw disable && ok "Firewall disabled" ;;
    4) read -rp "Port (e.g. 443 or 443/udp): " x; [ -n "$x" ] && ufw allow "$x" ;;
    5) read -rp "Port (e.g. 443 or 443/udp): " x; [ -n "$x" ] && ufw delete allow "$x" ;;
    6) while read -r proto port; do ufw allow "$port/$proto" >/dev/null; done < <(panel_ports); ok "Done" ;;
  esac
}

# ------------------------------------------------------------------ 24 SSH tunnel / bind
do_ssh() {
  local host port sshp ip; host="$(panel_host)"; port="$(panel_port)"; sshp="$(ssh_ports | awk '{print $1}')"; ip="$(pubip)"
  echo "Panel listens on: ${host:-?}:$port   ($([ "$host" = 127.0.0.1 ] && echo "only reachable through an SSH tunnel" || echo "open to the internet"))"
  echo
  echo " 1) Show the SSH tunnel command"
  echo " 2) Make the panel private (bind to 127.0.0.1)"
  echo " 3) Make the panel public again (bind to 0.0.0.0)"
  echo " 0) Back"
  read -rp "Choose: " c
  case "$c" in
    1) echo; echo "Run this on your phone/PC, then open https://127.0.0.1:8080 (or http:// if no domain is set):"
       echo "  ssh -N -L 8080:127.0.0.1:$port root@$ip -p $sshp"
       echo "In Termius: Port Forwarding -> Local, bind 127.0.0.1:8080 -> destination 127.0.0.1:$port." ;;
    2) if [ -z "$(sub_port)" ]; then echo "${Y}Subscription links are served by the panel itself. Without a separate subscription port they will stop working.${N}"; echo "Set one first (panel: Domain page -> subscription port) or accept that."; fi
       confirm "Bind the panel to 127.0.0.1?" || return
       grep -rl -- "--host 0.0.0.0" /etc/systemd/system/vpnpanel.service /etc/systemd/system/vpnpanel.service.d/ 2>/dev/null | xargs -r sed -i "s/--host 0.0.0.0/--host 127.0.0.1/"
       systemctl daemon-reload; systemctl restart vpnpanel; sleep 3
       ok "Done. Use the SSH tunnel (option 1) to open the panel." ;;
    3) grep -rl -- "--host 127.0.0.1" /etc/systemd/system/vpnpanel.service /etc/systemd/system/vpnpanel.service.d/ 2>/dev/null | xargs -r sed -i "s/--host 127.0.0.1/--host 0.0.0.0/"
       systemctl daemon-reload; systemctl restart vpnpanel; sleep 3; ok "Panel is public again." ;;
  esac
}

# ------------------------------------------------------------------ 25 engines
do_engines() {
  echo "Install / upgrade:  1) Xray   2) sing-box   3) WireGuard tools   4) All"
  read -rp "Choose: " c
  [[ "$c" =~ ^[14]$ ]] && bash -c "$(curl -fsSL https://github.com/XTLS/Xray-install/raw/main/install-release.sh)" @ install
  [[ "$c" =~ ^[24]$ ]] && { curl -fsSL https://sing-box.app/install.sh | sh; }
  [[ "$c" =~ ^[34]$ ]] && { apt-get install -y wireguard-tools >/dev/null 2>&1 && printf 'net.ipv4.ip_forward=1\n' > /etc/sysctl.d/99-vpnpanel.conf && sysctl -p /etc/sysctl.d/99-vpnpanel.conf >/dev/null 2>&1 && ok "WireGuard tools installed"; }
  do_restart_engines
}

# ------------------------------------------------------------------ 26-28
do_bbr() {
  local cur; cur="$(sysctl -n net.ipv4.tcp_congestion_control 2>/dev/null)"
  echo "Current congestion control: ${cur:-unknown}"
  if [ "$cur" = bbr ]; then
    confirm "BBR is already on. Turn it off (back to cubic)?" || return
    rm -f /etc/sysctl.d/99-tcm19-bbr.conf; sysctl -w net.ipv4.tcp_congestion_control=cubic >/dev/null; ok "BBR disabled"; return
  fi
  modprobe tcp_bbr 2>/dev/null
  sysctl -n net.ipv4.tcp_available_congestion_control 2>/dev/null | grep -qw bbr || { bad "This kernel does not support BBR."; return; }
  printf 'net.core.default_qdisc=fq\nnet.ipv4.tcp_congestion_control=bbr\n' > /etc/sysctl.d/99-tcm19-bbr.conf
  sysctl --system >/dev/null 2>&1
  [ "$(sysctl -n net.ipv4.tcp_congestion_control)" = bbr ] && ok "BBR enabled" || bad "Could not enable BBR"
}

do_geo() {
  # Download the .dat files straight from GitHub releases (does not depend on the Xray installer script).
  local dir="${GEO_DIR:-/usr/local/share/xray}" tmp f ok=0 src
  [ -d "$dir" ] || { mkdir -p "$dir" || { bad "Cannot create $dir"; return; }; }
  tmp="$(mktemp -d)"
  echo "Updating Xray geoip / geosite files in $dir ..."
  for src in \
    "https://github.com/v2fly/geoip/releases/latest/download/geoip.dat|https://github.com/v2fly/domain-list-community/releases/latest/download/dlc.dat" \
    "https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geoip.dat|https://github.com/Loyalsoldier/v2ray-rules-dat/releases/latest/download/geosite.dat"; do
    rm -f "$tmp/geoip.dat" "$tmp/geosite.dat"
    echo "  source: $(echo "${src%%|*}" | awk -F/ '{print $4"/"$5}')"
    curl -fsSL --retry 2 -m 120 -o "$tmp/geoip.dat" "${src%%|*}" \
      && curl -fsSL --retry 2 -m 120 -o "$tmp/geosite.dat" "${src##*|}" || continue
    # sanity check: real files are several MB
    [ "$(stat -c %s "$tmp/geoip.dat" 2>/dev/null || echo 0)" -gt 100000 ] && [ "$(stat -c %s "$tmp/geosite.dat" 2>/dev/null || echo 0)" -gt 100000 ] || continue
    ok=1; break
  done
  if [ "$ok" = 1 ]; then
    for f in geoip.dat geosite.dat; do
      [ -f "$dir/$f" ] && cp -a "$dir/$f" "$dir/$f.bak"
      install -m 644 "$tmp/$f" "$dir/$f"
    done
    systemctl restart xray 2>/dev/null
    ok "Geo files updated ($(du -h "$dir/geoip.dat" | cut -f1) geoip, $(du -h "$dir/geosite.dat" | cut -f1) geosite)."
    systemctl cat sing-box >/dev/null 2>&1 && echo "(sing-box does not use these files.)"
  else
    bad "Download failed (GitHub unreachable or blocked from this server)."
  fi
  rm -rf "$tmp"
}

do_speedtest() {
  local bin=/opt/ookla/speedtest arch url
  if [ ! -x "$bin" ]; then
    case "$(uname -m)" in x86_64) arch=x86_64 ;; aarch64|arm64) arch=aarch64 ;; *) bad "Unsupported CPU: $(uname -m)"; return ;; esac
    url="https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-$arch.tgz"
    echo "Downloading Ookla Speedtest..."
    mkdir -p /opt/ookla && curl -fsSL -m 90 "$url" | tar xz -C /opt/ookla speedtest || { bad "Download failed"; return; }
  fi
  "$bin" --accept-license --accept-gdpr
}

# ------------------------------------------------------------------ 29 backup / restore
do_backup() {
  local out="/root/panel-backup-$(date +%Y%m%d-%H%M%S).db"
  pyrun - "$out" <<'PY'
import sqlite3, sys
s = sqlite3.connect("/opt/vpnpanel/data/panel.db"); d = sqlite3.connect(sys.argv[1]); s.backup(d); d.close(); s.close()
PY
  chmod 600 "$out"
  ok "Database saved: $out  (download it with Termius SFTP)"
  tar czf "${out%.db}-data.tgz" -C "$P/data" . 2>/dev/null && chmod 600 "${out%.db}-data.tgz" && echo "Full data folder: ${out%.db}-data.tgz"
}

do_restore() {
  local list i c f
  mapfile -t list < <(ls -t /root/panel-backup-*.db 2>/dev/null | head -10)
  echo "Database backups in /root:"
  for i in "${!list[@]}"; do echo "  $((i+1))) $(basename "${list[$i]}")"; done
  read -rp "Number, or full path of a .db file (empty = cancel): " c
  if [[ "$c" =~ ^[0-9]+$ ]] && [ "$c" -ge 1 ] && [ "$c" -le "${#list[@]}" ]; then f="${list[$((c-1))]}"; else f="$c"; fi
  [ -n "$f" ] && [ -f "$f" ] || { [ -n "$c" ] && bad "File not found"; return; }
  python3 -c "import sqlite3,sys;sqlite3.connect(sys.argv[1]).execute('select count(*) from settings')" "$f" 2>/dev/null || { bad "Not a valid panel database"; return; }
  confirm "Replace the current database with $(basename "$f")?" || return
  do_backup >/dev/null 2>&1
  systemctl stop vpnpanel
  cp "$f" "$P/data/panel.db"; rm -f "$P/data/panel.db-wal" "$P/data/panel.db-shm"
  systemctl start vpnpanel; sleep 4
  [ "$(systemctl is-active vpnpanel)" = active ] && ok "Database restored." || { bad "Panel did not start:"; journalctl -u vpnpanel -n 8 --no-pager; }
}

do_data() {
  echo " 1) Backup now"
  echo " 2) Restore database from a backup"
  echo " 0) Back"
  read -rp "Choose: " c
  case "$c" in 1) do_backup ;; 2) do_restore ;; esac
}

# ------------------------------------------------------------------ main loop
menu() {
  while true; do
    show_menu
    read -rp "Please enter your selection [0-29]: " c
    echo
    case "$c" in
      0|q) exit 0 ;;
      1) do_reinstall; pause ;;        2) do_update; pause ;;          3) read -rp "File path or URL: " s; [ -n "$s" ] && do_update "$s"; pause ;;
      4) do_menu_update; pause ;;      5) do_rollback; pause ;;        6) do_uninstall; pause ;;
      7) do_password; pause ;;         8) do_unlock; pause ;;          9) do_reset_settings; pause ;;
      10) do_port; pause ;;            11) do_settings; pause ;;
      12) do_start; pause ;;           13) do_stop; pause ;;           14) do_restart; pause ;;
      15) do_restart_engines; pause ;; 16) do_status; pause ;;          17) do_logs; pause ;;
      18) do_autostart on; pause ;;    19) do_autostart off; pause ;;
      20) do_ssl; pause ;;             21) do_cloudflare; pause ;;     22) do_ips; pause ;;
      23) do_firewall; pause ;;        24) do_ssh; pause ;;            25) do_engines; pause ;;
      26) do_bbr; pause ;;             27) do_geo; pause ;;            28) do_speedtest; pause ;;
      29) do_data; pause ;;
      *) bad "Invalid choice"; sleep 1 ;;
    esac
  done
}

case "${1:-menu}" in
  menu) menu ;;                 status) do_status ;;          settings|info) do_settings ;;
  start) do_start ;;            stop) do_stop ;;              restart) do_restart ;;
  port) do_port ;;              password) do_password ;;      unlock) do_unlock ;;
  logs) journalctl -u vpnpanel -n 60 --no-pager ;;            backup) do_backup ;;
  update) do_update "${2:-}" ;; ssl) do_ssl ;;                ips) do_ips ;;
  firewall) do_firewall ;;      bind) do_ssh ;;               engines) do_engines ;;
  bbr) do_bbr ;;                geo) do_geo ;;                speedtest) do_speedtest ;;
  uninstall) do_uninstall ;;
  *) echo "Usage: tcm19 [status|settings|start|stop|restart|port|password|unlock|logs|backup|update [file|url]|ssl|ips|firewall|bind|engines|bbr|geo|speedtest|uninstall]" ;;
esac
